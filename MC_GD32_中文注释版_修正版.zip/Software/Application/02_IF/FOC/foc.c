/*
*******************************************************************************************************
*
* 文件名称 : foc.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : FOC核心算法库(Clark变换/Park变换/反Park变换/SVPWM/PI调节器)
* 
*******************************************************************************************************
*/


/* 头文件 ------------------------------------------------------------------------------------*/
#include "foc.h"  /* FOC算法接口与结构体类型定义 */

/* 宏定义 ------------------------------------------------------------------------------------------*/


/* 变量定义 ----------------------------------------------------------------------------------------*/


/* 函数定义 -----------------------------------------------------------------------------------------*/

/**
  * @brief Clark变换(三相静止坐标系变换到两相静止坐标系)
  * @param 无
  * @retval 无
  * @note ialpha = ia
  *       ibeta = (ia+2ib)/sqrt(3)
  */
void clark(pmsm_foc_t *foc)
{
    foc->ialpha = foc->ia;  /* α轴电流分量=A相电流 */
    foc->ibeta = (foc->ia * ONE_BY_SQRT3) + (foc->ib * 2 * ONE_BY_SQRT3);  /* β轴电流由A/B相电流合成 */
}

/**
  * @brief Park变换(两相静止坐标系变换到两相旋转坐标系)
  * @param 无
  * @retval 无
  * @note Id = ialpha*cos(theta) + ibeta*sin(theta)
  *       Iq = -ialpha*sin(theta) + ibeta*cos(theta)
  */
void park(pmsm_foc_t *foc)
{
    foc->id = (foc->ialpha * foc->cos) + (foc->ibeta * foc->sin);  /* d轴电流分量 */
    foc->iq = (foc->ibeta * foc->cos) - (foc->ialpha * foc->sin);  /* q轴电流分量 */
}

/**
  * @brief 反Park变换(两相旋转坐标系变换到两相静止坐标系)
  * @param 无
  * @retval 无
  * @note valpha = vd*cos(theta) - vq*sin(theta)
  *       vbeta  = vd*sin(theta) + vq*cos(theta)
  */
void inv_park(pmsm_foc_t *foc)
{
    foc->valpha = (foc->vd * foc->cos) - (foc->vq * foc->sin);  /* α轴电压分量 */
    foc->vbeta = (foc->vd * foc->sin) + (foc->vq * foc->cos);  /* β轴电压分量 */
}

/**
  * @brief 正余弦计算(根据电角度求sin/cos值)
  * @param 无
  * @retval 无
  * @note 
  */
void sin_cos(pmsm_foc_t *foc)
{
    foc->sin = arm_sin_f32(foc->angle);  /* 用DSP库求电角度正弦值 */
    foc->cos = arm_cos_f32(foc->angle);  /* 用DSP库求电角度余弦值 */
}

/**
  * @brief SVPWM空间矢量调制(扇区判断与三相比较点时间分配)
  * @param 无
  * @retval 无
  * @note 单电阻采样时为防止两相占空比相等导致采样窗口为0,占空比移相与触发点设置由single_shunt_cs.c完成(原版注:tb必须加1,本函数无tb变量,系模板遗留)
  */
void svpwm(pmsm_foc_t *foc)
{
    float vr1 = 0, vr2 = 0, vr3 = 0;  /* 扇区判定量 */
    float t1w = 0,t2w = 0;  /* 两个有效基本矢量的作用时间 */
    float t1 = 0, t2 = 0, t3 = 0;  /* 三相比较切换点(中心对齐) */

    vr1 = foc->vbeta;                                    /* 判定量vr1=β轴电压 */
    vr2 = (-foc->vbeta/2 + SQRT3_BY2 * foc->valpha);  /* 判定量vr2=-β/2+√3/2·α */
    vr3 = (-foc->vbeta/2 - SQRT3_BY2 * foc->valpha);  /* 判定量vr3=-β/2-√3/2·α */

    if(vr3 > 0)  /* 由vr1~vr3的符号组合判断电压矢量所在扇区 */
    {
        if(vr2 > 0)  /* vr3>0且vr2>0:扇区5 */
        {
            foc->sector = 5;  /* 记录扇区号为5 */

            t1w = foc->pwm_period * vr2;  /* 第一有效矢量作用时间(按vr2折算) */
            t2w = foc->pwm_period * vr3;  /* 第二有效矢量作用时间(按vr3折算) */

            t1 = (foc->pwm_period - t1w - t2w)/2;  /* t1为零矢量时间的一半(居中分配) */
            t2 = t1 + t1w;  /* t2为t1叠加第一矢量时间 */
            t3 = t2 + t2w;  /* t3为t2叠加第二矢量时间 */

            foc->pwma = t2;  /* A相比较值为t2 */
            foc->pwmb = t1;  /* B相比较值为t1 */
            foc->pwmc = t3;  /* C相比较值为t3 */
        }
        else
        {
            if(vr1 > 0)  /* vr3>0且vr2<=0且vr1>0:扇区3 */
            {
                foc->sector = 3;  /* 记录扇区号为3 */

                t1w = foc->pwm_period * vr3;  /* 第一有效矢量作用时间(按vr3折算) */
                t2w = foc->pwm_period * vr1;  /* 第二有效矢量作用时间(按vr1折算) */

                t1 = (foc->pwm_period - t1w - t2w)/2;  /* t1为零矢量时间的一半(居中分配) */
                t2 = t1 + t1w;  /* t2为t1叠加第一矢量时间 */
                t3 = t2 + t2w;  /* t3为t2叠加第二矢量时间 */

                foc->pwma = t1;  /* A相比较值为t1 */
                foc->pwmb = t3;  /* B相比较值为t3 */
                foc->pwmc = t2;  /* C相比较值为t2 */
            }
            else
            {
                foc->sector = 4;  /* vr3>0且vr2<=0且vr1<=0:扇区4 */

                t1w = foc->pwm_period * -vr2;  /* 第一有效矢量作用时间(按-vr2折算) */
                t2w = foc->pwm_period * -vr1;  /* 第二有效矢量作用时间(按-vr1折算) */

                t1 = (foc->pwm_period - t1w - t2w)/2;  /* t1为零矢量时间的一半(居中分配) */
                t2 = t1 + t1w;  /* t2为t1叠加第一矢量时间 */
                t3 = t2 + t2w;  /* t3为t2叠加第二矢量时间 */

                foc->pwma = t1;  /* A相比较值为t1 */
                foc->pwmb = t2;  /* B相比较值为t2 */
                foc->pwmc = t3;  /* C相比较值为t3 */
            }
        }
    }
    else
    {
        if(vr2 > 0)  /* vr3<=0且vr2>0 */
        {
            if(vr1 > 0)  /* vr3<=0且vr2>0且vr1>0:扇区1 */
            {
                foc->sector = 1;  /* 记录扇区号为1 */

                t1w = foc->pwm_period * vr1;  /* 第一有效矢量作用时间(按vr1折算) */
                t2w = foc->pwm_period * vr2;  /* 第二有效矢量作用时间(按vr2折算) */

                t1 = (foc->pwm_period - t1w - t2w)/2;  /* t1为零矢量时间的一半(居中分配) */
                t2 = t1 + t1w;  /* t2为t1叠加第一矢量时间 */
                t3 = t2 + t2w;  /* t3为t2叠加第二矢量时间 */

                foc->pwma = t3;  /* A相比较值为t3 */
                foc->pwmb = t2;  /* B相比较值为t2 */
                foc->pwmc = t1;  /* C相比较值为t1 */
            }
            else
            {
                foc->sector = 6;  /* vr3<=0且vr2>0且vr1<=0:扇区6 */

                t1w = foc->pwm_period * -vr1;  /* 第一有效矢量作用时间(按-vr1折算) */
                t2w = foc->pwm_period * -vr3;  /* 第二有效矢量作用时间(按-vr3折算) */

                t1 = (foc->pwm_period - t1w - t2w)/2;  /* t1为零矢量时间的一半(居中分配) */
                t2 = t1 + t1w;  /* t2为t1叠加第一矢量时间 */
                t3 = t2 + t2w;  /* t3为t2叠加第二矢量时间 */

                foc->pwma = t3;  /* A相比较值为t3 */
                foc->pwmb = t1;  /* B相比较值为t1 */
                foc->pwmc = t2;  /* C相比较值为t2 */
            }
        }
        else
        {
            foc->sector = 2;  /* vr3<=0且vr2<=0:扇区2 */

            t1w = foc->pwm_period * -vr3;  /* 第一有效矢量作用时间(按-vr3折算) */
            t2w = foc->pwm_period * -vr2;  /* 第二有效矢量作用时间(按-vr2折算) */

            t1 = (foc->pwm_period - t1w - t2w)/2;  /* t1为零矢量时间的一半(居中分配) */
            t2 = t1 + t1w;  /* t2为t1叠加第一矢量时间 */
            t3 = t2 + t2w;  /* t3为t2叠加第二矢量时间 */

            foc->pwma = t2;  /* A相比较值为t2 */
            foc->pwmb = t3;  /* B相比较值为t3 */
            foc->pwmc = t1;  /* C相比较值为t1 */
        }
    }
}

/**
  * @brief PI调节器初始化
  * @param 无
  * @retval 无
  * @note 
  */
void init_pi(pid_control_t *p_parm)
{
    p_parm->sum = 0;  /* 积分累加和清零 */
    p_parm->out = 0;  /* 输出值清零 */
}

/**
  * @brief PI调节器计算(带输出限幅与反计算抗积分饱和)
  * @param 无
  * @retval 无
  * @note 
  */
void calc_pi(pid_control_t *p_parm)
{
    float Err;    /* 误差(给定-反馈) */
    float U;      /* 未限幅的PI输出 */
    float Exc;    /* 饱和超出量(用于反计算抗饱和) */
    
    Err  = p_parm->ref - p_parm->meas;  /* 误差=给定值-反馈值 */
    p_parm->error =  Err;   /* 保存误差供外部使用 */
    U  = p_parm->sum + p_parm->kp * Err;  /* 未限幅输出=积分和+比例项 */
   
    if( U > p_parm->out_max)  /* 输出超过上限 */
    {
        p_parm->out = p_parm->out_max;  /* 输出限幅为上限值 */
    }    
    else if( U < p_parm->out_min)  /* 输出低于下限 */
    {
        p_parm->out = p_parm->out_min;  /* 输出限幅为下限值 */
    }
    else        
    {
        p_parm->out = U;    /* 输出在限幅范围内,直接取U */
    }
     
    Exc = U - p_parm->out;  /* 计算超出限幅的饱和量 */
    p_parm->sum = p_parm->sum + p_parm->ki * Err - p_parm->kc * Exc;  /* 积分和更新:累加ki*Err并扣除kc*Exc抗饱和 */
}

/* 局部函数 -----------------------------------------------------------------------------------*/


/***************************************** 文件结束 *********************************************/
