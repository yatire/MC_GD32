/*
*******************************************************************************************************
*
* 文件名称 : foc.h
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : FOC矢量控制核心算法库
* 
*******************************************************************************************************
*/
#ifndef _FOC_H_    /* 头文件保护宏 */
#define _FOC_H_    /* 定义头文件保护宏 */

#ifdef __cplusplus      /* 若使用C++编译器编译 */
extern "C"{             /* 以C语言方式编译链接，防止函数名被C++改名 */
#endif                  /* C++兼容声明结束 */

/* 头文件包含 ------------------------------------------------------------------------------------*/
#include <stdint.h>     /* 标准整数类型定义 */
#include "arm_math.h"   /* CMSIS-DSP库头文件(arm_sin_f32/arm_cos_f32等) */

/* 宏定义 ------------------------------------------------------------------------------------------*/
#define         SQRT3_BY2                       (float)0.866025403788  /* 定义sqrt(3)/2的值 */
#define         ONE_BY_SQRT3                    (float)0.5773502691    /* 定义1/sqrt(3)的值 */
#define         M_PI                                    (float)3.1415926535   /* 定义圆周率π的值 */

#define         ANGLE_2PI               (2*M_PI)               /* 定义2*PI(2π)的值 */
/* 类型定义 ------------------------------------------------------------------------------------------*/
typedef struct{
        float sum;          /* 积分累加项 */
        float kp;           /* 比例系数 */
        float ki;           /* 积分系数 */
        float kc;           /* 积分抗饱和回授系数 */
        float out_max;      /* 输出上限 */
        float out_min;      /* 输出下限 */
        float ref;          /* 给定值 */
        float meas;         /* 反馈(测量)值 */
        float out;          /* 调节器输出 */
    float error;        /* 偏差:给定-反馈 */
}pid_control_t;

typedef struct{
        float angle;        /* 电角度(弧度) */
        float sin;          /* 电角度正弦值 */
        float cos;          /* 电角度余弦值 */
        float ia;           /* A相电流 */
        float ib;           /* B相电流 */
    float ic;           /* C相电流 */
        float ialpha;       /* α轴电流(Clark变换输出) */
        float ibeta;        /* β轴电流(Clark变换输出) */
        float id;           /* d轴电流(Park变换输出) */
        float iq;           /* q轴电流(Park变换输出) */
        float vd;           /* d轴电压给定 */
        float vq;           /* q轴电压给定 */
        float valpha;       /* α轴电压(反Park变换输出) */
        float vbeta;        /* β轴电压(反Park变换输出) */
        
        /* PI调节器 */
        pid_control_t pi_d;     /* d轴电流环PI调节器 */
        pid_control_t pi_q;     /* q轴电流环PI调节器 */
        pid_control_t pi_w;     /* 速度环PI调节器 */
        
        /* SVPWM空间矢量调制 */
        float pwm_period;       /* PWM周期(定时器满计数值) */
        float pwma;             /* A相占空比(比较值) */
        float pwmb;             /* B相占空比(比较值) */
        float pwmc;             /* C相占空比(比较值) */
        uint8_t sector;         /* 电压矢量所在扇区(1~6) */
    
    float vdc;              /* 母线电压 */
    float max_phase_voltage;    /* 最大输出相电压(由母线电压决定) */
        
}pmsm_foc_t;

/* 变量定义 ----------------------------------------------------------------------------------------*/


/* 函数定义 -----------------------------------------------------------------------------------------*/
void sin_cos(pmsm_foc_t *foc);    /* 由电角度计算正余弦值 */
void inv_park(pmsm_foc_t *foc);   /* 反Park变换:dq轴电压变换到αβ轴 */
void park(pmsm_foc_t *foc);       /* Park变换:电流由αβ轴变换到dq轴 */
void clark(pmsm_foc_t *foc);      /* Clark变换:三相电流变换到αβ轴(利用ia+ib+ic=0简化) */
void svpwm(pmsm_foc_t *foc);      /* SVPWM:由αβ轴电压计算扇区与三相占空比 */
void init_pi(pid_control_t *p_parm);   /* PI调节器初始化(清积分与输出) */
void calc_pi(pid_control_t *p_parm);   /* PI调节器计算(含积分抗饱和与输出限幅) */

#ifdef __cplusplus      /* 若使用C++编译器编译(原文件遗留的重复代码块) */
extern "C"{             /* 以C语言方式编译链接 */
#endif                  /* C++兼容声明结束 */

#endif /* _FOC_H_ */   /* 头文件保护宏结束 */

/***************************************** 文件结束 *********************************************/
