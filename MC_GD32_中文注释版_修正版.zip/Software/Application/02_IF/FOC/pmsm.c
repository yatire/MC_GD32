/*
*******************************************************************************************************
*
* 文件名称 : pmsm.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : PMSM(永磁同步电机)驱动文件(I/F开环启动FOC实现)
*
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "pmsm.h"    /* PMSM应用接口与控制结构体定义 */
#include "foc.h"    /* FOC核心算法(Clark/Park/SVPWM/PI) */
#include "userparms.h"    /* 用户参数配置(PI参数/开环启动参数) */

/* 宏定义 ------------------------------------------------------------------------------------------*/


/* 变量定义 ----------------------------------------------------------------------------------------*/
pmsm_foc_t pmsm_foc_param;    /* FOC状态变量结构体(电流/电压/角度/PI等) */
pmsm_mc_t pmsm_mc_param;    /* PMSM电机控制参数及状态结构体 */

/* 函数定义 -----------------------------------------------------------------------------------------*/
static void pmsm_foc_init_control_parameters(void);    /* 控制参数初始化(电流环PI参数) */
static void calculate_park_angle(void);    /* Park角度计算(开环角度生成) */
static void pid_control(void);    /* 电流环PI控制 */

/**
  * @brief FOC初始化(复位控制参数与开环启动状态)
  * @param 无
  * @retval 无
  * @note
  */
void pmsm_foc_init(void)
{
	/* 控制参数初始化(原注释SMC Init系沿用SMO版本笔误,本版无滑模观测器) */
	
	pmsm_foc_init_control_parameters();    /* 初始化电流环PI控制参数 */
	
	pmsm_mc_param.run_motor = 1;    /* 置电机运行标志 */
	pmsm_mc_param.openloop = 1;    /* 置开环模式(I/F启动) */
	pmsm_mc_param.change_mode = 1;    /* 置模式切换标志(首次进入开环处理) */
	pmsm_mc_param.startup_lock_count = 0;    /* 预定位锁定计数清零 */
	pmsm_mc_param.startup_ramp = 0;    /* 开环角度斜坡增量清零 */
}

/**
  * @brief FOC主循环函数(每个控制周期调用一次)
  * @param 无
  * @retval 无
  * @note
  */
void pmsm_foc_run(void)
{
	clark(&pmsm_foc_param);    /* Clark变换(三相电流→两相αβ) */
	park(&pmsm_foc_param);    /* Park变换(αβ→dq旋转坐标系) */
    
	calculate_park_angle();    /* 计算Park变换用角度(开环生成) */
    
    pid_control();    /* 电流环PI调节 */
	
	sin_cos(&pmsm_foc_param);    /* 计算角度的正弦/余弦值 */
	
	inv_park(&pmsm_foc_param);    /* 反Park变换(dq→αβ电压) */
	
	svpwm(&pmsm_foc_param);    /* SVPWM空间矢量调制(计算三相占空比) */
}

/* 局部函数 -----------------------------------------------------------------------------------*/
/**
  * @brief 控制参数初始化(电流环PI参数)
  * @param 无
  * @retval 无
  * @note
  */
static void pmsm_foc_init_control_parameters(void)
{
	pmsm_foc_param.pi_d.kp = DKP;    /* d轴电流环比例系数 */
	pmsm_foc_param.pi_d.ki = DKI;    /* d轴电流环积分系数 */
	pmsm_foc_param.pi_d.kc = DKC;    /* d轴电流环抗积分饱和回算系数 */
	pmsm_foc_param.pi_d.out_max = DOUTMAX;    /* d轴PI输出上限(标幺值) */
	pmsm_foc_param.pi_d.out_min = -pmsm_foc_param.pi_d.out_max;    /* d轴PI输出下限=负的输出上限 */

	init_pi(&pmsm_foc_param.pi_d);    /* 复位d轴PI积分历史状态 */

	pmsm_foc_param.pi_q.kp = QKP;    /* q轴电流环比例系数 */
	pmsm_foc_param.pi_q.ki = QKI;    /* q轴电流环积分系数 */
	pmsm_foc_param.pi_q.kc = QKC;    /* q轴电流环抗积分饱和回算系数 */
	pmsm_foc_param.pi_q.out_max = QOUTMAX;    /* q轴PI输出上限(标幺值) */
	pmsm_foc_param.pi_q.out_min = -pmsm_foc_param.pi_d.out_max;    /* q轴PI输出下限=负的d轴上限(原代码取自pi_d,与q轴上限等值) */

	init_pi(&pmsm_foc_param.pi_q);    /* 复位q轴PI积分历史状态 */
}


/**
  * @brief Park角度计算(开环角度生成)
  * @param 无
  * @retval 无
  * @note
  */
static void calculate_park_angle(void)
{
	if(pmsm_mc_param.openloop)    /* 开环启动阶段:I/F电流拖动+频率斜升 */
	{
		/* 从预定位锁定序列开始,进行转子磁场对齐 */
		if(pmsm_mc_param.startup_lock_count < LOCK_COUNTER)    /* 预定位时间未到 */
		{
			pmsm_mc_param.startup_lock_count++;    /* 预定位计数累加 */
		}
		else if(pmsm_mc_param.startup_ramp < END_SPEED_RADS_ELEC_COUNTER)    /* 预定位完成:未达开环终止角度步进则继续加速 */
		{
			pmsm_mc_param.startup_ramp += OPENLOOP_RAMPSPEED_INCREASERATE;    /* 每周期增大开环角度增量 */
		}
		else    /* 已达开环终止速度 */
		{
#ifndef OPEN_LOOP_MODE    /* 未定义纯开环宏时:请求切入闭环 */
			pmsm_mc_param.change_mode = 1;    /* 置模式切换标志 */
			pmsm_mc_param.openloop = 0;    /* 退出开环,进入闭环 */
#endif    /* 结束条件编译(本工程已定义OPEN_LOOP_MODE,恒开环) */
		}
		pmsm_foc_param.angle += pmsm_mc_param.startup_ramp;    /* 开环角度按斜坡增量累加 */
        if(pmsm_foc_param.angle > ANGLE_2PI)    /* 角度大于2π */
            pmsm_foc_param.angle = pmsm_foc_param.angle - ANGLE_2PI;    /* 减2π归一化 */
	}
	else    /* 闭环阶段(空实现:本版无位置传感器闭环) */
	{
	}
}

/**
  * @brief PI电流环控制(开环I/F恒流给定)
  * @param 无
  * @retval 无
  * @note
  */
static void pid_control(void)
{
	if(pmsm_mc_param.openloop)    /* 开环阶段:I/F恒流给定,仅闭环电流环 */
	{
		if(pmsm_mc_param.change_mode)    /* 首次进入开环模式处理 */
		{
			pmsm_mc_param.change_mode = 0;    /* 清除模式切换标志 */
            pmsm_mc_param.id_ref = 0;    /* d轴电流给定清零 */
		}
        
        pmsm_mc_param.iq_ref = OPEN_LOOP_CURRENT;    /* q轴电流给定=开环电流(I/F恒流幅值) */
        
        /* q轴电流环PI调节 */
        pmsm_foc_param.pi_q.meas = pmsm_foc_param.iq;    /* q轴反馈电流 */
        pmsm_foc_param.pi_q.ref  = pmsm_mc_param.iq_ref;    /* q轴给定电流 */
        calc_pi(&pmsm_foc_param.pi_q);    /* q轴PI计算 */
        pmsm_foc_param.vq = pmsm_foc_param.pi_q.out;    /* PI输出作为q轴电压给定 */
       
        /* d轴电流环PI调节 */
        pmsm_foc_param.pi_d.meas = pmsm_foc_param.id;    /* d轴反馈电流 */
        pmsm_foc_param.pi_d.ref  = pmsm_mc_param.id_ref;    /* d轴给定电流 */
        calc_pi(&pmsm_foc_param.pi_d);    /* d轴PI计算 */
        pmsm_foc_param.vd = pmsm_foc_param.pi_d.out;    /* PI输出作为d轴电压给定 */
        
#ifdef OPEN_LOOP_VF_VQ    /* 若定义开环V/F固定电压宏(本工程未定义,不编译) */
        pmsm_foc_param.vq = OPEN_LOOP_VF_VQ;    /* q轴电压取固定宏值 */
        pmsm_foc_param.vd = 0;    /* d轴电压为0 */
#endif    /* 结束条件编译 */
        
	}
	else    /* 闭环阶段(空实现) */
	{

	}
}

/***************************************** (END OF FILE) *********************************************/
