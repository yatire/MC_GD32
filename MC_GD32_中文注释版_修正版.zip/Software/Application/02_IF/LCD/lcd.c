/*
*******************************************************************************************************
*
* 文件名称 : lcd.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : ST7789 LCD驱动：写命令/数据/区域填充/画点画线画圆/字符显示
*
*******************************************************************************************************
*/

#include "lcd.h" /* LCD驱动接口声明 */
#include "lcd_init.h" /* LCD初始化与底层写命令/写数据宏定义 */
#include "lcdfont.h" /* ASCII字模库 */
#include "systick.h" /* SysTick延时函数头文件 */


/******************************************************************************
      函数说明：在指定区域填充颜色
      入口数据：xsta,ysta   起始坐标
                xend,yend   终止坐标
								color       要填充的颜色
      返回值：  无
******************************************************************************/
void LCD_Fill(uint16_t xsta,uint16_t ysta,uint16_t xend,uint16_t yend,uint16_t color)
{          
	uint16_t i,j;  /* 行、列循环计数变量 */
	LCD_Address_Set(xsta,ysta,xend-1,yend-1);/* 设置显示范围 */
	for(i=ysta;i<yend;i++) /* 逐行扫描写入 */
	{													   	 	
		for(j=xsta;j<xend;j++) /* 逐列扫描写入 */
		{
			LCD_WR_DATA(color); /* 连续写入颜色数据填充区域 */
		}
	} 					  	    
}

/******************************************************************************
      函数说明：在指定位置画点
      入口数据：x,y 画点坐标
                color 点的颜色
      返回值：  无
******************************************************************************/
void LCD_DrawPoint(uint16_t x,uint16_t y,uint16_t color)
{
	LCD_Address_Set(x,y,x,y);/* 设置光标位置(单点写入窗口) */ 
	LCD_WR_DATA(color); /* 写入颜色数据完成画点 */
} 


/******************************************************************************
      函数说明：画线
      入口数据：x1,y1   起始坐标
                x2,y2   终止坐标
                color   线的颜色
      返回值：  无
******************************************************************************/
void LCD_DrawLine(uint16_t x1,uint16_t y1,uint16_t x2,uint16_t y2,uint16_t color)
{
	uint16_t t;  /* 循环计数 */
	int xerr=0,yerr=0,delta_x,delta_y,distance; /* x/y误差累计、坐标增量、主轴步进总距离 */
	int incx,incy,uRow,uCol; /* x/y单步方向、当前画点坐标 */
	delta_x=x2-x1; /* 计算x方向坐标增量 */ 
	delta_y=y2-y1; /* 计算y方向坐标增量 */
	uRow=x1;/* 画线起点坐标 */
	uCol=y1; /* 起点y坐标 */
	if(delta_x>0)incx=1; /* x正方向,单步+1 */ 
	else if (delta_x==0)incx=0;/* x增量为0即垂直线,单步0 */ 
	else {incx=-1;delta_x=-delta_x;} /* x负方向,增量取绝对值 */
	if(delta_y>0)incy=1; /* y正方向,单步+1 */
	else if (delta_y==0)incy=0;/* y增量为0即水平线,单步0 */ 
	else {incy=-1;delta_y=-delta_y;} /* y负方向,增量取绝对值 */
	if(delta_x>delta_y)distance=delta_x; /* 以x增量为主轴(长轴)决定步进次数 */ 
	else distance=delta_y; /* 否则以y增量为主轴 */
	for(t=0;t<distance+1;t++) /* 从起点到终点逐点绘制 */
	{
		LCD_DrawPoint(uRow,uCol,color);/* 画点 */
		xerr+=delta_x; /* 累计x方向误差 */
		yerr+=delta_y; /* 累计y方向误差 */
		if(xerr>distance) /* x误差超过主轴步进距离时 */
		{
			xerr-=distance; /* 误差回退一个步距 */
			uRow+=incx; /* x坐标前进一步 */
		}
		if(yerr>distance) /* y误差超过主轴步进距离时 */
		{
			yerr-=distance; /* 误差回退一个步距 */
			uCol+=incy; /* y坐标前进一步 */
		}
	}
}


/******************************************************************************
      函数说明：画矩形
      入口数据：x1,y1   起始坐标
                x2,y2   终止坐标
                color   矩形的颜色
      返回值：  无
******************************************************************************/
void LCD_DrawRectangle(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2,uint16_t color)
{
	LCD_DrawLine(x1,y1,x2,y1,color); /* 画上边 */
	LCD_DrawLine(x1,y1,x1,y2,color); /* 画左边 */
	LCD_DrawLine(x1,y2,x2,y2,color); /* 画下边 */
	LCD_DrawLine(x2,y1,x2,y2,color); /* 画右边 */
}


/******************************************************************************
      函数说明：画圆
      入口数据：x0,y0   圆心坐标
                r       半径
                color   圆的颜色
      返回值：  无
******************************************************************************/
void Draw_Circle(uint16_t x0,uint16_t y0,uint8_t r,uint16_t color)
{
	int a,b; /* 对称点坐标迭代变量 */
	a=0;b=r;	   /* 从(0,r)点开始迭代 */
	while(a<=b) /* 只遍历1/8圆弧,利用八对称性画出整圆 */
	{
		LCD_DrawPoint(x0-b,y0-a,color);             /* 对称点3 */           
		LCD_DrawPoint(x0+b,y0-a,color);             /* 对称点0 */           
		LCD_DrawPoint(x0-a,y0+b,color);             /* 对称点1 */                
		LCD_DrawPoint(x0-a,y0-b,color);             /* 对称点2 */             
		LCD_DrawPoint(x0+b,y0+a,color);             /* 对称点4 */               
		LCD_DrawPoint(x0+a,y0-b,color);             /* 对称点5 */
		LCD_DrawPoint(x0+a,y0+b,color);             /* 对称点6 */ 
		LCD_DrawPoint(x0-b,y0+a,color);             /* 对称点7 */
		a++; /* a从0起沿圆弧递增 */
		if((a*a+b*b)>(r*r))/* 判断理论圆弧是否内缩(a*a+b*b超过r*r) */
		{
			b--; /* 过冲时b回退1,使点贴近圆弧 */
		}
	}
}

/******************************************************************************
      函数说明：显示单个字符
      入口数据：x,y显示坐标
                num 要显示的字符
                fc 字的颜色
                bc 字的背景色
                sizey 字号
                mode:  0非叠加模式  1叠加模式
      返回值：  无
******************************************************************************/
void LCD_ShowChar(uint16_t x,uint16_t y,uint8_t num,uint16_t fc,uint16_t bc,uint8_t sizey,uint8_t mode)
{
	uint8_t temp,sizex,t,m=0; /* temp字模字节、sizex字符宽度、t位扫描序号、m列计数 */
	uint16_t i,TypefaceNum;/* i循环序号;TypefaceNum一个字符所占字节大小 */
	uint16_t x0=x; /* 保存起始x坐标,用于叠加模式换行回绕 */
	sizex=sizey/2; /* 字符宽度为字高的一半 */
	TypefaceNum=(sizex/8+((sizex%8)?1:0))*sizey; /* 字模总字节数=每行字节数×字高(行数) */
	num=num-' ';    /* 减去空格ASCII码,得到字模表偏移 */
	LCD_Address_Set(x,y,x+sizex-1,y+sizey-1);  /* 设置字符显示区域 */ 
	for(i=0;i<TypefaceNum;i++) /* 逐字节取出字模数据 */
	{ 
		if(sizey==12)temp=ascii_1206[num][i];		       /* 调用6x12字体 */
		else if(sizey==16)temp=ascii_1608[num][i];		 /* 调用8x16字体 */
		else if(sizey==24)temp=ascii_2412[num][i];		 /* 调用12x24字体 */
		else if(sizey==32)temp=ascii_3216[num][i];		 /* 调用16x32字体 */
		else return; /* 字号不支持则直接返回 */
		for(t=0;t<8;t++) /* 逐位扫描字模字节,每位对应一个像素 */
		{
			if(!mode)/* 非叠加模式 */
			{
				if(temp&(0x01<<t))LCD_WR_DATA(fc); /* 该位为1写入前景色 */
				else LCD_WR_DATA(bc); /* 该位为0写入背景色 */
				m++; /* 列计数加1 */
				if(m%sizex==0) /* 一行像素写完则跳出 */
				{
					m=0; /* 列计数清零 */
					break; /* 结束本字节扫描 */
				}
			}
			else/* 叠加模式 */
			{
				if(temp&(0x01<<t))LCD_DrawPoint(x,y,fc);/* 该位为1画一个前景色点 */
				x++; /* x坐标右移一个像素 */
				if((x-x0)==sizex) /* 一行像素写满 */
				{
					x=x0; /* 回到行首 */
					y++; /* 换到下一行 */
					break; /* 结束本字节扫描 */
				}
			}
		}
	}   	 	  
}


/******************************************************************************
      函数说明：显示字符串
      入口数据：x,y显示坐标
                *p 要显示的字符串
                fc 字的颜色
                bc 字的背景色
                sizey 字号
                mode:  0非叠加模式  1叠加模式
      返回值：  无
******************************************************************************/
void LCD_ShowString(uint16_t x,uint16_t y,const uint8_t *p,uint16_t fc,uint16_t bc,uint8_t sizey,uint8_t mode)
{         
	while(*p!='\0') /* 循环显示直到字符串结束符 */
	{       
		LCD_ShowChar(x,y,*p,fc,bc,sizey,mode); /* 逐个字符显示 */
		x+=sizey/2; /* x坐标右移一个字符宽度 */
		p++; /* 指向下一个字符 */
	}  
}


/******************************************************************************
      函数说明：整数幂运算(m的n次方,供数字显示函数取位使用)
      入口数据：m底数，n指数
      返回值：  m的n次方结果
******************************************************************************/
uint32_t mypow(uint8_t m,uint8_t n)
{
	uint32_t result=1;	  /* 乘积结果初值为1 */
	while(n--)result*=m; /* 连乘n次实现m的n次方 */
	return result; /* 返回m的n次方结果 */
}


/******************************************************************************
      函数说明：显示整数变量
      入口数据：x,y显示坐标
                num 要显示整数变量
                len 要显示的位数
                fc 字的颜色
                bc 字的背景色
                sizey 字号
      返回值：  无
******************************************************************************/
void LCD_ShowIntNum(uint16_t x,uint16_t y,uint16_t num,uint8_t len,uint16_t fc,uint16_t bc,uint8_t sizey)
{         	
	uint8_t t,temp; /* t位序号、temp当前位数字 */
	uint8_t enshow=0; /* 前导零抑制标志,1表示已遇到有效数字 */
	uint8_t sizex=sizey/2; /* 字符宽度 */
	for(t=0;t<len;t++) /* 从最高位到最低位逐位显示 */
	{
		temp=(num/mypow(10,len-t-1))%10; /* 取出当前位的十进制数字 */
		if(enshow==0&&t<(len-1)) /* 高位前导零处理(末位除外) */
		{
			if(temp==0) /* 该位仍为0 */
			{
				LCD_ShowChar(x+t*sizex,y,' ',fc,bc,sizey,0); /* 前导零以空格显示 */
				continue; /* 继续处理下一位 */
			}else enshow=1;  /* 遇到非零数字,停止前导零抑制 */
		 	 
		}
	 	LCD_ShowChar(x+t*sizex,y,temp+48,fc,bc,sizey,0); /* 数字加48转为ASCII码后显示 */
	}
} 


/******************************************************************************
      函数说明：显示两位小数变量
      入口数据：x,y显示坐标
                num 要显示小数变量
                len 要显示的位数
                fc 字的颜色
                bc 字的背景色
                sizey 字号
      返回值：  无
******************************************************************************/
void LCD_ShowFloatNum1(uint16_t x,uint16_t y,float num,uint8_t len,uint16_t fc,uint16_t bc,uint8_t sizey)
{         	
	uint8_t t,temp,sizex; /* t位序号、temp当前位数字、sizex字符宽度 */
	uint16_t num1; /* 放大100倍后的整数 */
	sizex=sizey/2; /* 字符宽度 */
	num1=num*100; /* 小数放大100倍,保留两位小数 */
	for(t=0;t<len;t++) /* 逐位显示 */
	{
		temp=(num1/mypow(10,len-t-1))%10; /* 取出当前位的十进制数字 */
		if(t==(len-2)) /* 到达小数点插入位置 */
		{
			LCD_ShowChar(x+(len-2)*sizex,y,'.',fc,bc,sizey,0); /* 在整数与小数部分之间显示小数点 */
			t++; /* 跳过小数点占位 */
			len+=1; /* 总显示位数加1(补偿小数点位) */
		}
	 	LCD_ShowChar(x+t*sizex,y,temp+48,fc,bc,sizey,0); /* 数字加48转为ASCII码后显示 */
	}
}


/******************************************************************************
      函数说明：显示图片
      入口数据：x,y起点坐标
                length 图片长度
                width  图片宽度
                pic[]  图片数组    
      返回值：  无
******************************************************************************/
void LCD_ShowPicture(uint16_t x,uint16_t y,uint16_t length,uint16_t width,const uint8_t pic[])
{
	uint16_t i,j; /* x/y方向循环计数 */
	uint32_t k=0; /* 图片数组索引 */
	LCD_Address_Set(x,y,x+length-1,y+width-1); /* 设置图片显示区域 */
	for(i=0;i<length;i++) /* 遍历x方向length个像素列 */
	{
		for(j=0;j<width;j++) /* 遍历y方向width个像素行 */
		{
			LCD_WR_DATA8(pic[k*2]); /* 写像素数据高8位 */
			LCD_WR_DATA8(pic[k*2+1]); /* 写像素数据低8位 */
			k++; /* 索引指向下一个像素 */
		}
	}			
}


