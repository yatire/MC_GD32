/*
*******************************************************************************************************
*
* 文件名称 : lcd_init.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : ST7789 LCD 底层驱动(GPIO/SPI 初始化、串行写时序、地址窗口设置与初始化命令序列)
*
*******************************************************************************************************
*/

#include "lcd_init.h" /* LCD 引脚宏定义与对外接口声明 */
#include "spi.h" /* SPI 外设初始化与收发接口 */
#include "systick.h" /* SysTick 延时函数接口 */

/******************************************************************************
      函数说明：LCD 控制引脚 GPIO 初始化
      入口数据：无
      返回值：  无
******************************************************************************/
void LCD_GPIO_Init(void)
{
    /*
    * LCD_BL--PC13(背光)
    * LCD_DC--PC14(数据/命令)
    * LCD_RST--PC15(复位)
    * SPI_CS--PC1(片选)
    */
    rcu_periph_clock_enable(RCU_GPIOC); /* 使能 GPIOC 外设时钟 */
    rcu_periph_clock_enable(RCU_GPIOB); /* 使能 GPIOB 外设时钟 */
    
    gpio_init(GPIOC, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_13); /* 背光引脚 LCD_BL(PC13) 推挽输出 */
    gpio_bit_write(GPIOC,GPIO_PIN_13,SET); /* 背光默认拉高：打开背光 */
    
    gpio_init(GPIOC, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_14); /* 数据/命令引脚 LCD_DC(PC14) 推挽输出 */
    gpio_bit_write(GPIOC,GPIO_PIN_14,SET); /* 默认拉高：处于数据状态 */
    
    gpio_init(GPIOC, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_15); /* 复位引脚 LCD_RST(PC15) 推挽输出 */
    gpio_bit_write(GPIOC,GPIO_PIN_15,SET); /* 默认拉高：释放复位 */
    
    gpio_init(GPIOC, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_1); /* 片选引脚 SPI_CS(PC1) 推挽输出 */
    gpio_bit_write(GPIOC,GPIO_PIN_1,SET); /* 默认拉高：未选中 LCD */
}

/******************************************************************************
      函数说明：简易软件延时(空循环计数)
      入口数据：t  空循环次数(延时时间与主频有关)
      返回值：  无
******************************************************************************/
void delay(int t)
{
	while(t--); /* 空循环递减计数，消耗 CPU 周期实现延时 */
}
/******************************************************************************
      函数说明：LCD串行数据写入函数
      入口数据：dat  要写入的串行数据
      返回值：  无
******************************************************************************/
void LCD_Writ_Bus(uint8_t dat) 
{	
	LCD_CS_Clr(); /* 拉低片选，选中 LCD */
    spi2_transmit_receive_data(dat); /* 启动 SPI2 硬件收发，串行发出一个字节 */
	LCD_CS_Set(); /* 拉高片选，结束本次传输 */
}

/******************************************************************************
      函数说明：LCD写入数据
      入口数据：dat 写入的数据
      返回值：  无
******************************************************************************/
void LCD_WR_DATA8(uint8_t dat)
{
	LCD_Writ_Bus(dat); /* 经 SPI 总线写入 8 位数据 */
}


/******************************************************************************
      函数说明：LCD写入数据
      入口数据：dat 写入的数据
      返回值：  无
******************************************************************************/
void LCD_WR_DATA(uint16_t dat)
{
	LCD_Writ_Bus(dat>>8); /* 先写高 8 位 */
	LCD_Writ_Bus(dat); /* 再写低 8 位，组成 16 位数据 */
}


/******************************************************************************
      函数说明：LCD写入命令
      入口数据：dat 写入的命令
      返回值：  无
******************************************************************************/
void LCD_WR_REG(uint8_t dat)
{
	LCD_DC_Clr();/* 写命令：DC 拉低表示命令 */
	LCD_Writ_Bus(dat); /* 发送命令字节 */
	LCD_DC_Set();/* 恢复 DC 高电平，切回数据状态 */
}


/******************************************************************************
      函数说明：设置起始和结束地址
      入口数据：x1,x2 设置列的起始和结束地址
                y1,y2 设置行的起始和结束地址
      返回值：  无
******************************************************************************/
void LCD_Address_Set(uint16_t x1,uint16_t y1,uint16_t x2,uint16_t y2)
{
	if(USE_HORIZONTAL==0) /* 竖屏(0°)：列偏移52，行偏移40 */
	{
		LCD_WR_REG(0x2a);/* 列地址设置命令(0x2A) */
		LCD_WR_DATA(x1+52); /* 设置列起始地址(含偏移52) */
		LCD_WR_DATA(x2+52); /* 设置列结束地址 */
		LCD_WR_REG(0x2b);/* 行地址设置命令(0x2B) */
		LCD_WR_DATA(y1+40); /* 设置行起始地址(含偏移40) */
		LCD_WR_DATA(y2+40); /* 设置行结束地址 */
		LCD_WR_REG(0x2c);/* 存储器写命令(0x2C)：随后向窗口写入像素 */
	}
	else if(USE_HORIZONTAL==1) /* 竖屏(旋转180°)：列偏移53，行偏移40 */
	{
		LCD_WR_REG(0x2a);/* 列地址设置命令(0x2A) */
		LCD_WR_DATA(x1+53); /* 设置列起始地址(含偏移53) */
		LCD_WR_DATA(x2+53); /* 设置列结束地址 */
		LCD_WR_REG(0x2b);/* 行地址设置命令(0x2B) */
		LCD_WR_DATA(y1+40); /* 设置行起始地址(含偏移40) */
		LCD_WR_DATA(y2+40); /* 设置行结束地址 */
		LCD_WR_REG(0x2c);/* 存储器写命令(0x2C)：随后向窗口写入像素 */
	}
	else if(USE_HORIZONTAL==2) /* 横屏(0°)：列偏移40，行偏移53 */
	{
		LCD_WR_REG(0x2a);/* 列地址设置命令(0x2A) */
		LCD_WR_DATA(x1+40); /* 设置列起始地址(含偏移40) */
		LCD_WR_DATA(x2+40); /* 设置列结束地址 */
		LCD_WR_REG(0x2b);/* 行地址设置命令(0x2B) */
		LCD_WR_DATA(y1+53); /* 设置行起始地址(含偏移53) */
		LCD_WR_DATA(y2+53); /* 设置行结束地址 */
		LCD_WR_REG(0x2c);/* 存储器写命令(0x2C)：随后向窗口写入像素 */
	}
	else /* 横屏(旋转180°)：列偏移40，行偏移52 */
	{
		LCD_WR_REG(0x2a);/* 列地址设置命令(0x2A) */
		LCD_WR_DATA(x1+40); /* 设置列起始地址(含偏移40) */
		LCD_WR_DATA(x2+40); /* 设置列结束地址 */
		LCD_WR_REG(0x2b);/* 行地址设置命令(0x2B) */
		LCD_WR_DATA(y1+52); /* 设置行起始地址(含偏移52) */
		LCD_WR_DATA(y2+52); /* 设置行结束地址 */
		LCD_WR_REG(0x2c);/* 存储器写命令(0x2C)：随后向窗口写入像素 */
	}
}

/******************************************************************************
      函数说明：LCD 复位与 ST7789 初始化命令序列
      入口数据：无
      返回值：  无
******************************************************************************/
void LCD_Init(void)
{
	LCD_GPIO_Init();/* 初始化 LCD 控制引脚 GPIO */
	spi2_init();    /* 初始化 SPI2 硬件外设 */
	LCD_RES_Clr();  /* 拉低复位引脚，开始硬件复位 */
	systick_delay(100); /* 保持复位低电平 100ms */
	LCD_RES_Set(); /* 释放复位，LCD 开始内部上电初始化 */
	systick_delay(100); /* 等待复位与内部初始化完成 */
	
	LCD_BLK_Set();/* 打开背光 */
    systick_delay(100); /* 背光稳定延时 */
	
	LCD_WR_REG(0x11); /* 退出睡眠模式(Sleep Out) */
	systick_delay(120); /* 手册要求延时 120ms，等待内部时钟稳定 */
	LCD_WR_REG(0x36); /* 存储器数据访问控制(MADCTL：扫描/镜像方向) */
	if(USE_HORIZONTAL==0)LCD_WR_DATA8(0x00); /* 竖屏(0°) */
	else if(USE_HORIZONTAL==1)LCD_WR_DATA8(0xC0); /* 竖屏(旋转180°) */
	else if(USE_HORIZONTAL==2)LCD_WR_DATA8(0x70); /* 横屏(0°) */
	else LCD_WR_DATA8(0xA0); /* 横屏(旋转180°) */

	LCD_WR_REG(0x3A); /* 接口像素格式设置命令 */
	LCD_WR_DATA8(0x05); /* 0x05：16位/像素(RGB565) */

	LCD_WR_REG(0xB2); /* 前后肩(Porch)时序设置命令 */
	LCD_WR_DATA8(0x0C); /* 正常模式：后肩(BackPorch)=12行 */
	LCD_WR_DATA8(0x0C); /* 正常模式：前肩(FrontPorch)=12行 */
	LCD_WR_DATA8(0x00); /* 空闲模式：后肩/前肩=0行 */
	LCD_WR_DATA8(0x33); /* 部分模式：后肩=0x33 */
	LCD_WR_DATA8(0x33); /* 部分模式：前肩=0x33 */

	LCD_WR_REG(0xB7); /* 栅极驱动电压控制命令 */
	LCD_WR_DATA8(0x35);  /* VGH=13.26V，VGL=-10.43V */

	LCD_WR_REG(0xBB); /* VCOM 电压设置命令 */
	LCD_WR_DATA8(0x19); /* VCOM=0.725V */

	LCD_WR_REG(0xC0); /* LCM 控制命令 */
	LCD_WR_DATA8(0x2C); /* LCM 控制参数(手册推荐值) */

	LCD_WR_REG(0xC2); /* VDV 与 VRH 命令使能 */
	LCD_WR_DATA8(0x01); /* 使能 VDV/VRH 寄存器写入 */

	LCD_WR_REG(0xC3); /* VRH(GVDD) 电压设置命令 */
	LCD_WR_DATA8(0x12);   /* GVDD=4.45V */

	LCD_WR_REG(0xC4); /* VDV 电压设置命令 */
	LCD_WR_DATA8(0x20);  /* VDV=0V */

	LCD_WR_REG(0xC6); /* 帧率控制命令 */
	LCD_WR_DATA8(0x0F);    /* 正常模式帧率 60Hz */

	LCD_WR_REG(0xD0); /* 电源控制1命令 */
	LCD_WR_DATA8(0xA4); /* 常规电源使能(固定值) */
	LCD_WR_DATA8(0xA1); /* 电源档位选择(AVDD/AVCL/VDS) */

	LCD_WR_REG(0xE0); /* 正极性 Gamma 校正命令 */
	LCD_WR_DATA8(0xD0); /* 正Gamma校正点 RP0 */
	LCD_WR_DATA8(0x04); /* 正Gamma校正点 RP1 */
	LCD_WR_DATA8(0x0D); /* 正Gamma校正点 RP2 */
	LCD_WR_DATA8(0x11); /* 正Gamma校正点 RP3 */
	LCD_WR_DATA8(0x13); /* 正Gamma校正点 RP4 */
	LCD_WR_DATA8(0x2B); /* 正Gamma校正点 RP5 */
	LCD_WR_DATA8(0x3F); /* 正Gamma校正点 RP6 */
	LCD_WR_DATA8(0x54); /* 正Gamma校正点 RP7 */
	LCD_WR_DATA8(0x4C); /* 正Gamma校正点 RP8 */
	LCD_WR_DATA8(0x18); /* 正Gamma校正点 RP9 */
	LCD_WR_DATA8(0x0D); /* 正Gamma校正点 RP10 */
	LCD_WR_DATA8(0x0B); /* 正Gamma校正点 RP11 */
	LCD_WR_DATA8(0x1F); /* 正Gamma校正点 RP12 */
	LCD_WR_DATA8(0x23); /* 正Gamma校正点 RP13 */

	LCD_WR_REG(0xE1); /* 负极性 Gamma 校正命令 */
	LCD_WR_DATA8(0xD0); /* 负Gamma校正点 RN0 */
	LCD_WR_DATA8(0x04); /* 负Gamma校正点 RN1 */
	LCD_WR_DATA8(0x0C); /* 负Gamma校正点 RN2 */
	LCD_WR_DATA8(0x11); /* 负Gamma校正点 RN3 */
	LCD_WR_DATA8(0x13); /* 负Gamma校正点 RN4 */
	LCD_WR_DATA8(0x2C); /* 负Gamma校正点 RN5 */
	LCD_WR_DATA8(0x3F); /* 负Gamma校正点 RN6 */
	LCD_WR_DATA8(0x44); /* 负Gamma校正点 RN7 */
	LCD_WR_DATA8(0x51); /* 负Gamma校正点 RN8 */
	LCD_WR_DATA8(0x2F); /* 负Gamma校正点 RN9 */
	LCD_WR_DATA8(0x1F); /* 负Gamma校正点 RN10 */
	LCD_WR_DATA8(0x1F); /* 负Gamma校正点 RN11 */
	LCD_WR_DATA8(0x20); /* 负Gamma校正点 RN12 */
	LCD_WR_DATA8(0x23); /* 负Gamma校正点 RN13 */

	LCD_WR_REG(0x21); /* 开启显示反色(反显) */

	LCD_WR_REG(0x29); /* 开启显示(Display ON)，初始化完成 */
}








