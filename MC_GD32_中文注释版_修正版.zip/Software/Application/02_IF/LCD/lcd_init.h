/*
*******************************************************************************************************
*
* 文件名称 : lcd_init.h
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : LCD 屏幕驱动头文件(引脚宏定义与初始化接口声明)
*
*******************************************************************************************************
*/

#ifndef __LCD_INIT_H    /* 头文件保护宏：防止重复包含 */
#define __LCD_INIT_H    /* 定义头文件保护宏 */

#include "gd32f30x.h"   /* GD32F30x 固件库总头文件 */

#define USE_HORIZONTAL 2  /* 设置横屏或者竖屏显示 0或1为竖屏 2或3为横屏 */


#if USE_HORIZONTAL==0||USE_HORIZONTAL==1    /* 竖屏：屏宽135，屏高240 */
#define LCD_W 135   /* LCD 屏幕宽度(像素) */
#define LCD_H 240   /* LCD 屏幕高度(像素) */

#else                                       /* 横屏：屏宽240，屏高135 */
#define LCD_W 240   /* LCD 屏幕宽度(像素) */
#define LCD_H 135   /* LCD 屏幕高度(像素) */
#endif  /* 屏幕方向配置结束 */



/* -----------------LCD端口定义---------------- */ 

#define LCD_RES_Clr()  gpio_bit_write(GPIOC,GPIO_PIN_15,RESET)  /* 复位引脚(PC15)拉低：复位LCD */
#define LCD_RES_Set()  gpio_bit_write(GPIOC,GPIO_PIN_15,SET)    /* 复位引脚(PC15)拉高：释放复位 */

#define LCD_DC_Clr()   gpio_bit_write(GPIOC,GPIO_PIN_14,RESET)  /* 数据/命令引脚(PC14)拉低：发命令 */
#define LCD_DC_Set()   gpio_bit_write(GPIOC,GPIO_PIN_14,SET)    /* 数据/命令引脚(PC14)拉高：发数据 */
                     
#define LCD_CS_Clr()   gpio_bit_write(GPIOC,GPIO_PIN_1,RESET)   /* 片选引脚(PC1)拉低：选中芯片 */
#define LCD_CS_Set()   gpio_bit_write(GPIOC,GPIO_PIN_1,SET)     /* 片选引脚(PC1)拉高：取消选中 */

#define LCD_BLK_Clr()  gpio_bit_write(GPIOC,GPIO_PIN_13,RESET)  /* 背光引脚(PC13)拉低：关闭背光 */
#define LCD_BLK_Set()  gpio_bit_write(GPIOC,GPIO_PIN_13,SET)    /* 背光引脚(PC13)拉高：打开背光 */



void LCD_GPIO_Init(void);/* 初始化GPIO */
void LCD_Writ_Bus(uint8_t dat);/* 经硬件SPI2发送一个字节 */
void LCD_WR_DATA8(uint8_t dat);/* 写入一个8位字节 */
void LCD_WR_DATA(uint16_t dat);/* 写入一个16位数据(两个字节) */
void LCD_WR_REG(uint8_t dat);/* 写入一个8位指令 */
void LCD_Address_Set(uint16_t x1,uint16_t y1,uint16_t x2,uint16_t y2);/* 设置绘图窗口坐标区域 */
void LCD_Init(void);/* LCD初始化 */
#endif  /* 头文件保护宏结束 */




