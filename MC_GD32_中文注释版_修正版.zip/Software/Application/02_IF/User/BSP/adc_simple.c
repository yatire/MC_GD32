/*
*******************************************************************************************************
*
* 文件名称 : adc_simple.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : ADC驱动文件
*
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "adc_simple.h"    /* 简易ADC采样驱动头文件(接口声明) */
#include "systick.h"    /* 系统节拍定时器头文件(systick_delay毫秒延时函数) */

/* 宏定义 ------------------------------------------------------------------------------------------*/


/* 变量定义 ----------------------------------------------------------------------------------------*/


/* 函数定义 -----------------------------------------------------------------------------------------*/


/**
  * @brief ADC1初始化
  * @param 无
  * @retval 无
  */
void adc1_init(void)    /* ADC1初始化:GPIO/时钟/模式/触发/校准 */
{
    /* GPIO初始化 */
    rcu_periph_clock_enable(RCU_GPIOA);    /* 使能GPIOA端口时钟(NTC采样引脚PA7) */
    rcu_periph_clock_enable(RCU_GPIOC);    /* 使能GPIOC端口时钟(母线电压采样引脚PC4) */
    gpio_init(GPIOA, GPIO_MODE_AIN, GPIO_OSPEED_MAX, GPIO_PIN_7);    /* NTC温度采样引脚(PA7/通道7)配置为模拟输入 */
    gpio_init(GPIOC, GPIO_MODE_AIN, GPIO_OSPEED_MAX, GPIO_PIN_4);    /* 母线电压采样引脚(PC4/通道14)配置为模拟输入 */
    
    /* 使能ADC时钟 */
    rcu_periph_clock_enable(RCU_ADC1);    /* 使能ADC1外设时钟 */
    /* 配置ADC时钟分频 */
    rcu_adc_clock_config(RCU_CKADC_CKAPB2_DIV2);    /* ADC时钟为APB2时钟2分频 */
    
    /* ADC工作模式配置 */
    adc_mode_config(ADC_MODE_FREE);    /* 独立模式:ADC1单独工作,不与其他ADC同步 */
    /* ADC数据对齐方式配置 */
    adc_data_alignment_config(ADC1, ADC_DATAALIGN_RIGHT);    /* 转换结果右对齐 */
    /* ADC规则组通道长度配置 */
    adc_channel_length_config(ADC1, ADC_REGULAR_CHANNEL, 1U);    /* 规则组通道长度为1,每次转换1个通道 */
    
    /* ADC触发源配置 */
    /* 规则组外部触发源选择NONE:不使用硬件触发,由软件触发转换 */
    adc_external_trigger_source_config(ADC1, ADC_REGULAR_CHANNEL, ADC0_1_2_EXTTRIG_REGULAR_NONE); 
    /* ADC外部触发配置 */
    adc_external_trigger_config(ADC1, ADC_REGULAR_CHANNEL, ENABLE);    /* 使能规则组触发(配合NONE源即软件触发) */

    /* 使能ADC外设接口 */
    adc_enable(ADC1);    /* 开启ADC1 */
    systick_delay(1U);    /* 延时1ms等待ADC上电稳定 */
    /* ADC校准与复位校准 */
    adc_calibration_enable(ADC1);    /* 复位校准并启动ADC自校准 */
}

/**
  * @brief ADC采样母线电压
  * @param 无
  * @retval 无
  */
uint16_t adc_get_vdc(void)    /* 采样母线电压,返回12位ADC原始值 */
{
    /* ADC规则组通道配置 */
    /* 规则组次序0挂接母线电压通道14(PC4),采样时间7.5个ADC时钟周期 */
    adc_regular_channel_config(ADC1, 0U, ADC_CHANNEL_14, ADC_SAMPLETIME_7POINT5);
    /* ADC软件触发使能 */
    adc_software_trigger_enable(ADC1, ADC_REGULAR_CHANNEL);    /* 软件触发规则组开始一次转换 */

    /* 等待转换完成标志 */
    while(!adc_flag_get(ADC1, ADC_FLAG_EOC));    /* 死等EOC(转换结束)标志置位 */
    /* 清除转换完成标志 */
    adc_flag_clear(ADC1, ADC_FLAG_EOC);    /* 清除EOC标志 */
    /* 返回规则组通道采样值 */
    return (adc_regular_data_read(ADC1));    /* 读取规则组数据寄存器,12位结果0~4095 */
}

/**
  * @brief ADC采样NTC温度
  * @param 无
  * @retval 无
  */
uint16_t adc_get_ntc(void)    /* 采样NTC温度,返回12位ADC原始值 */
{
    /* ADC规则组通道配置 */
    /* 规则组次序0挂接NTC温度通道7(PA7),采样时间7.5个ADC时钟周期 */
    adc_regular_channel_config(ADC1, 0U, ADC_CHANNEL_7, ADC_SAMPLETIME_7POINT5);
    /* ADC软件触发使能 */
    adc_software_trigger_enable(ADC1, ADC_REGULAR_CHANNEL);    /* 软件触发规则组开始一次转换 */

    /* 等待转换完成标志 */
    while(!adc_flag_get(ADC1, ADC_FLAG_EOC));    /* 死等EOC(转换结束)标志置位 */
    /* 清除转换完成标志 */
    adc_flag_clear(ADC1, ADC_FLAG_EOC);    /* 清除EOC标志 */
    /* 返回规则组通道采样值 */
    return (adc_regular_data_read(ADC1));    /* 读取规则组数据寄存器,12位结果0~4095 */
}

/* 局部函数 -----------------------------------------------------------------------------------*/
/* 注:以下文档块为空模板,本文件当前没有局部(静态)函数 */
/**
  * @brief 
  * @param 无
  * @retval 无
  */


/***************************************** 文件结束 *********************************************/
