/*
*******************************************************************************************************
*
* 文件名称 : can.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : CAN总线驱动文件
*
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "can.h"                                     /* CAN总线驱动头文件(CAN_BAUDRATE波特率宏与接口声明) */

/* 宏定义 ------------------------------------------------------------------------------------------*/


/* 变量定义 ----------------------------------------------------------------------------------------*/


/* 函数定义 -----------------------------------------------------------------------------------------*/
static void can_gpio_config(void);                   /* CAN收发引脚GPIO配置函数声明 */
static void can_nvic_config(void);                   /* CAN接收中断NVIC配置函数声明 */
static void can_config(void);                        /* CAN外设工作参数与过滤器配置函数声明 */

/**
  * @brief CAN总线初始化
  * @param 无
  * @retval 无
  */
void can_bus_init(void)
{
    can_gpio_config();                               /* 配置CAN收发引脚GPIO */
    can_nvic_config();                               /* 配置CAN接收中断NVIC */
    can_config();                                    /* 配置CAN外设工作参数与过滤器 */

    can_interrupt_enable(CAN0, CAN_INT_RFNE0);       /* 使能CAN0接收FIFO0非空中断(收到报文触发中断) */
}



/* 局部函数定义 -----------------------------------------------------------------------------------*/
/*!
    \brief      配置GPIO
    \param[in]  无
    \param[out] 无
    \retval     无
*/
static void can_gpio_config(void)
{
    /* 使能GPIO时钟 */
    rcu_periph_clock_enable(RCU_GPIOA);              /* 使能GPIOA外设时钟 */
    
    /* 配置CAN0收发引脚 */
    gpio_init(GPIOA,GPIO_MODE_IPU,GPIO_OSPEED_50MHZ,GPIO_PIN_11);    /* PA11配置为上拉输入，CAN0_RX接收引脚 */
    gpio_init(GPIOA,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,GPIO_PIN_12);    /* PA12配置为复用推挽输出，CAN0_TX发送引脚 */
}

/*!
    \brief      配置嵌套向量中断控制器(NVIC)
    \param[in]  无
    \param[out] 无
    \retval     无
*/
static void can_nvic_config(void)
{
    /* 配置CAN0 NVIC */
    nvic_irq_enable(USBD_LP_CAN0_RX0_IRQn,1,1);      /* 使能USBD_LP/CAN0_RX0共享中断，抢占优先级1，子优先级1 */
}

/*!
    \brief      初始化CAN外设和过滤器
    \param[in]  无(函数无输入参数)
    \param[out] 无
    \retval     无
*/
static void can_config(void)
{
    can_parameter_struct            can_parameter;       /* CAN初始化参数结构体 */
    can_filter_parameter_struct     can_filter;          /* CAN过滤器参数结构体 */
    can_struct_para_init(CAN_INIT_STRUCT, &can_parameter);    /* 将CAN初始化参数结构体成员填充为默认值 */
    can_struct_para_init(CAN_FILTER_STRUCT, &can_filter);    /* 将过滤器参数结构体成员填充为默认值 */
    
    rcu_periph_clock_enable(RCU_CAN0);                   /* 使能CAN0外设时钟 */
    
    /* 初始化CAN寄存器 */
    can_deinit(CAN0);                                    /* 复位CAN0外设寄存器到默认值 */
    
    /* 初始化CAN参数 */
    can_parameter.time_triggered = DISABLE;              /* 禁止时间触发通信模式 */
    can_parameter.auto_bus_off_recovery = ENABLE;        /* 使能自动离线(BUS-OFF)恢复 */
    can_parameter.auto_wake_up = DISABLE;                /* 禁止自动唤醒 */
    can_parameter.auto_retrans = ENABLE;                 /* 使能自动重传(发送失败自动重发) */
    can_parameter.rec_fifo_overwrite = DISABLE;          /* 禁止接收FIFO覆写(FIFO满后丢弃新报文) */
    can_parameter.trans_fifo_order = DISABLE;            /* 禁止发送FIFO按请求顺序发送(按ID优先级发送) */
    can_parameter.working_mode = CAN_NORMAL_MODE;        /* 工作模式：正常模式 */
    can_parameter.resync_jump_width = CAN_BT_SJW_1TQ;    /* 再同步跳跃宽度SJW = 1个时间单元 */
    can_parameter.time_segment_1 = CAN_BT_BS1_7TQ;       /* 位时段1 = 7个时间单元 */
    can_parameter.time_segment_2 = CAN_BT_BS2_2TQ;       /* 位时段2 = 2个时间单元(位时间=1+7+2=10TQ) */
    
    /* 1MBps */
#if CAN_BAUDRATE == 1000                             /* 波特率为1000kbps时 */
    can_parameter.prescaler = 6;                     /* 预分频系数6：60MHz/6/10TQ = 1Mbps */
    /* 500KBps */
#elif CAN_BAUDRATE == 500                            /* 波特率为500kbps时 */
    can_parameter.prescaler = 12;                    /* 预分频系数12：60MHz/12/10TQ = 500kbps */
    /* 250KBps */
#elif CAN_BAUDRATE == 250                            /* 波特率为250kbps时 */
    can_parameter.prescaler = 24;                    /* 预分频系数24 */
    /* 125KBps */
#elif CAN_BAUDRATE == 125                            /* 波特率为125kbps时 */
    can_parameter.prescaler = 48;                    /* 预分频系数48 */
    /* 100KBps */
#elif  CAN_BAUDRATE == 100                           /* 波特率为100kbps时 */
    can_parameter.prescaler = 60;                    /* 预分频系数60 */
    /* 50KBps */
#elif  CAN_BAUDRATE == 50                            /* 波特率为50kbps时 */
    can_parameter.prescaler = 120;                   /* 预分频系数120 */
    /* 20KBps */
#elif  CAN_BAUDRATE == 20                            /* 波特率为20kbps时 */
    can_parameter.prescaler = 300;                   /* 预分频系数300 */
#else
    #error "please select list can baudrate in private defines in main.c "           /* 请在main.c中选择CAN波特率 */
#endif  /* 波特率选择条件编译结束 */
    /* 初始化CAN */
    can_init(CAN0, &can_parameter);                  /* 按配置参数初始化CAN0外设 */
    
    /* 初始化过滤器 */ 
    can_filter.filter_number=0;                      /* 使用过滤器组0 */
    can_filter.filter_mode = CAN_FILTERMODE_MASK;    /* 过滤器模式：掩码模式 */
    can_filter.filter_bits = CAN_FILTERBITS_32BIT;   /* 过滤器位宽：32位 */
    can_filter.filter_list_high = 0x0000;            /* 过滤列表高16位 = 0 */
    can_filter.filter_list_low = 0x0000;             /* 过滤列表低16位 = 0 */
    can_filter.filter_mask_high = 0x0000;            /* 掩码高16位 = 0(不比较) */
    can_filter.filter_mask_low = 0x0000;             /* 掩码低16位 = 0(不比较，接收所有ID的报文) */
    can_filter.filter_fifo_number = CAN_FIFO0;       /* 匹配的报文存入接收FIFO0 */
    can_filter.filter_enable = ENABLE;               /* 使能该过滤器 */
    
    can_filter_init(&can_filter);                    /* 按配置参数初始化CAN过滤器 */
}

/***************************************** 文件结束 *********************************************/
