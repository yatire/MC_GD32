/*
 * 版权所有 (c) 2023, Texas Instruments Incorporated(德州仪器)
 * 保留所有权利。
 *
 * 在满足以下条件的前提下, 允许以源码和二进制形式重新分发和使用本软件(无论是否修改):
 *
 * *  以源码形式重新分发时, 必须保留上述版权声明、本条件列表及以下免责声明。
 *
 * *  以二进制形式重新分发时, 必须在随发布的文档和/或其他材料中复制上述版权声明、
 *    本条件列表及以下免责声明。
 *
 * *  未经Texas Instruments Incorporated或其贡献者事先书面许可, 不得以其名义
 *    为本软件的衍生产品做背书或推广。
 *
 * 本软件由版权持有者及贡献者"按原样"提供, 不提供任何明示或默示的保证, 包括但不限于
 * 对适销性和特定用途适用性的默示保证。在任何情况下, 无论因何原因(合同、严格责任或
 * 侵权行为)以及无论是否已被告知存在此类损害的可能性, 版权持有者或贡献者均不对任何
 * 直接、间接、偶然、特殊、惩戒性或后果性损害(包括但不限于替代商品或服务的采购、
 * 使用、数据或利润的损失、或业务中断)承担责任。
 */
/*!****************************************************************************
 *  @file       drv8323rs.h
 *  @brief      无感FOC电机控制库 DRV8323RS 电机驱动模块
 *
 *
 *  @anchor drv8323rs_h
 *  # 概述
 *
 *  DRV8323RS 的应用程序接口(API)
 *
 *  <hr>
 ******************************************************************************/

/** @defgroup MD_MODULE 电机驱动器/DRV8323RS模块
 * @{
 */
#ifndef DRV8323RS_H    /* 头文件保护宏:防止重复包含 */
#define DRV8323RS_H    /* 头文件保护宏定义 */

#include "gd32f30x.h"    /* GD32F30x芯片外设寄存器与固件库头文件 */
#include <stdlib.h>    /* C标准库头文件 */
#include <stdbool.h>    /* C标准布尔类型头文件 */

/* 包含IQmath定点数学运算库 */
/* #include <ti/iqmath/include/IQmathLib.h>    TI官方IQmath库,已注释停用 */

#ifdef __cplusplus    /* C++编译环境判断 */
extern "C" {    /* 以下声明按C语言方式编译(避免C++名称修饰) */
#endif    /* 结束C++兼容判断 */

#define SPI_CS_GPIO_PORT         GPIOA    /* DRV8323RS的SPI片选信号(CS)所在端口 */
#define SPI_CS_GPIO_PIN          GPIO_PIN_4    /* SPI片选引脚:PA4 */
#define SPI_CS_GPIO_CLK          RCU_GPIOA    /* SPI片选引脚端口时钟 */

#define ENABLE_GPIO_PORT         GPIOB    /* 芯片使能引脚(EN_GATE)所在端口 */
#define ENABLE_GPIO_PIN          GPIO_PIN_10    /* 芯片使能引脚:PB10,高电平正常工作/低电平休眠 */
#define ENABLE_GPIO_CLK          RCU_GPIOB    /* 芯片使能引脚端口时钟 */

#define CAL_GPIO_PORT           GPIOB   /* 电流采样放大器校准引脚(CAL)所在端口 */
#define CAL_GPIO_PIN            GPIO_PIN_2    /* 校准引脚:PB2,高脉冲触发CSA偏置自校准 */
#define CAL_GPIO_CLK            RCU_GPIOB   /* 校准引脚端口时钟 */

/*!
 * @brief DRV上电后等待SPI就绪所需的延时(单位:毫秒)
 */
#define DRV8323RS_SPI_READY_DELAY_MS                    (1)

/*!
 * @brief 使能引脚拉低后等待进入休眠模式的延时(单位:毫秒)
 */
#define DRV8323RS_TURNOFF_DELAY_MS                      (1)

/*!
 * @brief 读SPI寄存器时写入的哑数据(无效填充数据) 
 */
#define DRV8323RS_SPI_DUMMY_DATA                        (0x00)

/*!
 * @brief SPI数据帧中11位数据字段的掩码
 */
#define DRV8323RS_SPI_DATA_MASK                        (0x7FF)

/*! @brief 定义状态寄存器1中 VDS_LC 位的偏移:C相低侧MOS管VDS过流监视位 */
#define DRV8323RS_FAULT_STATUS_1_VDS_LC_OFS             (0)

/*! @brief 定义状态寄存器1中 VDS_HC 位的偏移:C相高侧MOS管VDS过流监视位 */
#define DRV8323RS_FAULT_STATUS_1_VDS_HC_OFS             (1)

/*! @brief 定义状态寄存器1中 VDS_LB 位的偏移:B相低侧MOS管VDS过流监视位 */
#define DRV8323RS_FAULT_STATUS_1_VDS_LB_OFS             (2)

/*! @brief 定义状态寄存器1中 VDS_HB 位的偏移:B相高侧MOS管VDS过流监视位 */
#define DRV8323RS_FAULT_STATUS_1_VDS_HB_OFS             (3)

/*! @brief 定义状态寄存器1中 VDS_LA 位的偏移:A相低侧MOS管VDS过流监视位 */
#define DRV8323RS_FAULT_STATUS_1_VDS_LA_OFS             (4)

/*! @brief 定义状态寄存器1中 VDS_HA 位的偏移:A相高侧MOS管VDS过流监视位(原注释笔误VDA_HA) */
#define DRV8323RS_FAULT_STATUS_1_VDS_HA_OFS             (5)

/*! @brief 定义状态寄存器1中 OTSD 位的偏移:过热关断(OTSD)位 */
#define DRV8323RS_FAULT_STATUS_1_OTSD_OFS               (6)

/*! @brief 定义状态寄存器1中 UVLO 位的偏移:欠压锁定(UVLO)位 */
#define DRV8323RS_FAULT_STATUS_1_UVLO_OFS               (7)

/*! @brief 定义状态寄存器1中 GDF 位的偏移:栅极驱动故障(GDF)位 */
#define DRV8323RS_FAULT_STATUS_1_GDF_OFS                (8)

/*! @brief 定义状态寄存器1中 VDS_OCP 位的偏移:VDS过流保护(VDS_OCP)位 */
#define DRV8323RS_FAULT_STATUS_1_VDS_OCP_OFS            (9)

/*! @brief 定义状态寄存器1中 FAULT 位的偏移:故障汇总标志位 */
#define DRV8323RS_FAULT_STATUS_1_FAULT_OFS              (10)

/*! @brief 定义状态寄存器1中 VDS_LC 位的掩码 */
#define DRV8323RS_FAULT_STATUS_1_VDS_LC_MASK      \
                                    (1 << DRV8323RS_FAULT_STATUS_1_VDS_LC_OFS)

/*! @brief 定义状态寄存器1中 VDS_HC 位的掩码 */
#define DRV8323RS_FAULT_STATUS_1_VDS_HC_MASK      \
                                    (1 << DRV8323RS_FAULT_STATUS_1_VDS_HC_OFS)

/*! @brief 定义状态寄存器1中 VDS_LB 位的掩码 */
#define DRV8323RS_FAULT_STATUS_1_VDS_LB_MASK      \
                                    (1 << DRV8323RS_FAULT_STATUS_1_VDS_LB_OFS)

/*! @brief 定义状态寄存器1中 VDS_HB 位的掩码 */
#define DRV8323RS_FAULT_STATUS_1_VDS_HB_MASK      \
                                    (1 << DRV8323RS_FAULT_STATUS_1_VDS_HB_OFS)

/*! @brief 定义状态寄存器1中 VDS_LA 位的掩码 */
#define DRV8323RS_FAULT_STATUS_1_VDS_LA_MASK      \
                                    (1 << DRV8323RS_FAULT_STATUS_1_VDS_LA_OFS)

/*! @brief 定义状态寄存器1中 VDS_HA 位的掩码(原注释笔误VDA_HA) */
#define DRV8323RS_FAULT_STATUS_1_VDS_HA_MASK      \
                                    (1 << DRV8323RS_FAULT_STATUS_1_VDS_HA_OFS)

/*! @brief 定义状态寄存器1中 OTSD 位的掩码 */
#define DRV8323RS_FAULT_STATUS_1_OTSD_MASK        \
                                    (1 << DRV8323RS_FAULT_STATUS_1_OTSD_OFS)

/*! @brief 定义状态寄存器1中 UVLO 位的掩码 */
#define DRV8323RS_FAULT_STATUS_1_UVLO_MASK        \
                                    (1 << DRV8323RS_FAULT_STATUS_1_UVLO_OFS)

/*! @brief 定义状态寄存器1中 GDF 位的掩码 */
#define DRV8323RS_FAULT_STATUS_1_GDF_MASK         \
                                    (1 << DRV8323RS_FAULT_STATUS_1_GDF_OFS)

/*! @brief 定义状态寄存器1中 VDS_OCP 位的掩码 */
#define DRV8323RS_FAULT_STATUS_1_VDS_OCP_MASK     \
                                    (1 << DRV8323RS_FAULT_STATUS_1_VDS_OCP_OFS)

/*! @brief 定义状态寄存器1中 FAULT 位的掩码 */
#define DRV8323RS_FAULT_STATUS_1_FAULT_MASK       \
                                    (1 << DRV8323RS_FAULT_STATUS_1_FAULT_OFS)               

/*! @brief 定义状态寄存器2中 VGS_LC 位的偏移:C相低侧MOS管栅源电压(VGS)故障位 */
#define DRV8323RS_FAULT_STATUS_2_VGS_LC_OFS               (0)

/*! @brief 定义状态寄存器2中 VGS_HC 位的偏移:C相高侧MOS管栅源电压(VGS)故障位 */
#define DRV8323RS_FAULT_STATUS_2_VGS_HC_OFS               (1)

/*! @brief 定义状态寄存器2中 VGS_LB 位的偏移:B相低侧MOS管栅源电压(VGS)故障位 */
#define DRV8323RS_FAULT_STATUS_2_VGS_LB_OFS               (2)

/*! @brief 定义状态寄存器2中 VGS_HB 位的偏移:B相高侧MOS管栅源电压(VGS)故障位 */
#define DRV8323RS_FAULT_STATUS_2_VGS_HB_OFS               (3)

/*! @brief 定义状态寄存器2中 VGS_LA 位的偏移:A相低侧MOS管栅源电压(VGS)故障位 */
#define DRV8323RS_FAULT_STATUS_2_VGS_LA_OFS               (4)

/*! @brief 定义状态寄存器2中 VGS_HA 位的偏移:A相高侧MOS管栅源电压(VGS)故障位 */
#define DRV8323RS_FAULT_STATUS_2_VGS_HA_OFS               (5)

/**
 * @brief 定义状态寄存器2中 CPUV(电荷泵欠压)位的偏移
 */
#define DRV8323RS_FAULT_STATUS_2_CPUV_OFS                 (6)

/*! @brief 定义状态寄存器2中 OTW 位的偏移:过热警告(OTW)位 */
#define DRV8323RS_FAULT_STATUS_2_OTW_OFS                  (7)

/*! @brief 定义状态寄存器2中 SC_OC 位的偏移:C相电流采样过流(SC_OC)位 */
#define DRV8323RS_FAULT_STATUS_2_SC_OC_OFS                (8)

/*! @brief 定义状态寄存器2中 SB_OC 位的偏移:B相电流采样过流(SB_OC)位 */
#define DRV8323RS_FAULT_STATUS_2_SB_OC_OFS                (9)

/*! @brief 定义状态寄存器2中 SA_OC 位的偏移:A相电流采样过流(SA_OC)位 */
#define DRV8323RS_FAULT_STATUS_2_SA_OC_OFS                (10)

/*! @brief 定义状态寄存器2中 VGS_LC 位的掩码 */
#define DRV8323RS_FAULT_STATUS_2_VGS_LC_MASK        \
                                    (1 << DRV8323RS_FAULT_STATUS_2_VGS_LC_OFS)

/*! @brief 定义状态寄存器2中 VGS_HC 位的掩码 */
#define DRV8323RS_FAULT_STATUS_2_VGS_HC_MASK        \
                                    (1 << DRV8323RS_FAULT_STATUS_2_VGS_HC_OFS)

/*! @brief 定义状态寄存器2中 VGS_LB 位的掩码 */
#define DRV8323RS_FAULT_STATUS_2_VGS_LB_MASK        \
                                    (1 << DRV8323RS_FAULT_STATUS_2_VGS_LB_OFS)

/*! @brief 定义状态寄存器2中 VGS_HB 位的掩码 */
#define DRV8323RS_FAULT_STATUS_2_VGS_HB_MASK        \
                                    (1 << DRV8323RS_FAULT_STATUS_2_VGS_HB_OFS)

/*! @brief 定义状态寄存器2中 VGS_LA 位的掩码 */
#define DRV8323RS_FAULT_STATUS_2_VGS_LA_MASK        \
                                    (1 << DRV8323RS_FAULT_STATUS_2_VGS_LA_OFS)

/*! @brief 定义状态寄存器2中 VGS_HA 位的掩码 */
#define DRV8323RS_FAULT_STATUS_2_VGS_HA_MASK        \
                                    (1 << DRV8323RS_FAULT_STATUS_2_VGS_HA_OFS)

/**
 * @brief 定义状态寄存器2中 CPUV(电荷泵欠压)位的掩码
 */
#define DRV8323RS_FAULT_STATUS_2_CPUV_MASK          \
                                    (1 << DRV8323RS_FAULT_STATUS_2_CPUV_OFS)

/*! @brief 定义状态寄存器2中 OTW 位的掩码 */
#define DRV8323RS_FAULT_STATUS_2_OTW_MASK           \
                                    (1 << DRV8323RS_FAULT_STATUS_2_OTW_OFS)

/*! @brief 定义状态寄存器2中 SC_OC 位的掩码 */
#define DRV8323RS_FAULT_STATUS_2_SC_OC_MASK         \
                                    (1 << DRV8323RS_FAULT_STATUS_2_SC_OC_OFS)

/*! @brief 定义状态寄存器2中 SB_OC 位的掩码 */
#define DRV8323RS_FAULT_STATUS_2_SB_OC_MASK         \
                                    (1 << DRV8323RS_FAULT_STATUS_2_SB_OC_OFS)

/*! @brief 定义状态寄存器2中 SA_OC 位的掩码 */
#define DRV8323RS_FAULT_STATUS_2_SA_OC_MASK         \
                                    (1 << DRV8323RS_FAULT_STATUS_2_SA_OC_OFS)

/*! @brief 定义控制寄存器2(驱动控制)中 CLR_FLT 位的偏移:清除故障锁存 */
#define DRV8323RS_DRIVER_CONTROL_CLR_FLT_OFS            (0)

/*! @brief 定义控制寄存器2中 BRAKE 位的偏移:刹车控制(低侧导通刹车) */
#define DRV8323RS_DRIVER_CONTROL_BRAKE_OFS              (1)

/*! @brief 定义控制寄存器2中 COAST 位的偏移:滑行控制(半桥高阻态) */
#define DRV8323RS_DRIVER_CONTROL_COAST_OFS              (2)

/*! @brief 定义控制寄存器2中 1PWM_DIR 位的偏移:1PWM模式的旋转方向 */
#define DRV8323RS_DRIVER_CONTROL_PWM1_DIR_OFS           (3)

/*! @brief 定义控制寄存器2中 1PWM_COM 位的偏移:1PWM模式的换相方式 */
#define DRV8323RS_DRIVER_CONTROL_PWM1_COM_OFS           (4)

/*! @brief 定义控制寄存器2中 PWM_MODE 位的偏移:PWM模式选择(6/3/1路输入) */
#define DRV8323RS_DRIVER_CONTROL_PWM_MODE_OFS           (5)

/*! @brief 定义控制寄存器2中 OTW_REP 位的偏移:过热警告报告使能 */
#define DRV8323RS_DRIVER_CONTROL_OTW_REP_OFS            (7)

/*! @brief 定义控制寄存器2中 DIS_GDF 位的偏移:禁用栅极驱动故障(GDF)报告 */
#define DRV8323RS_DRIVER_CONTROL_DIS_GDF_OFS            (8)

/*! @brief 定义控制寄存器2中 DIS_CPUV 位的偏移:禁用电荷泵欠压(CPUV)报告 */
#define DRV8323RS_DRIVER_CONTROL_DIS_CPUV_OFS           (9)

/*! @brief 定义控制寄存器2中 RESERVED1 位的偏移:保留位 */
#define DRV8323RS_DRIVER_CONTROL_RESERVED1_OFS          (10)

/*! @brief 定义控制寄存器2中 CLR_FLT 位的掩码 */
#define DRV8323RS_DRIVER_CONTROL_CLR_FLT_MASK     \
                                  (1 << DRV8323RS_DRIVER_CONTROL_CLR_FLT_OFS)

/*! @brief 定义控制寄存器2中 BRAKE 位的掩码 */
#define DRV8323RS_DRIVER_CONTROL_BRAKE_MASK       \
                                  (1 << DRV8323RS_DRIVER_CONTROL_BRAKE_OFS)

/*! @brief 定义控制寄存器2中 COAST 位的掩码 */
#define DRV8323RS_DRIVER_CONTROL_COAST_MASK       \
                                  (1 << DRV8323RS_DRIVER_CONTROL_COAST_OFS)

/*! @brief 定义控制寄存器2中 1PWM_DIR 位的掩码 */
#define DRV8323RS_DRIVER_CONTROL_PWM1_DIR_MASK    \
                                  (1 << DRV8323RS_DRIVER_CONTROL_PWM1_DIR_OFS)

/*! @brief 定义控制寄存器2中 1PWM_COM 位的掩码 */
#define DRV8323RS_DRIVER_CONTROL_PWM1_COM_MASK    \
                                  (1 << DRV8323RS_DRIVER_CONTROL_PWM1_COM_OFS)

/*! @brief 定义控制寄存器2中 PWM_MODE 位的掩码 */
#define DRV8323RS_DRIVER_CONTROL_PWM_MODE_MASK    \
                                  (3 << DRV8323RS_DRIVER_CONTROL_PWM_MODE_OFS)

/*! @brief 定义控制寄存器2中 OTW_REP 位的掩码 */
#define DRV8323RS_DRIVER_CONTROL_OTW_REP_MASK     \
                                  (1 << DRV8323RS_DRIVER_CONTROL_OTW_REP_OFS)

/*! @brief 定义控制寄存器2中 DIS_GDF 位的掩码 */
#define DRV8323RS_DRIVER_CONTROL_DIS_GDF_MASK     \
                                  (1 << DRV8323RS_DRIVER_CONTROL_DIS_GDF_OFS)

/*! @brief 定义控制寄存器2中 DIS_CPUV 位的掩码 */
#define DRV8323RS_DRIVER_CONTROL_DIS_CPUV_MASK    \
                                  (1 << DRV8323RS_DRIVER_CONTROL_DIS_CPUV_OFS)

/*! @brief 定义控制寄存器2中 RESERVED1 位的掩码 */
#define DRV8323RS_DRIVER_CONTROL_RESERVED1_MASK   \
                                  (1 << DRV8323RS_DRIVER_CONTROL_RESERVED1_OFS)

/*! @brief 定义控制寄存器3(栅极驱动高侧)中 IDRIVEN_HS 位的偏移:高侧栅极峰值灌电流
 */
#define DRV8323RS_GATE_DRIVE_HS_IDRIVEN_HS_OFS          (0)

/*! @brief 定义控制寄存器3(栅极驱动高侧)中 IDRIVEP_HS 位的偏移:高侧栅极峰值拉电流
 */
#define DRV8323RS_GATE_DRIVE_HS_IDRIVEP_HS_OFS          (4)

/*! @brief 定义控制寄存器3中 LOCK 位的偏移:SPI寄存器锁定/解锁控制 */
#define DRV8323RS_GATE_DRIVE_HS_LOCK_OFS                (8)

/*! @brief 定义控制寄存器3中 IDRIVEN_HS 位的掩码 */
#define DRV8323RS_GATE_DRIVE_HS_IDRIVEN_HS_MASK   \
                                  (15 << DRV8323RS_GATE_DRIVE_HS_IDRIVEN_HS_OFS)

/*! @brief 定义控制寄存器3中 IDRIVEP_HS 位的掩码 */
#define DRV8323RS_GATE_DRIVE_HS_IDRIVEP_HS_MASK   \
                                  (15 << DRV8323RS_GATE_DRIVE_HS_IDRIVEP_HS_OFS)

/*! @brief 定义控制寄存器3中 LOCK 位的掩码 */
#define DRV8323RS_GATE_DRIVE_HS_LOCK_MASK         \
                                  (7 << DRV8323RS_GATE_DRIVE_HS_LOCK_OFS)

/*! @brief 定义控制寄存器4(栅极驱动低侧)中 IDRIVEN_LS 位的偏移:低侧栅极峰值灌电流
 */
#define DRV8323RS_GATE_DRIVE_LS_IDRIVEN_LS_OFS          (0)

/*! @brief 定义控制寄存器4(栅极驱动低侧)中 IDRIVEP_LS 位的偏移:低侧栅极峰值拉电流
 */
#define DRV8323RS_GATE_DRIVE_LS_IDRIVEP_LS_OFS          (4)

/*! @brief 定义控制寄存器4中 TDRIVE 位的偏移:栅极驱动强充时间 */
#define DRV8323RS_GATE_DRIVE_LS_TDRIVE_OFS              (8)

/*! @brief 定义控制寄存器4中 CBC 位的偏移:逐周期限流(CBC)使能 */
#define DRV8323RS_GATE_DRIVE_LS_CBC_OFS                 (10)

/*! @brief 定义控制寄存器4中 IDRIVEN_LS 位的掩码 */
#define DRV8323RS_GATE_DRIVE_LS_IDRIVEN_LS_MASK   \
                                  (15 << DRV8323RS_GATE_DRIVE_LS_IDRIVEN_LS_OFS)

/*! @brief 定义控制寄存器4中 IDRIVEP_LS 位的掩码 */
#define DRV8323RS_GATE_DRIVE_LS_IDRIVEP_LS_MASK   \
                                  (15 << DRV8323RS_GATE_DRIVE_LS_IDRIVEP_LS_OFS)

/*! @brief 定义控制寄存器4中 TDRIVE 位的掩码 */
#define DRV8323RS_GATE_DRIVE_LS_TDRIVE_MASK       \
                                  (3 << DRV8323RS_GATE_DRIVE_LS_TDRIVE_OFS)

/*! @brief 定义控制寄存器4中 CBC 位的掩码 */
#define DRV8323RS_GATE_DRIVE_LS_CBC_MASK          \
                                  (1 << DRV8323RS_GATE_DRIVE_LS_CBC_OFS)

/*! @brief 定义控制寄存器5(过流控制)中 VDS_LVL 位的偏移:VDS过流比较阈值 */
#define DRV8323RS_OCP_CONTROL_VDS_LVL_OFS               (0)

/*! @brief 定义控制寄存器5中 OCP_DEG 位的偏移:过流故障去抖时间 */
#define DRV8323RS_OCP_CONTROL_OCP_DEG_OFS               (4)

/*! @brief 定义控制寄存器5中 OCP_MODE 位的偏移:过流处理模式 */
#define DRV8323RS_OCP_CONTROL_OCP_MODE_OFS              (6)

/*! @brief 定义控制寄存器5中 DEAD_TIME 位的偏移:死区时间 */
#define DRV8323RS_OCP_CONTROL_DEAD_TIME_OFS             (8)

/*! @brief 定义控制寄存器5中 TRETRY 位的偏移:过流自动重试时间 */
#define DRV8323RS_OCP_CONTROL_TRETRY_OFS                (10)

/*! @brief 定义控制寄存器5中 VDS_LVL 位的掩码 */
#define DRV8323RS_OCP_CONTROL_VDS_LVL_MASK        \
                                      (15 << DRV8323RS_OCP_CONTROL_VDS_LVL_OFS)

/*! @brief 定义控制寄存器5中 OCP_DEG 位的掩码 */
#define DRV8323RS_OCP_CONTROL_OCP_DEG_MASK        \
                                      (3 << DRV8323RS_OCP_CONTROL_OCP_DEG_OFS)

/*! @brief 定义控制寄存器5中 OCP_MODE 位的掩码 */
#define DRV8323RS_OCP_CONTROL_OCP_MODE_MASK       \
                                      (3 << DRV8323RS_OCP_CONTROL_OCP_MODE_OFS)

/*! @brief 定义控制寄存器5中 DEAD_TIME 位的掩码 */
#define DRV8323RS_OCP_CONTROL_DEAD_TIME_MASK      \
                                      (3 << DRV8323RS_OCP_CONTROL_DEAD_TIME_OFS)

/*! @brief 定义控制寄存器5中 TRETRY 位的掩码 */
#define DRV8323RS_OCP_CONTROL_TRETRY_MASK         \
                                      (1 << DRV8323RS_OCP_CONTROL_TRETRY_OFS)

/*! @brief 定义控制寄存器6(CSA控制)中 SEN_LVL 位的偏移:电流采样过流阈值 */
#define DRV8323RS_CSA_CONTROL_SEN_LVL_OFS               (0)

/*! @brief 定义控制寄存器6中 CSA_CAL_C 位的偏移:C相采样放大器偏置校准 */
#define DRV8323RS_CSA_CONTROL_CSA_CAL_C_OFS             (2)

/*! @brief 定义控制寄存器6中 CSA_CAL_B 位的偏移:B相采样放大器偏置校准 */
#define DRV8323RS_CSA_CONTROL_CSA_CAL_B_OFS             (3)

/*! @brief 定义控制寄存器6中 CSA_CAL_A 位的偏移:A相采样放大器偏置校准 */
#define DRV8323RS_CSA_CONTROL_CSA_CAL_A_OFS             (4)

/*! @brief 定义控制寄存器6中 DIS_SEN 位的偏移:禁用电流采样过流检测 */
#define DRV8323RS_CSA_CONTROL_DIS_SEN_OFS               (5)

/*! @brief 定义控制寄存器6中 CSA_GAIN 位的偏移:电流采样放大器(CSA)增益选择 */
#define DRV8323RS_CSA_CONTROL_CSA_GAIN_OFS              (6)

/*! @brief 定义控制寄存器6中 LS_REF 位的偏移:低侧过流检测参考点 */
#define DRV8323RS_CSA_CONTROL_LS_REF_OFS                (8)

/*! @brief 定义控制寄存器6中 VREF_DIV 位的偏移:采样放大器基准电压分频 */
#define DRV8323RS_CSA_CONTROL_VREF_DIV_OFS              (9)

/*! @brief 定义控制寄存器6中 CSA_FET 位的偏移:采样放大器正相输入选择 */
#define DRV8323RS_CSA_CONTROL_CSA_FET_OFS               (10)

/*! @brief 定义控制寄存器6中 SEN_LVL 位的掩码 */
#define DRV8323RS_CSA_CONTROL_SEN_LVL_MASK        \
                                    (3 << DRV8323RS_CSA_CONTROL_SEN_LVL_OFS)

/*! @brief 定义控制寄存器6中 CSA_CAL_C 位的掩码 */
#define DRV8323RS_CSA_CONTROL_CSA_CAL_C_MASK      \
                                    (1 << DRV8323RS_CSA_CONTROL_CSA_CAL_C_OFS)

/*! @brief 定义控制寄存器6中 CSA_CAL_B 位的掩码 */
#define DRV8323RS_CSA_CONTROL_CSA_CAL_B_MASK      \
                                    (1 << DRV8323RS_CSA_CONTROL_CSA_CAL_B_OFS)

/*! @brief 定义控制寄存器6中 CSA_CAL_A 位的掩码 */
#define DRV8323RS_CSA_CONTROL_CSA_CAL_A_MASK      \
                                    (1 << DRV8323RS_CSA_CONTROL_CSA_CAL_A_OFS)

/*! @brief 定义控制寄存器6中 DIS_SEN 位的掩码 */
#define DRV8323RS_CSA_CONTROL_DIS_SEN_MASK        \
                                    (1 << DRV8323RS_CSA_CONTROL_DIS_SEN_OFS)

/*! @brief 定义控制寄存器6中 CSA_GAIN 位的掩码 */
#define DRV8323RS_CSA_CONTROL_CSA_GAIN_MASK       \
                                    (3 << DRV8323RS_CSA_CONTROL_CSA_GAIN_OFS)

/*! @brief 定义控制寄存器6中 LS_REF 位的掩码 */
#define DRV8323RS_CSA_CONTROL_LS_REF_MASK         \
                                    (1 << DRV8323RS_CSA_CONTROL_LS_REF_OFS)

/*! @brief 定义控制寄存器6中 VREF_DIV 位的掩码 */
#define DRV8323RS_CSA_CONTROL_VREF_DIV_MASK       \
                                    (1 << DRV8323RS_CSA_CONTROL_VREF_DIV_OFS)

/*! @brief 定义控制寄存器6中 CSA_FET 位的掩码 */
#define DRV8323RS_CSA_CONTROL_CSA_FET_MASK        \
                                    (1 << DRV8323RS_CSA_CONTROL_CSA_FET_OFS)

/*! @brief SPI命令位偏移(bit15:读=1/写=0) */
#define DRV8323RS_SPI_CMD_OFS             (15)

/*! @brief SPI寄存器地址字段偏移(bit14~bit11) */
#define DRV8323RS_SPI_ADDR_OFS            (11)

/*! @brief SPI寄存器地址字段掩码 */
#define DRV8323RS_SPI_ADDR_MASK           (0xF << DRV8323RS_SPI_ADDR_OFS)

/** @brief ADC电压到母线电压的换算系数
 * 该系数为分压电阻比 ((R1 + R2) / R2),其中R1与R2组成电阻分压电路,
 * 将母线电压衰减到ADC可采集的输入电压范围内
 * 具体可参考DRV8323RS应用原理图
*/
#define DRV8323RS_DEFAULT_VOLT_R_DIVIDER  ((82+4.99)/4.99)

/*! @brief 母线电压(vm)换算系数的IQ15定点值(依赖IQmath库,本工程未启用) */
#define DRV8323RS_VOLTAGE_SF_IQ15        _IQ15(DRV8323RS_DEFAULT_VOLT_R_DIVIDER)

/*! @brief DRV可配置的电流采样增益档位总数 */
#define DRV8323RS_CSA_GAIN_MAX_VALUES      (4)

/** @brief DRV默认的采样电阻阻值(单位:欧姆) */
#define DRV8323RS_DEFAULT_R_SHUNT         (0.007f)

/** @brief DRV默认的PWM死区时间(单位:纳秒) */
#define DRV8323RS_DEFAULT_PWM_DEADBAND_NS (100)

/*!
 * @enum DRV8323RS_SPI_CMD
 * @brief SPI命令模式(读/写)
 */
typedef enum {
    /*! SPI写命令 */
    DRV8323RS_SPI_CMD_WRITE = 0,
    /*! SPI读命令 */
    DRV8323RS_SPI_CMD_READ,
}DRV8323RS_SPI_CMD;

/*!
 * @enum DRV8323RS_GATE_DRIVE_HS_LOCK
 * @brief SPI寄存器锁定/解锁枚举
 */
typedef enum {
    /*! 解锁值 */
    DRV8323RS_GATE_DRIVE_HS_LOCK_UNLOCK = 3,
    /*! 锁定值 */
    DRV8323RS_GATE_DRIVE_HS_LOCK_LOCK = 6
}DRV8323RS_GATE_DRIVE_HS_LOCK;

/*!
 * @enum DRV8323RS_DRIVER_CONTROL_PWM_MODE
 * @brief 驱动器PWM工作模式枚举
 */
typedef enum {
  /*! PWM_MODE值为6路PWM输入 */
  DRV8323RS_DRIVER_CONTROL_PWM_MODE_6 = 0, 
  /*! PWM_MODE值为3路PWM输入 */
  DRV8323RS_DRIVER_CONTROL_PWM_MODE_3, 
  /*! PWM_MODE值为1路PWM输入 */
  DRV8323RS_DRIVER_CONTROL_PWM_MODE_1 
} DRV8323RS_DRIVER_CONTROL_PWM_MODE;

/*!
 * @enum DRV8323RS_GATE_DRIVE_PEAK_CUR_TIME
 * @brief 栅极驱动峰值电流维持时间(TDRIVE)枚举
 */
typedef enum {
  /*! TDRIVE值为 500ns */
  DRV8323RS_GATE_DRIVE_PEAK_CUR_TIME_500_NS =0,  
  /*! TDRIVE值为 1000ns */
  DRV8323RS_GATE_DRIVE_PEAK_CUR_TIME_1000_NS, 
  /*! TDRIVE值为 2000ns */
  DRV8323RS_GATE_DRIVE_PEAK_CUR_TIME_2000_NS, 
  /*! TDRIVE值为 4000ns */
  DRV8323RS_GATE_DRIVE_PEAK_CUR_TIME_4000_NS  
} DRV8323RS_GATE_DRIVE_PEAK_CUR_TIME;

/*! 
 * @enum DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR
 * @brief 低侧栅极峰值拉电流(IDRIVEP_LS)枚举
 */
typedef enum {
  /*! IDRIVEP_LS值为 0.010A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P010_A =0,  
  /*! IDRIVEP_LS值为 0.030A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P030_A,  
  /*! IDRIVEP_LS值为 0.060A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P060_A,  
  /*! IDRIVEP_LS值为 0.080A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P080_A,  
  /*! IDRIVEP_LS值为 0.120A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P120_A,  
  /*! IDRIVEP_LS值为 0.140A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P140_A,  
  /*! IDRIVEP_LS值为 0.170A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P170_A,  
  /*! IDRIVEP_LS值为 0.190A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P190_A,  
  /*! IDRIVEP_LS值为 0.260A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P260_A,  
  /*! IDRIVEP_LS值为 0.330A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P330_A,  
  /*! IDRIVEP_LS值为 0.370A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P370_A, 
  /*! IDRIVEP_LS值为 0.440A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P440_A, 
  /*! IDRIVEP_LS值为 0.570A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P570_A, 
  /*! IDRIVEP_LS值为 0.680A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P680_A, 
  /*! IDRIVEP_LS值为 0.820A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P820_A, 
  /*! IDRIVEP_LS值为 1.000A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_1P000_A, 
} DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR;

/*!
 * @enum DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR
 * @brief 低侧栅极峰值灌电流(IDRIVEN_LS)枚举
 */
typedef enum {
  /*! IDRIVEN_LS值为 0.020A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_0P020_A = 0,  
  /*! IDRIVEN_LS值为 0.060A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_0P060_A,  
  /*! IDRIVEN_LS值为 0.120A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_0P120_A,  
  /*! IDRIVEN_LS值为 0.160A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_0P160_A,  
  /*! IDRIVEN_LS值为 0.240A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_0P240_A,  
  /*! IDRIVEN_LS值为 0.280A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_0P280_A,  
  /*! IDRIVEN_LS值为 0.340A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_0P340_A,  
  /*! IDRIVEN_LS值为 0.380A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_0P380_A,  
  /*! IDRIVEN_LS值为 0.520A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_0P520_A,  
  /*! IDRIVEN_LS值为 0.660A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_0P660_A,  
  /*! IDRIVEN_LS值为 0.740A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_0P740_A, 
  /*! IDRIVEN_LS值为 0.880A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_0P880_A, 
  /*! IDRIVEN_LS值为 1.140A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_1P140_A, 
  /*! IDRIVEN_LS值为 1.360A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_1P360_A, 
  /*! IDRIVEN_LS值为 1.640A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_1P640_A, 
  /*! IDRIVEN_LS值为 2.000A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_2P000_A, 
} DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR;

/*!
 * @enum DRV8323RS_OCP_CONTROL_VDS_LVL
 * @brief VDS过流比较阈值枚举
 */
typedef enum {
  /*! VDS_LEVEL值为 0.060V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_0P060_V = 0,  
  /*! VDS_LEVEL值为 0.130V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_0P130_V,  
  /*! VDS_LEVEL值为 0.200V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_0P200_V,  
  /*! VDS_LEVEL值为 0.260V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_0P260_V,  
  /*! VDS_LEVEL值为 0.310V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_0P310_V,  
  /*! VDS_LEVEL值为 0.450V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_0P450_V,  
  /*! VDS_LEVEL值为 0.530V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_0P530_V,  
  /*! VDS_LEVEL值为 0.600V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_0P600_V,  
  /*! VDS_LEVEL值为 0.680V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_0P680_V,  
  /*! VDS_LEVEL值为 0.750V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_0P750_V,  
  /*! VDS_LEVEL值为 0.940V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_0P940_V, 
  /*! VDS_LEVEL值为 1.130V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_1P130_V, 
  /*! VDS_LEVEL值为 1.300V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_1P300_V, 
  /*! VDS_LEVEL值为 1.500V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_1P500_V, 
  /*! VDS_LEVEL值为 1.700V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_1P700_V, 
  /*! VDS_LEVEL值为 1.880V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_1P880_V  
} DRV8323RS_OCP_CONTROL_VDS_LVL;

/*!
 * @enum DRV8323RS_OCP_CONTROL_OCP_DEG
 * @brief 过流(VDS)检测去抖时间枚举
 */
typedef enum {
  /*! TVDS值为 2us */
  DRV8323RS_OCP_CONTROL_OCP_DEG_2_US = 0, 
  /*! TVDS值为 4us */
  DRV8323RS_OCP_CONTROL_OCP_DEG_4_US, 
  /*! TVDS值为 6us */
  DRV8323RS_OCP_CONTROL_OCP_DEG_6_US, 
  /*! TVDS值为 8us */
  DRV8323RS_OCP_CONTROL_OCP_DEG_8_US  
} DRV8323RS_OCP_CONTROL_OCP_DEG;

/*!
 * @enum DRV8323RS_OCP_CONTROL_OCP_MODE
 * @brief 过流(OCP)处理模式枚举
 */
typedef enum {
  /*! OCP_MODE为锁存故障关断 */
  DRV8323RS_OCP_CONTROL_OCP_MODE_LATCHED_SHUTDOWN = 0, 
  /*! OCP_MODE为自动重试 */
  DRV8323RS_OCP_CONTROL_OCP_MODE_AUTOMATIC_RETRY,  
  /*! OCP_MODE为仅报告(不动作) */
  DRV8323RS_OCP_CONTROL_OCP_MODE_REPORT_ONLY,      
  /*! OCP_MODE为禁用过流保护 */
  DRV8323RS_OCP_CONTROL_OCP_MODE_DISABLE_OCP       
} DRV8323RS_OCP_CONTROL_OCP_MODE;

/*!
 * @enum DRV8323RS_OCP_CONTROL_DEADTIME
 * @brief 死区时间枚举
 */
typedef enum {
  /*! DEAD_TIME值为 50ns */
  DRV8323RS_OCP_CONTROL_DEADTIME_50_NS = 0,  
  /*! DEAD_TIME值为 100ns */
  DRV8323RS_OCP_CONTROL_DEADTIME_100_NS, 
  /*! DEAD_TIME值为 200ns */
  DRV8323RS_OCP_CONTROL_DEADTIME_200_NS, 
  /*! DEAD_TIME值为 400ns */
  DRV8323RS_OCP_CONTROL_DEADTIME_400_NS  
} DRV8323RS_OCP_CONTROL_DEADTIME;

/*!
 * @enum DRV8323RS_OCP_CONTROL_TRETRY
 * @brief 过流重试时间枚举
 */
typedef enum {
  /*! 重试时间为 4ms */
  DRV8323RS_OCP_CONTROL_TRETRY_4_MS = 0,
  /*! 重试时间为 50us */
  DRV8323RS_OCP_CONTROL_TRETRY_50_US,
} DRV8323RS_OCP_CONTROL_TRETRY;

/*!
 * @enum DRV8323RS_CSA_CONTROL_DIS_SEN
 * @brief 电流采样过流检测使能枚举 */
typedef enum {
  /*! 使能过流故障检测 */
  DRV8323RS_CSA_CONTROL_DIS_SEN_ENABLE = 0,
  /*! 禁用过流故障检测 */
  DRV8323RS_CSA_CONTROL_DIS_SEN_DISABLE,
} DRV8323RS_CSA_CONTROL_DIS_SEN;

/*!
 * @enum DRV8323RS_CSA_CONTROL_SEN_LVL
 * @brief 电流采样过流阈值枚举
 */
typedef enum {
  /*! SEN_LVL值为 0.25V */
  DRV8323RS_CSA_CONTROL_SEN_LVL_0P25_V = 0, 
  /*! SEN_LVL值为 0.50V */
  DRV8323RS_CSA_CONTROL_SEN_LVL_0P50_V, 
  /*! SEN_LVL值为 0.75V */
  DRV8323RS_CSA_CONTROL_SEN_LVL_0P75_V, 
  /*! SEN_LVL值为 1.00V */
  DRV8323RS_CSA_CONTROL_SEN_LVL_1P00_V  
} DRV8323RS_CSA_CONTROL_SEN_LVL;

/*!
 * @enum DRV8323RS_CSA_CONTROL_CSA_GAIN
 * @brief 电流采样放大器(CSA)增益枚举
 */
typedef enum {
  /*! GAIN_CSA值为 5V/V */
  DRV8323RS_CSA_CONTROL_CSA_GAIN_5VPV = 0,
  /*! GAIN_CSA值为 10V/V */
  DRV8323RS_CSA_CONTROL_CSA_GAIN_10VPV,
  /*! GAIN_CSA值为 20V/V */
  DRV8323RS_CSA_CONTROL_CSA_GAIN_20VPV,
  /*! GAIN_CSA值为 40V/V */
  DRV8323RS_CSA_CONTROL_CSA_GAIN_40VPV,
} DRV8323RS_CSA_CONTROL_CSA_GAIN;

/*!
 * @enum DRV8323RS_CSA_CONTROL_CSA_FET
 * @brief 电流采样放大器正相输入选择枚举
 */
typedef enum {
  /*! 采样放大器正相输入接SPx引脚 */
  DRV8323RS_CSA_CONTROL_CSA_FET_IN_SPX = 0,  
  /*! 采样放大器正相输入接SHx引脚 */
  DRV8323RS_CSA_CONTROL_CSA_FET_IN_SHX,
} DRV8323RS_CSA_CONTROL_CSA_FET;

/*!
 * @enum DRV8323RS_CSA_CONTROL_LS_REF
 * @brief 低侧过流检测参考点枚举
 */
typedef enum {
  /*! 低侧MOS管过流在SHx与SPx之间检测 */
  DRV8323RS_CSA_CONTROL_LS_REF_SH_SP = 0,  
  /*! 低侧MOS管过流在SHx与SNx之间检测 */
  DRV8323RS_CSA_CONTROL_LS_REF_SH_SN,
} DRV8323RS_CSA_CONTROL_LS_REF;

/*!
 * @enum DRV8323RS_CSA_CONTROL_VREF_DIV
 * @brief 电流采样放大器基准电压枚举
 */
typedef enum {
  /*! 采样放大器基准电压为VREF */
  DRV8323RS_CSA_CONTROL_VREF_DIV_1 = 0,  
  /*! 采样放大器基准电压为VREF/2 */
  DRV8323RS_CSA_CONTROL_VREF_DIV_2,
} DRV8323RS_CSA_CONTROL_VREF_DIV;

/*!
 * @enum DRV8323RS_REG_ADDR
 * @brief SPI寄存器地址枚举
 */
typedef enum {
    /*! 故障状态寄存器1地址 */
    DRV8323RS_REG_ADDR_FAULT_STATUS_1 = 0,
    /*! 故障状态寄存器2(VGS状态)地址 */
    DRV8323RS_REG_ADDR_FAULT_STATUS_2,
    /*! 驱动控制寄存器地址 */
    DRV8323RS_REG_ADDR_DRIVER_CONTROL,
    /*! 栅极驱动高侧寄存器地址 */
    DRV8323RS_REG_ADDR_GATE_DRIVE_HS,
    /*! 栅极驱动低侧寄存器地址 */
    DRV8323RS_REG_ADDR_GATE_DRIVE_LS,
    /*! 过流控制寄存器地址 */
    DRV8323RS_REG_ADDR_OCP_CONTROL,
    /*! 电流采样放大器控制寄存器地址 */
    DRV8323RS_REG_ADDR_CSA_CONTROL,
}DRV8323RS_REG_ADDR;

/*! @brief 定义DRV8323RS实例结构体 */
typedef struct {
    /*! 从ADC读取电流的换算系数 */
/*    _iq15 iSf;    (已注释停用) */
    /*! 使能引脚GPIO配置,参见 @ref HAL_GPIO_OUT_PIN */
    uint32_t enable_gpio_periph;    /* 使能引脚所在GPIO端口 */
    uint32_t enable_gpio_pin;    /* 使能引脚引脚号 */
    /*! 连接到nFAULT引脚的定时器故障输入,参见 @ref HAL_PWM_FAULT */

    /*! SPI通道,参见 @ref HAL_SPI_CHANNEL */

    /*! SPI片选,参见 @ref HAL_SPI_CS */
    uint32_t cs_gpio_periph;    /* 片选引脚所在GPIO端口 */
    uint32_t cs_gpio_pin;    /* 片选引脚引脚号 */
    /*! 母线电压vm的ADC通道,参见 @ref HAL_ADC_CHANNEL */
/*    HAL_ADC_CHANNEL vsenvm;    (已注释停用) */
    /*! A相电流的ADC通道,参见 @ref HAL_ADC_CHANNEL */
/*    HAL_ADC_CHANNEL isena;    (已注释停用) */
    /*! B相电流的ADC通道,参见 @ref HAL_ADC_CHANNEL */
/*    HAL_ADC_CHANNEL isenb;    (已注释停用) */
    /*! C相电流的ADC通道,参见 @ref HAL_ADC_CHANNEL */
/*    HAL_ADC_CHANNEL isenc;    (已注释停用) */
} DRV8323RS_Instance;

/* 外部引用CSA增益表drvGain(在drv8323rs.c中定义) */
extern int8_t drvGain[DRV8323RS_CSA_GAIN_MAX_VALUES];    /* 各增益档位对应的增益值(5/10/20/40) */

/**
 * @brief     使能DRV8323RS 
 * @param[in] handle    指向drv8323rs实例的指针
 */
void DRV8323RS_enable(void);

/**
 * @brief     禁用DRV8323RS 
 * @param[in] handle    指向drv8323rs实例的指针
 */
void DRV8323RS_disable(void);

/**
 * @brief     初始化DRV8323RS对象
 * @param[in] handle    指向drv8323rs实例的指针
 */
void DRV8323RS_init(void);

/**
 * @brief     构造待通过SPI发送的数据字
 * @param[in] wrCmd    SPI读或写命令,取值见 @ref DRV8323RS_SPI_CMD
 * @param[in] addr     SPI寄存器地址,取值见 @ref DRV8323RS_REG_ADDR
 * @param[in] data     要写入SPI寄存器的数据
 * @return    返回构造好的SPI数据字
 */
uint16_t DRV8323RS_createSPIDataWord(
               DRV8323RS_SPI_CMD wrCmd, DRV8323RS_REG_ADDR addr, uint16_t data);

/**
 * @brief     向SPI寄存器写入数据
 * @param[in] handle   指向drv8323rs实例的指针
 * @param[in] addr     SPI寄存器地址,取值见 @ref DRV8323RS_REG_ADDR
 * @param[in] data     要写入SPI寄存器的数据
 */
void DRV8323RS_spiWrite(DRV8323RS_REG_ADDR addr, uint16_t data);

/**
 * @brief     读取SPI寄存器中的数据
 * @param[in] handle   指向drv8323rs实例的指针
 * @param[in] addr     SPI寄存器地址,取值见 @ref DRV8323RS_REG_ADDR
 * @return    返回SPI寄存器中的数据
 */
uint16_t DRV8323RS_spiRead(DRV8323RS_REG_ADDR addr);

/**
 * @brief     只更新SPI寄存器中的某些位(读-改-写)
 * @param[in] handle   指向drv8323rs实例的指针
 * @param[in] addr     SPI寄存器地址,取值见 @ref DRV8323RS_REG_ADDR
 * @param[in] mask     要修改位的掩码
 * @param[in] data     要写入SPI寄存器的数据
 */
void DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR addr, uint32_t mask, uint16_t data);

/**
 * @brief     解锁或锁定DRV的SPI寄存器
 * @param[in] handle   指向drv8323rs实例的指针
 * @param[in] lock    锁定或解锁值
 * 取值见 @ref DRV8323RS_GATE_DRIVE_HS_LOCK
 */
void DRV8323RS_setSPIRegisterLock(DRV8323RS_GATE_DRIVE_HS_LOCK lock);

/**
 * @brief     设置栅极峰值拉电流
 * @param[in] handle  指向drv8323rs实例的指针
 * @param[in] hsPeakCurr 高侧栅极峰值拉电流
 * 取值见 @ref DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR
 * @param[in] lsPeakCurr 低侧栅极峰值拉电流
 * 取值见 @ref DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR
 */
void DRV8323RS_setPeakSourceGateCurr(
                               DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR hsPeakCurr, 
                               DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR lsPeakCurr);

/**
 * @brief     设置栅极峰值灌电流
 * @param[in] handle  指向drv8323rs实例的指针
 * @param[in] hsPeakCurr 高侧栅极峰值灌电流
 * 取值见 @ref DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR
 * @param[in] lsPeakCurr 低侧栅极峰值灌电流
 * 取值见 @ref DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR
 */
void DRV8323RS_setPeakSinkGateCurr(
                                 DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR hsPeakCurr, 
                                 DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR lsPeakCurr);

/**
 * @brief     设置栅极驱动峰值电流维持时间
 * @param[in] handle  指向drv8323rs实例的指针
 * @param[in] tdrive 要设置的峰值驱动电流维持时间
 * One of @ref DRV8323RS_GATE_DRIVE_PEAK_CUR_TIME
 */
void DRV8323RS_setPeakGateCurrTime(DRV8323RS_GATE_DRIVE_PEAK_CUR_TIME tdrive);   

/**
 * @brief     设置PWM模式
 * @param[in] handle  指向drv8323rs实例的指针
 * @param[in] pwmMode 要设置的PWM模式
 *  One of @ref DRV8323RS_DRIVER_CONTROL_PWM_MODE
 */
void DRV8323RS_setPwmMode(DRV8323RS_DRIVER_CONTROL_PWM_MODE pwmMode);

/**
 * @brief     设置过流动作电压(VDS阈值)
 * @param[in] handle  指向drv8323rs实例的指针
 * @param[in] vdsLvl  要设置的过流电平
 *  取值见 @ref DRV8323RS_OCP_CONTROL_VDS_LVL
 */
void DRV8323RS_setVdsLvl(DRV8323RS_OCP_CONTROL_VDS_LVL vdsLvl);

/**
 * @brief     设置过流去抖时间
 * @param[in] handle  指向drv8323rs实例的指针
 * @param[in] ocpDeg  要设置的去抖时间
 *  取值见 @ref DRV8323RS_OCP_CONTROL_OCP_DEG
 */
void DRV8323RS_setOcpDeg(DRV8323RS_OCP_CONTROL_OCP_DEG ocpDeg);

/**
 * @brief     设置过流处理模式
 * @param[in] handle  指向drv8323rs实例的指针
 * @param[in] ocpMode 要设置的过流处理模式
 *  取值见 @ref DRV8323RS_OCP_CONTROL_OCP_MODE
 */
void DRV8323RS_setOcpMode(DRV8323RS_OCP_CONTROL_OCP_MODE ocpMode);

/**
 * @brief     设置死区时间
 * @param[in] handle   指向drv8323rs实例的指针
 * @param[in] deadtime 要设置的死区时间
 * 取值见 @ref DRV8323RS_OCP_CONTROL_DEADTIME
 */
void DRV8323RS_setDeadtime(DRV8323RS_OCP_CONTROL_DEADTIME deadtime);

/**
 * @brief     设置过流重试时间
 * @param[in] handle 指向drv8323rs实例的指针
 * @param[in] tretry 要设置的重试时间,取值见 @ref DRV8323RS_OCP_CONTROL_TRETRY
 */
void DRV8323RS_setTretry(DRV8323RS_OCP_CONTROL_TRETRY tretry);

/**
 * @brief     设置电流采样过流阈值
 * @param[in] handle 指向drv8323rs实例的指针
 * @param[in] senLvl 要设置的过流检测电平
 * 取值见 @ref DRV8323RS_CSA_CONTROL_SEN_LVL
 */
void DRV8323RS_setSenLvl(DRV8323RS_CSA_CONTROL_SEN_LVL senLvl);

/**
 * @brief     使能或禁用电流采样过流检测
 * @param[in] handle 指向drv8323rs实例的指针
 * @param[in] disSen 要设置的过流检测状态
 * 取值见 @ref DRV8323RS_CSA_CONTROL_DIS_SEN
 */
void DRV8323RS_setDisSen(DRV8323RS_CSA_CONTROL_DIS_SEN disSen);

/**
 * @brief     设置电流采样放大器增益
 * @param[in] handle  指向drv8323rs实例的指针
 * @param[in] csaGain 要设置的增益,取值见 @ref DRV8323RS_CSA_CONTROL_CSA_GAIN
 */
void DRV8323RS_setCsaGain(DRV8323RS_CSA_CONTROL_CSA_GAIN csaGain);

/**
 * @brief     设置低侧过流检测参考点
 * @param[in] handle  指向drv8323rs实例的指针
 * @param[in] lsRef   要设置的参考点
 * 取值见 @ref DRV8323RS_CSA_CONTROL_LS_REF
 */
void DRV8323RS_setLsRef(DRV8323RS_CSA_CONTROL_LS_REF lsRef);

/**
 * @brief     设置电流采样放大器的基准电压
 * @param[in] handle   指向drv8323rs实例的指针
 * @param[in] vrefDiv  要设置的基准电压
 * 取值见 @ref DRV8323RS_CSA_CONTROL_VREF_DIV
 */
void DRV8323RS_setVrefDiv(DRV8323RS_CSA_CONTROL_VREF_DIV vrefDiv);

/**
 * @brief     设置电流采样放大器正相输入参考点
 * @param[in] handle  指向drv8323rs实例的指针
 * @param[in] csaFet  要设置的参考点
 * 取值见 @ref DRV8323RS_CSA_CONTROL_CSA_FET
 */
void DRV8323RS_setCsaFet(DRV8323RS_CSA_CONTROL_CSA_FET csaFet);

/**
 * @brief     从vsenvm通道获取母线电压ADC原始值
 * @param[in] handle    指向drv8323rs实例的指针
 * @return    返回读取到的ADC原始值
 */
__STATIC_INLINE uint16_t DRV8323RS_getVMRaw(void)
{
/*  return (HAL_getADCValue(handle->vsenvm));       (TODO:待实现) */
    return 0;    /* 暂未实现,固定返回0 */
}

/**
 * @brief     从isena通道获取A相电流ADC原始值
 * @param[in] handle    指向drv8323rs实例的指针
 * @return    返回读取到的ADC原始值
 */
__STATIC_INLINE uint16_t DRV8323RS_getIARaw(void)
{
/*  return (HAL_getADCValue(handle->isena));    (已注释停用) */
    return 0;    /* 暂未实现,固定返回0 */
}

/**
 * @brief     从isenb通道获取B相电流ADC原始值
 * @param[in] handle    指向drv8323rs实例的指针
 * @return    返回读取到的ADC原始值
 */
__STATIC_INLINE uint16_t DRV8323RS_getIBRaw(void)
{
/*  return (HAL_getADCValue(handle->isenb));    (已注释停用) */
    return 0;    /* 暂未实现,固定返回0 */
}

/**
 * @brief     从isenc通道获取C相电流ADC原始值
 * @param[in] handle    指向drv8323rs实例的指针
 * @return    返回读取到的ADC原始值
 */
__STATIC_INLINE uint16_t DRV8323RS_getICRaw(void)
{
/*  return (HAL_getADCValue(handle->isenc));    (已注释停用) */
    return 0;    /* 暂未实现,固定返回0 */
}

/* 以下函数声明已注释停用 */
/*
 * @brief     获取换算后的IA相电流
 * @param[in] handle    指向drv8323rs实例的指针
 * @return    返回IQ格式的IA相电流
 */
/* _iq DRV8323RS_getIA(void); */

/* 以下函数声明已注释停用 */
/*
 * @brief     获取换算后的IB相电流
 * @param[in] handle    指向drv8323rs实例的指针
 * @return    返回IQ格式的IB相电流
 */
/* _iq DRV8323RS_getIB(void); */

/* 以下函数声明已注释停用 */
/*
 * @brief     获取换算后的IC相电流
 * @param[in] handle    指向drv8323rs实例的指针
 * @return    返回IQ格式的IC相电流
 */
/* _iq DRV8323RS_getIC(void); */

/* 以下函数声明已注释停用 */
/*
 * @brief     获取换算后的VM母线电压
 * @param[in] handle    指向drv8323rs实例的指针
 * @return    返回IQ格式的VM母线电压
 */
/* _iq DRV8323RS_getVM(void); */

/**
 * @brief     设置相电流换算系数
 * @param[in] handle 指向drv8323rs实例的指针
 * @param[in] gain   电流采样放大器增益
 * @param[in] rshunt IQ15格式的采样电阻阻值
 */
/* void DRV8323RS_setISf(DRV8323RS_CSA_CONTROL_CSA_GAIN  gain, _iq15 rshunt);    (已注释停用) */

/**
 * @brief     检查是否发生故障
 * @param[in] handle    指向drv8323rs实例的指针
 * @return    返回故障状态
 */
bool DRV8323RS_isFaultOccurred(void);

/**
 * @brief     清除定时器和SPI寄存器中的故障状态
 * @param[in] handle    指向drv8323rs实例的指针
 */
void DRV8323RS_clearFaults(void);

#ifdef __cplusplus    /* C++编译环境判断 */
}
#endif    /* 结束C++兼容判断 */
#endif /* DRV8323RS_H */    /* 头文件保护宏结束 */
/** @}*/
