/*
*******************************************************************************************************
*
* 文件名称 : i2c.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : I2C驱动文件
* 
*******************************************************************************************************
*/



/* 头文件 -----------------------------------------------------------*/
#include "i2c.h" /* I2C驱动接口与软件I2C引脚宏定义 */
#include "delay.h" /* 微秒级延时接口 */

/* 宏定义 -----------------------------------------------------------*/
#ifdef HARDWARE_I2C /* 硬件I2C条件编译分支 */
I2C_HandleTypeDef hi2c; /* 硬件I2C外设句柄(仅HARDWARE_I2C方式使用) */
#endif /* 条件编译结束 */

/* 变量 -------------------------------------------------------------*/


/* 函数声明 ---------------------------------------------------------*/



/**
  * @brief I2C初始化函数
  * @param 无
  * @retval	无
  */
void i2c_init(void)
{
#ifdef HARDWARE_I2C /* 硬件I2C分支 */

#else /* 软件I2C分支:GPIO模拟I2C时序 */
	
    /**i2c GPIO配置    
    PB8     ------> I2C_SCL 时钟线
    PB9     ------> I2C_SDA 数据线 
    */
	
    rcu_periph_clock_enable(RCU_GPIOB); /* 使能GPIOB外设时钟 */

    gpio_init(GPIOB,GPIO_MODE_OUT_PP,GPIO_OSPEED_50MHZ,GPIO_PIN_8); /* PB8(SCL)配置为推挽输出 */
    gpio_init(GPIOB,GPIO_MODE_OUT_OD,GPIO_OSPEED_50MHZ,GPIO_PIN_9); /* PB9(SDA)配置为开漏输出,可释放总线读取应答 */
	
	SDA_OUT(1); /* 释放SDA总线(置高) */
	SCL_OUT(1); /* 释放SCL总线(置高) */

#endif	 /* 条件编译结束 */
}


/**
  * @brief 启用I2C发送数据
  * @param dev_addr-I2C从设备的地址
  * @param pbuffer-待发送的数据
  * @param len-数据长度
  * @param time_out-超时时间
  * @retval	0-发送成功 other_value-发送失败
  */
uint8_t i2c_master_send_data(uint16_t dev_addr,uint8_t *pbuffer,uint16_t len,uint32_t time_out)
{
#ifdef HARDWARE_I2C /* 硬件I2C分支 */
	
#else /* 软件I2C实现 */
	dev_addr &= ~(1<<0);	/* 最低位清0，IIC写 */
	
	soft_i2c_start(); /* 产生I2C起始信号 */
	
	soft_i2c_send_byte(dev_addr); /* 发送从机地址(写方向) */
	if(soft_i2c_wait_ack(time_out) == SOFT_I2C_ERR) /* 等待从机应答 */
		return SOFT_I2C_ERR; /* 无应答,发送失败 */
	
	while(len) /* 逐字节发送数据 */
	{
		soft_i2c_send_byte(*pbuffer); /* 发送一个数据字节 */
		if(soft_i2c_wait_ack(time_out) == SOFT_I2C_ERR) /* 等待从机应答 */
			return SOFT_I2C_ERR; /* 无应答,发送失败 */
		pbuffer ++ ; /* 数据指针递增 */
		len -- ; /* 待发送长度递减 */
	}
	soft_i2c_stop(); /* 产生I2C停止信号 */
	return SOFT_I2C_OK; /* 发送成功 */
#endif /* 条件编译结束 */
}


/**
  * @brief 启用I2C接收数据
  * @param dev_addr-I2C从设备的地址
  * @param pbuffer-接收数据缓冲区
  * @param len-数据长度
  * @param time_out-超时时间
  * @retval	0-接收成功 other_value-接收失败
  */
uint8_t i2c_master_receive_data(uint16_t dev_addr,uint8_t *pbuffer,uint16_t len,uint32_t time_out)
{
#ifdef HARDWARE_I2C /* 硬件I2C分支 */

#else /* 软件I2C实现 */
	dev_addr |= (1<<0);	/* 最低位置1，IIC读 */

	soft_i2c_start(); /* 产生I2C起始信号 */
	
	soft_i2c_send_byte(dev_addr); /* 发送从机地址(读方向) */
	if(soft_i2c_wait_ack(time_out) == SOFT_I2C_ERR) /* 等待从机应答 */
		return SOFT_I2C_ERR; /* 无应答,接收失败 */

	while(len) /* 逐字节接收数据 */
	{
		*pbuffer = soft_i2c_receive_byte(); /* 接收一个字节存入缓冲区 */
		pbuffer ++ ; /* 缓冲区指针递增 */
		len -- ; /* 待接收长度递减 */
		
		if(len == 0) /* 最后一个字节 */
			soft_i2c_no_ack(); /* 发送非应答,结束读取 */
		else
			soft_i2c_ack(); /* 发送应答,继续接收 */
	}
	soft_i2c_stop(); /* 产生I2C停止信号 */
	
	return SOFT_I2C_OK; /* 接收成功 */
	
#endif /* 条件编译结束 */
}



/**
  * @brief 启用I2C向存储器写入一定长度的数据
  * @param dev_addr-I2C从设备的地址
  * @param mem_addr-存储器内部地址
  * @param mem_add_size-存储器地址长度(8位或者16位)
  * @param pbuffer-待写入的数据
  * @param len-数据长度
  * @param time_out-超时时间
  * @retval	0-写入成功 other_value-写入失败
  */
uint8_t i2c_mem_write(uint16_t dev_addr, uint16_t mem_addr, uint16_t mem_add_size, uint8_t *pbuffer, uint16_t len, uint32_t time_out)
{
#ifdef HARDWARE_I2C /* 硬件I2C分支 */

#else /* 软件I2C实现 */
	
	/* //dev_addr <<= 1;		//7位IIC地址 */
	dev_addr &= ~(1<<0);	/* 最低位清0，IIC写 */
	
	soft_i2c_start(); /* 产生I2C起始信号 */
	
	soft_i2c_send_byte(dev_addr);						/* 发送IIC设备地址(写方向) */
	if(soft_i2c_wait_ack(time_out) == SOFT_I2C_ERR) /* 等待从机应答 */
		return SOFT_I2C_ERR; /* 无应答,写入失败 */
	
	/* 发送存储器地址或寄存器地址 */
	if(mem_add_size == I2C_MEMADD_16BIT) /* 16位存储器地址模式 */
	{
		soft_i2c_send_byte((mem_addr>>8)&0X00FF); /* 先发送存储器地址高8位 */
		if(soft_i2c_wait_ack(time_out) == SOFT_I2C_ERR) /* 等待应答 */
			return SOFT_I2C_ERR; /* 无应答,写入失败 */
	}
	soft_i2c_send_byte(mem_addr & 0X00FF);						/* 发送存储器地址低8位 */
	if(soft_i2c_wait_ack(time_out) == SOFT_I2C_ERR) /* 等待应答 */
		return SOFT_I2C_ERR; /* 无应答,写入失败 */
	
	
	/* 逐字节发送数据 */
	while(len)
	{
		soft_i2c_send_byte(*pbuffer);						/* 发送一个数据字节 */
		if(soft_i2c_wait_ack(time_out) == SOFT_I2C_ERR) /* 等待应答 */
			return SOFT_I2C_ERR; /* 无应答,写入失败 */
		
		pbuffer ++ ; /* 数据指针递增 */
		len -- ; /* 待发送长度递减 */
		
		delay_us(10); /* 字节间隔延时 */

	}

	
	soft_i2c_stop(); /* 产生I2C停止信号 */
	
	return SOFT_I2C_OK; /* 写入成功 */
	
#endif /* 条件编译结束 */
}




/**
  * @brief 启用I2C从储器读取一定长度的数据
  * @param dev_addr-I2C从设备的地址
  * @param mem_addr-存储器内部地址
  * @param mem_add_size-存储器地址长度(8位或者16位)
  * @param pbuffer-读取数据缓冲区
  * @param len-数据长度
  * @param time_out-超时时间
  * @retval	0-读取成功 other_value-读取失败
  */
uint8_t i2c_mem_read(uint16_t dev_addr, uint16_t mem_addr, uint16_t mem_add_size, uint8_t *pbuffer, uint16_t len, uint32_t time_out)
{
#ifdef HARDWARE_I2C /* 硬件I2C分支 */

#else /* 软件I2C实现 */
	
	/* //dev_addr <<= 1;		//7位IIC地址 */
	dev_addr &= ~(1<<0);	/* 最低位清0，IIC写 */
	/* //dev_addr |= (1<<0);	//最低位置1，IIC读 */
	
	soft_i2c_start(); /* 产生I2C起始信号 */
	
	soft_i2c_send_byte(dev_addr);						/* 发送IIC设备地址(写方向) */
	if(soft_i2c_wait_ack(time_out) == SOFT_I2C_ERR) /* 等待从机应答 */
		return SOFT_I2C_ERR; /* 无应答,读取失败 */
	
	/* 发送存储器地址或寄存器地址 */
	if(mem_add_size == I2C_MEMADD_16BIT) /* 16位存储器地址模式 */
	{
		soft_i2c_send_byte((mem_addr>>8)&0X00FF); /* 先发送存储器地址高8位 */
		if(soft_i2c_wait_ack(time_out) == SOFT_I2C_ERR) /* 等待应答 */
			return SOFT_I2C_ERR; /* 无应答,读取失败 */
	}
	soft_i2c_send_byte(mem_addr & 0X00FF);						/* 发送存储器地址低8位 */
	if(soft_i2c_wait_ack(time_out) == SOFT_I2C_ERR) /* 等待应答 */
		return SOFT_I2C_ERR; /* 无应答,读取失败 */
	
	
	soft_i2c_start(); /* 重复起始信号,切换为读方向 */
	
	dev_addr |= (1<<0);	/* 最低位置1，IIC读 */
	
	soft_i2c_send_byte(dev_addr);					/* 发送IIC设备地址(读方向) */
	if(soft_i2c_wait_ack(time_out) == SOFT_I2C_ERR) /* 等待从机应答 */
		return SOFT_I2C_ERR; /* 无应答,读取失败 */
	
	while(len) /* 逐字节接收数据 */
	{
		
		*pbuffer = soft_i2c_receive_byte(); /* 接收一个字节存入缓冲区 */
		pbuffer ++ ; /* 缓冲区指针递增 */
		len -- ; /* 待接收长度递减 */
		if(len == 0) /* 最后一个字节 */
			soft_i2c_no_ack(); /* 发送非应答,结束读取 */
		else
			soft_i2c_ack(); /* 发送应答,继续接收 */
		
	}
	
	soft_i2c_stop(); /* 产生I2C停止信号 */
	
	return SOFT_I2C_OK; /* 读取成功 */
	
#endif /* 条件编译结束 */
}



#ifdef SOFTWARE_I2C /* 软件I2C底层时序函数 */

/**
  * @brief I2C开始信号
  * @param 无
  * @retval	无
  */
void soft_i2c_start(void)
{
	SDA_OUT(1); /* SDA置高 */
	SCL_OUT(1); /* SCL置高,总线空闲 */

	delay_us(5); /* 建立时间延时 */
	
	SDA_OUT(0); /* SCL高电平期间SDA由高变低,产生起始信号 */
	delay_us(5); /* 保持起始条件 */
	SCL_OUT(0); /* 拉低SCL,准备收发数据 */
}

/**
  * @brief I2C停止信号
  * @param 无
  * @retval	无
  */
void soft_i2c_stop(void)
{
	SDA_OUT(0); /* SDA置低 */
	SCL_OUT(0); /* SCL置低 */
	delay_us(5); /* 建立时间延时 */
	
	SCL_OUT(1); /* SCL拉高 */
	delay_us(5); /* 保持时钟高电平 */
	SDA_OUT(1); /* SCL高电平期间SDA由低变高,产生停止信号 */
	delay_us(5); /* 停止后释放总线延时 */
}

/**
  * @brief I2C等待应答
  * @param time_out-等待的时间,单位5us
  * @retval	SOFT_I2C_OK-收到应答 SOFT_I2C_ERR-超时未应答
  */
uint8_t soft_i2c_wait_ack(uint32_t time_out)
{
	SDA_OUT(1); /* 释放SDA,由从机控制应答位 */
	delay_us(5); /* 延时 */
	SCL_OUT(1); /* SCL拉高,输出第9个时钟 */
	delay_us(1); /* 延时等待SDA稳定 */
	
	while(SDA_IN)	/* 如果读到SDA线为1，则等待。应答信号应是0 */
	{
		if(--time_out == 0) /* 超时计数递减,减到0判定无应答 */
		{
			soft_i2c_stop();	/* 超时未应答，停止总线 */
			return SOFT_I2C_ERR; /* 返回应答超时错误 */
		}
		delay_us(5); /* 延时后重试检测 */
	}
	
	SCL_OUT(0); /* 拉低SCL,结束应答时钟 */
	return SOFT_I2C_OK; /* 收到应答 */
}


/**
  * @brief I2C发送应答
  * @param 无
  * @retval	无
  */
void soft_i2c_ack(void)
{
	SCL_OUT(0); /* SCL置低,准备输出应答 */
	SDA_OUT(0); /* SDA置低表示应答 */
	delay_us(5); /* 延时 */
	SCL_OUT(1); /* SCL拉高,输出第9个时钟 */
	delay_us(5); /* 保持应答位 */
	SCL_OUT(0); /* SCL拉低,应答完成 */
}

/**
  * @brief I2C发送非应答
  * @param 无
  * @retval	无
  */
void soft_i2c_no_ack(void)
{
	SCL_OUT(0); /* SCL置低,准备输出非应答 */
	SDA_OUT(1); /* SDA置高表示非应答 */
	delay_us(5); /* 延时 */
	SCL_OUT(1); /* SCL拉高,输出第9个时钟 */
	delay_us(5); /* 保持非应答位 */
	SCL_OUT(0); /* SCL拉低,非应答完成 */
}

/**
  * @brief I2C发送一字节数据
  * @param byte-待发送的数据
  * @retval	无
  */
void soft_i2c_send_byte(uint8_t byte)
{
	unsigned char i=0; /* 位计数变量 */
	
	SCL_OUT(0); /* 拉低SCL,允许SDA变化 */
	
	for(i=0;i<8;i++) /* 从最高位起逐位发送8位 */
	{
		SDA_OUT((byte & 0X80) >> 7); /* 取最高位输出到SDA */
		
		byte <<= 1; /* 左移一位,准备发送下一位 */
		
		delay_us(5); /* 数据建立时间 */
		SCL_OUT(1); /* SCL拉高,从机采样该位 */
		delay_us(5); /* 保持时钟高电平 */
		SCL_OUT(0); /* SCL拉低,准备下一位 */
	}
}

/**
  * @brief I2C接收一字节数据
  * @param 无
  * @retval	接收到的数据
  */
uint8_t soft_i2c_receive_byte(void)
{
	unsigned char i = 0 , byte = 0; /* 位计数与接收缓存变量 */
	
	SDA_OUT(1);		/* 开漏状态下拉高SDA线以便读取输入数据 */
	
	for(i=0;i<8;i++) /* 逐位接收8位,高位在前 */
	{
		SCL_OUT(0); /* 时钟低电平,从机准备数据 */
		delay_us(5); /* 等待数据稳定 */
		SCL_OUT(1); /* SCL拉高,采样SDA读取该位 */
		
		byte <<= 1; /* 接收缓存左移一位 */
		if(SDA_IN) /* 采样SDA电平 */
			byte ++ ; /* 该位为1,最低位置1 */
		delay_us(5);	 /* 保持时钟高电平 */
	}
	return byte; /* 返回接收到的字节 */
}
#endif /* SOFTWARE_I2C条件编译结束 */



/***************************************** 文件结束 *********************************************/
