/*
*******************************************************************************************************
*
* 文件名称 : i2c.h
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : I2C驱动文件
* 
*******************************************************************************************************
*/

#ifndef _I2C_H     /* 头文件保护宏 */
#define _I2C_H     /* 定义头文件保护宏 */

#ifdef __cplusplus      /* 若使用C++编译器编译 */
extern "C"{             /* 以C语言方式编译链接，防止函数名被C++改名 */
#endif                  /* C++兼容声明结束 */

/* 头文件 -----------------------------------------------------------*/
#include "gd32f30x.h"   /* 包含GD32F30x固件库头文件(GPIO/硬件I2C外设定义) */

/* 宏定义 -----------------------------------------------------------*/



/* 选择软件I2C或者硬件I2C */
#define SOFTWARE_I2C   /* 当前选择软件I2C(注释掉本行则自动改用硬件I2C) */
#ifndef SOFTWARE_I2C    /* 未定义软件I2C时 */
#define HARDWARE_I2C    /* 使用GD32硬件I2C外设 */
#endif                  /* 硬件I2C条件编译结束 */

/* SOFTWARE_I2C的IO控制 */
#ifdef SOFTWARE_I2C
#define SDA_OUT(n)      (n?gpio_bit_write(GPIOB,GPIO_PIN_9,SET):gpio_bit_write(GPIOB,GPIO_PIN_9,RESET))    /* SDA数据线输出电平:n=1高,n=0低(PB9) */
#define SDA_IN          gpio_input_bit_get(GPIOB,GPIO_PIN_9)    /* 读取SDA数据线输入电平(PB9) */
#define SCL_OUT(n)      (n?gpio_bit_write(GPIOB,GPIO_PIN_8,SET):gpio_bit_write(GPIOB,GPIO_PIN_8,RESET))    /* SCL时钟线输出电平:n=1高,n=0低(PB8) */
#endif

/* I2C存储器的地址增长 */
#define I2C_MEMADD_8BIT            0x00000001U    /* 存储器地址长度:8位 */
#define I2C_MEMADD_16BIT           0x00000010U    /* 存储器地址长度:16位 */

/* typedef -----------------------------------------------------------*/
/* 软件I2C操作结果状态 */
typedef enum{SOFT_I2C_OK=0,SOFT_I2C_ERR}SOFT_I2C_StatusTypeDef;   /* SOFT_I2C_OK=操作成功,SOFT_I2C_ERR=操作失败 */




/* 全局变量 ----------------------------------------------------------*/
#ifdef HARDWARE_I2C

#endif

/* 函数声明 ----------------------------------------------------------*/

void i2c_init(void);    /* I2C初始化(GPIO/外设配置) */

/* 主模式发送数据:向设备dev_addr写入pbuffer中len字节(超时time_out) */
uint8_t i2c_master_send_data(uint16_t dev_addr,uint8_t *pbuffer,uint16_t len,uint32_t time_out);
/* 主模式接收数据:从设备dev_addr读取len字节到pbuffer(超时time_out) */
uint8_t i2c_master_receive_data(uint16_t dev_addr,uint8_t *pbuffer,uint16_t len,uint32_t time_out);
/* 向设备存储器指定地址写入数据(mem_add_size:存储器地址长度8/16位) */
uint8_t i2c_mem_write(uint16_t dev_addr, uint16_t mem_addr, uint16_t mem_add_size, uint8_t *pbuffer, uint16_t len, uint32_t time_out);
/* 从设备存储器指定地址读取数据(mem_add_size:存储器地址长度8/16位) */
uint8_t i2c_mem_read(uint16_t dev_addr, uint16_t mem_addr, uint16_t mem_add_size, uint8_t *pbuffer, uint16_t len, uint32_t time_out);


void soft_i2c_start(void);      /* 产生I2C起始信号 */
void soft_i2c_stop(void);       /* 产生I2C停止信号 */
uint8_t soft_i2c_wait_ack(uint32_t time_out);   /* 等待从机应答(超时返回错误) */
void soft_i2c_ack(void);        /* 产生ACK应答 */
void soft_i2c_no_ack(void);     /* 产生NACK非应答 */
void soft_i2c_send_byte(uint8_t byte);          /* 发送一个字节 */
uint8_t soft_i2c_receive_byte(void);            /* 接收一个字节 */

#ifdef __cplusplus      /* 若使用C++编译器编译(原文件遗留的重复代码块) */
extern "C"{             /* 以C语言方式编译链接 */
#endif                  /* C++兼容声明结束 */

#endif /* _I2C_H */   /* 头文件保护宏结束 */

/***************************************** 文件结束 *********************************************/
