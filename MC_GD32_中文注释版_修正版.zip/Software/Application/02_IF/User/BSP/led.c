/*
*******************************************************************************************************
*
* 文件名称 : led.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : LED 指示灯驱动(GPIO 初始化、点亮/熄灭/翻转)
* 
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "led.h" /* LED 驱动接口与引脚定义 */

/* 宏定义 ------------------------------------------------------------------------------------------*/


/* 变量定义 ----------------------------------------------------------------------------------------*/
static uint32_t GPIO_PORT[LEDn] = {LED1_GPIO_PORT, LED2_GPIO_PORT,LED3_GPIO_PORT}; /* 各 LED 的 GPIO 端口数组 */
static uint32_t GPIO_PIN[LEDn] = {LED1_PIN, LED2_PIN, LED3_PIN}; /* 各 LED 的 GPIO 引脚号数组 */

/* 函数定义 -----------------------------------------------------------------------------------------*/
/**
  * @brief LED 引脚初始化
  * @param 无
  * @retval 无
  */
void led_init(void)
{
    /* 使能 GPIO 时钟 */
    rcu_periph_clock_enable(LED1_GPIO_CLK); /* 使能 LED1 GPIO 时钟 */
    rcu_periph_clock_enable(LED2_GPIO_CLK); /* 使能 LED2 GPIO 时钟 */
    rcu_periph_clock_enable(LED3_GPIO_CLK); /* 使能 LED3 GPIO 时钟 */
    rcu_periph_clock_enable(RCU_AF); /* 使能复用功能(AF)时钟 */
    
    gpio_pin_remap_config(GPIO_SWJ_SWDPENABLE_REMAP, ENABLE); /* SWJ 重映射：关闭 JTAG 仅保留 SWD 调试口 */

    /* 配置 LED GPIO 端口 */ 
    gpio_init(GPIO_PORT[LED1], GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ,GPIO_PIN[LED1]); /* LED1 配置为推挽输出 */
    gpio_init(GPIO_PORT[LED2], GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ,GPIO_PIN[LED2]); /* LED2 配置为推挽输出 */
    gpio_init(GPIO_PORT[LED3], GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ,GPIO_PIN[LED3]); /* LED3 配置为推挽输出 */

    gpio_bit_write(GPIO_PORT[LED1], GPIO_PIN[LED1],SET); /* LED1 默认输出高电平(熄灭) */
    gpio_bit_write(GPIO_PORT[LED2], GPIO_PIN[LED2],SET); /* LED2 默认输出高电平(熄灭) */
    gpio_bit_write(GPIO_PORT[LED3], GPIO_PIN[LED3],SET); /* LED3 默认输出高电平(熄灭) */
}


/**
  * @brief 点亮指定 LED
  * @param lednum: 要点亮的 LED 编号
  * @retval 无
  */
void led_on(led_typedef_enum lednum)
{
    GPIO_BC(GPIO_PORT[lednum]) = GPIO_PIN[lednum]; /* 写清除寄存器(输出低电平)：点亮 LED */
}

/**
  * @brief 熄灭指定 LED
  * @param lednum: 要熄灭的 LED 编号
  * @retval 无
  */
void led_off(led_typedef_enum lednum)
{
    GPIO_BOP(GPIO_PORT[lednum]) = GPIO_PIN[lednum]; /* 写置位寄存器(输出高电平)：熄灭 LED */
}

/**
  * @brief 翻转指定 LED 状态
  * @param lednum: 要翻转的 LED 编号
  * @retval 无
  */
void led_toggle(led_typedef_enum lednum)
{
    gpio_bit_write(GPIO_PORT[lednum], GPIO_PIN[lednum], /* 读取当前输出电平取反后重新输出，实现翻转 */
                    (bit_status)(1-gpio_output_bit_get(GPIO_PORT[lednum], GPIO_PIN[lednum])));
}


/* 局部函数定义 -----------------------------------------------------------------------------------*/
/**
  * @brief 
  * @param None
  * @retval None
  */


/***************************************** 文件结束 *********************************************/
