/*
*******************************************************************************************************
*
* 文件名称 : led.h
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : LED驱动头文件
* 
*******************************************************************************************************
*/
#ifndef _LED_H_     /* 头文件保护宏,防止重复包含 */
#define _LED_H_     /* 定义头文件保护宏 */

#ifdef __cplusplus      /* 若使用C++编译器编译 */
extern "C"{             /* 以C语言方式编译链接,防止函数名被C++改名 */
#endif                  /* C++兼容声明结束 */

/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "gd32f30x.h"   /* 包含GD32F30x固件库头文件 */


/* 宏定义 ------------------------------------------------------------------------------------------*/
#define LEDn                             3U      /* 板载LED数量 */

#define LED1_PIN                         GPIO_PIN_2      /* LED1引脚:PD2 */
#define LED1_GPIO_PORT                   GPIOD           /* LED1端口 */
#define LED1_GPIO_CLK                    RCU_GPIOD       /* LED1端口时钟 */
  
#define LED2_PIN                         GPIO_PIN_12     /* LED2引脚:PC12 */
#define LED2_GPIO_PORT                   GPIOC           /* LED2端口 */
#define LED2_GPIO_CLK                    RCU_GPIOC       /* LED2端口时钟 */
  
#define LED3_PIN                         GPIO_PIN_15     /* LED3引脚:PA15 */
#define LED3_GPIO_PORT                   GPIOA           /* LED3端口 */
#define LED3_GPIO_CLK                    RCU_GPIOA       /* LED3端口时钟 */

#define LED_FAULT                       LED3    /* 故障指示灯(复用LED3) */
#define LED_SYS                         LED2    /* 系统运行指示灯(复用LED2) */

typedef enum 
{
    LED1 = 0,   /* LED1,编号0 */
    LED2 = 1,   /* LED2,编号1 */
    LED3 = 2    /* LED3,编号2 */
} led_typedef_enum;     /* LED编号枚举类型 */

/* 变量定义 ----------------------------------------------------------------------------------------*/


/* 函数定义 -----------------------------------------------------------------------------------------*/
void led_init(void);                            /* 初始化全部LED(GPIO时钟/SWJ重映射/推挽输出) */
void led_on(led_typedef_enum lednum);           /* 点亮指定LED(引脚输出低电平) */
void led_off(led_typedef_enum lednum);          /* 熄灭指定LED(引脚输出高电平) */
void led_toggle(led_typedef_enum lednum);       /* 翻转指定LED输出状态 */

#ifdef __cplusplus      /* 若使用C++编译器编译(此处与文件头部重复书写,按原样保留) */
extern "C"{
#endif                  /* C++兼容声明结束 */

#endif /* _LED_H_ */

/***************************************** 文件结束 *********************************************/
