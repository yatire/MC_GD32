/*
*******************************************************************************************************
*
* 文件名称 : spi.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : SPI 驱动
*
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "spi.h" /* SPI 驱动接口头文件 */

/* 宏定义 ----------------------------------------------------------------------------------------*/


/* 变量定义 ----------------------------------------------------------------------------------------*/


/* 函数定义 ----------------------------------------------------------------------------------------*/

/**
  * @brief SPI0 初始化
  * @param 无
  * @retval 无
  */
void spi0_init(void)
{
    spi_parameter_struct spi_init_struct; /* SPI 参数初始化结构体 */

    rcu_periph_clock_enable(RCU_GPIOA); /* 使能 GPIOA 外设时钟 */
    rcu_periph_clock_enable(RCU_SPI0); /* 使能 SPI0 外设时钟 */

    /* PA5(SCK)、PA7(MOSI) 配置为复用推挽输出 */
    gpio_init(GPIOA, GPIO_MODE_AF_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_5 | GPIO_PIN_7);
    /* PA6(MISO) 配置为浮空输入 */
    gpio_init(GPIOA, GPIO_MODE_IN_FLOATING, GPIO_OSPEED_50MHZ, GPIO_PIN_6);

    /* SPI0 参数配置 */
    spi_init_struct.trans_mode           = SPI_TRANSMODE_FULLDUPLEX; /* 全双工收发模式 */
    spi_init_struct.device_mode          = SPI_MASTER; /* 主机模式 */
    spi_init_struct.frame_size           = SPI_FRAMESIZE_16BIT; /* 数据帧长度 16 位 */
    spi_init_struct.clock_polarity_phase = SPI_CK_PL_LOW_PH_2EDGE; /* CPOL=0/CPHA=1: 空闲时钟低电平, 第 2 边沿采样 */
    spi_init_struct.nss                  = SPI_NSS_SOFT; /* NSS 片选由软件控制 */
    spi_init_struct.prescale             = SPI_PSC_64; /* 波特率 64 分频 */
    spi_init_struct.endian               = SPI_ENDIAN_MSB; /* 高位(MSB)在前 */
    spi_init(SPI0, &spi_init_struct); /* 按上述参数初始化 SPI0 */

    spi_enable(SPI0); /* 使能 SPI0 外设 */
}

/**
  * @brief SPI2 初始化
  * @param 无
  * @retval 无
  */
void spi2_init(void)
{
    spi_parameter_struct spi_init_struct; /* SPI 参数初始化结构体 */

    rcu_periph_clock_enable(RCU_GPIOB); /* 使能 GPIOB 外设时钟 */
    rcu_periph_clock_enable(RCU_SPI2); /* 使能 SPI2 外设时钟 */

    /* SWJ 调试口重映射, 释放被调试口占用的 PB3 引脚供 SPI2 使用 */
    gpio_pin_remap_config(GPIO_SWJ_SWDPENABLE_REMAP, ENABLE);

    /* PB3(SCK)、PB5(MOSI) 配置为复用推挽输出 */
    gpio_init(GPIOB, GPIO_MODE_AF_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_3 | GPIO_PIN_5);

    /* SPI2 参数配置 */
    spi_init_struct.trans_mode           = SPI_TRANSMODE_FULLDUPLEX; /* 全双工收发模式 */
    spi_init_struct.device_mode          = SPI_MASTER; /* 主机模式 */
    spi_init_struct.frame_size           = SPI_FRAMESIZE_8BIT; /* 数据帧长度 8 位 */
    spi_init_struct.clock_polarity_phase = SPI_CK_PL_LOW_PH_1EDGE; /* CPOL=0/CPHA=0: 空闲时钟低电平, 第 1 边沿采样 */
    spi_init_struct.nss                  = SPI_NSS_SOFT; /* NSS 片选由软件控制 */
    spi_init_struct.prescale             = 0; /* 波特率 2 分频(PSC=0) */
    spi_init_struct.endian               = SPI_ENDIAN_MSB; /* 高位(MSB)在前 */
    spi_init(SPI2, &spi_init_struct); /* 按上述参数初始化 SPI2 */

    spi_enable(SPI2); /* 使能 SPI2 外设 */
}

/**
  * @brief SPI2 发送并接收 8 位数据
  * @param 无
  * @retval 无
  */
uint8_t spi2_transmit_receive_data(uint8_t data)
{
    while(RESET == spi_i2s_flag_get(SPI2, SPI_FLAG_TBE)) { /* 等待发送缓冲区空(TBE), 可写入新数据 */
    }
    spi_i2s_data_transmit(SPI2, data); /* 将数据写入发送缓冲区启动发送 */

    while(RESET == spi_i2s_flag_get(SPI2, SPI_FLAG_RBNE)) { /* 等待接收缓冲区非空(RBNE), 收到数据 */
    }
    return spi_i2s_data_receive(SPI2); /* 读出并返回接收到的数据 */
}

/**
  * @brief SPI0 发送并接收 16 位数据
  * @param 无
  * @retval 无
  */
uint16_t spi0_transmit_receive_data(uint16_t data)
{
    while(RESET == spi_i2s_flag_get(SPI0, SPI_FLAG_TBE)) { /* 等待发送缓冲区空(TBE), 可写入新数据 */
    }
    spi_i2s_data_transmit(SPI0, data); /* 将数据写入发送缓冲区启动发送 */

    while(RESET == spi_i2s_flag_get(SPI0, SPI_FLAG_RBNE)) { /* 等待接收缓冲区非空(RBNE), 收到数据 */
    }
    return spi_i2s_data_receive(SPI0); /* 读出并返回接收到的数据 */
}

/* 局部函数 -----------------------------------------------------------------------------------*/
/**
  * @brief
  * @param 无
  * @retval 无
  */


/***************************************** 文件结束 *********************************************/
