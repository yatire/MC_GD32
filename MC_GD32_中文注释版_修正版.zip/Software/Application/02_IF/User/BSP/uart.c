/*
*******************************************************************************************************
*
* 文件名称 : uart.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 串口驱动文件(USART2+DMA0收发,DMA方式发送与接收)
*
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include <string.h> /* 标准库:memcpy内存拷贝 */
#include "uart.h" /* 串口驱动接口声明(UART2_DATA_ADDRESS等宏) */

/* 宏定义 ------------------------------------------------------------------------------------------*/


/* 变量定义 ----------------------------------------------------------------------------------------*/
static uint8_t rxbuffer[32] = {0}; /* 串口DMA接收缓冲区(32字节,由DMA自动填入) */
static uint8_t txbuffer[32] = {0}; /* 串口DMA发送缓冲区(32字节) */

/* 函数定义 -----------------------------------------------------------------------------------------*/
/**
  * @brief 串口初始化
  * @param 无
  * @retval 无
  */
void usart_init(void)
{
    dma_parameter_struct dma_init_struct; /* DMA初始化参数结构体 */
    
    /* 使能GPIO时钟 */
    rcu_periph_clock_enable(RCU_GPIOC);
    /* 使能DMA0时钟 */
    rcu_periph_clock_enable(RCU_DMA0);
    /* 使能USART2时钟 */
    rcu_periph_clock_enable(RCU_USART2);

    /* 使能复用功能时钟 */
    rcu_periph_clock_enable(RCU_AF);
    
    /* USART2部分重映射:TX-PC10/RX-PC11 */
    gpio_pin_remap_config(GPIO_USART2_PARTIAL_REMAP,ENABLE);

    /* PC10复用为USART2_TX(复用推挽输出) */
    gpio_init(GPIOC, GPIO_MODE_AF_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_10);

    /* PC11复用为USART2_RX(浮空输入) */
    gpio_init(GPIOC, GPIO_MODE_IN_FLOATING, GPIO_OSPEED_50MHZ, GPIO_PIN_11);

    /* USART2参数配置 */
    usart_deinit(USART2); /* 复位USART2外设 */
    usart_baudrate_set(USART2, 921600U); /* 设置波特率921600 */
    usart_receive_config(USART2, USART_RECEIVE_ENABLE); /* 使能接收功能 */
    usart_transmit_config(USART2, USART_TRANSMIT_ENABLE); /* 使能发送功能 */
    usart_enable(USART2); /* 使能USART2 */
    
    /* 复位DMA0通道1(USART2发送) */
    dma_deinit(DMA0, DMA_CH1);
    dma_struct_para_init(&dma_init_struct); /* DMA参数结构体填入默认值 */
    
    dma_init_struct.direction = DMA_MEMORY_TO_PERIPHERAL; /* 传输方向:存储器到外设(发送) */
    dma_init_struct.memory_addr = (uint32_t)txbuffer; /* 存储器地址:发送缓冲区首地址 */
    dma_init_struct.memory_inc = DMA_MEMORY_INCREASE_ENABLE; /* 存储器地址递增使能 */
    dma_init_struct.memory_width = DMA_MEMORY_WIDTH_8BIT; /* 存储器数据宽度:8位 */
    dma_init_struct.number = ARRAYNUM(txbuffer); /* 传输数据数量:32(缓冲区大小) */
    dma_init_struct.periph_addr = UART2_DATA_ADDRESS; /* 外设地址:USART2数据寄存器 */
    dma_init_struct.periph_inc = DMA_PERIPH_INCREASE_DISABLE; /* 外设地址固定不递增 */
    dma_init_struct.periph_width = DMA_PERIPHERAL_WIDTH_8BIT; /* 外设数据宽度:8位 */
    dma_init_struct.priority = DMA_PRIORITY_ULTRA_HIGH; /* 通道优先级:超高 */
    dma_init(DMA0, DMA_CH1, &dma_init_struct); /* 按上述参数初始化DMA0通道1 */
    
    /* 复位DMA0通道2(USART2接收) */
    dma_deinit(DMA0, DMA_CH2);
    dma_struct_para_init(&dma_init_struct); /* DMA参数结构体填入默认值 */

    dma_init_struct.direction = DMA_PERIPHERAL_TO_MEMORY; /* 传输方向:外设到存储器(接收) */
    dma_init_struct.memory_addr = (uint32_t)rxbuffer; /* 存储器地址:接收缓冲区首地址 */
    dma_init_struct.memory_inc = DMA_MEMORY_INCREASE_ENABLE; /* 存储器地址递增使能 */
    dma_init_struct.memory_width = DMA_MEMORY_WIDTH_8BIT; /* 存储器数据宽度:8位 */
    dma_init_struct.number = ARRAYNUM(rxbuffer); /* 传输数据数量:32(缓冲区大小) */
    dma_init_struct.periph_addr = UART2_DATA_ADDRESS; /* 外设地址:USART2数据寄存器 */
    dma_init_struct.periph_inc = DMA_PERIPH_INCREASE_DISABLE; /* 外设地址固定不递增 */
    dma_init_struct.periph_width = DMA_PERIPHERAL_WIDTH_8BIT; /* 外设数据宽度:8位 */
    dma_init_struct.priority = DMA_PRIORITY_ULTRA_HIGH; /* 通道优先级:超高 */
    dma_init(DMA0, DMA_CH2, &dma_init_struct); /* 按上述参数初始化DMA0通道2 */
    
    /* 配置DMA工作模式 */
    dma_circulation_disable(DMA0, DMA_CH1); /* 通道1禁止循环模式(发完即停) */
    dma_memory_to_memory_disable(DMA0, DMA_CH1); /* 通道1禁止存储器到存储器模式 */
    dma_circulation_disable(DMA0, DMA_CH2); /* 通道2禁止循环模式 */
    dma_memory_to_memory_disable(DMA0, DMA_CH2); /* 通道2禁止存储器到存储器模式 */
    
    /* 使能USART2的接收DMA请求 */
    usart_dma_receive_config(USART2, USART_RECEIVE_DMA_ENABLE);
    /* 使能DMA0通道1传输完成中断(此功能已停用) */
/*    dma_interrupt_enable(DMA0, DMA_CH1, DMA_INT_FTF); */
    /* 使能DMA0通道1 */
    dma_channel_enable(DMA0, DMA_CH1);
    /* 使能USART2的发送DMA请求 */
    usart_dma_transmit_config(USART2, USART_TRANSMIT_DMA_ENABLE);
    /* 使能DMA0通道2传输完成中断(此功能已停用) */
/*    dma_interrupt_enable(DMA0, DMA_CH2, DMA_INT_FTF); */
    /* 使能DMA0通道2 */
    dma_channel_enable(DMA0, DMA_CH2);
}

/**
  * @brief 异步发送数据(DMA方式)
  * @param buf-待发送数据缓冲区
  * @param len-数据长度(字节)
  * @retval 无
  */
void usart_send_data(uint8_t *buf,uint8_t len)
{
    if(len < ARRAYNUM(txbuffer)) /* 发送长度必须小于缓冲区容量 */
    {
        if(dma_flag_get(DMA0, DMA_CH1, DMA_INTF_FTFIF) == SET) /* 仅当上一次DMA发送已完成(全传输标志置位)才允许重新配置 */
        {
            dma_parameter_struct dma_init_struct; /* DMA初始化参数结构体 */
            
            memcpy(txbuffer,buf,len); /* 把待发送数据拷入发送缓冲区 */
            dma_deinit(DMA0, DMA_CH1); /* 复位DMA0通道1以便重新配置 */
            dma_struct_para_init(&dma_init_struct); /* DMA参数结构体填入默认值 */
            dma_init_struct.direction = DMA_MEMORY_TO_PERIPHERAL; /* 传输方向:存储器到外设(发送) */
            dma_init_struct.memory_addr = (uint32_t)txbuffer; /* 存储器地址:发送缓冲区首地址 */
            dma_init_struct.memory_inc = DMA_MEMORY_INCREASE_ENABLE; /* 存储器地址递增使能 */
            dma_init_struct.memory_width = DMA_MEMORY_WIDTH_8BIT; /* 存储器数据宽度:8位 */
            dma_init_struct.number = len; /* 传输数据数量:本次实际长度 */
            dma_init_struct.periph_addr = UART2_DATA_ADDRESS; /* 外设地址:USART2数据寄存器 */
            dma_init_struct.periph_inc = DMA_PERIPH_INCREASE_DISABLE; /* 外设地址固定不递增 */
            dma_init_struct.periph_width = DMA_PERIPHERAL_WIDTH_8BIT; /* 外设数据宽度:8位 */
            dma_init_struct.priority = DMA_PRIORITY_ULTRA_HIGH; /* 通道优先级:超高 */
            dma_init(DMA0, DMA_CH1, &dma_init_struct); /* 按上述参数初始化DMA0通道1 */
            /* 配置DMA工作模式 */
            dma_circulation_disable(DMA0, DMA_CH1); 
            /* 使能DMA通道1 */
            dma_channel_enable(DMA0, DMA_CH1);
        }
    }
}


/* 局部函数 -----------------------------------------------------------------------------------*/
/**
  * @brief 无局部函数
  * @param 无
  * @retval 无
  */


/***************************************** 文件结束 *********************************************/
