/*!
    \file    gd32f30x_it.c
    \brief   中断服务函数

    \version 2017-02-10, V1.0.0, firmware for GD32F30x
    \version 2018-10-10, V1.1.0, firmware for GD32F30x
    \version 2018-12-25, V2.0.0, firmware for GD32F30x
    \version 2020-09-30, V2.1.0, firmware for GD32F30x
*/

/*
    版权所有 (c) 2020, GigaDevice Semiconductor Inc.

    在满足以下条件的前提下, 允许以源码和二进制形式重新分发和使用本软件(无论是否修改):

    1. 以源码形式重新分发时, 必须保留上述版权声明、本条件列表及以下免责声明。
    2. 以二进制形式重新分发时, 必须在随发布的文档和/或其他材料中复制上述版权声明、
       本条件列表及以下免责声明。
    3. 未经版权持有者或贡献者事先书面许可, 不得以其名义为本软件的衍生产品做背书或推广。

    本软件由版权持有者及贡献者"按原样"提供, 不提供任何明示或默示的保证, 包括但不限于
    对适销性和特定用途适用性的默示保证。在任何情况下, 无论因何原因(合同、严格责任或
    侵权行为, 包括疏忽或其他方式)以及无论是否已被告知存在此类损害的可能性, 版权持有者
    或贡献者均不对任何直接、间接、偶然、特殊、惩戒性或后果性损害(包括但不限于替代商品
    或服务的采购、使用、数据或利润的损失、或业务中断)承担责任。
*/

#include "gd32f30x_it.h" /* 中断服务函数及相关声明头文件 */
#include "systick.h" /* 滴答定时器配置头文件 */

/*!
    \brief      此函数处理 NMI(不可屏蔽中断)异常
    \param[in]  无
    \param[out] 无
    \retval     无
*/
void NMI_Handler(void)
{
}

/*!
    \brief      此函数处理 HardFault(硬错误)异常
    \param[in]  无
    \param[out] 无
    \retval     无
*/
void HardFault_Handler(void)
{
    /* 发生硬错误异常时进入死循环 */
    while (1){ /* 停机等待, 便于调试器定位错误 */
    }
}

/*!
    \brief      此函数处理 MemManage(存储器管理)异常
    \param[in]  无
    \param[out] 无
    \retval     无
*/
void MemManage_Handler(void)
{
    /* 发生存储器管理异常时进入死循环 */
    while (1){ /* 停机等待, 便于调试器定位错误 */
    }
}

/*!
    \brief      此函数处理 BusFault(总线错误)异常
    \param[in]  无
    \param[out] 无
    \retval     无
*/
void BusFault_Handler(void)
{
    /* 发生总线错误异常时进入死循环 */
    while (1){ /* 停机等待, 便于调试器定位错误 */
    }
}

/*!
    \brief      此函数处理 UsageFault(用法错误)异常
    \param[in]  无
    \param[out] 无
    \retval     无
*/
void UsageFault_Handler(void)
{
    /* 发生用法错误异常时进入死循环 */
    while (1){ /* 停机等待, 便于调试器定位错误 */
    }
}

/*!
    \brief      此函数处理 SVC(系统服务调用)异常
    \param[in]  无
    \param[out] 无
    \retval     无
*/
void SVC_Handler(void)
{
}

/*!
    \brief      此函数处理 DebugMon(调试监视)异常
    \param[in]  无
    \param[out] 无
    \retval     无
*/
void DebugMon_Handler(void)
{
}

/*!
    \brief      此函数处理 PendSV(可悬起服务)异常
    \param[in]  无
    \param[out] 无
    \retval     无
*/
void PendSV_Handler(void)
{
}

/*!
    \brief      此函数处理 SysTick(滴答定时器)异常
    \param[in]  无
    \param[out] 无
    \retval     无
*/
/* SysTick_Handler 在此被注释掉, 避免与 systick.c 中的实现重复定义 */
/* void SysTick_Handler(void)
{

} */
