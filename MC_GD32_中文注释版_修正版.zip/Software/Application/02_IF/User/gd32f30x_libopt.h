/*!
    \file    gd32f30x_libopt.h
    \brief   GD32F30x固件库外设包含选项文件

    \version 2017-02-10, V1.0.0, firmware for GD32F30x
    \version 2018-10-10, V1.1.0, firmware for GD32F30x
    \version 2018-12-25, V2.0.0, firmware for GD32F30x
    \version 2020-09-30, V2.1.0, firmware for GD32F30x 
*/

/*
    版权所有 (c) 2020, GigaDevice Semiconductor Inc.

    在满足以下条件的前提下, 允许以源码和二进制形式重新分发和使用本软件(无论是否修改):

    1. 以源码形式重新分发时, 必须保留上述版权声明、本条件列表及以下免责声明。
    2. 以二进制形式重新分发时, 必须在随发布的文档和/或其他材料中复制上述版权声明、
       本条件列表及以下免责声明。
    3. 未经版权持有者或贡献者事先书面许可, 不得以其名义为本软件的衍生产品做背书或推广。

    本软件由版权持有者及贡献者"按原样"提供, 不提供任何明示或默示的保证, 包括但不限于
    对适销性和特定用途适用性的默示保证。在任何情况下, 无论因何原因(合同、严格责任或
    侵权行为, 包括疏忽或其他方式)以及无论是否已被告知存在此类损害的可能性, 版权持有者
    或贡献者均不对任何直接、间接、偶然、特殊、惩戒性或后果性损害(包括但不限于替代商品
    或服务的采购、使用、数据或利润的损失、或业务中断)承担责任。
*/

#ifndef GD32F30X_LIBOPT_H   /* 头文件保护宏,防止重复包含 */
#define GD32F30X_LIBOPT_H   /* 定义头文件保护宏 */

#include "gd32f30x_rcu.h"     /* RCU时钟控制单元 */
#include "gd32f30x_adc.h"     /* ADC模数转换器 */
#include "gd32f30x_can.h"     /* CAN总线控制器 */
#include "gd32f30x_crc.h"     /* CRC循环冗余校验 */
#include "gd32f30x_ctc.h"     /* CTC时钟校准控制器 */
#include "gd32f30x_dac.h"     /* DAC数模转换器 */
#include "gd32f30x_dbg.h"     /* DBG调试接口 */
#include "gd32f30x_dma.h"     /* DMA直接内存访问 */
#include "gd32f30x_exti.h"    /* EXTI外部中断 */
#include "gd32f30x_fmc.h"     /* FMC闪存控制器 */
#include "gd32f30x_fwdgt.h"   /* FWDGT独立看门狗 */
#include "gd32f30x_gpio.h"    /* GPIO通用输入输出 */
#include "gd32f30x_i2c.h"     /* I2C总线接口 */
#include "gd32f30x_pmu.h"     /* PMU电源管理 */
#include "gd32f30x_bkp.h"     /* BKP备份寄存器 */
#include "gd32f30x_rtc.h"     /* RTC实时时钟 */
#include "gd32f30x_sdio.h"    /* SDIO存储卡接口 */
#include "gd32f30x_spi.h"     /* SPI串行外设接口 */
#include "gd32f30x_timer.h"   /* TIMER定时器 */
#include "gd32f30x_usart.h"   /* USART通用同步异步收发器 */
#include "gd32f30x_wwdgt.h"   /* WWDGT窗口看门狗 */
#include "gd32f30x_misc.h"    /* MISC杂项(NVIC中断配置) */
#include "gd32f30x_enet.h"    /* ENET以太网控制器 */
#include "gd32f30x_exmc.h"    /* EXMC外部存储器控制器 */

#endif /* GD32F30X_LIBOPT_H */
