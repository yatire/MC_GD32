/*
*******************************************************************************************************
*
* 文件名称 : main.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 主函数文件
*
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include <string.h>    /* 标准字符串处理头文件 */
#include "gd32f30x.h"    /* GD32F30x固件库主头文件(外设寄存器定义与库函数) */
#include "gd32f30x_libopt.h"    /* GD32F30x固件库外设配置头文件(库选项) */
#include "systick.h"    /* 滴答定时器头文件(系统时基) */
#include "led.h"    /* LED驱动头文件 */
#include "motor_hardware.h"    /* 电机硬件层头文件(PWM/ADC等硬件配置) */
#include "uart.h"    /* 串口驱动头文件 */
#include "i2c.h"    /* I2C驱动头文件 */
#include "eeprom.h"    /* EEPROM(24C02)读写驱动头文件 */
#include "delay.h"    /* 延时函数头文件 */
#include "adc_simple.h"    /* ADC简易采样头文件 */
#include "drv8323rs.h"    /* DRV8323RS栅极驱动器驱动头文件 */
#include "lcd.h"    /* LCD显示驱动头文件 */
#include "lcd_init.h"    /* LCD底层初始化头文件 */
#include "can.h"    /* CAN总线驱动头文件 */
#include "foc.h"    /* FOC矢量控制算法头文件(本例用于I/F电流频率比开环) */
#include "pmsm.h"    /* PMSM电机模型头文件(FOC参数结构体、电流换算系数) */
#include "userparms.h"    /* 用户参数配置头文件 */
/* 宏定义 ------------------------------------------------------------------------------------------*/

/* 变量定义 ----------------------------------------------------------------------------------------*/
uint8_t adc_calibration = 0;    /* ADC零点标定完成标志(0=标定中，1=标定完成) */
uint32_t ia_offset = 0,ib_offset = 0,ic_offset = 0;  /* A/B/C相电流ADC零点偏置(标定阶段累加求和，完成后为4096次平均值) */
uint16_t adc_ia = 0,adc_ib = 0,adc_ic = 0;  /* A/B/C相电流ADC采样原始值(注入组转换结果) */
/* 函数定义 -----------------------------------------------------------------------------------------*/


/**
  * @brief 主函数
  * @param 无
  * @retval 无
  */
int main(void)
{
    SCB->VTOR = FLASH_BASE | 0x4000;    /* 重定位中断向量表到应用程序区(FLASH_BASE+0x4000，为Bootloader预留前16KB) */
    __enable_irq();    /* 使能全局中断 */
    
    systick_init();    /* 初始化滴答定时器(系统时基) */
    led_init();    /* 初始化LED */
    usart_init();    /* 初始化串口 */
    DRV8323RS_init();    /* 初始化DRV8323RS栅极驱动器 */
    
    motor_hardware_init();    /* 初始化电机硬件(定时器/PWM/ADC采样等) */
    motor_pwm_enable();    /* 使能电机PWM输出 */
    pmsm_foc_param.pwm_period = (float)MOTOR_PWM_PERIOD * 0.95f;    /* 设置PWM周期计数值(取95%留裕量，防止占空比到达满载) */
    pmsm_foc_init();    /* 初始化FOC模块(本例按用户参数配置为I/F电流频率比开环运行) */
    
    while(1)    /* 主循环：LED闪烁指示程序正常运行 */
    {
        led_toggle(LED1);    /* 翻转LED1状态 */
        systick_delay(100);    /* 滴答定时器延时100ms */
        led_toggle(LED2);    /* 翻转LED2状态 */
        systick_delay(100);    /* 滴答定时器延时100ms */
    }
}

void TIMER0_BRK_IRQHandler(void)    /* TIMER0刹车(BRK)中断服务函数：发生刹车故障时强制关闭PWM输出 */
{
    timer_channel_output_mode_config(TIMER0,TIMER_CH_0,TIMER_OC_MODE_INACTIVE);    /* 将W相通道(CH0)置为匹配时无效电平模式(关闭W相输出) */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_1,TIMER_OC_MODE_INACTIVE);    /* 将V相通道(CH1)置为匹配时无效电平模式(关闭V相输出) */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_2,TIMER_OC_MODE_INACTIVE);    /* 将U相通道(CH2)置为匹配时无效电平模式(关闭U相输出) */
    /* 清除TIMER中断标志位 */
    timer_interrupt_flag_clear(TIMER0,TIMER_INT_FLAG_BRK);
    
    led_on(LED_FAULT);    /* 点亮故障指示LED */
}

void ADC0_1_IRQHandler(void)    /* ADC0_1中断服务函数：ADC注入组转换完成中断(电流采样+FOC实时运算) */
{
    float temp1 = 0;    /* 临时变量：相电流换算/串口发送中转 */
    float temp2 = 0;    /* 临时变量：相电流换算/串口发送中转 */
    float temp3 = 0;    /* 临时变量：相电流换算/串口发送中转 */
    uint8_t uart_data[16] = {0};    /* 串口发送缓冲区(3个float相电流共12字节+2字节帧尾) */
    
    /* 清除ADC中断标志 */
    adc_interrupt_flag_clear(ADC0, ADC_INT_FLAG_EOIC);
    
    if(adc_calibration == 0)    /* 若尚未完成ADC零点标定则先进行零点标定 */
    {
        static uint16_t cnt;    /* 静态计数器：统计标定采样次数 */
        
        cnt++;    /* 标定采样计数加1 */
        adc_ia = adc_inserted_data_read(ADC0, IU_INSERTED_CHANNEL);    /* 读取A相电流注入组ADC转换值 */
        adc_ib = adc_inserted_data_read(ADC0, IV_INSERTED_CHANNEL);    /* 读取B相电流注入组ADC转换值 */
        adc_ic = adc_inserted_data_read(ADC0, IW_INSERTED_CHANNEL);    /* 读取C相电流注入组ADC转换值 */
        
        ia_offset += adc_ia;    /* 累加A相ADC值用于求零点均值 */
        ib_offset += adc_ib;    /* 累加B相ADC值用于求零点均值 */
        ic_offset += adc_ic;    /* 累加C相ADC值用于求零点均值 */
        
        if(cnt >= (1 << 12))    /* 累计4096(2^12)次采样后结束标定 */
        {
            adc_calibration = 1;    /* 置ADC零点标定完成标志 */
            ia_offset = ia_offset >> 12;    /* 右移12位(除以4096)求平均，得到A相零点偏置 */
            ib_offset = ib_offset >> 12;    /* 右移12位(除以4096)求平均，得到B相零点偏置 */
            ic_offset = ic_offset >> 12;    /* 右移12位(除以4096)求平均，得到C相零点偏置 */
        }
    }
    else
    {
        /* 读取ADC注入组数据寄存器 */
        adc_ia = adc_inserted_data_read(ADC0, IU_INSERTED_CHANNEL);
        adc_ib = adc_inserted_data_read(ADC0, IV_INSERTED_CHANNEL);    /* 读取B相电流注入组ADC转换值 */
        adc_ic = adc_inserted_data_read(ADC0, IW_INSERTED_CHANNEL);    /* 读取C相电流注入组ADC转换值 */

        temp1 = ((float)adc_ia - ia_offset) * ADC_TO_CURRENT_COEF;    /* (ADC值-零点偏置)×换算系数 得到A相相电流(单位A) */
        temp2 = ((float)adc_ib - ib_offset) * ADC_TO_CURRENT_COEF;    /* (ADC值-零点偏置)×换算系数 得到B相相电流(单位A) */
        temp3 = ((float)adc_ic - ic_offset) * ADC_TO_CURRENT_COEF;    /* (ADC值-零点偏置)×换算系数 得到C相相电流(单位A) */
        
        pmsm_foc_param.ia = temp1;    /* 将A相相电流写入FOC参数 */
        pmsm_foc_param.ib = temp2;    /* 将B相相电流写入FOC参数 */
        pmsm_foc_param.ic = temp3;    /* 将C相相电流写入FOC参数 */
        
        pmsm_foc_run();    /* 执行FOC运算(I/F开环：内部按电流频率比生成给定电流矢量) */
        
        temp1 = (float)pmsm_foc_param.ia;    /* 取A相相电流值转为float */
        memcpy(&uart_data[0],&temp1,4);    /* 将A相相电流(4字节float)复制到串口发送缓冲区 */
        temp2 = (float)pmsm_foc_param.ib;    /* 取B相相电流值转为float */
        memcpy(&uart_data[4],&temp2,4);    /* 将B相相电流(4字节float)复制到串口发送缓冲区 */
        temp3 = (float)pmsm_foc_param.ic;    /* 取C相相电流值转为float */
        memcpy(&uart_data[8],&temp3,4);    /* 将C相相电流(4字节float)复制到串口发送缓冲区 */
        uart_data[sizeof(uart_data)-2] = 0x80;    /* 写入帧尾第1字节0x80 */
        uart_data[sizeof(uart_data)-1] = 0x7f;    /* 写入帧尾第2字节0x7f(上位机据此解析数据帧) */
        usart_send_data(uart_data,sizeof(uart_data));    /* 通过串口发送16字节数据帧 */
        
        /* 将FOC输出的三相占空比写入PWM(更新电机输出电压矢量) */
        motor_pwm_set_duty(pmsm_foc_param.pwma,pmsm_foc_param.pwmb,pmsm_foc_param.pwmc);
    }
}

/***************************************** 文件结束 *********************************************/
