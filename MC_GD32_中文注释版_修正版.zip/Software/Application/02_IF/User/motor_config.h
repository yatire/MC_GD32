/*
*******************************************************************************************************
*
* 文件名称 : motor_config.h
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 电机参数配置头文件(ADC采样换算系数/过流阈值/PWM与霍尔定时器参数)
* 
*******************************************************************************************************
*/
#ifndef _MOTOR_CONFIG_H_    /* 头文件保护宏,防止重复包含 */
#define _MOTOR_CONFIG_H_    /* 定义头文件保护宏 */

#ifdef __cplusplus  /* C++编译环境兼容 */
extern "C"{  /* 按C语言方式编译(不做名字修饰) */
#endif

/* 头文件 ------------------------------------------------------------------------------------*/



/* 宏定义 ------------------------------------------------------------------------------------------*/
#define ADC_FULLSCALE_VOLT              (float)3.3  /* ADC满量程参考电压(V) */
#define ADC_FULL_BIT                    (1<<12)  /* ADC满量程码值(12位分辨率) */
#define SHUNT_RES                       (float)0.005  /* 电流采样电阻阻值(Ω) */
#define SHUNT_OPA_GAIN                  (float)10  /* 相电流采样运放放大倍数(倍) */
    
#define VDC_SERIES_RES                  (float)100000  /* 母线电压分压串联电阻(Ω) */
#define VDC_PARALLEL_RES                (float)5100  /* 母线电压分压并联电阻(Ω) */
    
/* ADC码值到相电流换算系数(A/LSB)=3.3V/4096码/0.005Ω/运放增益 */
#define ADC_TO_CURRENT_COEF             (float)(ADC_FULLSCALE_VOLT/ADC_FULL_BIT/SHUNT_RES/SHUNT_OPA_GAIN)
/* ADC码值到母线电压换算系数(V/LSB),含分压比(串联+并联)/并联 */
#define ADC_TO_VDC_COEF                 (float)((VDC_SERIES_RES+VDC_PARALLEL_RES)/VDC_PARALLEL_RES*ADC_FULLSCALE_VOLT/ADC_FULL_BIT)

#define PHASE_OVER_CURRENT_AMP          (float)15  /* 相电流过流保护阈值(A) */
/* 过流保护DAC比较设定值(ADC码值)=2048中点+过流阈值折算的码值 */
#define PHASE_OVER_CURRENT_DAC_VAULE    (float)(2048.0f + PHASE_OVER_CURRENT_AMP*SHUNT_RES*SHUNT_OPA_GAIN*ADC_FULL_BIT/ADC_FULLSCALE_VOLT)
    
#define SYSTEM_CORE_CLOCK               120000000  /* 系统主频(Hz):120MHz */
#define PWM_PRESCALER                   0  /* PWM定时器预分频值(0=不分频) */
#define MOTOR_PWM_FREQ_HZ               16000  /* 电机PWM频率(Hz):16kHz */
/* PWM周期寄存器值(中心对齐计数):120MHz/2/16kHz-1=3749 */
#define MOTOR_PWM_PERIOD                ((SYSTEM_CORE_CLOCK/(PWM_PRESCALER+1)/MOTOR_PWM_FREQ_HZ/2)-1)

#define HALL_TIMER_PRESCALER            119  /* 霍尔定时器预分频值:120MHz/(119+1)=1MHz计数 */
#define HALL_TIMER_FREQ_HZ              (SYSTEM_CORE_CLOCK/(HALL_TIMER_PRESCALER+1))  /* 霍尔定时器计数频率(Hz) */

/* 变量定义 ----------------------------------------------------------------------------------------*/


/* 函数定义 -----------------------------------------------------------------------------------------*/


#ifdef __cplusplus  /* C++编译环境兼容 */
extern "C"{  /* 注:按对称结构此处应为右花括号,历史遗留写法保持原样 */
#endif

#endif /* _MOTOR_CONFIG_H_ */

/***************************************** 文件结束 *********************************************/
