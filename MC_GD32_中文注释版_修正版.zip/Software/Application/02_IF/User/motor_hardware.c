/*
*******************************************************************************************************
*
* 文件名称 : motor_hardware.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 电机控制硬件配置文件
*
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "motor_hardware.h"      /* 电机硬件层头文件(PWM通道映射、ADC采样通道、霍尔与桥臂引脚定义) */
#include "motor_config.h"        /* 电机参数配置头文件(PWM周期、电流换算系数、过流阈值等) */
#include "systick.h"             /* 系统滴答定时器头文件(延时函数) */

/* 宏定义 ------------------------------------------------------------------------------------------*/


/* 变量定义 ----------------------------------------------------------------------------------------*/

/* 函数定义 -----------------------------------------------------------------------------------------*/
static void pwm_gpio_init(void);             /* PWM输出引脚GPIO初始化函数声明 */
static void pwm_timer_config(void);          /* PWM定时器(TIMER0)配置函数声明 */
static void adc_gpio_init(void);             /* ADC采样引脚GPIO初始化函数声明 */
static void adc0_config(void);               /* ADC0工作模式配置函数声明 */
static void hall_timer_config(void);         /* 霍尔接口定时器(TIMER2)配置函数声明 */

/**
  * @brief GPIO和定时器初始化
  * @param 无
  * @retval 无
  */
void motor_hardware_init(void)
{
    interrupt_init();       /* NVIC中断优先级配置 */
    pwm_gpio_init();        /* PWM输出引脚GPIO初始化 */
    pwm_timer_config();     /* PWM定时器(TIMER0)配置 */
    motor_pwm_disable();    /* 上电先关闭三相PWM输出 */
    hall_init();            /* 霍尔传感器接口初始化 */
    adc0_init();            /* ADC0初始化 */
}

/**
  * @brief NVIC中断配置
  * @param 无
  * @retval 无
  */
void interrupt_init(void)
{
    nvic_irq_enable(TIMER0_BRK_IRQn, 0, 0);      /* 使能TIMER0刹车中断, 抢占0/子优先级0(最高) */
    nvic_irq_enable(ADC0_1_IRQn, 0, 2);          /* 使能ADC0_1中断(FOC主循环入口), 抢占0/子优先级2 */
    nvic_irq_enable(TIMER2_IRQn, 1, 1);          /* 使能TIMER2霍尔捕获中断, 抢占1/子优先级1 */
}

/**
  * @brief 更新三相PWM占空比
  * @param duty_u U相占空比
  * @param duty_v V相占空比
  * @param duty_w W相占空比
  * @retval 无
  */
void motor_pwm_set_duty(uint16_t duty_u,uint16_t duty_v,uint16_t duty_w)
{
    timer_channel_output_pulse_value_config(MOTOR_PWM_TIMER,PWM_U_CHANNEL,duty_u);  /* 设置U相比较值(TIMER0_CH2) */
    timer_channel_output_pulse_value_config(MOTOR_PWM_TIMER,PWM_V_CHANNEL,duty_v);  /* 设置V相比较值(TIMER0_CH1) */
    timer_channel_output_pulse_value_config(MOTOR_PWM_TIMER,PWM_W_CHANNEL,duty_w);  /* 设置W相比较值(TIMER0_CH0) */
}



/**
  * @brief ADC0初始化
  * @param 无
  * @retval 无
  */
void adc0_init(void)
{
    adc_gpio_init();        /* ADC采样引脚GPIO初始化 */
    adc0_config();          /* ADC0工作模式与时序配置 */
}

/**
  * @brief DAC过流保护阈值输出配置
  * @param 无
  * @retval 无
  */
void comp_protect_init(void)
{
    /* 使能外设时钟 */
    rcu_periph_clock_enable(RCU_GPIOA);     /* 使能GPIOA时钟 */
    rcu_periph_clock_enable(RCU_DAC);       /* 使能DAC时钟 */
    
    /* DAC使能后, 对应GPIO引脚会自动连接到DAC转换器 */
    gpio_init(GPIOA, GPIO_MODE_AIN, GPIO_OSPEED_50MHZ, GPIO_PIN_5);    /* PA5配置为模拟输入(即DAC1输出引脚) */
    
    dac_deinit();                           /* 复位DAC外设 */
    /* 配置DAC1(输出过流阈值电压, 原注释写作DAC0) */
    dac_wave_mode_config(DAC1, DAC_WAVE_MODE_LFSR);        /* DAC1波形发生模式: LFSR噪声(未使能触发时输出仍为设定值) */
    dac_lfsr_noise_config(DAC1, DAC_LFSR_BITS10_0);        /* LFSR噪声掩码位选择bit[10:0] */
    
    /* 使能DAC1并设置输出数据 */
    dac_enable(DAC1);                       /* 使能DAC1 */
    /* dac_data_set(DAC1, DAC_ALIGN_12B_R, PHASE_OVER_CURRENT_DAC_VAULE); */    /* 重复行已停用, 见下一行 */
    dac_data_set(DAC1, DAC_ALIGN_12B_R, PHASE_OVER_CURRENT_DAC_VAULE);  /* DAC输出相电流过流阈值对应码值 */
}

/**
  * @brief 霍尔传感器初始化
  * @param 无
  * @retval 无
  */
void hall_init(void)
{
    /* 使能GPIO时钟 */
    rcu_periph_clock_enable(HALLA_GPIO_CLK);     /* 使能霍尔A相引脚端口时钟 */
    rcu_periph_clock_enable(HALLB_GPIO_CLK);     /* 使能霍尔B相引脚端口时钟 */
    rcu_periph_clock_enable(HALLC_GPIO_CLK);     /* 使能霍尔C相引脚端口时钟 */
    rcu_periph_clock_enable(RCU_AF);        /* 使能复用功能时钟 */
    
    gpio_pin_remap_config(GPIO_TIMER2_FULL_REMAP,ENABLE);  /* TIMER2完全重映射: CH0/CH1/CH2映射到霍尔引脚PC6/PC7/PC8 */
    
    gpio_init(HALLA_GPIO_PORT,GPIO_MODE_IN_FLOATING,GPIO_OSPEED_50MHZ,HALLA_GPIO_PIN);  /* 霍尔A相引脚PC6, 浮空输入 */
    gpio_init(HALLB_GPIO_PORT,GPIO_MODE_IN_FLOATING,GPIO_OSPEED_50MHZ,HALLB_GPIO_PIN);  /* 霍尔B相引脚PC7, 浮空输入 */
    gpio_init(HALLC_GPIO_PORT,GPIO_MODE_IN_FLOATING,GPIO_OSPEED_50MHZ,HALLC_GPIO_PIN);  /* 霍尔C相引脚PC8, 浮空输入 */
    
    hall_timer_config();     /* 霍尔接口定时器(TIMER2)配置 */
}

/**
  * @brief 获取霍尔传感器状态
  * @param 无
  * @retval 无
  */
uint8_t hall_get(void)
{
    uint8_t ret = 0;    /* 霍尔状态组合值(位2~0对应C/B/A) */
    
    ret |= gpio_input_bit_get(HALLA_GPIO_PORT,HALLA_GPIO_PIN);                            /* 霍尔A相电平存入bit0 */
    ret |= gpio_input_bit_get(HALLB_GPIO_PORT,HALLB_GPIO_PIN) << 1;                       /* 霍尔B相电平存入bit1 */
    ret |= gpio_input_bit_get(HALLC_GPIO_PORT,HALLC_GPIO_PIN) << 2;                       /* 霍尔C相电平存入bit2 */
    
    return ret;    /* 返回霍尔状态码(1~6为有效换相状态) */
}

/**
  * @brief 将PWM引脚恢复为定时器复用输出模式
  * @param 无
  * @retval 无
  */
void motor_pwm_pin_enable(void)
{
    gpio_init(PWM_UH_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_UH_GPIO_PIN);  /* U相上桥臂(PA10): 复用推挽输出 */
    gpio_init(PWM_VH_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_VH_GPIO_PIN);  /* V相上桥臂(PA9): 复用推挽输出 */
    gpio_init(PWM_WH_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_WH_GPIO_PIN);  /* W相上桥臂(PA8): 复用推挽输出 */

    gpio_init(PWM_UL_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_UL_GPIO_PIN);  /* U相下桥臂(PB15): 复用推挽输出 */
    gpio_init(PWM_VL_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_VL_GPIO_PIN);  /* V相下桥臂(PB14): 复用推挽输出 */
    gpio_init(PWM_WL_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_WL_GPIO_PIN);  /* W相下桥臂(PB13): 复用推挽输出 */
}

/**
  * @brief 将PWM引脚切换为普通GPIO输出并置低
  * @param 无
  * @retval 无
  */
void motor_pwm_pin_disable(void)
{
    gpio_bit_write(PWM_UH_GPIO_PORT, PWM_UH_GPIO_PIN,RESET);    /* U相上管输出置低 */
    gpio_bit_write(PWM_VH_GPIO_PORT, PWM_VH_GPIO_PIN,RESET);    /* V相上管输出置低 */
    gpio_bit_write(PWM_WH_GPIO_PORT, PWM_WH_GPIO_PIN,RESET);    /* W相上管输出置低 */

    gpio_bit_write(PWM_UL_GPIO_PORT, PWM_UL_GPIO_PIN,RESET);    /* U相下管输出置低 */
    gpio_bit_write(PWM_VL_GPIO_PORT, PWM_VL_GPIO_PIN,RESET);    /* V相下管输出置低 */
    gpio_bit_write(PWM_WL_GPIO_PORT, PWM_WL_GPIO_PIN,RESET);    /* W相下管输出置低 */
    
    gpio_init(PWM_UH_GPIO_PORT,GPIO_MODE_OUT_PP,GPIO_OSPEED_50MHZ,PWM_UH_GPIO_PIN);  /* U相上桥臂: 普通推挽输出 */
    gpio_init(PWM_VH_GPIO_PORT,GPIO_MODE_OUT_PP,GPIO_OSPEED_50MHZ,PWM_VH_GPIO_PIN);  /* V相上桥臂: 普通推挽输出 */
    gpio_init(PWM_WH_GPIO_PORT,GPIO_MODE_OUT_PP,GPIO_OSPEED_50MHZ,PWM_WH_GPIO_PIN);  /* W相上桥臂: 普通推挽输出 */

    gpio_init(PWM_UL_GPIO_PORT,GPIO_MODE_OUT_PP,GPIO_OSPEED_50MHZ,PWM_UL_GPIO_PIN);  /* U相下桥臂: 普通推挽输出 */
    gpio_init(PWM_VL_GPIO_PORT,GPIO_MODE_OUT_PP,GPIO_OSPEED_50MHZ,PWM_VL_GPIO_PIN);  /* V相下桥臂: 普通推挽输出 */
    gpio_init(PWM_WL_GPIO_PORT,GPIO_MODE_OUT_PP,GPIO_OSPEED_50MHZ,PWM_WL_GPIO_PIN);  /* W相下桥臂: 普通推挽输出 */
}

/**
  * @brief 关闭三相PWM输出
  * @param 无
  * @retval 无
  */
void motor_pwm_disable(void)
{
    timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_U_CHANNEL,TIMER_CCX_DISABLE);  /* 关闭U相正输出(CH2) */
    timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_V_CHANNEL,TIMER_CCX_DISABLE);  /* 关闭V相正输出(CH1) */
    timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_W_CHANNEL,TIMER_CCX_DISABLE);  /* 关闭W相正输出(CH0) */
    /* 关闭U相互补输出(CH2N) */
    timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_U_CHANNEL,TIMER_CCXN_DISABLE);
    /* 关闭V相互补输出(CH1N) */
    timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_V_CHANNEL,TIMER_CCXN_DISABLE);
    /* 关闭W相互补输出(CH0N) */
    timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_W_CHANNEL,TIMER_CCXN_DISABLE);
}

/**
  * @brief 使能三相PWM输出
  * @param 无
  * @retval 无
  */
void motor_pwm_enable(void)
{
    timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_U_CHANNEL,TIMER_CCX_ENABLE);  /* 使能U相正输出(CH2) */
    timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_V_CHANNEL,TIMER_CCX_ENABLE);  /* 使能V相正输出(CH1) */
    timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_W_CHANNEL,TIMER_CCX_ENABLE);  /* 使能W相正输出(CH0) */
    /* 使能U相互补输出(CH2N) */
    timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_U_CHANNEL,TIMER_CCXN_ENABLE);
    /* 使能V相互补输出(CH1N) */
    timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_V_CHANNEL,TIMER_CCXN_ENABLE);
    /* 使能W相互补输出(CH0N) */
    timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_W_CHANNEL,TIMER_CCXN_ENABLE);
}

/**
  * @brief 按电压矢量号直接用GPIO输出六步开关状态(覆盖PWM输出)
  * @param 无
  * @retval 无
  */
void motor_set_voltage_vector(int16_t vector)
{
    /* 按矢量号以GPIO电平覆盖PWM输出, 开关状态位序为c-b-a(1=上管导通) */
    switch(vector)    /* 根据矢量号选择三相开关状态 */
    {
        case 0:    /* 矢量0 */
            /* c-b-a :: 0-0-0, 三相全关(输出高阻) */
            gpio_bit_write(PWM_UH_GPIO_PORT, PWM_UH_GPIO_PIN,RESET);  /* U相上管关 */
            gpio_bit_write(PWM_VH_GPIO_PORT, PWM_VH_GPIO_PIN,RESET);  /* V相上管关 */
            gpio_bit_write(PWM_WH_GPIO_PORT, PWM_WH_GPIO_PIN,RESET);  /* W相上管关 */

            gpio_bit_write(PWM_UL_GPIO_PORT, PWM_UL_GPIO_PIN,RESET);  /* U相下管关 */
            gpio_bit_write(PWM_VL_GPIO_PORT, PWM_VL_GPIO_PIN,RESET);  /* V相下管关 */
            gpio_bit_write(PWM_WL_GPIO_PORT, PWM_WL_GPIO_PIN,RESET);  /* W相下管关 */
        break;    /* 跳出switch */
        
        case 1:    /* 矢量1 */
            /* c-b-a :: 0-0-1, W相上管导通, U/V相下管导通 */
            gpio_bit_write(PWM_UH_GPIO_PORT, PWM_UH_GPIO_PIN,RESET);  /* U相上管关 */
            gpio_bit_write(PWM_VH_GPIO_PORT, PWM_VH_GPIO_PIN,RESET);  /* V相上管关 */
            gpio_bit_write(PWM_WH_GPIO_PORT, PWM_WH_GPIO_PIN,SET);  /* W相上管开 */

            gpio_bit_write(PWM_UL_GPIO_PORT, PWM_UL_GPIO_PIN,SET);  /* U相下管开 */
            gpio_bit_write(PWM_VL_GPIO_PORT, PWM_VL_GPIO_PIN,SET);  /* V相下管开 */
            gpio_bit_write(PWM_WL_GPIO_PORT, PWM_WL_GPIO_PIN,RESET);  /* W相下管关 */
        break;    /* 跳出switch */
        
        case 2:    /* 矢量2 */
            /* c-b-a :: 0-1-1, V/W相上管导通, U相下管导通 */
            gpio_bit_write(PWM_UH_GPIO_PORT, PWM_UH_GPIO_PIN,RESET);  /* U相上管关 */
            gpio_bit_write(PWM_VH_GPIO_PORT, PWM_VH_GPIO_PIN,SET);  /* V相上管开 */
            gpio_bit_write(PWM_WH_GPIO_PORT, PWM_WH_GPIO_PIN,SET);  /* W相上管开 */

            gpio_bit_write(PWM_UL_GPIO_PORT, PWM_UL_GPIO_PIN,SET);  /* U相下管开 */
            gpio_bit_write(PWM_VL_GPIO_PORT, PWM_VL_GPIO_PIN,RESET);  /* V相下管关 */
            gpio_bit_write(PWM_WL_GPIO_PORT, PWM_WL_GPIO_PIN,RESET);  /* W相下管关 */
        break;    /* 跳出switch */
        
        case 3:    /* 矢量3 */
            /* c-b-a :: 0-1-0, V相上管导通, U/W相下管导通 */
            gpio_bit_write(PWM_UH_GPIO_PORT, PWM_UH_GPIO_PIN,RESET);  /* U相上管关 */
            gpio_bit_write(PWM_VH_GPIO_PORT, PWM_VH_GPIO_PIN,SET);  /* V相上管开 */
            gpio_bit_write(PWM_WH_GPIO_PORT, PWM_WH_GPIO_PIN,RESET);  /* W相上管关 */

            gpio_bit_write(PWM_UL_GPIO_PORT, PWM_UL_GPIO_PIN,SET);  /* U相下管开 */
            gpio_bit_write(PWM_VL_GPIO_PORT, PWM_VL_GPIO_PIN,RESET);  /* V相下管关 */
            gpio_bit_write(PWM_WL_GPIO_PORT, PWM_WL_GPIO_PIN,SET);  /* W相下管开 */
        break;    /* 跳出switch */
        
        case 4:    /* 矢量4 */
            /* c-b-a :: 1-1-0, U/V相上管导通, W相下管导通 */
            gpio_bit_write(PWM_UH_GPIO_PORT, PWM_UH_GPIO_PIN,SET);  /* U相上管开 */
            gpio_bit_write(PWM_VH_GPIO_PORT, PWM_VH_GPIO_PIN,SET);  /* V相上管开 */
            gpio_bit_write(PWM_WH_GPIO_PORT, PWM_WH_GPIO_PIN,RESET);  /* W相上管关 */

            gpio_bit_write(PWM_UL_GPIO_PORT, PWM_UL_GPIO_PIN,RESET);  /* U相下管关 */
            gpio_bit_write(PWM_VL_GPIO_PORT, PWM_VL_GPIO_PIN,RESET);  /* V相下管关 */
            gpio_bit_write(PWM_WL_GPIO_PORT, PWM_WL_GPIO_PIN,SET);  /* W相下管开 */
        break;    /* 跳出switch */
        
        case 5:    /* 矢量5 */
            /* c-b-a :: 1-0-0, U相上管导通, V/W相下管导通 */
            gpio_bit_write(PWM_UH_GPIO_PORT, PWM_UH_GPIO_PIN,SET);  /* U相上管开 */
            gpio_bit_write(PWM_VH_GPIO_PORT, PWM_VH_GPIO_PIN,RESET);  /* V相上管关 */
            gpio_bit_write(PWM_WH_GPIO_PORT, PWM_WH_GPIO_PIN,RESET);  /* W相上管关 */

            gpio_bit_write(PWM_UL_GPIO_PORT, PWM_UL_GPIO_PIN,RESET);  /* U相下管关 */
            gpio_bit_write(PWM_VL_GPIO_PORT, PWM_VL_GPIO_PIN,SET);  /* V相下管开 */
            gpio_bit_write(PWM_WL_GPIO_PORT, PWM_WL_GPIO_PIN,SET);  /* W相下管开 */
        break;    /* 跳出switch */
        
        case 6:    /* 矢量6 */
             /* c-b-a :: 1-0-1, U/W相上管导通, V相下管导通 */
            gpio_bit_write(PWM_UH_GPIO_PORT, PWM_UH_GPIO_PIN,SET);  /* U相上管开 */
            gpio_bit_write(PWM_VH_GPIO_PORT, PWM_VH_GPIO_PIN,RESET);  /* V相上管关 */
            gpio_bit_write(PWM_WH_GPIO_PORT, PWM_WH_GPIO_PIN,SET);  /* W相上管开 */

            gpio_bit_write(PWM_UL_GPIO_PORT, PWM_UL_GPIO_PIN,RESET);  /* U相下管关 */
            gpio_bit_write(PWM_VL_GPIO_PORT, PWM_VL_GPIO_PIN,SET);  /* V相下管开 */
            gpio_bit_write(PWM_WL_GPIO_PORT, PWM_WL_GPIO_PIN,RESET);  /* W相下管关 */
        break;    /* 跳出switch */
        
        case 7:    /* 矢量7 */
            /* c-b-a :: 1-1-1, 三相上管全导通 */
            gpio_bit_write(PWM_UH_GPIO_PORT, PWM_UH_GPIO_PIN,SET);  /* U相上管开 */
            gpio_bit_write(PWM_VH_GPIO_PORT, PWM_VH_GPIO_PIN,SET);  /* V相上管开 */
            gpio_bit_write(PWM_WH_GPIO_PORT, PWM_WH_GPIO_PIN,SET);  /* W相上管开 */

            gpio_bit_write(PWM_UL_GPIO_PORT, PWM_UL_GPIO_PIN,RESET);  /* U相下管关 */
            gpio_bit_write(PWM_VL_GPIO_PORT, PWM_VL_GPIO_PIN,RESET);  /* V相下管关 */
            gpio_bit_write(PWM_WL_GPIO_PORT, PWM_WL_GPIO_PIN,RESET);  /* W相下管关 */
        break;    /* 跳出switch */

        default:    /* 非法矢量号 */
            vector = 0;    /* 矢量号置0(容错处理) */
        break;    /* 跳出switch */
    }
}

/* 局部函数 -----------------------------------------------------------------------------------*/

/**
  * @brief PWM输出引脚GPIO初始化
  * @param 无
  * @retval 无
  */
static void pwm_gpio_init(void)
{
    rcu_periph_clock_enable(RCU_GPIOA);     /* 使能GPIOA时钟 */
    rcu_periph_clock_enable(RCU_GPIOB);     /* 使能GPIOB时钟 */
    rcu_periph_clock_enable(RCU_AF);        /* 使能复用功能时钟 */

    /* 配置PA8 PA9 PA10(TIMER0 CH0 CH1 CH2)为复用推挽输出 */
    gpio_init(PWM_UH_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_UH_GPIO_PIN);  /* PA10: U相上桥臂PWM输出 */
    gpio_init(PWM_VH_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_VH_GPIO_PIN);  /* PA9: V相上桥臂PWM输出 */
    gpio_init(PWM_WH_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_WH_GPIO_PIN);  /* PA8: W相上桥臂PWM输出 */

    /* 配置PB13 PB14 PB15(TIMER0 CH0N CH1N CH2N)为复用推挽输出 */
    gpio_init(PWM_UL_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_UL_GPIO_PIN);  /* PB15: U相下桥臂互补PWM输出 */
    gpio_init(PWM_VL_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_VL_GPIO_PIN);  /* PB14: V相下桥臂互补PWM输出 */
    gpio_init(PWM_WL_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_WL_GPIO_PIN);  /* PB13: W相下桥臂互补PWM输出 */

    /* 配置PB12(TIMER0 BKIN)为浮空输入 */
    gpio_init(PWM_BKIN_GPIO_PORT,GPIO_MODE_IN_FLOATING,GPIO_OSPEED_50MHZ,PWM_BKIN_GPIO_PIN);  /* 刹车输入BKIN */
}

/**
  * @brief ADC采样引脚GPIO初始化
  * @param 无
  * @retval 无
  */
static void adc_gpio_init(void)
{
    /* 使能GPIO时钟 */
    rcu_periph_clock_enable(IU_ADC_CLK);    /* 使能U相电流采样引脚(PC4)端口时钟 */
    rcu_periph_clock_enable(IV_ADC_CLK);    /* 使能V相电流采样引脚(PC5)端口时钟 */
    rcu_periph_clock_enable(IW_ADC_CLK);    /* 使能W相电流采样引脚(PB0)端口时钟 */
    rcu_periph_clock_enable(IDC_AVER_ADC_CLK);  /* 使能母线电流平均值采样引脚(PA3)端口时钟 */
    
    gpio_init(IU_ADC_PORT, GPIO_MODE_AIN, GPIO_OSPEED_MAX, IU_ADC_PIN);  /* U相电流采样引脚PC4: 模拟输入 */
    gpio_init(IV_ADC_PORT, GPIO_MODE_AIN, GPIO_OSPEED_MAX, IV_ADC_PIN);  /* V相电流采样引脚PC5: 模拟输入 */
    gpio_init(IW_ADC_PORT, GPIO_MODE_AIN, GPIO_OSPEED_MAX, IW_ADC_PIN);  /* W相电流采样引脚PB0: 模拟输入 */
    gpio_init(IDC_AVER_ADC_PORT, GPIO_MODE_AIN, GPIO_OSPEED_MAX, IDC_AVER_ADC_PIN);  /* 母线电流平均值采样引脚: 模拟输入 */
}

/**
  * @brief PWM定时器(TIMER0)配置
  * @param 无
  * @retval 无
  */
static void pwm_timer_config(void)
{
    /* 系统主频 systemcoreclock = 120MHz
    *  PWM频率 = systemcoreclock / (预分频+1) / 周期值 / 2(中心对齐模式一升一降计数)
    *  死区时间 = 2us(deadtime=0xb8,DT=(64+56)×2×t_DTS,t_DTS=1/120MHz)
    */
    timer_oc_parameter_struct timer_ocintpara;      /* 通道输出比较配置结构体 */
    timer_parameter_struct timer_initpara;          /* 定时器基础配置结构体 */
    timer_break_parameter_struct timer_breakpara;   /* 刹车/死区配置结构体 */

    rcu_periph_clock_enable(RCU_TIMER0);    /* 使能TIMER0时钟(电机三相互补PWM主定时器) */

    timer_deinit(TIMER0);    /* 复位TIMER0 */

    /* TIMER0基础配置 */
    timer_initpara.prescaler         = 0;                            /* 预分频系数0: 计数频率=120MHz */
    timer_initpara.alignedmode       = TIMER_COUNTER_CENTER_UP;      /* 中心对齐模式(计数先增后减) */
    timer_initpara.counterdirection  = TIMER_COUNTER_UP;             /* 计数方向: 向上 */
    timer_initpara.period            = MOTOR_PWM_PERIOD;             /* 周期值=3749, 决定PWM频率16kHz */
    timer_initpara.clockdivision     = TIMER_CKDIV_DIV1;             /* t_DTS时钟分割: 不分频(用于死区计算) */
    timer_initpara.repetitioncounter = 0;                            /* 重复计数器0: 每次上下溢都产生更新事件 */
    timer_init(TIMER0,&timer_initpara);  /* 初始化TIMER0 */

     /* CH0/CH0N、CH1/CH1N、CH2/CH2N通道输出模式配置 */
    timer_ocintpara.outputstate  = TIMER_CCX_ENABLE;                 /* 正向输出使能(CHx) */
    timer_ocintpara.outputnstate = TIMER_CCXN_ENABLE;                /* 互补输出使能(CHxN) */
    timer_ocintpara.ocpolarity   = TIMER_OC_POLARITY_HIGH;           /* 正向输出高电平有效 */
    timer_ocintpara.ocnpolarity  = TIMER_OCN_POLARITY_HIGH;          /* 互补输出高电平有效 */
    timer_ocintpara.ocidlestate  = TIMER_OC_IDLE_STATE_LOW;          /* 空闲状态正向输出为低 */
    timer_ocintpara.ocnidlestate = TIMER_OCN_IDLE_STATE_LOW;         /* 空闲状态互补输出为低 */

    timer_channel_output_config(TIMER0,TIMER_CH_0,&timer_ocintpara);  /* CH0输出配置(W相上下管) */
    timer_channel_output_config(TIMER0,TIMER_CH_1,&timer_ocintpara);  /* CH1输出配置(V相上下管) */
    timer_channel_output_config(TIMER0,TIMER_CH_2,&timer_ocintpara);  /* CH2输出配置(U相上下管) */
    timer_channel_output_config(TIMER0,TIMER_CH_3,&timer_ocintpara);  /* CH3输出配置(比较事件触发ADC注入组采样) */

    timer_channel_output_pulse_value_config(TIMER0,TIMER_CH_0,1000);  /* CH0比较值初值1000(W相占空比) */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_0,TIMER_OC_MODE_PWM0);  /* CH0输出模式PWM0(计数值<比较值时有效) */
    timer_channel_output_shadow_config(TIMER0,TIMER_CH_0,TIMER_OC_SHADOW_ENABLE);  /* CH0比较值写入影子寄存器 */

    timer_channel_output_pulse_value_config(TIMER0,TIMER_CH_1,1000);  /* CH1比较值初值1000(V相占空比) */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_1,TIMER_OC_MODE_PWM0);  /* CH1输出模式PWM0(计数值<比较值时有效) */
    timer_channel_output_shadow_config(TIMER0,TIMER_CH_1,TIMER_OC_SHADOW_ENABLE);  /* CH1比较值写入影子寄存器 */

    timer_channel_output_pulse_value_config(TIMER0,TIMER_CH_2,1000);  /* CH2比较值初值1000(U相占空比) */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_2,TIMER_OC_MODE_PWM0);  /* CH2输出模式PWM0(计数值<比较值时有效) */
    timer_channel_output_shadow_config(TIMER0,TIMER_CH_2,TIMER_OC_SHADOW_ENABLE);  /* CH2比较值写入影子寄存器 */
    
    timer_channel_output_pulse_value_config(TIMER0,TIMER_CH_3,timer_initpara.period - 1);  /* ADC注入组采样触发点 */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_3,TIMER_OC_MODE_PWM0);  /* CH3输出模式PWM0 */
    timer_channel_output_shadow_config(TIMER0,TIMER_CH_3,TIMER_OC_SHADOW_DISABLE);  /* CH3不使用影子寄存器(写入立即生效) */


    /* 运行/空闲输出状态、刹车、死区与写保护配置 */
    timer_breakpara.runoffstate      = TIMER_ROS_STATE_ENABLE;       /* 运行模式下输出状态: 使能 */
    timer_breakpara.ideloffstate     = TIMER_IOS_STATE_ENABLE ;      /* 空闲模式下输出状态: 使能 */
    timer_breakpara.deadtime         = 0xb8;        /* 死区时间, 0xb8对应约2us */
    timer_breakpara.breakpolarity    = TIMER_BREAK_POLARITY_LOW;     /* 刹车输入(BRK)低电平有效 */
    timer_breakpara.outputautostate  = TIMER_OUTAUTO_ENABLE;         /* 自动输出使能(OAEN=1:刹车信号撤销后,下次更新事件由硬件自动重新置位MOE) */
    timer_breakpara.protectmode      = TIMER_CCHP_PROT_OFF;          /* 互补输出写保护: 关闭 */
    timer_breakpara.breakstate       = TIMER_BREAK_ENABLE;           /* 刹车输入使能 */
    timer_break_config(TIMER0,&timer_breakpara);  /* 写入TIMER0刹车/死区配置 */
    
    /* TIMER0主输出功能使能 */
    timer_primary_output_config(TIMER0,ENABLE);  /* 使能主输出MOE(PWM输出总开关) */

    /* TIMER0更新中断使能 */
    timer_interrupt_enable(TIMER0,TIMER_INT_UP);  /* 每个PWM周期上溢/下溢各触发一次(中心对齐) */
    /* TIMER0刹车中断使能 */
    timer_interrupt_enable(TIMER0,TIMER_INT_BRK);  /* 刹车故障保护中断 */
    
    timer_interrupt_enable(TIMER0,TIMER_INT_CH3);  /* 使能CH3比较中断(与ADC注入组触发共用CH3事件) */

    /* TIMER0计数器使能 */
    timer_enable(TIMER0);    /* 启动TIMER0计数 */
}

/**
  * @brief ADC0配置
  * @param 无
  * @retval 无
  * @note ADC转换时间 = (12.5+采样周期数) / CLK_ADC
  *       CLK_ADC = APB2 / 4 = 30MHz
  *       采样周期数 = 1.5
  *       ADC转换时间 = (12.5+1.5) × (1/30M) = 0.466us(单通道)
  */
static void adc0_config(void)
{
    /* 使能ADC0时钟 */
    rcu_periph_clock_enable(RCU_ADC0);  /* 使能ADC0外设时钟 */
    /* 配置ADC时钟 */
    rcu_adc_clock_config(RCU_CKADC_CKAPB2_DIV4);  /* ADC时钟=APB2/4=30MHz */
    
    /* ADC工作模式配置 */
    adc_mode_config(ADC_MODE_FREE);   /* 独立模式(不与其他ADC同步) */
    /* ADC特殊功能配置 */
    adc_special_function_config(ADC0, ADC_SCAN_MODE, ENABLE);  /* 使能扫描模式(注入组多通道自动依次转换) */
    adc_special_function_config(ADC0, ADC_CONTINUOUS_MODE, DISABLE);    /* 关闭连续转换模式(单次触发转换) */
    /* ADC数据对齐配置 */
    adc_data_alignment_config(ADC0, ADC_DATAALIGN_RIGHT);  /* 转换结果右对齐 */

    /* ADC注入组通道长度配置 */
    adc_channel_length_config(ADC0, ADC_INSERTED_CHANNEL, 3);  /* 注入组转换通道数为3(三相相电流) */
    /* ADC注入组通道配置 */
    /* 注入序号0: U相电流通道IU_ADC_CHANNEL(PC4/CH14), 1.5周期采样 */
    adc_inserted_channel_config(ADC0, IU_INSERTED_CHANNEL, IU_ADC_CHANNEL, ADC_SAMPLETIME_1POINT5);
    /* 注入序号1: V相电流通道IV_ADC_CHANNEL(PC5/CH15), 1.5周期采样 */
    adc_inserted_channel_config(ADC0, IV_INSERTED_CHANNEL, IV_ADC_CHANNEL, ADC_SAMPLETIME_1POINT5);
    /* 注入序号2: W相电流通道IW_ADC_CHANNEL(PB0/CH8), 1.5周期采样 */
    adc_inserted_channel_config(ADC0, IW_INSERTED_CHANNEL, IW_ADC_CHANNEL, ADC_SAMPLETIME_1POINT5);
    /* ADC触发配置 */
    /* 注入组外部触发源=TIMER0_CH3比较事件(与PWM同步采样相电流) */
    adc_external_trigger_source_config(ADC0, ADC_INSERTED_CHANNEL, ADC0_1_EXTTRIG_INSERTED_T0_CH3); 
    /* ADC外部触发使能 */
    adc_external_trigger_config(ADC0, ADC_INSERTED_CHANNEL, ENABLE);  /* 使能注入组外部触发 */
    
    /* 清除ADC中断标志 */
    adc_interrupt_flag_clear(ADC0, ADC_INT_FLAG_EOC);  /* 清除规则组转换结束标志EOC */
    adc_interrupt_flag_clear(ADC0, ADC_INT_FLAG_EOIC);  /* 清除注入组转换结束标志EOIC */
    /* 使能ADC中断 */
    adc_interrupt_enable(ADC0, ADC_INT_EOIC);  /* 使能注入组转换结束中断(FOC主循环由该中断驱动) */

    /* 使能ADC接口 */
    adc_enable(ADC0);    /* 使能ADC0 */
    systick_delay(1);    /* 延时1ms等待ADC稳定 */
    /* ADC校准(含复位校准) */
    adc_calibration_enable(ADC0);  /* 启动ADC自校准 */
}

/**
  * @brief 霍尔接口定时器(TIMER2)配置
  * @param 无
  * @retval 无
  */
static void hall_timer_config(void)
{
    /* TIMER2配置: 输入捕获模式 */
    timer_ic_parameter_struct timer_icinitpara;     /* 输入捕获配置结构体 */
    timer_parameter_struct timer_initpara;          /* 定时器基础配置结构体 */

    rcu_periph_clock_enable(RCU_TIMER2);    /* 使能TIMER2时钟 */

    timer_deinit(TIMER2);    /* 复位TIMER2 */

    /* TIMER2基础配置 */
    timer_initpara.prescaler         = HALL_TIMER_PRESCALER;  /* 预分频119: 计数频率=120MHz/120=1MHz */
    timer_initpara.alignedmode       = TIMER_COUNTER_EDGE;  /* 边沿对齐模式 */
    timer_initpara.counterdirection  = TIMER_COUNTER_UP;  /* 向上计数 */
    timer_initpara.period            = 0xFFFF;  /* 周期值最大65535(1MHz计数下约65.5ms) */
    timer_initpara.clockdivision     = TIMER_CKDIV_DIV1;  /* t_DTS时钟分割: 不分频 */
    timer_initpara.repetitioncounter = 0;  /* 重复计数器0 */
    timer_init(TIMER2,&timer_initpara);  /* 初始化TIMER2 */

    /* TIMER2配置 */
    /* TIMER2输入捕获配置 */
    timer_icinitpara.icpolarity  = TIMER_IC_POLARITY_RISING;  /* 上升沿捕获 */
    timer_icinitpara.icselection = TIMER_IC_SELECTION_ITS;  /* 捕获输入映射到ITS内部触发信号(由TRGS选择,此处为CH0边沿检测,霍尔接口模式下为三路霍尔异或) */
    timer_icinitpara.icprescaler = TIMER_IC_PSC_DIV1;  /* 不分频: 每个有效边沿都捕获 */
    timer_icinitpara.icfilter    = 0x0;  /* 输入滤波器0: 不滤波 */
    timer_input_capture_config(TIMER2,TIMER_CH_0,&timer_icinitpara);  /* 配置CH0输入捕获(霍尔A相) */
    
    timer_icinitpara.icpolarity  = TIMER_IC_POLARITY_RISING;  /* 上升沿捕获 */
    timer_icinitpara.icselection = TIMER_IC_SELECTION_ITS;  /* 捕获输入映射到ITS内部触发信号(由TRGS选择,此处为CH0边沿检测,霍尔接口模式下为三路霍尔异或) */
    timer_icinitpara.icprescaler = TIMER_IC_PSC_DIV1;  /* 不分频: 每个有效边沿都捕获 */
    timer_icinitpara.icfilter    = 0x0;  /* 输入滤波器0: 不滤波 */
    timer_input_capture_config(TIMER2,TIMER_CH_1,&timer_icinitpara);  /* 配置CH1输入捕获(霍尔B相) */
    
    timer_icinitpara.icpolarity  = TIMER_IC_POLARITY_RISING;  /* 上升沿捕获 */
    timer_icinitpara.icselection = TIMER_IC_SELECTION_ITS;  /* 捕获输入映射到ITS内部触发信号(由TRGS选择,此处为CH0边沿检测,霍尔接口模式下为三路霍尔异或) */
    timer_icinitpara.icprescaler = TIMER_IC_PSC_DIV1;  /* 不分频: 每个有效边沿都捕获 */
    timer_icinitpara.icfilter    = 0x0;  /* 输入滤波器0: 不滤波 */
    timer_input_capture_config(TIMER2,TIMER_CH_2,&timer_icinitpara);  /* 配置CH2输入捕获(霍尔C相) */
    
    /* TIMER2从模式选择 */
    timer_input_trigger_source_select(TIMER2,TIMER_SMCFG_TRGSEL_CI0F_ED);  /* 触发源=CH0输入边沿检测(霍尔三路异或信号) */
    timer_slave_mode_select(TIMER2,TIMER_SLAVE_MODE_RESTART);  /* 复位模式: 霍尔边沿到来时计数器复位重计 */
    
    /* 霍尔模式配置 */
    timer_hall_mode_config(TIMER2, TIMER_HALLINTERFACE_ENABLE);  /* 使能霍尔接口模式(CH0输入=三路霍尔异或) */

    /* 使能自动重装载预装载 */
    timer_auto_reload_shadow_enable(TIMER2);  /* 周期值经影子寄存器在更新事件时生效 */
    /* 清除通道0中断标志 */
    timer_interrupt_flag_clear(TIMER2,TIMER_INT_FLAG_CH0);  /* 清除CH0捕获中断标志 */
    /* 通道0中断使能 */
    timer_interrupt_enable(TIMER2,TIMER_INT_CH0);  /* 使能CH0捕获中断(由捕获值计算换相间隔) */

    /* TIMER2计数器使能 */
    timer_enable(TIMER2);  /* 启动TIMER2计数 */
}

/***************************************** 文件结束 *********************************************/
