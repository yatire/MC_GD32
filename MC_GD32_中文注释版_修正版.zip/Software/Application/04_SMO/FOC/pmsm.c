/*
*******************************************************************************************************
*
* 文件名称 : pmsm.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : PMSM(永磁同步电机)FOC驱动文件(SMO滑模观测器无感方案)
*
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "pmsm.h"    /* PMSM控制参数结构体与接口声明 */
#include "foc.h"    /* FOC核心算法(Clark/Park/SVPWM/PI)及结构体定义 */
#include "smcpos.h"    /* 滑模观测器(SMO)结构体及算法声明 */
#include "userparms.h"    /* 用户参数配置(PI参数/启动参数/电机参数) */
#include "motor_hardware.h"    /* 电机硬件接口宏(PWM定时器/ADC通道) */
/* 宏定义 ------------------------------------------------------------------------------------------*/


/* 变量定义 ----------------------------------------------------------------------------------------*/
pmsm_foc_t pmsm_foc_param;    /* FOC状态变量结构体(相电流/电压/角度等,定义见foc.h) */
pmsm_mc_t pmsm_mc_param;    /* PMSM电机控制参数与状态结构体(定义见pmsm.h) */
smc_t smc1;    /* 滑模观测器(SMO)结构体(定义见smcpos.h) */

float theta_error = 0;    /* 开环→闭环切换时的角度偏差(闭环初期逐步衰减归零) */
float iq_error = 0;    /* iq电流误差变量(本文件未参与运算,供调试观察) */
uint32_t iq_error_count = 0;    /* iq误差持续周期计数(本文件未参与运算,供调试观察) */

/* 函数定义 -----------------------------------------------------------------------------------------*/
static void pmsm_foc_init_control_parameters(void);    /* 控制参数初始化(前置声明) */
static void calculate_park_angle(void);    /* Park角度计算(前置声明) */
static void pid_control(void);    /* PI电流环/速度环控制(前置声明) */

/**
  * @brief PMSM FOC初始化(参数与观测器初始化)
  * @param 无
  * @retval 无
  * @note
  */
void pmsm_foc_init(void)
{
	/* 滑模观测器(SMC)初始化 */
	
	pmsm_foc_init_control_parameters();    /* 初始化D/Q轴电流环与速度环PI参数 */
	
	pmsm_mc_param.run_motor = 1;    /* 运行标志置1:允许电机运行 */
	pmsm_mc_param.openloop = 1;    /* 置开环模式:先开环启动 */
	pmsm_mc_param.change_mode = 1;    /* 置模式切换请求:进入对应分支时执行一次切换初始化 */
	pmsm_mc_param.startup_lock_count = 0;    /* 转子预定位计数器清零 */
	pmsm_mc_param.startup_ramp = 0;    /* 开环斜坡累加值清零 */
    
    pmsm_mc_param.vel_input = NOMINAL_SPEED_RAD_PER_SEC_ELEC;    /* 速度给定=额定电角速度(电弧度/秒) */
    
    smc_init_parameters(&smc1);    /* 初始化SMO观测器参数(增益/滤波系数等) */
}

/**
  * @brief FOC主循环函数(每个控制周期执行一次)
  * @param None
  * @param 无
  * @retval 无
  */
void pmsm_foc_run(void)
{
    if(pmsm_mc_param.run_motor)    /* 运行标志有效时执行FOC算法 */
    {
        clark(&pmsm_foc_param);    /* Clark变换:三相电流→αβ静止两相电流 */
        park(&pmsm_foc_param);    /* Park变换:αβ电流→dq旋转坐标系电流 */
        
        smc1.ialpha = pmsm_foc_param.ialpha;    /* 将α轴电流送入SMO观测器 */
        smc1.ibeta = pmsm_foc_param.ibeta;    /* 将β轴电流送入SMO观测器 */
        smc1.valpha = pmsm_foc_param.valpha * pmsm_mc_param.max_phase_voltage;    /* α轴电压还原为实际电压(标幺值×最大相电压) */
        smc1.vbeta = pmsm_foc_param.vbeta * pmsm_mc_param.max_phase_voltage;    /* β轴电压还原为实际电压(标幺值×最大相电压) */
        smc_position_estimation(&smc1);    /* SMO滑模观测器解算:估算转子电角度与转速 */
        pmsm_mc_param.actual_speed = smc1.omega_fltred;    /* 取SMO滤波后估算转速作为实际转速反馈 */
        
        calculate_park_angle();    /* 计算Park角度(开环斜坡角或SMO估算角) */
        
        pid_control();    /* PI电流环/速度环运算,得到dq轴电压给定 */
        
        sin_cos(&pmsm_foc_param);    /* 计算当前角度的正弦/余弦值 */
        
        inv_park(&pmsm_foc_param);    /* 反Park变换:dq轴电压→αβ静止坐标系电压 */
        
        svpwm(&pmsm_foc_param);    /* SVPWM空间矢量调制:计算并更新三相占空比 */
    }
    else
    {
        timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_U_CHANNEL,TIMER_CCX_DISABLE);    /* 关闭U相输出 */
        timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_V_CHANNEL,TIMER_CCX_DISABLE);    /* 关闭V相输出 */
        timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_W_CHANNEL,TIMER_CCX_DISABLE);    /* 关闭W相输出 */
        /* 停止运行:关闭U相互补输出(下桥臂) */
        timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_U_CHANNEL,TIMER_CCXN_DISABLE);
        /* 关闭V相互补输出(下桥臂) */
        timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_V_CHANNEL,TIMER_CCXN_DISABLE);
        /* 关闭W相互补输出(下桥臂) */
        timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_W_CHANNEL,TIMER_CCXN_DISABLE);
    }
}

/* 局部函数定义 -----------------------------------------------------------------------------------*/
/**
  * @brief 控制参数初始化(D/Q轴电流环与速度环PI参数)
  * @param 无
  * @retval 无
  * @note
  */
static void pmsm_foc_init_control_parameters(void)
{
	pmsm_foc_param.pi_d.kp = DKP;    /* D轴电流环比例系数 */
	pmsm_foc_param.pi_d.ki = DKI;    /* D轴电流环积分系数 */
	pmsm_foc_param.pi_d.kc = DKC;    /* D轴电流环抗积分饱和回算系数 */
	pmsm_foc_param.pi_d.out_max = DOUTMAX;    /* D轴电流环输出上限(标幺值) */
	pmsm_foc_param.pi_d.out_min = -pmsm_foc_param.pi_d.out_max;    /* D轴电流环输出下限(与上限对称) */

	init_pi(&pmsm_foc_param.pi_d);    /* D轴PI调节器初始化(清零积分与输出) */

	pmsm_foc_param.pi_q.kp = QKP;    /* Q轴电流环比例系数 */
	pmsm_foc_param.pi_q.ki = QKI;    /* Q轴电流环积分系数 */
	pmsm_foc_param.pi_q.kc = QKC;    /* Q轴电流环抗积分饱和回算系数 */
	pmsm_foc_param.pi_q.out_max = QOUTMAX;    /* Q轴电流环输出上限(标幺值) */
	pmsm_foc_param.pi_q.out_min = -pmsm_foc_param.pi_q.out_max;    /* Q轴电流环输出下限(与上限对称) */

	init_pi(&pmsm_foc_param.pi_q);    /* Q轴PI调节器初始化(清零积分与输出) */
    
	pmsm_foc_param.pi_w.kp = WKP;    /* 速度环比例系数 */
	pmsm_foc_param.pi_w.ki = WKI;    /* 速度环积分系数 */
	pmsm_foc_param.pi_w.kc = WKC;    /* 速度环抗积分饱和回算系数 */
	pmsm_foc_param.pi_w.out_max = WOUTMAX;    /* 速度环输出上限(即q轴电流给定限幅,安) */
	pmsm_foc_param.pi_w.out_min = -pmsm_foc_param.pi_w.out_max;    /* 速度环输出下限(取-pi_w.out_max,与上限对称) */
	
	init_pi(&pmsm_foc_param.pi_w);    /* 速度环PI调节器初始化(清零积分与输出) */
}


/**
  * @brief 角度计算(开环斜坡角度或SMO估算角度)
  * @param 无
  * @retval 无
  * @note
  */
static void calculate_park_angle(void)
{
	if(pmsm_mc_param.openloop)    /* 开环模式:角度由斜坡强制生成 */
	{
		/* 先执行转子预定位(锁定)过程,使转子磁场对齐 */
		if(pmsm_mc_param.startup_lock_count < LOCK_COUNTER)    /* 预定位阶段:计数未达LOCK_COUNTER前保持角度不变 */
		{
			pmsm_mc_param.startup_lock_count++;    /* 预定位计数递增 */
		}
		else if(pmsm_mc_param.startup_ramp < END_SPEED_RADS_ELEC_COUNTER)    /* 斜坡加速阶段:开环步进未达结束值前继续累加 */
		{
			pmsm_mc_param.startup_ramp += OPENLOOP_RAMPSPEED_INCREASERATE;    /* 每周期按固定增量增大开环角度步进 */
		}
		else
		{
            theta_error = pmsm_foc_param.angle - smc1.theta;    /* 斜坡结束:记录开环角度与SMO估算角度之差 */
#ifndef OPEN_LOOP_MODE    /* 未定义开环模式宏(非强制开环)时 */
            if((pmsm_foc_param.angle < M_PI) && (smc1.theta < M_PI))    /* 开环角度与SMO估算角度均小于π(避开跨零区)才切换 */
            {
                pmsm_mc_param.change_mode = 1;    /* 置切换请求并退出开环模式 */
                pmsm_mc_param.openloop = 0;    /* 进入闭环模式 */
            }
#endif    /* 结束条件编译 */
		}
		pmsm_foc_param.angle += pmsm_mc_param.startup_ramp;    /* 开环角度按斜坡步进累加 */
        if(pmsm_foc_param.angle > ANGLE_2PI)    /* 角度超过2π时回卷 */
            pmsm_foc_param.angle = pmsm_foc_param.angle - ANGLE_2PI;    /* 减去2π归一化到0~2π */
	}
	else
	{
        pmsm_foc_param.angle = smc1.theta + theta_error;    /* 闭环:角度=SMO估算角+切换偏差(平滑过渡) */
        if((fabsf(theta_error) > 0.01f))    /* 切换偏差大于0.01rad则继续衰减 */
        {
            if (theta_error < 0)    /* 偏差为负:每周期增加0.01 */
            {
                theta_error += 0.01f;    /* 负偏差逐步趋向0 */
            }
            else
            {
                theta_error -= 0.01f;    /* 正偏差逐步趋向0 */
            }
        }
        else
        {
            theta_error = 0;    /* 偏差足够小则清零 */
        }
	}
}

/**
  * @brief PI电流环/速度环控制(输出dq轴电压给定)
  * @param 无
  * @retval 无
  * @note
  */
static void pid_control(void)
{
	if(pmsm_mc_param.openloop)    /* 开环模式:电流给定由开环启动参数决定 */
	{
		if(pmsm_mc_param.change_mode)    /* 首次进入开环分支:执行切换初始化 */
		{
			pmsm_mc_param.change_mode = 0;    /* 清切换请求标志 */
            pmsm_mc_param.id_ref = 0;    /* d轴电流给定清零 */
		}
        
        pmsm_mc_param.iq_ref = OPEN_LOOP_CURRENT;    /* q轴电流给定=开环电流(恒定转矩启动) */
        
        /* Q轴电流环PI调节 */
        pmsm_foc_param.pi_q.meas = pmsm_foc_param.iq;    /* q轴反馈电流 */
        pmsm_foc_param.pi_q.ref  = pmsm_mc_param.iq_ref;    /* q轴给定电流 */
        calc_pi(&pmsm_foc_param.pi_q);    /* 执行q轴PI计算 */
        pmsm_foc_param.vq = pmsm_foc_param.pi_q.out;    /* PI输出作为q轴电压给定 */
       
        /* D轴电流环PI调节 */
        pmsm_foc_param.pi_d.meas = pmsm_foc_param.id;    /* d轴反馈电流 */
        pmsm_foc_param.pi_d.ref  = pmsm_mc_param.id_ref;    /* d轴给定电流 */
        calc_pi(&pmsm_foc_param.pi_d);    /* 执行d轴PI计算 */
        pmsm_foc_param.vd = pmsm_foc_param.pi_d.out;    /* PI输出作为d轴电压给定 */
        
#ifdef OPEN_LOOP_VF_VQ    /* 若定义了V/F开环电压给定宏 */
        pmsm_foc_param.vq = OPEN_LOOP_VF_VQ;    /* V/F方式:q轴电压直接给固定值(标幺值) */
        pmsm_foc_param.vd = 0;    /* d轴电压给定为0 */
#endif    /* 结束条件编译 */
	}
	else
	{
        float vd_squared = 0;    /* vd的平方(电压圆限幅用) */
        float vq_squared_max = 0;    /* vq可用平方上限(电压圆限幅用) */

		if(pmsm_mc_param.change_mode)    /* 首次进入闭环分支:执行切换初始化 */
		{
            pmsm_mc_param.change_mode = 0;    /* 清切换请求标志 */
            pmsm_mc_param.vel_ref = END_SPEED_RADS_ELEC;    /* 速度参考预置为开环结束电角速度(无缝衔接) */
            pmsm_mc_param.id_ref = 0;    /* d轴电流给定清零 */
            pmsm_foc_param.pi_w.sum = OPEN_LOOP_CURRENT;    /* 速度环积分器预置为开环电流,避免切换时转矩突变 */
            pmsm_mc_param.speed_loop_count = SPEED_LOOP_CYCLE;    /* 预置分频计数,使首个闭环周期立即执行速度环 */
		}
        pmsm_mc_param.vel_diff =  pmsm_mc_param.vel_input - pmsm_mc_param.vel_ref;    /* 速度给定与参考之差(斜坡判断用) */

       /* 速度斜坡限幅处理 */
        if(pmsm_mc_param.vel_diff >= CL_SPEED_HYSTERESIS)    /* 给定高于参考超过迟滞带:参考递增 */
        {
             pmsm_mc_param.vel_ref += CL_SPEED_RAMP_RATE_DELTA;    /* 参考加上每周期斜坡增量(加速) */
        }
        else if(pmsm_mc_param.vel_diff <=- CL_SPEED_HYSTERESIS)    /* 给定低于参考超过迟滞带:参考递减 */
        {
             pmsm_mc_param.vel_ref -= CL_SPEED_RAMP_RATE_DELTA;    /* 参考减去每周期斜坡增量(减速) */
        }
        else
        {
             pmsm_mc_param.vel_ref = pmsm_mc_param.vel_input;    /* 差值在迟滞带内:参考直接跟随给定 */
        }
        
#ifdef TORQUE_MODE    /* 若定义了转矩模式宏(速度环旁路) */
        /* pmsm_mc_param.iq_ref = OPEN_LOOP_CURRENT; */    /* 固定q轴电流给定(已停用) */
        if(pmsm_mc_param.speed_loop_count++ >= SPEED_LOOP_CYCLE)    /* 按分频周期仅更新SMO速度滤波系数(不执行速度环) */
        {
            smc1.kslf = LOOPTIME_SEC * smc1.omega_fltred;  /* SMO速度滤波系数=T×电角速度ω(rad/s),即T*2π*fc(fc为电频率Hz) */
            smc1.filt_omega_coef = smc1.kslf_final = smc1.kslf;    /* 反电动势滤波系数同步更新为kslf */
        }
#else    /* 速度模式(执行速度环) */
        if(pmsm_mc_param.speed_loop_count++ >= SPEED_LOOP_CYCLE)    /* 速度环分频:计满SPEED_LOOP_CYCLE执行一次 */
        {
            pmsm_mc_param.speed_loop_count = 0;    /* 分频计数清零 */
            /* 速度环PI调节 */
            pmsm_foc_param.pi_w.meas = smc1.omega_fltred;    /* 反馈速度=SMO滤波估算电角速度 */
            pmsm_foc_param.pi_w.ref  = pmsm_mc_param.vel_ref;    /* 给定速度=斜坡限幅后参考值 */
            calc_pi(&pmsm_foc_param.pi_w);    /* 执行速度环PI计算 */
            pmsm_mc_param.iq_ref = pmsm_foc_param.pi_w.out;    /* 速度环输出作为q轴电流给定 */
            
            smc1.kslf = LOOPTIME_SEC * smc1.omega_fltred;  /* SMO速度滤波系数=T×电角速度ω(rad/s),即T*2π*fc(fc为电频率Hz) */
            smc1.filt_omega_coef = smc1.kslf_final = smc1.kslf;    /* 反电动势滤波系数同步更新为kslf */
        }
#endif    /* 结束条件编译 */
            
        /* D轴电流环PI调节 */
        pmsm_foc_param.pi_d.meas = pmsm_foc_param.id;    /* d轴反馈电流 */
        pmsm_foc_param.pi_d.ref  = pmsm_mc_param.id_ref;    /* d轴给定电流 */
        calc_pi(&pmsm_foc_param.pi_d);    /* 执行d轴PI计算 */
        pmsm_foc_param.vd = pmsm_foc_param.pi_d.out;    /* PI输出作为d轴电压给定 */
        
        vd_squared = pmsm_foc_param.vd * pmsm_foc_param.vd;    /* 计算vd的平方 */
        vq_squared_max = 0.99f - vd_squared;    /* 电压圆限幅:vq可用平方=0.99-vd² */
		arm_sqrt_f32(vq_squared_max,&pmsm_foc_param.pi_q.out_max);    /* 开方得到vq上限,写入q轴PI输出限幅 */
        pmsm_foc_param.pi_q.out_min = -pmsm_foc_param.pi_q.out_max;    /* q轴输出下限与上限对称 */

        /* Q轴电流环PI调节 */
        pmsm_foc_param.pi_q.meas = pmsm_foc_param.iq;    /* q轴反馈电流 */
        pmsm_foc_param.pi_q.ref  = pmsm_mc_param.iq_ref;    /* q轴给定电流 */
        calc_pi(&pmsm_foc_param.pi_q);    /* 执行q轴PI计算 */
        pmsm_foc_param.vq = pmsm_foc_param.pi_q.out;    /* PI输出作为q轴电压给定 */
        
	}
}

/***************************************** 文件结束 *********************************************/
