/*
*******************************************************************************************************
*
* 文件名称 : smcpos.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : PMSM滑模观测器(SMO)控制文件(位置/速度估算)
*
*******************************************************************************************************
*/

/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "smcpos.h" /* 滑模观测器(SMO)接口:smc_t结构体与函数声明 */
#include "foc.h" /* FOC公共定义:M_PI/ANGLE_2PI等宏 */
#include "userparms.h" /* 用户参数:电机参数/滑模增益/开环转速等宏 */

/* 宏定义 ------------------------------------------------------------------------------------------*/

/* 变量定义 ----------------------------------------------------------------------------------------*/


/* 局部函数  -----------------------------------------------------------------------------------*/
static void calc_pll(smc_t *psmc); /* 内部函数声明:PLL锁相环角度与速度计算 */

/* 全局函数  ----------------------------------------------------------------------------------*/

/**
  * @brief 初始化SMC(SMO)结构体
  * @param *psmc -  SMC结构体指针
  * @retval 无
  * @note
  */
void smc_init_parameters(smc_t *psmc) /* 初始化滑模观测器全部状态变量与模型参数 */
{
    psmc->valpha = 0; /* α轴定子电压输入清零 */
    psmc->ealpha = 0; /* α轴滑模滤波输出(反电动势α)清零 */
    psmc->ealpha_final = 0; /* α轴反电动势二次滤波输出清零(本版本未使用) */
    psmc->zalpha = 0; /* α轴滑模控制量清零 */
    psmc->gsmopos = 0; /* 电机模型系数g清零 */
    psmc->est_ialpha = 0; /* α轴电流观测估计值清零 */
    psmc->fsmopos = 0; /* 电机模型系数f清零 */
    psmc->vbeta = 0; /* β轴定子电压输入清零 */
    psmc->ebeta = 0; /* β轴滑模滤波输出(反电动势β)清零 */
    psmc->ebeta_final = 0; /* β轴反电动势二次滤波输出清零(本版本未使用) */
    psmc->zbeta = 0; /* β轴滑模控制量清零 */
    psmc->est_ibeta = 0; /* β轴电流观测估计值清零 */
    psmc->ialpha = 0; /* α轴定子相电流输入清零 */
    psmc->ialpha_error = 0; /* α轴电流观测误差清零 */
    psmc->kslide = 0; /* 滑模增益清零 */
    psmc->max_smc_error = 0; /* 滑模误差线性区边界清零 */
    psmc->ibeta = 0; /* β轴定子相电流输入清零 */
    psmc->ibeta_error = 0; /* β轴电流观测误差清零 */
    psmc->kslf = 0; /* 滑模控制量滤波系数清零 */
    psmc->kslf_final = 0; /* 反电动势二次滤波系数清零(本版本未使用) */
    psmc->filt_omega_coef = 0; /* 转速低通滤波系数清零 */
    psmc->theta_offset = 0; /* 电角度安装偏置清零(本版本未使用) */
    psmc->theta = 0; /* 估算电角度清零 */
    psmc->omega = 0; /* 估算电角速度清零 */
    psmc->omega_fltred = 0; /* 滤波后电角速度清零 */
    psmc->theta_error = 0; /* 开环→闭环切换角度偏差清零(本文件未使用) */
    
    if(MOTOR_PHASE_RESISTANCE * LOOPTIME_SEC > MOTOR_PHASE_INDUCTANCE) /* 系数f=1-R*T/L,若R*T>L则为负,需钳位 */
    {
        psmc->fsmopos = 0; /* 系数f置0(防止观测器发散) */
    }
    else
    {
        /* 系数f=1-R*T/L(电流观测一阶离散模型) */
        psmc->fsmopos = 1 - MOTOR_PHASE_RESISTANCE * LOOPTIME_SEC / MOTOR_PHASE_INDUCTANCE;
    }
    if(LOOPTIME_SEC > MOTOR_PHASE_INDUCTANCE) /* 系数g=T/L,若T>L则g越界,需钳位 */
    {
        psmc->gsmopos = 0.9999f; /* 系数g钳位为0.9999 */
    }
    else
    {
        psmc->gsmopos = LOOPTIME_SEC / MOTOR_PHASE_INDUCTANCE; /* 系数g=T/L(电压到电流的增益) */
    }
    psmc->kslide = MA_SMCGAIN; /* 滑模增益取MA_SMCGAIN(userparms.h) */
    psmc->max_smc_error = MA_MAXLINEARSMC; /* 误差线性区边界取MA_MAXLINEARSMC */
    /* 转速滤波系数=T*2π*fc,fc为电角频率(开环结束转速换算) */
    psmc->filt_omega_coef = LOOPTIME_SEC * M_PI * 2 * (OPEN_LOOP_END_SPEED_RPM * MOTOR_NOPOLESPAIRS / 60);
    psmc->kslf = psmc->filt_omega_coef; /* 滑模滤波系数=转速滤波系数(反电动势二次滤波未启用) */
    
    psmc->pll_err_sum = 0; /* PLL误差积分和清零 */
    psmc->pll_kp = 20; /* PLL比例系数 */
    psmc->pll_ki = 0.1; /* PLL积分系数 */

}


/**
  * @brief 电机转速与角度估算器
  * @param *psmc -  SMC结构体指针
  * @retval 无
  * @note
  */
void smc_position_estimation (smc_t *psmc) /* SMO位置与速度估算(每个控制周期调用一次) */
{
    /* 滑模电流观测器:由电压方程重构电流估计值 */
    /* 电流观测离散方程:est_i(k+1)=f*est_i(k)+g*(u-e-z) */
    psmc->est_ialpha = psmc->fsmopos * psmc->est_ialpha + \
                       psmc->gsmopos * (psmc->valpha- psmc->ealpha - psmc->zalpha);
    /* β轴同理:est_ibeta=f*est_ibeta+g*(vbeta-ebeta-zbeta) */
    psmc->est_ibeta = psmc->fsmopos * psmc->est_ibeta + \
                       psmc->gsmopos * (psmc->vbeta- psmc->ebeta - psmc->zbeta);
    
    /* 电流观测误差(估计值-实测值) */
	psmc->ialpha_error = psmc->est_ialpha - psmc->ialpha; /* α轴电流误差=估计值-实测值 */
	psmc->ibeta_error = psmc->est_ibeta - psmc->ibeta; /* β轴电流误差=估计值-实测值 */
    
    /* 滑模控制量计算(线性区内按比例,区外开关切换) */
    if(ABS(psmc->ialpha_error) < psmc->max_smc_error) /* 误差在线性区内:按比例输出 */
    {
        psmc->zalpha = psmc->kslide * psmc->ialpha_error / psmc->max_smc_error; /* zα=滑模增益*误差/边界(线性输出) */
    }
	else
    {
		psmc->zalpha = (psmc->ialpha_error > 0)?psmc->kslide:-psmc->kslide; /* 误差超边界:输出±滑模增益(开关特性) */
    }
    
    if(ABS(psmc->ibeta_error) < psmc->max_smc_error) /* β轴同α轴 */
    {
        psmc->zbeta = psmc->kslide * psmc->ibeta_error / psmc->max_smc_error; /* zβ=滑模增益*误差/边界(线性输出) */
    }
	else
    {
		psmc->zbeta = (psmc->ibeta_error > 0) ? psmc->kslide : -psmc->kslide; /* 误差超边界:输出±滑模增益(开关特性) */
    }
    
    /* 滑模控制量低通滤波→反电动势估算(z的缓变分量即BEMF) */
    psmc->ealpha = psmc->ealpha + psmc->kslf * (psmc->zalpha - psmc->ealpha); /* 低通滤波提取α轴反电动势 */
    psmc->ebeta = psmc->ebeta + psmc->kslf * (psmc->zbeta - psmc->ebeta); /* 低通滤波提取β轴反电动势 */
    
    /* PLL锁相环:计算电角速度与电角度 */
    calc_pll(psmc); /* 由反电动势正交量锁相估算角度与转速 */
}

/*==================================================================================================
*                                       局部函数
==================================================================================================*/

static void calc_pll(smc_t *psmc) /* PLL鉴相输出转速,积分得到电角度 */
{
    float sin_value = 0; /* 正弦值缓存 */
    float cos_value = 0; /* 余弦值缓存 */
    
    cos_value = arm_cos_f32(psmc->theta); /* 求估算电角度的余弦 */
    sin_value = arm_sin_f32(psmc->theta); /* 求估算电角度的正弦(DSP库三角函数) */
    
    psmc->pll_err = -psmc->ealpha * cos_value - psmc->ebeta * sin_value; /* PLL鉴相误差:近似正比于角度偏差 */

    psmc->pll_err = (psmc->pll_err > PI/6)  ?  (PI/6) : (psmc->pll_err); /* 鉴相误差正向限幅π/6 */
    psmc->pll_err = (psmc->pll_err < -PI/6) ? (-PI/6) : (psmc->pll_err); /* 鉴相误差负向限幅-π/6 */
    
    psmc->pll_err_sum += psmc->pll_err; /* 误差累加(积分项) */
    
    psmc->omega = psmc->pll_err * psmc->pll_kp + psmc->pll_err_sum * psmc->pll_ki; /* PI调节输出电角速度 */
    
    psmc->theta	= psmc->theta + (psmc->omega)*(LOOPTIME_SEC); /* 角度积分:θ+=ω*T */
    if(psmc->theta >= ANGLE_2PI) /* 角度越过2π则回卷 */
    {
        psmc->theta = psmc->theta - ANGLE_2PI; /* 减2π归一化到0~2π */
    }
    if(psmc->theta <= 0) /* 角度为负则回卷 */
    {
        psmc->theta = psmc->theta + ANGLE_2PI; /* 加2π归一化到0~2π */
    }
    /* 转速低通滤波(一阶IIR),供速度环使用 */
    psmc->omega_fltred = psmc->omega_fltred + psmc->filt_omega_coef * (psmc->omega - psmc->omega_fltred);
}

/************************************************文件结束************************************************/
