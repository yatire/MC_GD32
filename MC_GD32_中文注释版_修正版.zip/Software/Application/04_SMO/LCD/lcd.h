/*
*******************************************************************************************************
*
* 文件名称 : lcd.h
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : LCD驱动接口头文件(区域填充/画点画线/显示汉字与数字/显示图片等)
*
*******************************************************************************************************
*/

#ifndef __LCD_H    /* 头文件保护宏 */
#define __LCD_H /* 定义头文件保护宏 */

#include "gd32f30x.h" /* 包含GD32F30x固件库头文件(uint类型等定义) */

void LCD_Fill(uint16_t xsta,uint16_t ysta,uint16_t xend,uint16_t yend,uint16_t color); /* 指定区域填充颜色 */
void LCD_DrawPoint(uint16_t x,uint16_t y,uint16_t color); /* 在指定位置画一个点 */
void LCD_DrawLine(uint16_t x1,uint16_t y1,uint16_t x2,uint16_t y2,uint16_t color); /* 在指定位置画一条线 */
void LCD_DrawRectangle(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2,uint16_t color); /* 在指定位置画一个矩形 */
void Draw_Circle(uint16_t x0,uint16_t y0,uint8_t r,uint16_t color); /* 在指定位置画一个圆 */

/* 显示汉字串 */
void LCD_ShowChinese(uint16_t x,uint16_t y,uint8_t *s,uint16_t fc,uint16_t bc,uint8_t sizey,uint8_t mode);
/* 显示单个12x12汉字 */
void LCD_ShowChinese12x12(uint16_t x,uint16_t y,uint8_t *s,uint16_t fc,uint16_t bc,uint8_t sizey,uint8_t mode);
/* 显示单个16x16汉字 */
void LCD_ShowChinese16x16(uint16_t x,uint16_t y,uint8_t *s,uint16_t fc,uint16_t bc,uint8_t sizey,uint8_t mode);
/* 显示单个24x24汉字 */
void LCD_ShowChinese24x24(uint16_t x,uint16_t y,uint8_t *s,uint16_t fc,uint16_t bc,uint8_t sizey,uint8_t mode);
/* 显示单个32x32汉字 */
void LCD_ShowChinese32x32(uint16_t x,uint16_t y,uint8_t *s,uint16_t fc,uint16_t bc,uint8_t sizey,uint8_t mode);

/* 显示一个字符 */
void LCD_ShowChar(uint16_t x,uint16_t y,uint8_t num,uint16_t fc,uint16_t bc,uint8_t sizey,uint8_t mode);
/* 显示字符串 */
void LCD_ShowString(uint16_t x,uint16_t y,const uint8_t *p,uint16_t fc,uint16_t bc,uint8_t sizey,uint8_t mode);
uint32_t mypow(uint8_t m,uint8_t n); /* 求幂(m的n次方) */
/* 显示整数变量 */
void LCD_ShowIntNum(uint16_t x,uint16_t y,uint16_t num,uint8_t len,uint16_t fc,uint16_t bc,uint8_t sizey);
/* 显示两位小数变量 */
void LCD_ShowFloatNum1(uint16_t x,uint16_t y,float num,uint8_t len,uint16_t fc,uint16_t bc,uint8_t sizey);
/* 显示带符号浮点变量(1位小数) */
void LCD_ShowFloatNum2(uint16_t x,uint16_t y,float num,uint8_t len,uint16_t fc,uint16_t bc,uint8_t sizey);

void LCD_ShowPicture(uint16_t x,uint16_t y,uint16_t length,uint16_t width,const uint8_t pic[]); /* 显示图片 */


/* 画笔颜色 */
#define WHITE         	 0xFFFF /* 白色 */
#define BLACK         	 0x0000	   /* 黑色 */
#define BLUE           	 0x001F   /* 蓝色 */
#define BRED             0XF81F /* 品红色(与MAGENTA同值) */
#define GRED 			       0XFFE0 /* 黄色(与YELLOW同值) */
#define GBLUE			       0X07FF /* 青色(绿+蓝) */
#define RED           	 0xF800 /* 红色 */
#define MAGENTA       	 0xF81F /* 品红色 */
#define GREEN         	 0x07E0 /* 绿色 */
#define CYAN          	 0x7FFF /* 青色 */
#define YELLOW        	 0xFFE0 /* 黄色 */
#define BROWN 			     0XBC40 /* 棕色 */
#define BRRED 			     0XFC07 /* 棕红色 */
#define GRAY  			     0X8430 /* 灰色 */
#define DARKBLUE      	 0X01CF	/* 深蓝色 */
#define LIGHTBLUE      	 0X7D7C	/* 浅蓝色 */
#define GRAYBLUE       	 0X5458 /* 灰蓝色 */
#define LIGHTGREEN     	 0X841F /* 浅绿色 */
#define LGRAY 			     0XC618 /* 浅灰色(PANNEL),窗体背景色 */
#define LGRAYBLUE        0XA651 /* 浅灰蓝色(中间层颜色) */
#define LBBLUE           0X2B12 /* 浅棕蓝色(选择条目的反色) */

#endif /* 头文件保护宏结束 */





