/*
*******************************************************************************************************
*
* 文件名称 : adc_simple.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 简单ADC采样驱动文件
*
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "adc_simple.h" /* ADC引脚/通道/滤波深度参数与接口声明 */
#include "systick.h" /* 滴答延时接口(systick_delay) */
#include "motor_hardware.h" /* 电机硬件层配置头文件 */

/* 宏定义 ------------------------------------------------------------------------------------------*/


/* 变量定义 ----------------------------------------------------------------------------------------*/
uint8_t channel_index = 0; /* 当前采样的通道序号(轮询索引) */
/* 通道序号到ADC通道号映射表:NTC温度/母线电压/平均母线电流 */
uint8_t adc_channel_buffer[ADC_SIMPLE_CHANNEL] = {NTC_ADC_CHANNEL,VDC_ADC_CHANNEL,IDC_AVER_ADC_CHANNEL};
adc_filter_t adc_filter_handler[ADC_SIMPLE_CHANNEL] = {0}; /* 各通道均值滤波缓冲区(深度ADC_FILTER_COUNT=16) */

/* 函数定义 -----------------------------------------------------------------------------------------*/


/**
  * @brief ADC1初始化(NTC/母线电压/母线电流通道轮询采样)
  * @param 无
  * @retval 无
  */
void adc1_init(void)
{
    /* ADC采样引脚GPIO初始化 */
    rcu_periph_clock_enable(VDC_ADC_CLK); /* 使能母线电压采样引脚GPIO时钟 */
    rcu_periph_clock_enable(NTC_ADC_CLK); /* 使能NTC温度采样引脚GPIO时钟 */
    rcu_periph_clock_enable(IDC_AVER_ADC_CLK); /* 使能母线电流采样引脚GPIO时钟 */
    
    gpio_init(VDC_ADC_PORT, GPIO_MODE_AIN, GPIO_OSPEED_MAX, VDC_ADC_PIN); /* 母线电压采样引脚配置为模拟输入 */
    gpio_init(NTC_ADC_PORT, GPIO_MODE_AIN, GPIO_OSPEED_MAX, NTC_ADC_PIN); /* NTC温度采样引脚配置为模拟输入 */
    gpio_init(IDC_AVER_ADC_PORT, GPIO_MODE_AIN, GPIO_OSPEED_MAX, IDC_AVER_ADC_PIN); /* 母线电流采样引脚配置为模拟输入 */
    
    /* 使能ADC时钟 */
    rcu_periph_clock_enable(RCU_ADC1);
    /* 配置ADC时钟 */
    rcu_adc_clock_config(RCU_CKADC_CKAPB2_DIV2); /* ADC时钟=APB2时钟2分频 */
    
    /* ADC工作模式配置 */
    adc_mode_config(ADC_MODE_FREE); /* 独立模式(各ADC互不同步) */
    /* ADC数据对齐方式配置 */
    adc_data_alignment_config(ADC1, ADC_DATAALIGN_RIGHT); /* 转换结果右对齐(12位结果直接可读) */
    /* ADC规则组通道长度配置 */
    adc_channel_length_config(ADC1, ADC_REGULAR_CHANNEL, 1U); /* 规则组每次转换1个通道 */
    
    /* ADC触发源配置 */
    /* 规则组外部触发源选NONE(用软件触发) */
    adc_external_trigger_source_config(ADC1, ADC_REGULAR_CHANNEL, ADC0_1_2_EXTTRIG_REGULAR_NONE); 
    /* ADC外部触发使能配置 */
    adc_external_trigger_config(ADC1, ADC_REGULAR_CHANNEL, ENABLE); /* 使能规则组外部触发(配合软件触发启动转换) */

    /* 使能ADC */
    adc_enable(ADC1);
    systick_delay(1U); /* 延时1ms等待ADC稳定 */
    /* ADC校准(复位校准并启动自校准) */
    adc_calibration_enable(ADC1);
    systick_delay(1U); /* 延时1ms等待校准完成 */
    
    /* ADC规则组通道配置 */
    /* 首个转换通道取通道表当前项,采样时间7.5周期 */
    adc_regular_channel_config(ADC1, 0U, adc_channel_buffer[channel_index], ADC_SAMPLETIME_7POINT5);
    /* 软件触发启动首次转换 */
    adc_software_trigger_enable(ADC1, ADC_REGULAR_CHANNEL);
}

/**
  * @brief ADC轮询转换任务
  * @param 无
  * @retval 无
  * @note 在空闲任务(IDLE)中循环调用
  */
void adc_task(void)
{
    if(adc_flag_get(ADC1, ADC_FLAG_EOC) == SET) /* 转换结束标志EOC置位:本次转换完成 */
    {
        adc_flag_clear(ADC1, ADC_FLAG_EOC); /* 清除EOC转换结束标志 */
        /* 读取本次转换结果,存入当前通道的均值滤波缓冲区 */
        adc_filter_handler[channel_index].buffer[adc_filter_handler[channel_index].count] = adc_regular_data_read(ADC1);
        adc_filter_handler[channel_index].count++; /* 滤波缓冲区写入位置后移 */
        if(adc_filter_handler[channel_index].count >= ADC_FILTER_COUNT) /* 写满一圈(ADC_FILTER_COUNT=16)后回卷 */
        {
            adc_filter_handler[channel_index].count = 0; /* 写位置回卷到0 */
        }
        
        channel_index++; /* 轮询切换到下一个ADC通道 */
        if(channel_index >= ADC_SIMPLE_CHANNEL) /* 超过通道总数则回卷 */
        {
            channel_index = 0; /* 回到第一个通道 */
        }
        /* 配置下一个通道为规则组转换通道 */
        adc_regular_channel_config(ADC1, 0U, adc_channel_buffer[channel_index], ADC_SAMPLETIME_7POINT5);
        adc_software_trigger_enable(ADC1, ADC_REGULAR_CHANNEL); /* 软件触发启动下一次转换 */
    }
}

/**
  * @brief 读取某通道ADC均值滤波结果
  * @param ch-ADC通道号
  * @retval 12位ADC均值滤波数据
  * @note
  */
uint16_t adc_read_data(adc_ch_t ch)
{
    uint32_t sum = 0; /* 累加和(32位防止16位样本求和溢出) */
    uint16_t i = 0; /* 循环索引 */
    if(ch < ADC_SIMPLE_CHANNEL) /* 通道号合法才读滤波缓冲区 */
    {
        for(i=0;i<ADC_FILTER_COUNT;i++) /* 累加该通道全部16个滤波样本 */
        {
            sum += adc_filter_handler[ch].buffer[i]; /* 累加样本值 */
        }
        return (sum >> ADC_FILTER_COUNT_POWER); /* 右移4位(除以16)得到均值 */
    }
    return 0; /* 非法通道号返回0 */
}

/* 局部函数 -----------------------------------------------------------------------------------*/
/**
  * @brief 无局部函数
  * @param 无
  * @retval 无
  */


/***************************************** 文件结束 *********************************************/
