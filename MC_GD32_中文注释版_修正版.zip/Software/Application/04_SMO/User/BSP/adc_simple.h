/*
*******************************************************************************************************
*
* 文件名称 : adc_simple.h
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 简单ADC采样头文件(母线电压/NTC温度/母线电流三通道轮询与均值滤波)
* 
*******************************************************************************************************
*/
#ifndef _ADC_SIMPLE_H_    /* 头文件保护宏,防止重复包含 */
#define _ADC_SIMPLE_H_    /* 定义头文件保护宏 */

#ifdef __cplusplus  /* C++编译环境兼容 */
extern "C"{  /* 按C语言方式编译(不做名字修饰) */
#endif

/* 头文件 ------------------------------------------------------------------------------------*/
#include "gd32f30x.h"  /* GD32F30x固件库总头文件(寄存器与库函数定义) */


/* 宏定义 ------------------------------------------------------------------------------------------*/
#define VDC_ADC_PORT        GPIOC  /* 母线电压采样引脚端口:GPIOC */
#define VDC_ADC_PIN         GPIO_PIN_3  /* 母线电压采样引脚:PC3 */
#define VDC_ADC_CLK         RCU_GPIOC  /* 母线电压采样端口时钟 */
#define VDC_ADC_CHANNEL     ADC_CHANNEL_13  /* 母线电压采样ADC通道:通道13 */

#define NTC_ADC_PORT        GPIOC  /* NTC温度采样引脚端口:GPIOC */
#define NTC_ADC_PIN         GPIO_PIN_2  /* NTC温度采样引脚:PC2 */
#define NTC_ADC_CLK         RCU_GPIOC  /* NTC温度采样端口时钟 */
#define NTC_ADC_CHANNEL     ADC_CHANNEL_12  /* NTC温度采样ADC通道:通道12 */

#define ADC_FILTER_COUNT_POWER      4  /* 均值滤波点数为2的幂:2^4=16点 */
#define ADC_FILTER_COUNT            (1<<ADC_FILTER_COUNT_POWER)  /* 均值滤波缓冲区深度(16点) */

#define ADC_SIMPLE_CHANNEL      3  /* 轮询采样通道总数:NTC/母线电压/母线电流共3个 */

/* 类型定义 ------------------------------------------------------------------------------------------*/
typedef struct  /* 均值滤波缓冲区结构体 */
{
    uint16_t count;                   /* 当前写入位置(已存样本数) */
    uint16_t buffer[ADC_FILTER_COUNT];  /* 滤波样本环形缓冲区 */
}adc_filter_t;  /* 均值滤波器类型 */

typedef enum  /* ADC通道索引枚举 */
{
    ADC_CH_NTC = 0,   /* NTC温度通道(索引0) */
    ADC_CH_VDC,       /* 母线电压通道(索引1) */
    ADC_CHIDC_AVER,   /* 母线电流通道(索引2) */
}adc_ch_t;  /* ADC通道类型 */

/* 变量定义 ----------------------------------------------------------------------------------------*/


/* 函数定义 -----------------------------------------------------------------------------------------*/
void adc1_init(void);                                /* ADC1初始化:GPIO/时基/规则组与校准 */
uint16_t adc_get_vdc(void);      /* 读取母线电压ADC均值(12位原始值) */
uint16_t adc_get_ntc(void);      /* 读取NTC温度ADC均值(12位原始值) */
float calculate_temperature_float(uint16_t ntc_adc);  /* 由NTC采样值查表计算温度(℃) */
void adc_task(void);             /* ADC轮询转换任务(空闲任务中循环调用) */
uint16_t adc_read_data(adc_ch_t ch);  /* 读取指定通道16点均值滤波结果 */

#ifdef __cplusplus  /* C++编译环境兼容 */
extern "C"{  /* 注:按对称结构此处应为右花括号,历史遗留写法保持原样 */
#endif

#endif /* _ADC_SIMPLE_H_ */

/***************************************** 文件结束 *********************************************/
