/*
*******************************************************************************************************
*
* 文件名称 : encoder.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 正交编码器驱动文件(含按键扫描检测)
*
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "encoder.h" /* 编码器引脚宏/动作码枚举/按键类型与参数定义 */

/* 宏定义 ------------------------------------------------------------------------------------------*/


/* 变量定义 ----------------------------------------------------------------------------------------*/
static encoder_code_t encoder_code = ENCODER_NONE; /* 编码器动作码(中断置位,读取后清零) */
static KEY_T key_x[KEY_COUNT];  /* 按键结构体数组 */
static KEY_FIFO key_f;          /* 按键FIFO结构体变量 */

/* 局部函数 -----------------------------------------------------------------------------------*/
static void encoder_gpio_init(void); /* 编码器A/B相与按键GPIO初始化 */
static void encoder_timer_init(void); /* TIMER3正交编码器模式初始化 */

static void key_put(uint8_t keyCode); /* 按键码存入FIFO */
static void key_var_init(void); /* 按键结构体与FIFO初始化 */
static void key_detect(uint8_t i); /* 单个按键检测(消抖/按下/长按/连发) */
/* 读取按键是否按下的函数 */
static uint8_t IsKey0Down(void) {if(gpio_input_bit_get(KEY_GPIO_PORT,KEY_GPIO_PIN)==0)return KEY_ISDOWN;else return KEY_NOTDOWN;}


/* 函数定义 -----------------------------------------------------------------------------------------*/
/**
  * @brief 编码器初始化(NVIC/GPIO/TIMER3编码器模式/按键FIFO)
  * @param 无
  * @retval 无
  */
void encoder_init(void)
{
    nvic_irq_enable(TIMER3_IRQn, 1, 1); /* 使能TIMER3中断,抢占优先级1、子优先级1 */
    encoder_gpio_init(); /* 初始化编码器A/B相与按键输入GPIO */
    encoder_timer_init(); /* TIMER3配置为正交编码器模式 */
    key_var_init(); /* 初始化按键结构体数组与FIFO */
}

encoder_code_t encoder_get(void) /* 读取编码器动作码并清除(未动作返回ENCODER_NONE) */
{
    encoder_code_t code = encoder_code; /* 取出当前动作码快照 */
    encoder_code = ENCODER_NONE; /* 动作码清零,保证一次动作只被读取一次 */
    return code; /* 返回取出的动作码 */
}

/**
  * @brief 获取按键
  * @param 无
  * @retval 返回按键fifo的一个按键
  * @note 
  */
uint8_t key_get(void)
{
    uint8_t ret; /* 读出的按键码 */
    
    if(key_f.Read == key_f.Write) /* 读指针与写指针相等 */       
    {
        /*FIFO空 */
        return KEY_NONE; /* FIFO空,无按键返回KEY_NONE */
    }
    else
    {
        /*从FIFO读出一个数据且读指针加1 */
        ret = key_f.Buf[key_f.Read++]; /* 取出按键码,读指针后移一位 */
        

        if(key_f.Read >= KEY_FIFO_SIZE) /* 读指针越过缓冲区末尾 */
        {
            key_f.Read = 0; /* 读指针回卷到0 */
        }
        return ret; /* 返回按键码 */
    }
}

/**
  * @brief 清空按键fifo
  * @param 无
  * @retval 无
  * @note 
  */
void key_clear(void)
{
    key_f.Read = key_f.Write; /* 读指针追平写指针即清空FIFO */
}


/**
  * @brief 扫描所有按键
  * @param 无
  * @retval 无
  * @note 必须被周期性调用
  */
void key_scan(void)
{
    uint8_t i=0; /* 循环索引 */
    for(i=0;i<KEY_COUNT;i++) /* 逐个扫描所有按键 */
    {
        key_detect(i); /* 检测第i个按键 */
    }
}

void TIMER3_IRQHandler(void) /* TIMER3触发中断:编码器计数事件判向 */
{
    int16_t cnt = 0; /* 编码器计数增量(带符号) */
    if(SET == timer_interrupt_flag_get(TIMER3,TIMER_INT_FLAG_TRG)) /* 触发中断标志置位(编码器模式2下CI0每个计数边沿触发) */
    {
        timer_interrupt_flag_clear(TIMER3,TIMER_INT_FLAG_TRG); /* 清除触发中断标志 */
        cnt = timer_counter_read(TIMER3); /* 读取自上次中断以来的计数值(单步转动为±1) */
        timer_counter_value_config(TIMER3,0); /* 计数器清零,为下一次增量测量做准备 */
        if(cnt > 0) /* 计数值为正:一个中断间隔内计数器递增 */
        {
            encoder_code = ENCODER_DEC; /* 置编码器减方向动作码 */
        }
        else
        {
            encoder_code = ENCODER_INC; /* 计数值非正(计数器递减方向):置编码器增方向动作码 */
        }
    }
}


/* 局部函数 -----------------------------------------------------------------------------------*/
/**
  * @brief 编码器A/B相与按键GPIO初始化
  * @param 无
  * @retval 无
  */
static void encoder_gpio_init(void)
{
    /* 使能GPIO时钟 */
    rcu_periph_clock_enable(ENCODERA_GPIO_CLK); /* 使能编码器A相GPIO时钟 */
    rcu_periph_clock_enable(ENCODERB_GPIO_CLK); /* 使能编码器B相GPIO时钟 */
    rcu_periph_clock_enable(KEY_GPIO_CLK); /* 使能按键GPIO时钟 */

    gpio_init(ENCODERA_GPIO_PORT,GPIO_MODE_IN_FLOATING,GPIO_OSPEED_50MHZ,ENCODERA_GPIO_PIN); /* 编码器A相引脚浮空输入 */
    gpio_init(ENCODERB_GPIO_PORT,GPIO_MODE_IN_FLOATING,GPIO_OSPEED_50MHZ,ENCODERB_GPIO_PIN); /* 编码器B相引脚浮空输入 */
    gpio_init(KEY_GPIO_PORT,GPIO_MODE_IN_FLOATING,GPIO_OSPEED_50MHZ,KEY_GPIO_PIN); /* 按键引脚浮空输入 */
}


static void encoder_timer_init(void) /* TIMER3正交编码器模式配置 */
{
    /* TIMER3配置:先配置输入捕获通道,再切入正交编码器模式 */
    timer_ic_parameter_struct timer_icinitpara; /* 输入捕获通道参数结构体 */
    timer_parameter_struct timer_initpara; /* 定时器时基参数结构体 */

    rcu_periph_clock_enable(RCU_TIMER3); /* 使能TIMER3时钟 */

    timer_deinit(TIMER3); /* 复位TIMER3到默认状态 */

    /* TIMER3时基配置 */
    timer_initpara.prescaler         = 0; /* 预分频0:计数时钟=定时器输入时钟 */
    timer_initpara.alignedmode       = TIMER_COUNTER_EDGE; /* 边沿对齐计数模式 */
    timer_initpara.counterdirection  = TIMER_COUNTER_UP; /* 向上计数(编码器模式下实际方向由脉冲相位决定) */
    timer_initpara.period            = 0xFFFF; /* 周期65535:16位全范围,双向计数负增量以回绕表示 */
    timer_initpara.clockdivision     = TIMER_CKDIV_DIV1; /* 时钟分割DIV1(数字滤波器采样基准) */
    timer_initpara.repetitioncounter = 0; /* 重复计数器0 */
    timer_init(TIMER3,&timer_initpara); /* 初始化TIMER3时基 */

    /* TIMER3捕获通道配置 */
    /* TIMER3输入捕获参数配置 */
    timer_icinitpara.icpolarity  = TIMER_IC_POLARITY_RISING; /* 捕获极性:上升沿 */
    timer_icinitpara.icselection = TIMER_IC_SELECTION_DIRECTTI; /* 输入直接映射到捕获通道 */
    timer_icinitpara.icprescaler = TIMER_IC_PSC_DIV1; /* 不分频:每个有效边沿都捕获 */
    timer_icinitpara.icfilter    = 0x10; /* 数字滤波系数0x10(滤除窄脉冲毛刺) */
    timer_input_capture_config(TIMER3,TIMER_CH_0,&timer_icinitpara); /* 配置CI0(编码器A相)输入捕获 */
    timer_input_capture_config(TIMER3,TIMER_CH_1,&timer_icinitpara); /* 配置CI1(编码器B相)输入捕获 */

    timer_input_trigger_source_select(TIMER3,TIMER_SMCFG_TRGSEL_CI0FE0); /* 触发源选滤波后的CI0:编码器计数边沿产生触发事件 */
    /* 正交编码器模式2:计数器在CI0与CI1两路输入的所有边沿计数(4倍频),计数方向由两相信号正交相位关系决定 */
    timer_quadrature_decoder_mode_config(TIMER3,TIMER_ENCODER_MODE2,TIMER_IC_POLARITY_RISING,TIMER_IC_POLARITY_RISING);
    
    timer_interrupt_enable(TIMER3,TIMER_INT_TRG); /* 使能触发中断:每个编码器计数事件进入一次中断 */

    /* 使能TIMER3计数器(原注释TIMER2为笔误) */
    timer_enable(TIMER3); /* 启动TIMER3开始计数 */
}

/**
  * @brief 往按键fifo存入一个按键
  * @param 无
  * @retval 无
  * @note 
  */
static void key_put(uint8_t keyCode)
{
    /*往FIFO存入一个数据且写指针加1 */
    key_f.Buf[key_f.Write++] = keyCode; /* 往FIFO存入按键码,写指针后移一位 */
    
    if(key_f.Write >= KEY_FIFO_SIZE) /* 写指针越过缓冲区末尾则回卷 */
        key_f.Write = 0; /* 写指针回卷到0 */
}

/**
  * @brief 按键fifo相关结构体变量初始化
  * @param 无
  * @retval 无
  * @note 
  */
static void key_var_init(void)
{
    uint8_t i=0; /* 循环索引 */
    
    key_f.Read = 0; /* FIFO读指针清零 */
    key_f.Write = 0; /* FIFO写指针清零 */
    
    /* 注:长按计数器LongCount未在此初始化,静态变量上电默认为0 */
    for(i=0;i<KEY_COUNT;i++) /* 初始化每个按键的参数 */
    {
        key_x[i].LongTime = KEY_LONG_TIME; /* 长按判定时间(KEY_LONG_TIME,单位10ms) */
        key_x[i].Count = KEY_FILTER_TIME / 2; /* 滤波计数器初值为半个滤波时间 */
        key_x[i].State = 0; /* 按键状态0-未按下 */
        key_x[i].RepeatSpeed = 0; /* 连发周期0-不连发 */
        key_x[i].RepeatCount = 0; /* 连发计数器清零 */
        key_x[i].LongPressFlag = 0; /* 长按标志清零 */
    }
    
    /*判断按键是否按下的函数 */
    key_x[0].IsKeyDownFunc = IsKey0Down; /* 绑定按键按下检测函数IsKey0Down */
}




/**
  * @brief 检测一个按键
  * @param 无
  * @retval 无
  * @note 这个函数里面判断按键是否按下,并进行滤波
  */
static void key_detect(uint8_t i)
{
    KEY_T *pKey; /* 指向当前检测按键的结构体指针 */
    
    pKey = &key_x[i]; /* 取第i个按键的结构体地址 */
    if(pKey->IsKeyDownFunc() == KEY_ISDOWN)     /*按键按下了 */
    {
        if(pKey->Count < KEY_FILTER_TIME) /* 按下瞬间:计数直接拉满到滤波时间 */
        {
            pKey->Count = KEY_FILTER_TIME; /* 计数补足到滤波时间,从确认门限起步 */
        }
        else if(pKey->Count < 2 * KEY_FILTER_TIME) /* 计数从滤波时间增长到2倍滤波时间:消抖确认 */
        {
            pKey->Count++; /* 连续检测到按下则计数累加 */
        }
        else
        {
            /*滤波消抖后的 */
            if(pKey->State == 0)        /*如果按键状态为未按下 */
            {   
                pKey->State = 1;        /*标记按键状态为按下 */
                
                key_put((uint8_t)(3*i+1));  /*存入按键按下 */
            }
            if(pKey->LongTime > 0)      /*如果支持长按 */
            {
                if(pKey->LongCount < pKey->LongTime) /* 长按计时未达长按时间阈值 */
                {
                    pKey->LongCount++; /* 长按计数累加 */
                    if(pKey->LongCount >= pKey->LongTime) /* 长按计数达到长按时间 */
                    {
                        /*存入按键长按 */
                        key_put((uint8_t)(3*i+3)); /* 存入长按键码(3*i+3) */
                        pKey->LongPressFlag = 1; /* 置长按标志(释放时不再存弹起码) */
                    }
                    
                }
                else
                {
                    if(pKey->RepeatSpeed>0) /* 配置了连发周期(RepeatSpeed>0) */
                    {
                        pKey->RepeatCount++; /* 连发计数累加 */
                        if(pKey->RepeatCount >= pKey->RepeatSpeed) /* 连发计数达到连发周期 */
                        {
                            /*按键长按后，定期存入按键长按 */
                            pKey->RepeatCount = 0; /* 连发计数清零重新计时 */
                            key_put((uint8_t)(3*i+1)); /* 周期性存入按下键码(3*i+1)实现连发 */
                        }
                    }
                }
            }
        }
    }
    else        /*按键未按下 */
    {   
        if(pKey->Count > KEY_FILTER_TIME) /* 释放瞬间:计数直接降到滤波时间 */
        {
            pKey->Count = KEY_FILTER_TIME; /* 计数降到滤波时间,对称消抖 */
        }
        else if(pKey->Count > 0) /* 计数大于0则递减确认释放 */
        {
            pKey->Count--; /* 释放消抖计数递减 */
        }
        else
        {
            
            if(pKey->State == 1)    /*如果按键原来是按下的 */
            {
                pKey->State = 0; /* 状态更新为未按下 */
                if(pKey->LongPressFlag) /* 此前发生过长按 */
                {
                    /* 长按后释放:仅清长按标志,不存释放键码 */

                    pKey->LongPressFlag = 0; /* 清长按标志 */
                }
                else
                {
                    /*存入按键弹起来 */
                    key_put((uint8_t)(3*i+2)); /* 存入弹起键码(3*i+2) */
                }
            }
        }
        
        pKey->LongCount = 0; /* 释放后长按计数清零 */
        pKey->RepeatCount = 0; /* 连发计数清零 */
    }
}

/***************************************** 文件结束 *********************************************/
