/*
*******************************************************************************************************
*
* 文件名称 : encoder.h
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 旋转编码器与按键接口(编码器正交解码读取、按键扫描与事件 FIFO)
* 
*******************************************************************************************************
*/
#ifndef _ENCODER_H_ /* 头文件保护宏：防止重复包含 */
#define _ENCODER_H_ /* 定义头文件保护宏 */

#ifdef __cplusplus /* C++ 兼容处理 */
extern "C"{ /* 以 C 语言方式编译 */
#endif /* __cplusplus 条件编译结束 */

/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "gd32f30x.h" /* GD32F30x 固件库总头文件 */


/* 宏定义 ------------------------------------------------------------------------------------------*/
#define ENCODERA_GPIO_PORT                  GPIOB /* 编码器 A 相引脚端口 */
#define ENCODERA_GPIO_PIN                   GPIO_PIN_6 /* 编码器 A 相引脚：PB6 */
#define ENCODERA_GPIO_CLK                   RCU_GPIOB /* 编码器 A 相引脚时钟 */

#define ENCODERB_GPIO_PORT                  GPIOB /* 编码器 B 相引脚端口 */
#define ENCODERB_GPIO_PIN                   GPIO_PIN_7 /* 编码器 B 相引脚：PB7 */
#define ENCODERB_GPIO_CLK                   RCU_GPIOB /* 编码器 B 相引脚时钟 */

#define KEY_GPIO_PORT                       GPIOC /* 按键引脚端口 */
#define KEY_GPIO_PIN                        GPIO_PIN_0 /* 按键引脚：PC0 */
#define KEY_GPIO_CLK                        RCU_GPIOC /* 按键引脚时钟 */

/* 按键个数 */
#define KEY_COUNT 1
/* 按键滤波时间 单位10ms */
#define KEY_FILTER_TIME   5
/* 按键长按时间 单位10ms */
#define KEY_LONG_TIME     100
/* 定义按键FIFO缓冲区大小 */
#define KEY_FIFO_SIZE	2

typedef enum{ /* 编码器动作码枚举 */
    ENCODER_NONE = 0, /* 无动作 */
    ENCODER_INC, /* 编码器增量旋转 */
    ENCODER_DEC, /* 编码器减量旋转 */
}encoder_code_t; /* 编码器动作码类型 */

/* 按键是否按下 */
typedef enum
{
	KEY_ISDOWN = 0, /* 按键按下 */
	KEY_NOTDOWN, /* 按键未按下 */
}KEY_DOWN; /* 按键按下状态类型 */


/* 按键类型 */
typedef enum
{
	KEY_NONE = 0, /* 无按键事件 */
	
	KEY_0_PRESS, /* 按键0按下 */
	KEY_0_RELEASE, /* 按键0释放 */
	KEY_0_LONG_PRESS, /* 按键0长按 */
	
}KEY_ENUM; /* 按键事件类型 */


/* 按键结构体 */
typedef struct
{
	uint8_t (*IsKeyDownFunc)(void);		/* 按键是否按下的函数指针 */
	
	uint8_t Count;	/* 滤波器计数器 */
	uint16_t LongCount;	/* 长按计数器 */
	uint16_t LongTime;	/* 按键按下的时间 */
	uint8_t State;		/* 按键的当前状态 */
	uint8_t RepeatSpeed;	/* 连续按键周期 */
	uint8_t RepeatCount;		/* 连续按键计数器 */
	uint8_t LongPressFlag; /* 长按标志 */
	
	
}KEY_T; /* 按键结构体类型 */


/* fifo结构体 */
typedef struct
{
	uint8_t Buf[KEY_FIFO_SIZE];        /* 按键缓冲区 */
	uint8_t Read;                      /* 读指针 */
	uint8_t Write;                     /* 写指针 */
	
}KEY_FIFO; /* 按键 FIFO 结构体类型 */

/* 变量定义 ----------------------------------------------------------------------------------------*/


/* 函数定义 -----------------------------------------------------------------------------------------*/
void encoder_init(void); /* 编码器初始化：GPIO 与 TIMER3 正交解码模式 */
encoder_code_t encoder_get(void); /* 读取编码器动作码(增量/减量) */

void key_clear(void); /* 清空按键 FIFO */
void key_scan(void); /* 按键扫描(需周期调用) */
uint8_t key_get(void); /* 从按键 FIFO 读取一个按键事件 */

#ifdef __cplusplus /* C++ 兼容处理 */
extern "C"{ /* 以 C 语言方式编译 */
#endif /* __cplusplus 条件编译结束 */

#endif /* _ENCODER_H_ */

/***************************************** 文件结束 *********************************************/
