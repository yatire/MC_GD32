/*
*******************************************************************************************************
*
* 文件名称 : motor_app.h
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 电机控制主应用头文件(电机应用任务接口与运行数据结构定义)
*
*******************************************************************************************************
*/
#ifndef _MOTOR_APP_H_    /* 头文件保护宏,防止重复包含 */
#define _MOTOR_APP_H_    /* 定义头文件保护宏 */

#ifdef __cplusplus    /* C++编译兼容处理 */
extern "C"{    /* 按C语言方式导出接口 */
#endif    /* 结束条件编译 */

/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "motor_hardware.h"    /* 电机硬件接口宏(PWM/ADC通道定义) */
#include "motor_config.h"    /* 电机硬件参数配置(PWM频率/换算系数等) */

/* 宏定义 ------------------------------------------------------------------------------------------*/
#define START_DELAY_SEC     (float)2    /* 启动前延时时间(秒) */
/* 启动延时折算成PWM周期数(延时秒数×PWM频率) */
#define START_DELAY_TICK    (uint32_t)((float)START_DELAY_SEC/(1/(float)MOTOR_PWM_FREQ_HZ))

#define ADC_CAL_COUNT       1024    /* ADC零点标定采样次数(1024次取均值) */

/* 电机运行状态机枚举 */
typedef enum{
    INIT = 0,    /* 初始化 */
    ADC_CAL,    /* ADC零点标定 */
    START_DELAY,    /* 启动延时 */
    STOP,    /* 停止 */
    RUN,    /* 运行 */
    FAULT,    /* 故障 */
}motor_state_t;

/* 电机控制运行数据结构体 */
typedef struct{
    uint16_t adc_ia;    /* A相电流ADC原始值 */
    uint16_t adc_ib;    /* B相电流ADC原始值 */
    uint16_t adc_ic;    /* C相电流ADC原始值 */
    uint16_t ia_offset;    /* A相电流零点偏置(标定均值) */
    uint16_t ib_offset;    /* B相电流零点偏置(标定均值) */
    uint16_t ic_offset;    /* C相电流零点偏置(标定均值) */
    uint32_t adc_cal_cnt;    /* 标定采样计数 */
    
    uint32_t start_delay_tick;    /* 启动延时已计时PWM周期数 */
    
    uint16_t ntc_adc;    /* NTC温度ADC原始值 */
    uint16_t vdc_adc;    /* 母线电压ADC原始值 */
    uint16_t idc_adc;    /* 母线电流ADC原始值 */
    float mosfet_temp;    /* MOS管温度(摄氏度) */
    float vdc;    /* 母线电压(伏) */
    float idc;    /* 母线电流(安) */
    
    uint16_t speed_rpm;    /* 实际转速(转/分) */
    
    motor_state_t state;    /* 当前状态机状态 */
}motor_control_t;

/* 变量定义 ----------------------------------------------------------------------------------------*/


/* 函数定义 -----------------------------------------------------------------------------------------*/
void motor_app_init(void);                   /* 电机应用初始化(状态机复位/CAN发送报文/LCD界面初始化) */
void motor_app_isr(void);                    /* 电机中断服务函数,由PWM周期中断调用(状态机与FOC主流程) */
void motor_app_task10ms(void);               /* 电机10ms任务(ADC采样/编码器/按键处理) */
void motor_app_task100ms(void);              /* 电机100ms任务(空实现) */
void motor_app_task500ms(void);              /* 电机500ms任务(空实现) */
void motor_app_task1s(void);                 /* 电机1s任务(刷新LCD显示界面) */
void motor_app_idle(void);                   /* 电机空闲任务(ADC轮询采样) */

#ifdef __cplusplus    /* C++编译兼容处理 */
extern "C"{    /* 按C语言方式导出接口(此块为文件尾重复的历史遗留写法,原样保留) */
#endif    /* 结束条件编译 */

#endif /* _MOTOR_APP_H_ */    /* 头文件保护宏结束 */

/***************************************** 文件结束 *********************************************/
