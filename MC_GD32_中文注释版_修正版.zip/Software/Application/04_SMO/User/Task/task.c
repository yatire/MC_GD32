/*
*******************************************************************************************************
*
* 文件名称 : task.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 创建日期 : 2023年2月26日
* 说    明 : 基于滴答定时器的软定时器任务调度(1ms/5ms/10ms/100ms/500ms/1s周期任务+空闲任务)
*
*******************************************************************************************************
*/

/*******************************************************************************
* 头文件包含
*******************************************************************************/
#include "task.h"       /* 任务调度模块头文件 */
#include "systick.h"    /* 滴答定时器头文件(提供系统时基计数) */
#include "led.h"        /* LED驱动头文件(心跳灯用) */
#include "motor_app.h"  /* 电机应用层头文件(各周期任务的实际处理) */

/*******************************************************************************
* 宏定义
*******************************************************************************/

/*******************************************************************************
* 宏与类型定义
*******************************************************************************/
#define TICK_PRD_1MS 			1       /* 1ms任务周期:1ms */
#define TICK_PRD_5MS 			5       /* 5ms任务周期:5ms */
#define TICK_PRD_10MS 			10      /* 10ms任务周期:10ms */
#define TICK_PRD_100MS 			100     /* 100ms任务周期:100ms */
#define TICK_PRD_500MS 			500     /* 500ms任务周期:500ms */
#define TICK_PRD_1S 			1000    /* 1s任务周期:1000ms */

/* 计算当前时基与上次执行时基的差值(处理32位计数回绕:未回绕直接相减,回绕则从0xFFFFFFFF补算) */
#define CalcPeriod(curr_tick, lastTick)	(curr_tick >= lastTick) ? \
										(curr_tick - lastTick) : \
									   (0xFFFFFFFF - lastTick + curr_tick)

/* 判断指定周期是否已到(delta为CalcPeriod算出的时基差,prd为周期ms数) */
#define IsPeriodReached(prd) 			(delta >= prd)

/*******************************************************************************
* 全局常量定义
*******************************************************************************/

/*******************************************************************************
* 局部常量定义
*******************************************************************************/

/*******************************************************************************
* 全局变量定义
*******************************************************************************/

/*******************************************************************************
* 局部变量定义
*******************************************************************************/
static uint32_t tick1ms = 0;    /* 1ms任务上次执行的时基 */
static uint32_t tick5ms = 0;    /* 5ms任务上次执行的时基 */
static uint32_t tick10ms = 0;   /* 10ms任务上次执行的时基 */
static uint32_t tick100ms = 0;  /* 100ms任务上次执行的时基 */
static uint32_t tick500ms = 0;  /* 500ms任务上次执行的时基 */
static uint32_t tick1s = 0;     /* 1s任务上次执行的时基 */

/*******************************************************************************
* 局部函数声明
*******************************************************************************/
static void sch_task1ms(void);      /* 1ms周期任务 */
static void sch_task5ms(void);      /* 5ms周期任务 */
static void sch_task10ms(void);     /* 10ms周期任务 */
static void sch_task100ms(void);    /* 100ms周期任务 */
static void sch_task500ms(void);    /* 500ms周期任务 */
static void sch_task1s(void);       /* 1s周期任务 */
static void sch_idle(void);         /* 空闲任务(所有周期任务均未到时执行) */

/*******************************************************************************
*  全局函数定义
*******************************************************************************/



/**
  * @brief TASK初始化
  * @param void
  * @retval     void
  * @note
  */
void task_init(void)
{
    motor_app_init();   /* 初始化电机应用层(硬件/参数/状态机) */
}

/**
  * @brief 1ms任务
  * @param void
  * @retval     void
  * @note
  */
static void sch_task1ms(void)
{
    /* 预留:当前无1ms周期任务 */
}

/**
  * @brief 5ms任务
  * @param void
  * @retval     void
  * @note
  */
static void sch_task5ms(void)
{
    /* 预留:当前无5ms周期任务 */
}

/**
  * @brief 10ms任务
  * @param void
  * @retval     void
  * @note
  */
static void sch_task10ms(void)
{
    motor_app_task10ms();   /* 执行电机应用10ms周期处理 */
}

/**
  * @brief 100ms任务
  * @param void
  * @retval     void
  * @note
  */
static void sch_task100ms(void)
{
    motor_app_task100ms();  /* 执行电机应用100ms周期处理 */
}

/**
  * @brief 500ms任务
  * @param void
  * @retval     void
  * @note
  */
static void sch_task500ms(void)
{
    led_toggle(LED1);           /* LED1翻转(心跳灯指示调度正常) */
    motor_app_task500ms();      /* 执行电机应用500ms周期处理 */
}

/**
  * @brief 1S任务
  * @param void
  * @retval     void
  * @note
  */
static void sch_task1s(void)
{
    motor_app_task1s();     /* 执行电机应用1s周期处理 */
}

/**
  * @brief 空闲任务(原注释"1S任务"系笔误)
  * @param void
  * @retval     void
  * @note
  */
static void sch_idle(void)
{
    motor_app_idle();       /* 执行电机应用空闲处理 */
}

/**
  * @brief TASK任务调度
  * @param void
  * @retval     void
  * @note 主循环中循环调用,按各任务周期到时执行,全部未到时执行空闲任务
  */
void task_scheduler(void)
{
	uint8_t isIdle;                 /* 空闲标志:1表示本轮无任何周期任务执行 */
	uint32_t curr_tick, delta;      /* 当前时基/时基差值 */

	isIdle = 1;                     /* 先假定本轮空闲 */
	curr_tick = systick_get_current_tick();     /* 读取当前系统时基(1ms计数) */

	delta = CalcPeriod(curr_tick, tick1ms);     /* 计算1ms任务距上次执行的时基差 */
	if (IsPeriodReached(TICK_PRD_1MS))          /* 时基差达到1ms周期 */
	{
		/* 重载周期时基 */
		tick1ms = curr_tick;                    /* 记录本次执行时基,作为下轮比较基准 */

		sch_task1ms();                          /* 执行1ms周期任务 */

		isIdle = 0;                             /* 有任务执行,清除空闲标志 */
	}

	delta = CalcPeriod(curr_tick, tick5ms);     /* 计算5ms任务距上次执行的时基差 */
	if (IsPeriodReached(TICK_PRD_5MS))          /* 时基差达到5ms周期 */
	{
		/* 重载周期时基 */
		tick5ms = curr_tick;                    /* 记录本次执行时基 */

		sch_task5ms();                          /* 执行5ms周期任务 */

		isIdle = 0;                             /* 有任务执行,清除空闲标志 */
	}

	delta = CalcPeriod(curr_tick, tick10ms);    /* 计算10ms任务距上次执行的时基差 */
	if (IsPeriodReached(TICK_PRD_10MS))         /* 时基差达到10ms周期 */
	{
		/* 重载周期时基 */
		tick10ms = curr_tick;                   /* 记录本次执行时基 */

		sch_task10ms();                         /* 执行10ms周期任务 */

		isIdle = 0;                             /* 有任务执行,清除空闲标志 */
	}

	delta    = CalcPeriod(curr_tick, tick100ms);    /* 计算100ms任务距上次执行的时基差 */
	if (IsPeriodReached(TICK_PRD_100MS))            /* 时基差达到100ms周期 */
	{
		/* 重载周期时基 */
		tick100ms = curr_tick;                  /* 记录本次执行时基 */

		sch_task100ms();                        /* 执行100ms周期任务 */

		isIdle = 0;                             /* 有任务执行,清除空闲标志 */
	}

	delta    = CalcPeriod(curr_tick, tick500ms);    /* 计算500ms任务距上次执行的时基差 */
	if (IsPeriodReached(TICK_PRD_500MS))            /* 时基差达到500ms周期 */
	{
		/* 重载周期时基 */
		tick500ms = curr_tick;                  /* 记录本次执行时基 */

		sch_task500ms();                        /* 执行500ms周期任务 */

		isIdle = 0;                             /* 有任务执行,清除空闲标志 */
	}

	delta    = CalcPeriod(curr_tick, tick1s);   /* 计算1s任务距上次执行的时基差 */
	if (IsPeriodReached(TICK_PRD_1S))           /* 时基差达到1s周期 */
	{
		/* 重载周期时基 */
		tick1s = curr_tick;                     /* 记录本次执行时基 */

		sch_task1s();                           /* 执行1s周期任务 */

		isIdle = 0;                             /* 有任务执行,清除空闲标志 */
	}

	if (isIdle)                     /* 本轮所有周期任务均未到时 */
	{
		sch_idle();                 /* 执行空闲任务 */
	}
}
