/*
*******************************************************************************************************
*
* 文件名称 : main.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 主函数文件(SMO滑模观测器无感FOC例程)
*
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include <string.h> /* C字符串/内存操作库头文件(memcpy等) */
#include "gd32f30x.h" /* GD32F30x芯片外设寄存器与固件库头文件 */
#include "gd32f30x_libopt.h" /* GD32F30x固件库外设包含配置头文件 */
#include "systick.h" /* 滴答定时器配置头文件(系统节拍/延时) */
#include "led.h" /* LED驱动头文件 */
#include "motor_hardware.h" /* 电机硬件接口配置头文件(PWM/ADC/用户IO) */
#include "uart.h" /* 串口驱动头文件 */
#include "i2c.h" /* I2C驱动头文件 */
#include "encoder.h" /* 编码器(旋钮)驱动头文件 */
#include "eeprom.h" /* EEPROM(24C02)读写驱动头文件 */
#include "delay.h" /* 忙等待延时函数头文件 */
#include "adc_simple.h" /* 简易ADC采样头文件(母线电压/NTC温度) */
#include "lcd.h" /* LCD显示驱动头文件(绘图/填充/显示字符串) */
#include "lcd_init.h" /* LCD初始化及硬件引脚配置头文件 */
#include "can.h" /* CAN总线驱动头文件 */
#include "drv8323rs.h" /* DRV8323RS栅极驱动器SPI驱动头文件 */
#include "foc.h" /* FOC算法头文件(Clark/Park变换/SVPWM) */
#include "pmsm.h" /* PMSM电机控制头文件(FOC参数与主运算) */
#include "userparms.h" /* 用户参数配置头文件(电机极对数/PI参数等) */
#include "task.h" /* 任务调度器头文件(任务初始化/时间片调度) */
#include "motor_app.h" /* 电机应用层头文件(状态机/启动控制) */

/* 宏定义 ------------------------------------------------------------------------------------------*/
#define START_DELAY_SEC     (float)2 /* 启动延时时间:2秒 */
/* 启动延时对应的PWM周期数(2秒×16kHz=32000,与motor_app.h中同名宏重复) */
#define START_DELAY_TICK    (uint32_t)((float)START_DELAY_SEC/(1/(float)MOTOR_PWM_FREQ_HZ))

/* 变量定义 ----------------------------------------------------------------------------------------*/
uint8_t adc_calibration = 0; /* ADC零点标定完成标志(历史遗留变量,当前版本未引用) */
uint32_t ia_offset = 0,ib_offset = 0,ic_offset = 0,idc_offset = 0; /* 三相/母线电流ADC零点偏置(历史遗留,标定量存于motor1结构体) */
uint16_t adc1_ia = 0,adc1_ib = 0,adc1_ic = 0,adc1_idc = 0; /* 注入组相电流/母线电流采样原始值(历史遗留变量,未引用) */

uint32_t start_delay_tick = 0; /* 启动延时计数器(历史遗留变量,当前版本未引用) */

extern uint16_t adc_filter_buffer[ADC_FILTER_COUNT]; /* ADC滤波缓冲区extern声明(历史遗留,未定义未引用,实际滤波在adc_simple.c) */
extern uint16_t speed_rpm; /* 实际转速extern声明(历史遗留,未定义未引用,实际为motor1.speed_rpm成员) */
extern uint16_t adc_filter_count; /* 滤波计数extern声明(历史遗留,未定义未引用) */

/* 函数定义 -----------------------------------------------------------------------------------------*/


/**
  * @brief 主函数
  * @param 无
  * @retval 无
  */
int main(void)
{
    SCB->VTOR = FLASH_BASE | 0x4000; /* 设置中断向量表到APP区基址(偏移0x4000,由Bootloader引导) */
    __enable_irq(); /* 使能全局中断 */
    
    systick_init(); /* 初始化滴答定时器(1ms系统节拍) */
    led_init(); /* 初始化LED指示灯 */
    usart_init(); /* 初始化调试串口 */
    adc1_init(); /* 初始化ADC1(软件触发采样NTC温度/母线电压) */
    can_bus_init(); /* 初始化CAN总线(波特率/过滤器) */
    encoder_init(); /* 初始化编码器(旋钮)接口 */
    LCD_Init(); /* 初始化LCD(电机应用界面显示用) */
    LCD_Fill(0,0,LCD_W,LCD_H,WHITE); /* 全屏填充白色背景 */
    DRV8323RS_init(); /* 初始化DRV8323RS栅极驱动器(SPI寄存器配置/CSA校准) */
    task_init(); /* 任务调度器初始化(内部调用电机应用初始化) */
    
    motor_hardware_init(); /* 初始化电机硬件(NVIC/PWM/ADC注入组) */
    pmsm_foc_param.pwm_period = (float)MOTOR_PWM_PERIOD * 0.95f; /* 设置SVPWM调制满量程计数值(周期值×0.95,留出过调制余量) */
    pmsm_foc_init(); /* PMSM FOC初始化(计算启动参数) */
    
    while(1) /* 主循环:运行时间片任务调度器 */
    {
        task_scheduler(); /* 轮询调度1ms/5ms等周期任务 */
    }
}

/**
  * @brief TIMER0刹车中断服务函数(硬件故障保护时触发)
  * @param 无
  * @retval 无
  */
void TIMER0_BRK_IRQHandler(void)
{
    timer_channel_output_mode_config(TIMER0,TIMER_CH_0,TIMER_OC_MODE_INACTIVE); /* 将W相通道(CH0)置为匹配时无效电平,封锁PWM */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_1,TIMER_OC_MODE_INACTIVE); /* 将V相通道(CH1)置为匹配时无效电平,封锁PWM */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_2,TIMER_OC_MODE_INACTIVE); /* 将U相通道(CH2)置为匹配时无效电平,封锁PWM */
    /* 清除定时器中断标志 */
    timer_interrupt_flag_clear(TIMER0,TIMER_INT_FLAG_BRK); /* 清除刹车中断标志 */
    
    led_on(LED_FAULT); /* 点亮故障指示LED */
}

/**
  * @brief ADC0/ADC1中断服务函数(注入组转换完成中断)
  * @param 无
  * @retval 无
  */
void ADC0_1_IRQHandler(void)
{
    /* 清除ADC中断标志 */
    adc_interrupt_flag_clear(ADC0, ADC_INT_FLAG_EOIC); /* 清除注入组转换完成中断标志 */
    motor_app_isr(); /* 调用电机应用中断处理(电流采样/SMO观测/FOC运算) */
}

/*!
    \brief      CAN0 RX0接收中断服务函数(读取报文以清除接收标志)
    \param[in]  无
    \param[out] 无
    \retval     无
*/
void USBD_LP_CAN0_RX0_IRQHandler(void)
{
    can_receive_message_struct receive_message; /* CAN接收报文结构体 */
    /* 检查接收报文 */
    can_message_receive(CAN0, CAN_FIFO0, &receive_message); /* 读取CAN0 FIFO0中的一条报文 */
}


/***************************************** 文件结束 *********************************************/
