/*
*******************************************************************************************************
*
* 文件名称 : drv8323rs.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 无感FOC电机控制库 DRV8323RS 栅极驱动器SPI驱动
*
*******************************************************************************************************
*/

/*
    版权所有 (c) 2023, 德州仪器(Texas Instruments Incorporated)
    保留所有权利。

    在满足以下条件的前提下，允许以源代码和二进制形式对本软件进行再发布与使用(无论是否修改)：

    *  以源代码形式再发布时，必须保留上述版权声明、本条件列表及以下免责声明。

    *  以二进制形式再发布时，必须在随附的文档和/或其他分发材料中重现上述版权声明、
       本条件列表及以下免责声明。

    *  未经事先书面许可，不得使用德州仪器(Texas Instruments Incorporated)或其贡献者的名义
       为本软件的衍生产品进行背书或推广。

    本软件由版权持有人和贡献者"按原样"提供，不提供任何明示或默示的保证，包括但不限于对
    适销性和特定用途适用性的默示保证。在任何情况下，无论因何原因产生或基于何种责任理论，
    无论是合同责任、严格责任还是侵权责任(包括过失或其他)，版权持有人或贡献者均不对任何直接
    的、间接的、偶然的、特殊的、惩罚性的或后果性的损害(包括但不限于替代商品或服务的采购、
    使用、数据或利润损失、或业务中断)承担责任，即使已被告知可能发生此类损害。
*/
/* DRV8323RS栅极驱动器寄存器地址/位段定义与接口声明 */
#include "drv8323rs.h"
/* SysTick毫秒延时函数(systick_delay)声明 */
#include "systick.h"
/* SPI0初始化与全双工收发函数声明 */
#include "spi.h"

/**
 * @brief 存储DRV8323RS电流检测放大器(CSA)可选的增益值
 */
int8_t drvGain[DRV8323RS_CSA_GAIN_MAX_VALUES] = { 5, 10, 20, 40};

/* DRV8323RS初始化：配置SPI与使能/片选引脚，清除故障并设置VDS过流监视阈值 */
void DRV8323RS_init(void)
{
    uint16_t Fault_Status_1 = 0;    /* 故障状态寄存器1读回值(本函数未使用) */
    uint16_t VGS_Status_1 = 0;    /* VGS状态寄存器1读回值(本函数未使用) */
    uint16_t Gate_Drive_HS = 0;    /* 高侧栅极驱动寄存器读回值 */
    uint16_t ocp_reg_data = 0;    /* 过流保护寄存器数据(本函数未使用) */
    
    rcu_periph_clock_enable(SPI_CS_GPIO_CLK);    /* 使能SPI片选引脚GPIO时钟 */
    rcu_periph_clock_enable(ENABLE_GPIO_CLK);    /* 使能DRV8323RS使能引脚GPIO时钟 */
    
    spi0_init();    /* 初始化SPI0(与DRV8323RS进行SPI通信) */
    
    gpio_init(SPI_CS_GPIO_PORT, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ,SPI_CS_GPIO_PIN);    /* 片选引脚推挽输出 */
    gpio_init(ENABLE_GPIO_PORT, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ,ENABLE_GPIO_PIN);    /* 使能引脚推挽输出 */

    gpio_bit_write(ENABLE_GPIO_PORT,ENABLE_GPIO_PIN,RESET);    /* 先拉低使能引脚，DRV8323RS初始禁用 */
    gpio_bit_write(SPI_CS_GPIO_PORT,SPI_CS_GPIO_PIN,SET);    /* 拉高片选，SPI总线空闲 */
    
    DRV8323RS_disable();    /* 先禁用DRV8323RS，使其寄存器恢复默认值 */
    DRV8323RS_enable();    /* 再使能DRV8323RS并等待SPI就绪 */

    DRV8323RS_clearFaults();    /* 清除DRV8323RS故障锁存 */
    
    /* Gate_Drive_HS 默认值 : 0x3FF */
    Gate_Drive_HS = DRV8323RS_spiRead(DRV8323RS_REG_ADDR_GATE_DRIVE_HS);    /* 读回高侧栅极驱动寄存器值 */
    DRV8323RS_setVdsLvl(DRV8323RS_OCP_CONTROL_VDS_LVL_0P130_V);    /* 设置VDS过流监视阈值为0.130V */
    
    if(Gate_Drive_HS != 0x3FF)    /* 读回值与默认值0x3FF不符，说明SPI通信异常 */
    {
        while(1);    /* 停机等待，便于排查 */
    }
}

/* 组装DRV8323RS的SPI数据帧：命令位+寄存器地址+数据 */
uint16_t DRV8323RS_createSPIDataWord(
                DRV8323RS_SPI_CMD wrCmd, DRV8323RS_REG_ADDR addr, uint16_t data)
{   
    /* 位15 W0：写=0，读=1 */
    uint16_t dataWord = ((wrCmd) << DRV8323RS_SPI_CMD_OFS);    /* 命令位置于位15 */

    /* 位14-11：寄存器地址 */
    dataWord |= ((addr << DRV8323RS_SPI_ADDR_OFS) & DRV8323RS_SPI_ADDR_MASK);    /* 地址左移至位14-11并屏蔽其余位 */

    /* 位10-0：数据 */
    dataWord |= (data & DRV8323RS_SPI_DATA_MASK);    /* 数据段置于位10-0 */
    return  dataWord;    /* 返回组装完成的SPI数据帧 */
}

/* 拉高使能引脚启动DRV8323RS，并等待其SPI接口就绪 */
void DRV8323RS_enable(void)
{
    /* 使能DRV8323RS */
    gpio_bit_write(ENABLE_GPIO_PORT,ENABLE_GPIO_PIN,SET);

    /* 等待DRV8323RS的SPI接口就绪的启动延时 */
    systick_delay(DRV8323RS_SPI_READY_DELAY_MS);
}

/* 拉低使能引脚令DRV8323RS进入休眠(其寄存器值将被复位) */
void DRV8323RS_disable(void)
{
    /* 禁用DRV8323RS */
    gpio_bit_write(ENABLE_GPIO_PORT,ENABLE_GPIO_PIN,RESET);

    /* 允许DRV8323RS进入休眠，休眠会复位其寄存器值。
    数据手册指出需至少等待1ms才能确保其已进入休眠模式。 */
    systick_delay(DRV8323RS_TURNOFF_DELAY_MS);
}

/* 向DRV8323RS指定寄存器写入数据 */
void DRV8323RS_spiWrite(DRV8323RS_REG_ADDR addr, uint16_t data)
{
    /* 组装写命令SPI数据帧 */
    uint16_t dataWord = DRV8323RS_createSPIDataWord(
                                           DRV8323RS_SPI_CMD_WRITE, addr, data);
    gpio_bit_write(SPI_CS_GPIO_PORT,SPI_CS_GPIO_PIN,RESET);    /* 拉低片选，选中DRV8323RS */
    spi0_transmit_receive_data(dataWord);    /* SPI发送写命令帧 */
    gpio_bit_write(SPI_CS_GPIO_PORT,SPI_CS_GPIO_PIN,SET);    /* 拉高片选，结束本次传输 */
}

/* 读取DRV8323RS指定寄存器的数据 */
uint16_t DRV8323RS_spiRead(DRV8323RS_REG_ADDR addr)
{
    uint16_t ret = 0;    /* 读回数据缓存 */
    /* 组装读命令SPI数据帧(数据段填充哑数据) */
    uint16_t dataWord = DRV8323RS_createSPIDataWord(
                        DRV8323RS_SPI_CMD_READ, addr, DRV8323RS_SPI_DUMMY_DATA);
    gpio_bit_write(SPI_CS_GPIO_PORT,SPI_CS_GPIO_PIN,RESET);    /* 拉低片选，选中DRV8323RS */
    ret = spi0_transmit_receive_data(dataWord);    /* 发送读命令帧并接收寄存器数据 */
    gpio_bit_write(SPI_CS_GPIO_PORT,SPI_CS_GPIO_PIN,SET);    /* 拉高片选，结束本次传输 */
    return ret & DRV8323RS_SPI_DATA_MASK;    /* 屏蔽位15-11，仅返回11位数据段 */
}

/* 读-改-写更新指定寄存器：仅修改mask覆盖的位段，其余位保持原值 */
void DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR addr, uint32_t mask, uint16_t data)
{
    uint16_t dataValue;    /* 寄存器读回值缓存 */
    dataValue = (uint16_t) DRV8323RS_spiRead(addr);    /* 先读出寄存器当前值 */
    dataValue &= ~(mask);    /* 清除mask指定的目标位段 */
    dataValue |= data;    /* 写入新的位段值 */
    DRV8323RS_spiWrite(addr, dataValue);    /* 回写整个寄存器 */
}

/* 设置DRV8323RS寄存器写保护锁(锁定后寄存器不可再写入) */
void DRV8323RS_setSPIRegisterLock(DRV8323RS_GATE_DRIVE_HS_LOCK lock)
{
    /* 更新GATE_DRIVE_HS寄存器中的LOCK锁定位段 */
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_GATE_DRIVE_HS,
                                    DRV8323RS_GATE_DRIVE_HS_LOCK_MASK, 
                                    (lock << DRV8323RS_GATE_DRIVE_HS_LOCK_OFS));
}

/* 设置高侧/低侧栅极驱动峰值拉电流(源电流，用于开启MOS管) */
void DRV8323RS_setPeakSourceGateCurr(
                                DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR hsPeakCurr, 
                                DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR lsPeakCurr)
{
    /* 更新GATE_DRIVE_HS寄存器的IDRIVEP_HS位段 */
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_GATE_DRIVE_HS,
                        DRV8323RS_GATE_DRIVE_HS_IDRIVEP_HS_MASK, 
                        (hsPeakCurr << DRV8323RS_GATE_DRIVE_HS_IDRIVEP_HS_OFS));

    /* 更新GATE_DRIVE_LS寄存器的IDRIVEP_LS位段 */
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_GATE_DRIVE_LS,
                        DRV8323RS_GATE_DRIVE_LS_IDRIVEP_LS_MASK, 
                        (lsPeakCurr << DRV8323RS_GATE_DRIVE_LS_IDRIVEP_LS_OFS));
}

/* 设置高侧/低侧栅极驱动峰值灌电流(吸收电流，用于关断MOS管) */
void DRV8323RS_setPeakSinkGateCurr(
                                  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR hsPeakCurr, 
                                  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR lsPeakCurr)
{
    /* 更新GATE_DRIVE_HS寄存器的IDRIVEN_HS位段 */
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_GATE_DRIVE_HS,
                        DRV8323RS_GATE_DRIVE_HS_IDRIVEN_HS_MASK, 
                        (hsPeakCurr << DRV8323RS_GATE_DRIVE_HS_IDRIVEN_HS_OFS));

    /* 更新GATE_DRIVE_LS寄存器的IDRIVEN_LS位段 */
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_GATE_DRIVE_LS,
                        DRV8323RS_GATE_DRIVE_LS_IDRIVEN_LS_MASK, 
                        (lsPeakCurr << DRV8323RS_GATE_DRIVE_LS_IDRIVEN_LS_OFS));
}

/* 设置栅极驱动峰值电流保持时间TDRIVE */
void DRV8323RS_setPeakGateCurrTime(DRV8323RS_GATE_DRIVE_PEAK_CUR_TIME tdrive)
{
    /* 更新GATE_DRIVE_LS寄存器的TDRIVE位段 */
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_GATE_DRIVE_LS,
                        DRV8323RS_GATE_DRIVE_LS_TDRIVE_MASK, 
                        (tdrive << DRV8323RS_GATE_DRIVE_LS_TDRIVE_OFS));
}

/* 设置DRV8323RS的PWM输入模式(6路/3路/1路输入) */
void DRV8323RS_setPwmMode(DRV8323RS_DRIVER_CONTROL_PWM_MODE pwmMode)
{
    /* 更新DRIVER_CONTROL寄存器的PWM_MODE位段 */
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_DRIVER_CONTROL,
                            DRV8323RS_DRIVER_CONTROL_PWM_MODE_MASK, 
                            (pwmMode << DRV8323RS_DRIVER_CONTROL_PWM_MODE_OFS));
}

/* 设置VDS过流监视阈值(功率管导通压降上限) */
void DRV8323RS_setVdsLvl(DRV8323RS_OCP_CONTROL_VDS_LVL vdsLvl)
{
    /* 更新OCP_CONTROL寄存器的VDS_LVL位段 */
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_OCP_CONTROL,
                                DRV8323RS_OCP_CONTROL_VDS_LVL_MASK, 
                                (vdsLvl << DRV8323RS_OCP_CONTROL_VDS_LVL_OFS));
}

/* 设置VDS过流检测消抖时间(2~8us) */
void DRV8323RS_setOcpDeg(DRV8323RS_OCP_CONTROL_OCP_DEG ocpDeg)
{
    /* 更新OCP_CONTROL寄存器的OCP_DEG位段 */
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_OCP_CONTROL,
                                DRV8323RS_OCP_CONTROL_OCP_DEG_MASK, 
                                (ocpDeg << DRV8323RS_OCP_CONTROL_OCP_DEG_OFS));
}

/* 设置过流保护动作模式(锁存关断/自动重试/仅报告/禁用) */
void DRV8323RS_setOcpMode(DRV8323RS_OCP_CONTROL_OCP_MODE ocpMode)
{
    /* 更新OCP_CONTROL寄存器的OCP_MODE位段 */
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_OCP_CONTROL,
                               DRV8323RS_OCP_CONTROL_OCP_MODE_MASK, 
                               (ocpMode << DRV8323RS_OCP_CONTROL_OCP_MODE_OFS));
}

/* 设置互补输出的死区时间(DEAD_TIME位域四档:50/100/200/400ns) */
void DRV8323RS_setDeadtime(DRV8323RS_OCP_CONTROL_DEADTIME deadtime)
{
    /* 更新OCP_CONTROL寄存器的DEAD_TIME位段 */
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_OCP_CONTROL,
                             DRV8323RS_OCP_CONTROL_DEAD_TIME_MASK, 
                             (deadtime << DRV8323RS_OCP_CONTROL_DEAD_TIME_OFS));
}

/* 设置过流故障后的自动重试等待时间 */
void DRV8323RS_setTretry(DRV8323RS_OCP_CONTROL_TRETRY tretry)
{
    /* 更新OCP_CONTROL寄存器的TRETRY位段 */
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_OCP_CONTROL,
                                  DRV8323RS_OCP_CONTROL_TRETRY_MASK, 
                                  (tretry << DRV8323RS_OCP_CONTROL_TRETRY_OFS));
}

/* 设置电流检测过流(SEN OCP)阈值电平 */
void DRV8323RS_setSenLvl(DRV8323RS_CSA_CONTROL_SEN_LVL senLvl)
{
    /* 更新CSA_CONTROL寄存器的SEN_LVL位段 */
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_CSA_CONTROL,
                                 DRV8323RS_CSA_CONTROL_SEN_LVL_MASK, 
                                 (senLvl << DRV8323RS_CSA_CONTROL_SEN_LVL_OFS));
}

/* 使能/禁用电流检测过流故障保护 */
void DRV8323RS_setDisSen(DRV8323RS_CSA_CONTROL_DIS_SEN disSen)
{
    /* 更新CSA_CONTROL寄存器的DIS_SEN位段 */
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_CSA_CONTROL,
                                 DRV8323RS_CSA_CONTROL_DIS_SEN_MASK,
                                 (disSen << DRV8323RS_CSA_CONTROL_DIS_SEN_OFS));
}

/* 设置电流检测放大器(CSA)增益(5/10/20/40 V/V) */
void DRV8323RS_setCsaGain(DRV8323RS_CSA_CONTROL_CSA_GAIN csaGain)
{
    /* 更新CSA_CONTROL寄存器的CSA_GAIN位段 */
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_CSA_CONTROL,
                                DRV8323RS_CSA_CONTROL_CSA_GAIN_MASK,
                               (csaGain << DRV8323RS_CSA_CONTROL_CSA_GAIN_OFS));
}

/* 设置低边过流检测参考点选择(LS_REF) */
void DRV8323RS_setLsRef(DRV8323RS_CSA_CONTROL_LS_REF lsRef)
{
    /* 更新CSA_CONTROL寄存器的LS_REF位段 */
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_CSA_CONTROL,
                                   DRV8323RS_CSA_CONTROL_LS_REF_MASK,
                                   (lsRef << DRV8323RS_CSA_CONTROL_LS_REF_OFS));
}

/* 设置电流检测放大器参考电压分压选择(VREF_DIV) */
void DRV8323RS_setVrefDiv(DRV8323RS_CSA_CONTROL_VREF_DIV vrefDiv)
{
    /* 更新CSA_CONTROL寄存器的VREF_DIV位段 */
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_CSA_CONTROL,
                               DRV8323RS_CSA_CONTROL_VREF_DIV_MASK,
                               (vrefDiv << DRV8323RS_CSA_CONTROL_VREF_DIV_OFS));
}

/* 设置电流检测放大器正相输入源选择(CSA_FET) */
void DRV8323RS_setCsaFet(DRV8323RS_CSA_CONTROL_CSA_FET csaFet)
{
    /* 更新CSA_CONTROL寄存器的CSA_FET位段 */
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_CSA_CONTROL,
                                 DRV8323RS_CSA_CONTROL_CSA_FET_MASK,
                                 (csaFet << DRV8323RS_CSA_CONTROL_CSA_FET_OFS));
}

/* 相电流IA读取函数(依赖TI HAL层接口，已被注释停用) */
/*
_iq DRV8323RS_getIA(void)
{
    _iq15 adcVal = HAL_getADCVoltage(handle->isena);
    _iq15 offset = _IQdiv2(HAL_getADCRefVoltage(handle->isena));
    return _IQ15toIQ(_IQ15mpy(adcVal - offset, handle->iSf));
}
*/

/* 相电流IB读取函数(依赖TI HAL层接口，已被注释停用) */
/*
_iq DRV8323RS_getIB(void)
{
    _iq15 adcVal = HAL_getADCVoltage(handle->isenb);
    _iq15 offset = _IQdiv2(HAL_getADCRefVoltage(handle->isenb));
    return _IQ15toIQ(_IQ15mpy(adcVal - offset, handle->iSf));
}
*/

/* 相电流IC读取函数(依赖TI HAL层接口，已被注释停用) */
/*
_iq DRV8323RS_getIC(void)
{
    _iq15 adcVal = HAL_getADCVoltage(handle->isenc);
    _iq15 offset = _IQdiv2(HAL_getADCRefVoltage(handle->isenc));
    return _IQ15toIQ(_IQ15mpy(adcVal - offset, handle->iSf));
}
*/

/* 母线电压VM读取函数(依赖TI HAL层接口，已被注释停用) */
/*
_iq DRV8323RS_getVM(void)
{
    _iq15 adcVal = (HAL_getADCVoltage(handle->vsenvm));
    return _IQ15toIQ(_IQ15mpy(adcVal, DRV8323RS_VOLTAGE_SF_IQ15));
}
*/

/* 设置电流采样换算系数iSf函数(依赖IQmath库，已被注释停用) */
/*
void DRV8323RS_setISf(DRV8323RS_CSA_CONTROL_CSA_GAIN  gain, _iq15 rshunt)
{
    handle->iSf = _IQ15div(_IQ15(1),
                               _IQ15mpy(_IQ15((int32_t)drvGain[gain]), rshunt));
}
*/

/* 查询DRV8323RS是否发生故障 */
bool DRV8323RS_isFaultOccurred(void)
{
    /* return HAL_getPWMFaultStatus(handle->nfault); */    /* 原nFAULT引脚检测实现已注释停用 */
    return 0;    /* 暂固定返回0表示无故障 */
}

/* 清除DRV8323RS故障锁存 */
void DRV8323RS_clearFaults(void)
{
    /* HAL_clearPWMFault(handle->nfault); */    /* 原nFAULT引脚清故障实现已注释停用 */
    /* 置位DRIVER_CONTROL寄存器的CLR_FLT位以清除故障锁存 */
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_DRIVER_CONTROL, 
                                DRV8323RS_DRIVER_CONTROL_CLR_FLT_MASK, 
                                (1 << DRV8323RS_DRIVER_CONTROL_CLR_FLT_OFS));
}
