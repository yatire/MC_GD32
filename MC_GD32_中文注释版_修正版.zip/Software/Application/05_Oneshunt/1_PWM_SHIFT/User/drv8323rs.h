/*
*******************************************************************************************************
*
* 文件名称 : drv8323rs.h
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 无感FOC电机控制库 DRV8323RS 电机驱动模块
*
*******************************************************************************************************
*/

/*
    版权所有 (c) 2023, 德州仪器(Texas Instruments Incorporated)

    在满足以下条件的前提下，允许以源代码和二进制形式对本软件进行再发布与使用(无论是否修改)：

    *  以源代码形式再发布时，必须保留上述版权声明、本条件列表及以下免责声明。

    *  以二进制形式再发布时，必须在随附的文档和/或其他分发材料中重现上述版权声明、
       本条件列表及以下免责声明。

    *  未经事先书面许可，不得使用德州仪器(Texas Instruments Incorporated)或其贡献者的名义
       为本软件的衍生产品进行背书或推广。

    本软件由版权持有人和贡献者"按原样"提供，不提供任何明示或默示的保证，包括但不限于对
    适销性和特定用途适用性的默示保证。在任何情况下，无论因何原因产生或基于何种责任理论，
    无论是合同责任、严格责任还是侵权责任(包括过失或其他)，版权持有人或贡献者均不对任何直接
    的、间接的、偶然的、特殊的、惩罚性的或后果性的损害(包括但不限于替代商品或服务的采购、
    使用、数据或利润损失、或业务中断)承担责任，即使已被告知可能发生此类损害。
*/

/*!****************************************************************************
 *  @file       drv8323rs.h
 *  @brief      无感FOC电机控制库 DRV8323RS 电机驱动模块
 *
 *
 *  @anchor drv8323rs_h
 *  # 概述
 *
 *  DRV8323RS 栅极驱动器的应用程序接口(API)
 *
 *  <hr>
 ******************************************************************************/
/** @defgroup MD_MODULE 电机驱动/DRV8323RS
 * @{
 */
#ifndef DRV8323RS_H    /* 头文件保护宏：防止头文件被重复包含 */
#define DRV8323RS_H    /* 定义头文件保护宏 */

#include "gd32f30x.h"    /* GD32F30x固件库主头文件(外设寄存器定义与库函数) */
#include <stdlib.h>    /* 标准库头文件 */
#include <stdbool.h>    /* 标准布尔类型头文件(bool/true/false) */

/* 包含IQmath定点数学库 */
/* #include <ti/iqmath/include/IQmathLib.h> */    /* IQmath库暂未使用，该包含已注释 */

#ifdef __cplusplus    /* 若按C++编译器编译 */
extern "C" {    /* 以C语言链接约定导出接口(避免C++名称修饰) */
#endif    /* __cplusplus条件编译结束 */

#define SPI_CS_GPIO_PORT         GPIOA    /* DRV8323RS片选(SPI_CS)引脚所在GPIO端口：GPIOA */
#define SPI_CS_GPIO_PIN          GPIO_PIN_4    /* DRV8323RS片选(SPI_CS)引脚：PA4 */
#define SPI_CS_GPIO_CLK          RCU_GPIOA    /* DRV8323RS片选(SPI_CS)引脚端口时钟 */

#define ENABLE_GPIO_PORT         GPIOB    /* DRV8323RS使能(ENABLE)引脚所在GPIO端口：GPIOB */
#define ENABLE_GPIO_PIN          GPIO_PIN_10    /* DRV8323RS使能(ENABLE)引脚：PB10 */
#define ENABLE_GPIO_CLK          RCU_GPIOB    /* DRV8323RS使能(ENABLE)引脚端口时钟 */

/*!
 * @brief DRV8323RS上电后等待SPI就绪所需的延时
 */
#define DRV8323RS_SPI_READY_DELAY_MS                    (1)

/*!
 * @brief 使能引脚拉低后进入休眠模式前所需的等待延时
 */
#define DRV8323RS_TURNOFF_DELAY_MS                      (1)

/*!
 * @brief 读取SPI寄存器时写入的哑数据(占位无效数据)
 */
#define DRV8323RS_SPI_DUMMY_DATA                        (0x00)

/*!
 * @brief 11位SPI数据的掩码
 */
#define DRV8323RS_SPI_DATA_MASK                        (0x7FF)

/*! @brief 定义状态寄存器1(Status1)中 VDS_LC 位(C相下管VDS过流监视)的偏移 */
#define DRV8323RS_FAULT_STATUS_1_VDS_LC_OFS             (0)

/*! @brief 定义状态寄存器1(Status1)中 VDS_HC 位(C相上管VDS过流监视)的偏移 */
#define DRV8323RS_FAULT_STATUS_1_VDS_HC_OFS             (1)

/*! @brief 定义状态寄存器1(Status1)中 VDS_LB 位(B相下管VDS过流监视)的偏移 */
#define DRV8323RS_FAULT_STATUS_1_VDS_LB_OFS             (2)

/*! @brief 定义状态寄存器1(Status1)中 VDS_HB 位(B相上管VDS过流监视)的偏移 */
#define DRV8323RS_FAULT_STATUS_1_VDS_HB_OFS             (3)

/*! @brief 定义状态寄存器1(Status1)中 VDS_LA 位(A相下管VDS过流监视)的偏移 */
#define DRV8323RS_FAULT_STATUS_1_VDS_LA_OFS             (4)

/*! @brief 定义状态寄存器1(Status1)中 VDS_HA 位(A相上管VDS过流监视)的偏移 */
#define DRV8323RS_FAULT_STATUS_1_VDS_HA_OFS             (5)

/*! @brief 定义状态寄存器1(Status1)中 OTSD 位(过热关断)的偏移 */
#define DRV8323RS_FAULT_STATUS_1_OTSD_OFS               (6)

/*! @brief 定义状态寄存器1(Status1)中 UVLO 位(欠压锁定)的偏移 */
#define DRV8323RS_FAULT_STATUS_1_UVLO_OFS               (7)

/*! @brief 定义状态寄存器1(Status1)中 GDF 位(栅极驱动故障)的偏移 */
#define DRV8323RS_FAULT_STATUS_1_GDF_OFS                (8)

/*! @brief 定义状态寄存器1(Status1)中 VDS_OCP 位(VDS过流保护)的偏移 */
#define DRV8323RS_FAULT_STATUS_1_VDS_OCP_OFS            (9)

/*! @brief 定义状态寄存器1(Status1)中 FAULT 位(总故障标志)的偏移 */
#define DRV8323RS_FAULT_STATUS_1_FAULT_OFS              (10)

/*! @brief 定义状态寄存器1(Status1)中 VDS_LC 位(C相下管VDS过流监视)的掩码 */
#define DRV8323RS_FAULT_STATUS_1_VDS_LC_MASK      \
                                    (1 << DRV8323RS_FAULT_STATUS_1_VDS_LC_OFS)

/*! @brief 定义状态寄存器1(Status1)中 VDS_HC 位(C相上管VDS过流监视)的掩码 */
#define DRV8323RS_FAULT_STATUS_1_VDS_HC_MASK      \
                                    (1 << DRV8323RS_FAULT_STATUS_1_VDS_HC_OFS)

/*! @brief 定义状态寄存器1(Status1)中 VDS_LB 位(B相下管VDS过流监视)的掩码 */
#define DRV8323RS_FAULT_STATUS_1_VDS_LB_MASK      \
                                    (1 << DRV8323RS_FAULT_STATUS_1_VDS_LB_OFS)

/*! @brief 定义状态寄存器1(Status1)中 VDS_HB 位(B相上管VDS过流监视)的掩码 */
#define DRV8323RS_FAULT_STATUS_1_VDS_HB_MASK      \
                                    (1 << DRV8323RS_FAULT_STATUS_1_VDS_HB_OFS)

/*! @brief 定义状态寄存器1(Status1)中 VDS_LA 位(A相下管VDS过流监视)的掩码 */
#define DRV8323RS_FAULT_STATUS_1_VDS_LA_MASK      \
                                    (1 << DRV8323RS_FAULT_STATUS_1_VDS_LA_OFS)

/*! @brief 定义状态寄存器1(Status1)中 VDS_HA 位(A相上管VDS过流监视)的掩码 */
#define DRV8323RS_FAULT_STATUS_1_VDS_HA_MASK      \
                                    (1 << DRV8323RS_FAULT_STATUS_1_VDS_HA_OFS)

/*! @brief 定义状态寄存器1(Status1)中 OTSD 位(过热关断)的掩码 */
#define DRV8323RS_FAULT_STATUS_1_OTSD_MASK        \
                                    (1 << DRV8323RS_FAULT_STATUS_1_OTSD_OFS)

/*! @brief 定义状态寄存器1(Status1)中 UVLO 位(欠压锁定)的掩码 */
#define DRV8323RS_FAULT_STATUS_1_UVLO_MASK        \
                                    (1 << DRV8323RS_FAULT_STATUS_1_UVLO_OFS)

/*! @brief 定义状态寄存器1(Status1)中 GDF 位(栅极驱动故障)的掩码 */
#define DRV8323RS_FAULT_STATUS_1_GDF_MASK         \
                                    (1 << DRV8323RS_FAULT_STATUS_1_GDF_OFS)

/*! @brief 定义状态寄存器1(Status1)中 VDS_OCP 位(VDS过流保护)的掩码 */
#define DRV8323RS_FAULT_STATUS_1_VDS_OCP_MASK     \
                                    (1 << DRV8323RS_FAULT_STATUS_1_VDS_OCP_OFS)

/*! @brief 定义状态寄存器1(Status1)中 FAULT 位(总故障标志)的掩码 */
#define DRV8323RS_FAULT_STATUS_1_FAULT_MASK       \
                                    (1 << DRV8323RS_FAULT_STATUS_1_FAULT_OFS)               

/*! @brief 定义状态寄存器2(Status2)中 VGS_LC 位(C相下管VGS栅极驱动故障)的偏移 */
#define DRV8323RS_FAULT_STATUS_2_VGS_LC_OFS               (0)

/*! @brief 定义状态寄存器2(Status2)中 VGS_HC 位(C相上管VGS栅极驱动故障)的偏移 */
#define DRV8323RS_FAULT_STATUS_2_VGS_HC_OFS               (1)

/*! @brief 定义状态寄存器2(Status2)中 VGS_LB 位(B相下管VGS栅极驱动故障)的偏移 */
#define DRV8323RS_FAULT_STATUS_2_VGS_LB_OFS               (2)

/*! @brief 定义状态寄存器2(Status2)中 VGS_HB 位(B相上管VGS栅极驱动故障)的偏移 */
#define DRV8323RS_FAULT_STATUS_2_VGS_HB_OFS               (3)

/*! @brief 定义状态寄存器2(Status2)中 VGS_LA 位(A相下管VGS栅极驱动故障)的偏移 */
#define DRV8323RS_FAULT_STATUS_2_VGS_LA_OFS               (4)

/*! @brief 定义状态寄存器2(Status2)中 VGS_HA 位(A相上管VGS栅极驱动故障)的偏移 */
#define DRV8323RS_FAULT_STATUS_2_VGS_HA_OFS               (5)

/**
 * @brief 定义状态寄存器2(Status2)中 CPUV(充电泵欠压)位的偏移
 */
#define DRV8323RS_FAULT_STATUS_2_CPUV_OFS                 (6)

/*! @brief 定义状态寄存器2(Status2)中 OTW 位(过温预警)的偏移 */
#define DRV8323RS_FAULT_STATUS_2_OTW_OFS                  (7)

/*! @brief 定义状态寄存器2(Status2)中 SC_OC 位(C相电流采样过流)的偏移 */
#define DRV8323RS_FAULT_STATUS_2_SC_OC_OFS                (8)

/*! @brief 定义状态寄存器2(Status2)中 SB_OC 位(B相过电流)的偏移 */
#define DRV8323RS_FAULT_STATUS_2_SB_OC_OFS                (9)

/*! @brief 定义状态寄存器2(Status2)中 SA_OC 位(A相过电流)的偏移 */
#define DRV8323RS_FAULT_STATUS_2_SA_OC_OFS                (10)

/*! @brief 定义状态寄存器2(Status2)中 VGS_LC 位(C相下管VGS栅极驱动故障)的掩码 */
#define DRV8323RS_FAULT_STATUS_2_VGS_LC_MASK        \
                                    (1 << DRV8323RS_FAULT_STATUS_2_VGS_LC_OFS)

/*! @brief 定义状态寄存器2(Status2)中 VGS_HC 位(C相上管VGS栅极驱动故障)的掩码 */
#define DRV8323RS_FAULT_STATUS_2_VGS_HC_MASK        \
                                    (1 << DRV8323RS_FAULT_STATUS_2_VGS_HC_OFS)

/*! @brief 定义状态寄存器2(Status2)中 VGS_LB 位(B相下管VGS栅极驱动故障)的掩码 */
#define DRV8323RS_FAULT_STATUS_2_VGS_LB_MASK        \
                                    (1 << DRV8323RS_FAULT_STATUS_2_VGS_LB_OFS)

/*! @brief 定义状态寄存器2(Status2)中 VGS_HB 位(B相上管VGS栅极驱动故障)的掩码 */
#define DRV8323RS_FAULT_STATUS_2_VGS_HB_MASK        \
                                    (1 << DRV8323RS_FAULT_STATUS_2_VGS_HB_OFS)

/*! @brief 定义状态寄存器2(Status2)中 VGS_LA 位(A相下管VGS栅极驱动故障)的掩码 */
#define DRV8323RS_FAULT_STATUS_2_VGS_LA_MASK        \
                                    (1 << DRV8323RS_FAULT_STATUS_2_VGS_LA_OFS)

/*! @brief 定义状态寄存器2(Status2)中 VGS_HA 位(A相上管VGS栅极驱动故障)的掩码 */
#define DRV8323RS_FAULT_STATUS_2_VGS_HA_MASK        \
                                    (1 << DRV8323RS_FAULT_STATUS_2_VGS_HA_OFS)

/**
 * @brief 定义状态寄存器2(Status2)中 CPUV(充电泵欠压)位的掩码
 */
#define DRV8323RS_FAULT_STATUS_2_CPUV_MASK          \
                                    (1 << DRV8323RS_FAULT_STATUS_2_CPUV_OFS)

/*! @brief 定义状态寄存器2(Status2)中 OTW 位(过温预警)的掩码 */
#define DRV8323RS_FAULT_STATUS_2_OTW_MASK           \
                                    (1 << DRV8323RS_FAULT_STATUS_2_OTW_OFS)

/*! @brief 定义状态寄存器2(Status2)中 SC_OC 位(C相电流采样过流)的掩码 */
#define DRV8323RS_FAULT_STATUS_2_SC_OC_MASK         \
                                    (1 << DRV8323RS_FAULT_STATUS_2_SC_OC_OFS)

/*! @brief 定义状态寄存器2(Status2)中 SB_OC 位(B相过电流)的掩码 */
#define DRV8323RS_FAULT_STATUS_2_SB_OC_MASK         \
                                    (1 << DRV8323RS_FAULT_STATUS_2_SB_OC_OFS)

/*! @brief 定义状态寄存器2(Status2)中 SA_OC 位(A相过电流)的掩码 */
#define DRV8323RS_FAULT_STATUS_2_SA_OC_MASK         \
                                    (1 << DRV8323RS_FAULT_STATUS_2_SA_OC_OFS)

/*! @brief 定义控制寄存器2(Control2)中 CLR_FLT 位(清除故障)的偏移 */
#define DRV8323RS_DRIVER_CONTROL_CLR_FLT_OFS            (0)

/*! @brief 定义控制寄存器2(Control2)中 BRAKE 位(刹车)的偏移 */
#define DRV8323RS_DRIVER_CONTROL_BRAKE_OFS              (1)

/*! @brief 定义控制寄存器2(Control2)中 COAST 位(滑行自由停车)的偏移 */
#define DRV8323RS_DRIVER_CONTROL_COAST_OFS              (2)

/*! @brief 定义控制寄存器2(Control2)中 1PWM_DIR 位(1PWM模式方向)的偏移 */
#define DRV8323RS_DRIVER_CONTROL_PWM1_DIR_OFS           (3)

/*! @brief 定义控制寄存器2(Control2)中 1PWM_COM 位(1PWM模式换相)的偏移 */
#define DRV8323RS_DRIVER_CONTROL_PWM1_COM_OFS           (4)

/*! @brief 定义控制寄存器2(Control2)中 PWM_MODE 位(PWM模式选择)的偏移 */
#define DRV8323RS_DRIVER_CONTROL_PWM_MODE_OFS           (5)

/*! @brief 定义控制寄存器2(Control2)中 OTW_REP 位(过温预警上报)的偏移 */
#define DRV8323RS_DRIVER_CONTROL_OTW_REP_OFS            (7)

/*! @brief 定义控制寄存器2(Control2)中 DIS_GDF 位(禁用栅极驱动故障)的偏移 */
#define DRV8323RS_DRIVER_CONTROL_DIS_GDF_OFS            (8)

/*! @brief 定义控制寄存器2(Control2)中 DIS_CPUV 位(禁用充电泵欠压)的偏移 */
#define DRV8323RS_DRIVER_CONTROL_DIS_CPUV_OFS           (9)

/*! @brief 定义控制寄存器2(Control2)中 RESERVED1 位(保留)的偏移 */
#define DRV8323RS_DRIVER_CONTROL_RESERVED1_OFS          (10)

/*! @brief 定义控制寄存器2(Control2)中 CLR_FLT 位(清除故障)的掩码 */
#define DRV8323RS_DRIVER_CONTROL_CLR_FLT_MASK     \
                                  (1 << DRV8323RS_DRIVER_CONTROL_CLR_FLT_OFS)

/*! @brief 定义控制寄存器2(Control2)中 BRAKE 位(刹车)的掩码 */
#define DRV8323RS_DRIVER_CONTROL_BRAKE_MASK       \
                                  (1 << DRV8323RS_DRIVER_CONTROL_BRAKE_OFS)

/*! @brief 定义控制寄存器2(Control2)中 COAST 位(滑行自由停车)的掩码 */
#define DRV8323RS_DRIVER_CONTROL_COAST_MASK       \
                                  (1 << DRV8323RS_DRIVER_CONTROL_COAST_OFS)

/*! @brief 定义控制寄存器2(Control2)中 1PWM_DIR 位(1PWM模式方向)的掩码 */
#define DRV8323RS_DRIVER_CONTROL_PWM1_DIR_MASK    \
                                  (1 << DRV8323RS_DRIVER_CONTROL_PWM1_DIR_OFS)

/*! @brief 定义控制寄存器2(Control2)中 1PWM_COM 位(1PWM模式换相)的掩码 */
#define DRV8323RS_DRIVER_CONTROL_PWM1_COM_MASK    \
                                  (1 << DRV8323RS_DRIVER_CONTROL_PWM1_COM_OFS)

/*! @brief 定义控制寄存器2(Control2)中 PWM_MODE 位(PWM模式选择)的掩码 */
#define DRV8323RS_DRIVER_CONTROL_PWM_MODE_MASK    \
                                  (3 << DRV8323RS_DRIVER_CONTROL_PWM_MODE_OFS)

/*! @brief 定义控制寄存器2(Control2)中 OTW_REP 位(过温预警上报)的掩码 */
#define DRV8323RS_DRIVER_CONTROL_OTW_REP_MASK     \
                                  (1 << DRV8323RS_DRIVER_CONTROL_OTW_REP_OFS)

/*! @brief 定义控制寄存器2(Control2)中 DIS_GDF 位(禁用栅极驱动故障)的掩码 */
#define DRV8323RS_DRIVER_CONTROL_DIS_GDF_MASK     \
                                  (1 << DRV8323RS_DRIVER_CONTROL_DIS_GDF_OFS)

/*! @brief 定义控制寄存器2(Control2)中 DIS_CPUV 位(禁用充电泵欠压)的掩码 */
#define DRV8323RS_DRIVER_CONTROL_DIS_CPUV_MASK    \
                                  (1 << DRV8323RS_DRIVER_CONTROL_DIS_CPUV_OFS)

/*! @brief 定义控制寄存器2(Control2)中 RESERVED1 位(保留)的掩码 */
#define DRV8323RS_DRIVER_CONTROL_RESERVED1_MASK   \
                                  (1 << DRV8323RS_DRIVER_CONTROL_RESERVED1_OFS)

/*! @brief 定义控制寄存器3(Control3)中 IDRIVEN_HS 位(高边管峰值灌电流设定)的偏移
 */
#define DRV8323RS_GATE_DRIVE_HS_IDRIVEN_HS_OFS          (0)

/*! @brief 定义控制寄存器3(Control3)中 IDRIVEP_HS 位(高边管峰值拉电流设定)的偏移
 */
#define DRV8323RS_GATE_DRIVE_HS_IDRIVEP_HS_OFS          (4)

/*! @brief 定义控制寄存器3(Control3)中 LOCK 位(SPI寄存器锁定设定)的偏移 */
#define DRV8323RS_GATE_DRIVE_HS_LOCK_OFS                (8)

/*! @brief 定义控制寄存器3(Control3)中 IDRIVEN_HS 位(高边管峰值灌电流设定)的掩码 */
#define DRV8323RS_GATE_DRIVE_HS_IDRIVEN_HS_MASK   \
                                  (15 << DRV8323RS_GATE_DRIVE_HS_IDRIVEN_HS_OFS)

/*! @brief 定义控制寄存器3(Control3)中 IDRIVEP_HS 位(高边管峰值拉电流设定)的掩码 */
#define DRV8323RS_GATE_DRIVE_HS_IDRIVEP_HS_MASK   \
                                  (15 << DRV8323RS_GATE_DRIVE_HS_IDRIVEP_HS_OFS)

/*! @brief 定义控制寄存器3(Control3)中 LOCK 位(SPI寄存器锁定设定)的掩码 */
#define DRV8323RS_GATE_DRIVE_HS_LOCK_MASK         \
                                  (7 << DRV8323RS_GATE_DRIVE_HS_LOCK_OFS)

/*! @brief 定义控制寄存器4(Control4)中 IDRIVEN_LS 位(低边管峰值灌电流设定)的偏移
 */
#define DRV8323RS_GATE_DRIVE_LS_IDRIVEN_LS_OFS          (0)

/*! @brief 定义控制寄存器4(Control4)中 IDRIVEP_LS 位(低边管峰值拉电流设定)的偏移
 */
#define DRV8323RS_GATE_DRIVE_LS_IDRIVEP_LS_OFS          (4)

/*! @brief 定义控制寄存器4(Control4)中 TDRIVE 位(栅极驱动峰值电流时间设定)的偏移 */
#define DRV8323RS_GATE_DRIVE_LS_TDRIVE_OFS              (8)

/*! @brief 定义控制寄存器4(Control4)中 CBC 位(逐周期限流使能)的偏移 */
#define DRV8323RS_GATE_DRIVE_LS_CBC_OFS                 (10)

/*! @brief 定义控制寄存器4(Control4)中 IDRIVEN_LS 位(低边管峰值灌电流设定)的掩码 */
#define DRV8323RS_GATE_DRIVE_LS_IDRIVEN_LS_MASK   \
                                  (15 << DRV8323RS_GATE_DRIVE_LS_IDRIVEN_LS_OFS)

/*! @brief 定义控制寄存器4(Control4)中 IDRIVEP_LS 位(低边管峰值拉电流设定)的掩码 */
#define DRV8323RS_GATE_DRIVE_LS_IDRIVEP_LS_MASK   \
                                  (15 << DRV8323RS_GATE_DRIVE_LS_IDRIVEP_LS_OFS)

/*! @brief 定义控制寄存器4(Control4)中 TDRIVE 位(栅极驱动峰值电流时间设定)的掩码 */
#define DRV8323RS_GATE_DRIVE_LS_TDRIVE_MASK       \
                                  (3 << DRV8323RS_GATE_DRIVE_LS_TDRIVE_OFS)

/*! @brief 定义控制寄存器4(Control4)中 CBC 位(逐周期限流使能)的掩码 */
#define DRV8323RS_GATE_DRIVE_LS_CBC_MASK          \
                                  (1 << DRV8323RS_GATE_DRIVE_LS_CBC_OFS)

/*! @brief 定义控制寄存器5(Control5)中 VDS_LVL 位(VDS过流监视阈值设定)的偏移 */
#define DRV8323RS_OCP_CONTROL_VDS_LVL_OFS               (0)

/*! @brief 定义控制寄存器5(Control5)中 OCP_DEG 位(过流消抖时间设定)的偏移 */
#define DRV8323RS_OCP_CONTROL_OCP_DEG_OFS               (4)

/*! @brief 定义控制寄存器5(Control5)中 OCP_MODE 位(过流处理模式设定)的偏移 */
#define DRV8323RS_OCP_CONTROL_OCP_MODE_OFS              (6)

/*! @brief 定义控制寄存器5(Control5)中 DEAD_TIME 位(死区时间设定)的偏移 */
#define DRV8323RS_OCP_CONTROL_DEAD_TIME_OFS             (8)

/*! @brief 定义控制寄存器5(Control5)中 TRETRY 位(过流重试时间设定)的偏移 */
#define DRV8323RS_OCP_CONTROL_TRETRY_OFS                (10)

/*! @brief 定义控制寄存器5(Control5)中 VDS_LVL 位(VDS过流监视阈值设定)的掩码 */
#define DRV8323RS_OCP_CONTROL_VDS_LVL_MASK        \
                                      (15 << DRV8323RS_OCP_CONTROL_VDS_LVL_OFS)

/*! @brief 定义控制寄存器5(Control5)中 OCP_DEG 位(过流消抖时间设定)的掩码 */
#define DRV8323RS_OCP_CONTROL_OCP_DEG_MASK        \
                                      (3 << DRV8323RS_OCP_CONTROL_OCP_DEG_OFS)

/*! @brief 定义控制寄存器5(Control5)中 OCP_MODE 位(过流处理模式设定)的掩码 */
#define DRV8323RS_OCP_CONTROL_OCP_MODE_MASK       \
                                      (3 << DRV8323RS_OCP_CONTROL_OCP_MODE_OFS)

/*! @brief 定义控制寄存器5(Control5)中 DEAD_TIME 位(死区时间设定)的掩码 */
#define DRV8323RS_OCP_CONTROL_DEAD_TIME_MASK      \
                                      (3 << DRV8323RS_OCP_CONTROL_DEAD_TIME_OFS)

/*! @brief 定义控制寄存器5(Control5)中 TRETRY 位(过流重试时间设定)的掩码 */
#define DRV8323RS_OCP_CONTROL_TRETRY_MASK         \
                                      (1 << DRV8323RS_OCP_CONTROL_TRETRY_OFS)

/*! @brief 定义控制寄存器6(Control6)中 SEN_LVL 位(电流检测过流阈值设定)的偏移 */
#define DRV8323RS_CSA_CONTROL_SEN_LVL_OFS               (0)

/*! @brief 定义控制寄存器6(Control6)中 CSA_CAL_C 位(C相电流放大器自校准)的偏移 */
#define DRV8323RS_CSA_CONTROL_CSA_CAL_C_OFS             (2)

/*! @brief 定义控制寄存器6(Control6)中 CSA_CAL_B 位(B相电流放大器自校准)的偏移 */
#define DRV8323RS_CSA_CONTROL_CSA_CAL_B_OFS             (3)

/*! @brief 定义控制寄存器6(Control6)中 CSA_CAL_A 位(A相电流放大器自校准)的偏移 */
#define DRV8323RS_CSA_CONTROL_CSA_CAL_A_OFS             (4)

/*! @brief 定义控制寄存器6(Control6)中 DIS_SEN 位(禁用电流检测过流保护)的偏移 */
#define DRV8323RS_CSA_CONTROL_DIS_SEN_OFS               (5)

/*! @brief 定义控制寄存器6(Control6)中 CSA_GAIN 位(电流检测放大器增益设定)的偏移 */
#define DRV8323RS_CSA_CONTROL_CSA_GAIN_OFS              (6)

/*! @brief 定义控制寄存器6(Control6)中 LS_REF 位(低边过流检测参考点选择)的偏移 */
#define DRV8323RS_CSA_CONTROL_LS_REF_OFS                (8)

/*! @brief 定义控制寄存器6(Control6)中 VREF_DIV 位(CSA参考电压分压选择)的偏移 */
#define DRV8323RS_CSA_CONTROL_VREF_DIV_OFS              (9)

/*! @brief 定义控制寄存器6(Control6)中 CSA_FET 位(CSA正相输入源选择)的偏移 */
#define DRV8323RS_CSA_CONTROL_CSA_FET_OFS               (10)

/*! @brief 定义控制寄存器6(Control6)中 SEN_LVL 位(电流检测过流阈值设定)的掩码 */
#define DRV8323RS_CSA_CONTROL_SEN_LVL_MASK        \
                                    (3 << DRV8323RS_CSA_CONTROL_SEN_LVL_OFS)

/*! @brief 定义控制寄存器6(Control6)中 CSA_CAL_C 位(C相电流放大器自校准)的掩码 */
#define DRV8323RS_CSA_CONTROL_CSA_CAL_C_MASK      \
                                    (1 << DRV8323RS_CSA_CONTROL_CSA_CAL_C_OFS)

/*! @brief 定义控制寄存器6(Control6)中 CSA_CAL_B 位(B相电流放大器自校准)的掩码 */
#define DRV8323RS_CSA_CONTROL_CSA_CAL_B_MASK      \
                                    (1 << DRV8323RS_CSA_CONTROL_CSA_CAL_B_OFS)

/*! @brief 定义控制寄存器6(Control6)中 CSA_CAL_A 位(A相电流放大器自校准)的掩码 */
#define DRV8323RS_CSA_CONTROL_CSA_CAL_A_MASK      \
                                    (1 << DRV8323RS_CSA_CONTROL_CSA_CAL_A_OFS)

/*! @brief 定义控制寄存器6(Control6)中 DIS_SEN 位(禁用电流检测过流保护)的掩码 */
#define DRV8323RS_CSA_CONTROL_DIS_SEN_MASK        \
                                    (1 << DRV8323RS_CSA_CONTROL_DIS_SEN_OFS)

/*! @brief 定义控制寄存器6(Control6)中 CSA_GAIN 位(电流检测放大器增益设定)的掩码 */
#define DRV8323RS_CSA_CONTROL_CSA_GAIN_MASK       \
                                    (3 << DRV8323RS_CSA_CONTROL_CSA_GAIN_OFS)

/*! @brief 定义控制寄存器6(Control6)中 LS_REF 位(低边过流检测参考点选择)的掩码 */
#define DRV8323RS_CSA_CONTROL_LS_REF_MASK         \
                                    (1 << DRV8323RS_CSA_CONTROL_LS_REF_OFS)

/*! @brief 定义控制寄存器6(Control6)中 VREF_DIV 位(CSA参考电压分压选择)的掩码 */
#define DRV8323RS_CSA_CONTROL_VREF_DIV_MASK       \
                                    (1 << DRV8323RS_CSA_CONTROL_VREF_DIV_OFS)

/*! @brief 定义控制寄存器6(Control6)中 CSA_FET 位(CSA正相输入源选择)的掩码 */
#define DRV8323RS_CSA_CONTROL_CSA_FET_MASK        \
                                    (1 << DRV8323RS_CSA_CONTROL_CSA_FET_OFS)

/*! @brief 定义SPI命令位的偏移 */
#define DRV8323RS_SPI_CMD_OFS             (15)

/*! @brief 定义SPI寄存器地址位的偏移 */
#define DRV8323RS_SPI_ADDR_OFS            (11)

/*! @brief 定义SPI寄存器地址位的掩码 */
#define DRV8323RS_SPI_ADDR_MASK           (0xF << DRV8323RS_SPI_ADDR_OFS)

/** @brief ADC电压到母线电压的换算系数
 * 该值为分压电阻比值 ((R1 + R2) / R2)，其中 R1 与 R2 组成分压电路，
 * 将母线电压缩放到ADC可采样的输入电压范围内
 * 详见 DRV8323RS 原理图以便理解
*/
#define DRV8323RS_DEFAULT_VOLT_R_DIVIDER  ((82+4.99)/4.99)

/*! @brief 母线电压(vm)的电压换算系数，IQ15定点格式 */
#define DRV8323RS_VOLTAGE_SF_IQ15        _IQ15(DRV8323RS_DEFAULT_VOLT_R_DIVIDER)

/*! @brief DRV可配置的电流检测放大器增益档位数量上限 */
#define DRV8323RS_CSA_GAIN_MAX_VALUES      (4)

/** @brief DRV内部的默认采样电阻(分流电阻)阻值 */
#define DRV8323RS_DEFAULT_R_SHUNT         (0.007f)

/** @brief DRV的默认死区(死区时间) */
#define DRV8323RS_DEFAULT_PWM_DEADBAND_NS (100)

/*!
 * @enum DRV8323RS_SPI_CMD
 * @brief SPI命令模式
 */
typedef enum {
    /*! SPI写命令 */
    DRV8323RS_SPI_CMD_WRITE = 0,
    /*! SPI读命令 */
    DRV8323RS_SPI_CMD_READ,
}DRV8323RS_SPI_CMD;    /* SPI命令模式(写/读)枚举类型 */

/*!
 * @enum DRV8323RS_GATE_DRIVE_HS_LOCK
 * @brief SPI寄存器锁定/解锁的枚举
 */
typedef enum {
    /*! 解锁值 */
    DRV8323RS_GATE_DRIVE_HS_LOCK_UNLOCK = 3,
    /*! 锁定值 */
    DRV8323RS_GATE_DRIVE_HS_LOCK_LOCK = 6
}DRV8323RS_GATE_DRIVE_HS_LOCK; /* SPI寄存器锁定/解锁枚举类型 */

/*!
 * @enum DRV8323RS_DRIVER_CONTROL_PWM_MODE
 * @brief 驱动器PWM模式的枚举
 */
typedef enum {
  /*! PWM_MODE值为6路输入 */
  DRV8323RS_DRIVER_CONTROL_PWM_MODE_6 = 0, 
  /*! PWM_MODE值为3路输入 */
  DRV8323RS_DRIVER_CONTROL_PWM_MODE_3, 
  /*! PWM_MODE值为1路输入 */
  DRV8323RS_DRIVER_CONTROL_PWM_MODE_1 
} DRV8323RS_DRIVER_CONTROL_PWM_MODE; /* 驱动器PWM模式枚举类型 */

/*!
 * @enum DRV8323RS_GATE_DRIVE_PEAK_CUR_TIME
 * @brief 峰值电流栅极驱动时间的枚举
 */
typedef enum {
  /*! TDRIVEN值为500ns */
  DRV8323RS_GATE_DRIVE_PEAK_CUR_TIME_500_NS =0,  
  /*! TDRIVEN值为1000ns */
  DRV8323RS_GATE_DRIVE_PEAK_CUR_TIME_1000_NS, 
  /*! TDRIVEN值为2000ns */
  DRV8323RS_GATE_DRIVE_PEAK_CUR_TIME_2000_NS, 
  /*! TDRIVEN值为4000ns */
  DRV8323RS_GATE_DRIVE_PEAK_CUR_TIME_4000_NS  
} DRV8323RS_GATE_DRIVE_PEAK_CUR_TIME; /* 峰值栅极驱动电流时间枚举类型 */

/*!
 * @enum DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR
 * @brief 低边管栅极驱动峰值拉电流(source)的枚举
 */
typedef enum {
  /*! IDRIVEP_LS值为0.010A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P010_A =0,  
  /*! IDRIVEP_LS值为0.030A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P030_A,  
  /*! IDRIVEP_LS值为0.060A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P060_A,  
  /*! IDRIVEP_LS值为0.080A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P080_A,  
  /*! IDRIVEP_LS值为0.120A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P120_A,  
  /*! IDRIVEP_LS值为0.140A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P140_A,  
  /*! IDRIVEP_LS值为0.170A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P170_A,  
  /*! IDRIVEP_LS值为0.190A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P190_A,  
  /*! IDRIVEP_LS值为0.260A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P260_A,  
  /*! IDRIVEP_LS值为0.330A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P330_A,  
  /*! IDRIVEP_LS值为0.370A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P370_A, 
  /*! IDRIVEP_LS值为0.440A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P440_A, 
  /*! IDRIVEP_LS值为0.570A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P570_A, 
  /*! IDRIVEP_LS值为0.680A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P680_A, 
  /*! IDRIVEP_LS值为0.820A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_0P820_A, 
  /*! IDRIVEP_LS值为1.000A */
  DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR_1P000_A, 
} DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR; /* 低边管峰值拉电流枚举类型 */

/*!
 * @enum DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR
 * @brief 低边管栅极驱动峰值灌电流(sink)的枚举
 */
typedef enum {
  /*! IDRIVEN_LS值为0.020A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_0P020_A = 0,  
  /*! IDRIVEN_LS值为0.060A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_0P060_A,  
  /*! IDRIVEN_LS值为0.120A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_0P120_A,  
  /*! IDRIVEN_LS值为0.160A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_0P160_A,  
  /*! IDRIVEN_LS值为0.240A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_0P240_A,  
  /*! IDRIVEN_LS值为0.280A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_0P280_A,  
  /*! IDRIVEN_LS值为0.340A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_0P340_A,  
  /*! IDRIVEN_LS值为0.380A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_0P380_A,  
  /*! IDRIVEN_LS值为0.520A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_0P520_A,  
  /*! IDRIVEN_LS值为0.660A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_0P660_A,  
  /*! IDRIVEN_LS值为0.740A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_0P740_A, 
  /*! IDRIVEN_LS值为0.880A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_0P880_A, 
  /*! IDRIVEN_LS值为1.140A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_1P140_A, 
  /*! IDRIVEN_LS值为1.360A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_1P360_A, 
  /*! IDRIVEN_LS值为1.640A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_1P640_A, 
  /*! IDRIVEN_LS值为2.000A */
  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR_2P000_A, 
} DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR; /* 低边管峰值灌电流枚举类型 */

/*!
 * @enum DRV8323RS_OCP_CONTROL_VDS_LVL
 * @brief VDS比较器过流阈值的枚举
 */
typedef enum {
  /*! VDS_LEVEL值为0.060V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_0P060_V = 0,  
  /*! VDS_LEVEL值为0.130V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_0P130_V,  
  /*! VDS_LEVEL值为0.200V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_0P200_V,  
  /*! VDS_LEVEL值为0.260V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_0P260_V,  
  /*! VDS_LEVEL值为0.310V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_0P310_V,  
  /*! VDS_LEVEL值为0.450V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_0P450_V,  
  /*! VDS_LEVEL值为0.530V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_0P530_V,  
  /*! VDS_LEVEL值为0.600V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_0P600_V,  
  /*! VDS_LEVEL值为0.680V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_0P680_V,  
  /*! VDS_LEVEL值为0.750V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_0P750_V,  
  /*! VDS_LEVEL值为0.940V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_0P940_V, 
  /*! VDS_LEVEL值为1.130V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_1P130_V, 
  /*! VDS_LEVEL值为1.300V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_1P300_V, 
  /*! VDS_LEVEL值为1.500V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_1P500_V, 
  /*! VDS_LEVEL值为1.700V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_1P700_V, 
  /*! VDS_LEVEL值为1.880V */
  DRV8323RS_OCP_CONTROL_VDS_LVL_1P880_V  
} DRV8323RS_OCP_CONTROL_VDS_LVL; /* VDS过流阈值枚举类型 */

/*!
 * @enum DRV8323RS_OCP_CONTROL_OCP_DEG
 * @brief 过流/VDS检测消抖时间的枚举
 */
typedef enum {
  /*! TVDS值为2us */
  DRV8323RS_OCP_CONTROL_OCP_DEG_2_US = 0, 
  /*! TVDS值为4us */
  DRV8323RS_OCP_CONTROL_OCP_DEG_4_US, 
  /*! TVDS值为6us */
  DRV8323RS_OCP_CONTROL_OCP_DEG_6_US, 
  /*! TVDS值为8us */
  DRV8323RS_OCP_CONTROL_OCP_DEG_8_US  
} DRV8323RS_OCP_CONTROL_OCP_DEG; /* 过流消抖时间枚举类型 */

/*!
 * @enum DRV8323RS_OCP_CONTROL_OCP_MODE
 * @brief 过流处理模式的枚举
 */
typedef enum {
  /*! OCP_MODE为锁存故障关断 */
  DRV8323RS_OCP_CONTROL_OCP_MODE_LATCHED_SHUTDOWN = 0, 
  /*! OCP_MODE为自动重试 */
  DRV8323RS_OCP_CONTROL_OCP_MODE_AUTOMATIC_RETRY,  
  /*! OCP_MODE为仅报告 */
  DRV8323RS_OCP_CONTROL_OCP_MODE_REPORT_ONLY,      
  /*! OCP_MODE为禁用过流保护 */
  DRV8323RS_OCP_CONTROL_OCP_MODE_DISABLE_OCP       
} DRV8323RS_OCP_CONTROL_OCP_MODE; /* 过流处理模式枚举类型 */

/*!
 * @enum DRV8323RS_OCP_CONTROL_DEADTIME
 * @brief 死区时间的枚举
 */
typedef enum {
  /*! DEAD_TIME值为50ns */
  DRV8323RS_OCP_CONTROL_DEADTIME_50_NS = 0,  
  /*! DEAD_TIME值为100ns */
  DRV8323RS_OCP_CONTROL_DEADTIME_100_NS, 
  /*! DEAD_TIME值为200ns */
  DRV8323RS_OCP_CONTROL_DEADTIME_200_NS, 
  /*! DEAD_TIME值为400ns */
  DRV8323RS_OCP_CONTROL_DEADTIME_400_NS  
} DRV8323RS_OCP_CONTROL_DEADTIME; /* 死区时间枚举类型 */

/*!
 * @enum DRV8323RS_OCP_CONTROL_TRETRY
 * @brief 重试时间的枚举
 */
typedef enum {
  /*! 重试时间值为4ms */
  DRV8323RS_OCP_CONTROL_TRETRY_4_MS = 0,
  /*! 重试时间值为50us */
  DRV8323RS_OCP_CONTROL_TRETRY_50_US,
} DRV8323RS_OCP_CONTROL_TRETRY; /* 过流重试时间枚举类型 */

/*!
 * @enum DRV8323RS_CSA_CONTROL_DIS_SEN
 * @brief 过流检测使能/禁用的枚举 */
typedef enum {
  /*! 过流故障使能 */
  DRV8323RS_CSA_CONTROL_DIS_SEN_ENABLE = 0,
  /*! 过流故障禁用 */
  DRV8323RS_CSA_CONTROL_DIS_SEN_DISABLE,
} DRV8323RS_CSA_CONTROL_DIS_SEN; /* 过流检测使能/禁用枚举类型 */

/*!
 * @enum DRV8323RS_CSA_CONTROL_SEN_LVL
 * @brief 电流检测过流(SEN OCP)阈值的枚举
 */
typedef enum {
  /*! SEN_LVL值为0.25V */
  DRV8323RS_CSA_CONTROL_SEN_LVL_0P25_V = 0, 
  /*! SEN_LVL值为0.50V */
  DRV8323RS_CSA_CONTROL_SEN_LVL_0P50_V, 
  /*! SEN_LVL值为0.75V */
  DRV8323RS_CSA_CONTROL_SEN_LVL_0P75_V, 
  /*! SEN_LVL值为1.00V */
  DRV8323RS_CSA_CONTROL_SEN_LVL_1P00_V  
} DRV8323RS_CSA_CONTROL_SEN_LVL; /* 电流检测过流阈值枚举类型 */

/*!
 * @enum DRV8323RS_CSA_CONTROL_CSA_GAIN
 * @brief 电流检测放大器(CSA)增益的枚举
 */
typedef enum {
  /*! GAIN_CSA值为5V/V */
  DRV8323RS_CSA_CONTROL_CSA_GAIN_5VPV = 0,
  /*! GAIN_CSA值为10V/V */
  DRV8323RS_CSA_CONTROL_CSA_GAIN_10VPV,
  /*! GAIN_CSA值为20V/V */
  DRV8323RS_CSA_CONTROL_CSA_GAIN_20VPV,
  /*! GAIN_CSA值为40V/V */
  DRV8323RS_CSA_CONTROL_CSA_GAIN_40VPV,
} DRV8323RS_CSA_CONTROL_CSA_GAIN; /* 电流检测放大器增益枚举类型 */

/*!
 * @enum DRV8323RS_CSA_CONTROL_CSA_FET
 * @brief CSA正相输入选择的枚举
 */
typedef enum {
  /*! 电流检测放大器正相输入为SPx */
  DRV8323RS_CSA_CONTROL_CSA_FET_IN_SPX = 0,  
  /*! 电流检测放大器正相输入为SHx */
  DRV8323RS_CSA_CONTROL_CSA_FET_IN_SHX,
} DRV8323RS_CSA_CONTROL_CSA_FET; /* CSA正相输入选择枚举类型 */

/*!
 * @enum DRV8323RS_CSA_CONTROL_LS_REF
 * @brief 低边过流检测参考点的枚举
 */
typedef enum {
  /*! 低边MOS管过流在SHx与SPx之间测量 */
  DRV8323RS_CSA_CONTROL_LS_REF_SH_SP = 0,  
  /*! 低边MOS管过流在SHx与SNx之间测量 */
  DRV8323RS_CSA_CONTROL_LS_REF_SH_SN,
} DRV8323RS_CSA_CONTROL_LS_REF; /* 低边过流检测参考点枚举类型 */

/*!
 * @enum DRV8323RS_CSA_CONTROL_VREF_DIV
 * @brief CSA参考电压选择的枚举
 */
typedef enum {
  /*! 电流检测放大器参考电压为VREF */
  DRV8323RS_CSA_CONTROL_VREF_DIV_1 = 0,  
  /*! 电流检测放大器参考电压为VREF/2 */
  DRV8323RS_CSA_CONTROL_VREF_DIV_2,
} DRV8323RS_CSA_CONTROL_VREF_DIV; /* CSA参考电压选择枚举类型 */

/*!
 * @enum DRV8323RS_REG_ADDR
 * @brief SPI寄存器地址的枚举
 */
typedef enum {
    /*! 故障状态寄存器1地址 */
    DRV8323RS_REG_ADDR_FAULT_STATUS_1 = 0,
    /*! 故障状态寄存器2地址 */
    DRV8323RS_REG_ADDR_FAULT_STATUS_2,
    /*! 驱动控制寄存器地址 */
    DRV8323RS_REG_ADDR_DRIVER_CONTROL,
    /*! 高边栅极驱动寄存器地址 */
    DRV8323RS_REG_ADDR_GATE_DRIVE_HS,
    /*! 低边栅极驱动寄存器地址 */
    DRV8323RS_REG_ADDR_GATE_DRIVE_LS,
    /*! 过流保护控制寄存器地址 */
    DRV8323RS_REG_ADDR_OCP_CONTROL,
    /*! 电流检测放大器控制寄存器地址 */
    DRV8323RS_REG_ADDR_CSA_CONTROL,
}DRV8323RS_REG_ADDR;    /* SPI寄存器地址枚举类型 */

/*! @brief 定义 DRV8323RS 结构体 */
typedef struct {
    /*! 从ADC读取电流的换算系数 */
/*    _iq15 iSf; */
    /*! 使能引脚所配置的GPIO。@ref HAL_GPIO_OUT_PIN */
    uint32_t enable_gpio_periph;
    uint32_t enable_gpio_pin;    /* 使能引脚的引脚号 */
    /*! 连接到nFAULT引脚的定时器故障输入。@ref HAL_PWM_FAULT */

    /*! SPI通道。@ref HAL_SPI_CHANNEL */

    /*! SPI片选。@ref HAL_SPI_CS */
    uint32_t cs_gpio_periph;
    uint32_t cs_gpio_pin;    /* 片选引脚的引脚号 */
    /*! 母线电压vm的ADC通道。@ref HAL_ADC_CHANNEL */
/*    HAL_ADC_CHANNEL vsenvm; */
    /*! A相电流的ADC通道。@ref HAL_ADC_CHANNEL */
/*    HAL_ADC_CHANNEL isena; */
    /*! B相电流的ADC通道。@ref HAL_ADC_CHANNEL */
/*    HAL_ADC_CHANNEL isenb; */
    /*! C相电流的ADC通道。@ref HAL_ADC_CHANNEL */
/*    HAL_ADC_CHANNEL isenc; */
} DRV8323RS_Instance;    /* DRV8323RS实例结构体类型 */

/* 外部声明drvGain增益表 */
extern int8_t drvGain[DRV8323RS_CSA_GAIN_MAX_VALUES];    /* DRV电流检测放大器各增益档位对应的增益值数组 */

/**
 * @brief     使能DRV8323RS
 * @param[in] handle    drv8323rs实例的指针
 */
void DRV8323RS_enable(void);

/**
 * @brief     禁用DRV8323RS
 * @param[in] handle    drv8323rs实例的指针
 */
void DRV8323RS_disable(void);

/**
 * @brief     初始化DRV8323RS对象
 * @param[in] handle    drv8323rs实例的指针
 */
void DRV8323RS_init(void);

/**
 * @brief     构造一个待通过SPI发送的数据字
 * @param[in] wrCmd    SPI读命令或写命令。@ref DRV8323RS_SPI_CMD 之一
 * @param[in] addr     SPI寄存器地址。@ref DRV8323RS_REG_ADDR 之一
 * @param[in] data     待写入SPI寄存器的数据。
 * @return    返回构造好的SPI数据字
 */
uint16_t DRV8323RS_createSPIDataWord(
               DRV8323RS_SPI_CMD wrCmd, DRV8323RS_REG_ADDR addr, uint16_t data);

/**
 * @brief     向SPI寄存器写入数据
 * @param[in] handle   drv8323rs实例的指针
 * @param[in] addr     SPI寄存器地址。@ref DRV8323RS_REG_ADDR 之一
 * @param[in] data     待写入SPI寄存器的数据。
 */
void DRV8323RS_spiWrite(DRV8323RS_REG_ADDR addr, uint16_t data);

/**
 * @brief     读取SPI寄存器中的数据
 * @param[in] handle   drv8323rs实例的指针
 * @param[in] addr     SPI寄存器地址。@ref DRV8323RS_REG_ADDR 之一
 * @return    返回SPI寄存器中的数据
 */
uint16_t DRV8323RS_spiRead(DRV8323RS_REG_ADDR addr);

/**
 * @brief     仅更新SPI寄存器中的某些位
 * @param[in] handle   drv8323rs实例的指针
 * @param[in] addr     SPI寄存器地址。@ref DRV8323RS_REG_ADDR 之一
 * @param[in] mask     待修改位的掩码
 * @param[in] data     待写入SPI寄存器的数据
 */
void DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR addr, uint32_t mask, uint16_t data);

/**
 * @brief     解锁或锁定DRV的SPI寄存器
 * @param[in] handle   drv8323rs实例的指针
 * @param[in] lock     锁定或解锁值。
 * @ref DRV8323RS_GATE_DRIVE_HS_LOCK 之一
 */
void DRV8323RS_setSPIRegisterLock(DRV8323RS_GATE_DRIVE_HS_LOCK lock);

/**
 * @brief     设置栅极峰值拉电流
 * @param[in] handle  drv8323rs实例的指针
 * @param[in] hsPeakCurr 高边管峰值拉电流。
 * @ref DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR 之一
 * @param[in] lsPeakCurr 低边管峰值拉电流。
 * @ref DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR 之一
 */
void DRV8323RS_setPeakSourceGateCurr(
                               DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR hsPeakCurr, 
                               DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR lsPeakCurr);

/**
 * @brief     设置栅极峰值灌电流
 * @param[in] handle  drv8323rs实例的指针
 * @param[in] hsPeakCurr 高边管峰值灌电流。
 * @ref DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR 之一
 * @param[in] lsPeakCurr 低边管峰值灌电流。
 * @ref DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR 之一
 */
void DRV8323RS_setPeakSinkGateCurr(
                                 DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR hsPeakCurr, 
                                 DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR lsPeakCurr);

/**
 * @brief     设置峰值电流栅极驱动时间
 * @param[in] handle  drv8323rs实例的指针
 * @param[in] tdrive  待设置的峰值栅极驱动电流时间。
 * @ref DRV8323RS_GATE_DRIVE_PEAK_CUR_TIME 之一
 */
void DRV8323RS_setPeakGateCurrTime(DRV8323RS_GATE_DRIVE_PEAK_CUR_TIME tdrive);   

/**
 * @brief     设置PWM模式
 * @param[in] handle  drv8323rs实例的指针
 * @param[in] pwmMode 待设置的PWM模式。
 * @ref DRV8323RS_DRIVER_CONTROL_PWM_MODE 之一
 */
void DRV8323RS_setPwmMode(DRV8323RS_DRIVER_CONTROL_PWM_MODE pwmMode);

/**
 * @brief     设置过流动作电压(VDS阈值)
 * @param[in] handle  drv8323rs实例的指针
 * @param[in] vdsLvl  待设置的过流电平。
 * @ref DRV8323RS_OCP_CONTROL_VDS_LVL 之一
 */
void DRV8323RS_setVdsLvl(DRV8323RS_OCP_CONTROL_VDS_LVL vdsLvl);

/**
 * @brief     设置过流消抖时间
 * @param[in] handle  drv8323rs实例的指针
 * @param[in] ocpDeg  待设置的过流消抖时间。
 * @ref DRV8323RS_OCP_CONTROL_OCP_DEG 之一
 */
void DRV8323RS_setOcpDeg(DRV8323RS_OCP_CONTROL_OCP_DEG ocpDeg);

/**
 * @brief     设置过流处理模式
 * @param[in] handle  drv8323rs实例的指针
 * @param[in] ocpMode 待设置的过流处理模式。
 * @ref DRV8323RS_OCP_CONTROL_OCP_MODE 之一
 */
void DRV8323RS_setOcpMode(DRV8323RS_OCP_CONTROL_OCP_MODE ocpMode);

/**
 * @brief     设置死区时间
 * @param[in] handle   drv8323rs实例的指针
 * @param[in] deadtime 待设置的死区时间。
 * @ref DRV8323RS_OCP_CONTROL_DEADTIME 之一
 */
void DRV8323RS_setDeadtime(DRV8323RS_OCP_CONTROL_DEADTIME deadtime);

/**
 * @brief     设置过流重试时间
 * @param[in] handle drv8323rs实例的指针
 * @param[in] tretry 待设置的重试时间。@ref DRV8323RS_OCP_CONTROL_TRETRY 之一
 */
void DRV8323RS_setTretry(DRV8323RS_OCP_CONTROL_TRETRY tretry);

/**
 * @brief     设置过流检测电平
 * @param[in] handle drv8323rs实例的指针
 * @param[in] senLvl 待设置的过流检测电平。
 * @ref DRV8323RS_CSA_CONTROL_SEN_LVL 之一
 */
void DRV8323RS_setSenLvl(DRV8323RS_CSA_CONTROL_SEN_LVL senLvl);

/**
 * @brief     使能或禁用过流检测
 * @param[in] handle drv8323rs实例的指针
 * @param[in] disSen 待设置的过流检测状态。
 * @ref DRV8323RS_CSA_CONTROL_DIS_SEN 之一
 */
void DRV8323RS_setDisSen(DRV8323RS_CSA_CONTROL_DIS_SEN disSen);

/**
 * @brief     设置电流检测放大器(CSA)增益
 * @param[in] handle  drv8323rs实例的指针
 * @param[in] csaGain 待设置的增益。@ref DRV8323RS_CSA_CONTROL_CSA_GAIN 之一
 */
void DRV8323RS_setCsaGain(DRV8323RS_CSA_CONTROL_CSA_GAIN csaGain);

/**
 * @brief     设置低边过流(OCP)参考点
 * @param[in] handle  drv8323rs实例的指针
 * @param[in] lsRef   待设置的参考点。
 * @ref DRV8323RS_CSA_CONTROL_LS_REF 之一
 */
void DRV8323RS_setLsRef(DRV8323RS_CSA_CONTROL_LS_REF lsRef);

/**
 * @brief     设置电流检测放大器的参考电压
 * @param[in] handle   drv8323rs实例的指针
 * @param[in] vrefDiv  待设置的参考电压。
 * @ref DRV8323RS_CSA_CONTROL_VREF_DIV 之一
 */
void DRV8323RS_setVrefDiv(DRV8323RS_CSA_CONTROL_VREF_DIV vrefDiv);

/**
 * @brief     设置电流检测放大器正相输入的参考点
 * @param[in] handle  drv8323rs实例的指针
 * @param[in] csaFet  待设置的参考点。
 * @ref DRV8323RS_CSA_CONTROL_CSA_FET 之一
 */
void DRV8323RS_setCsaFet(DRV8323RS_CSA_CONTROL_CSA_FET csaFet);

/**
 * @brief     从vsenvm ADC获取母线电压(vm)原始值
 * @param[in] handle    drv8323rs实例的指针
 * @return    返回读取到的ADC原始值
 */
__STATIC_INLINE uint16_t DRV8323RS_getVMRaw(void)
{
/*  return (HAL_getADCValue(handle->vsenvm)); */    /* TODO */
    return 0;    /* ADC读取暂未实现，占位返回0 */
}

/**
 * @brief     从isena ADC获取A相电流原始值
 * @param[in] handle    drv8323rs实例的指针
 * @return    返回读取到的ADC原始值
 */
__STATIC_INLINE uint16_t DRV8323RS_getIARaw(void)
{
/*  return (HAL_getADCValue(handle->isena)); */
    return 0;    /* ADC读取暂未实现，占位返回0 */
}

/**
 * @brief     从isenb ADC获取B相电流原始值
 * @param[in] handle    drv8323rs实例的指针
 * @return    返回读取到的ADC原始值
 */
__STATIC_INLINE uint16_t DRV8323RS_getIBRaw(void)
{
/*  return (HAL_getADCValue(handle->isenb)); */
    return 0;    /* ADC读取暂未实现，占位返回0 */
}

/**
 * @brief     从isenc ADC获取C相电流原始值
 * @param[in] handle    drv8323rs实例的指针
 * @return    返回读取到的ADC原始值
 */
__STATIC_INLINE uint16_t DRV8323RS_getICRaw(void)
{
/*  return (HAL_getADCValue(handle->isenc)); */
    return 0;    /* ADC读取暂未实现，占位返回0 */
}

/*
 * @brief     获取换算后的IA相电流
 * @param[in] handle    drv8323rs实例的指针
 * @return    返回IQ格式的换算后IA相电流
 *
 * 注：该接口未启用，函数声明已被注释
 */
/* _iq DRV8323RS_getIA(void); */

/*
 * @brief     获取换算后的IB相电流
 * @param[in] handle    drv8323rs实例的指针
 * @return    返回IQ格式的换算后IB相电流
 *
 * 注：该接口未启用，函数声明已被注释
 */
/* _iq DRV8323RS_getIB(void); */

/*
 * @brief     获取换算后的IC相电流
 * @param[in] handle    drv8323rs实例的指针
 * @return    返回IQ格式的换算后IC相电流
 *
 * 注：该接口未启用，函数声明已被注释
 */
/* _iq DRV8323RS_getIC(void); */

/*
 * @brief     获取换算后的母线电压VM
 * @param[in] handle    drv8323rs实例的指针
 * @return    返回IQ格式的换算后VM电压
 *
 * 注：该接口未启用，函数声明已被注释
 */
/* _iq DRV8323RS_getVM(void); */

/**
 * @brief     设置相电流换算系数
 * @param[in] handle drv8323rs实例的指针
 * @param[in] gain   电流检测放大器的增益
 * @param[in] rshunt 采样电阻值(iq15格式)
 */
/* void DRV8323RS_setISf(DRV8323RS_CSA_CONTROL_CSA_GAIN  gain, _iq15 rshunt); */

/**
 * @brief     检查是否发生故障
 * @param[in] handle    drv8323rs实例的指针
 * @return    返回故障状态
 */
bool DRV8323RS_isFaultOccurred(void);

/**
 * @brief     清除定时器和SPI寄存器中的故障状态
 * @param[in] handle    drv8323rs实例的指针
 */
void DRV8323RS_clearFaults(void);

#ifdef __cplusplus    /* 若按C++编译器编译 */
}    /* 结束extern "C"块 */
#endif    /* __cplusplus条件编译结束 */
#endif /* DRV8323RS_H */
/** @}*/
