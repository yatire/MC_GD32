/*
*******************************************************************************************************
*
* 文件名称 : main.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 主函数文件(单电阻采样-PWM移相方案验证例程)
* 
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "gd32f30x.h"        /* GD32F30x芯片外设寄存器与固件库头文件 */
#include "gd32f30x_libopt.h" /* GD32F30x固件库外设包含配置头文件 */
#include "motor_hardware.h"  /* 电机硬件接口配置头文件(PWM/ADC/IO) */
#include "led.h"             /* LED驱动头文件 */
#include "uart.h"            /* 串口驱动头文件 */
#include "drv8323rs.h"       /* DRV8323RS栅极驱动器SPI驱动头文件 */
#include "motor_config.h"    /* 电机参数配置头文件(PWM周期/采样系数) */
#include "systick.h"         /* 滴答定时器配置头文件(系统节拍/延时) */
#include <string.h>          /* C字符串/内存操作库(memcpy等) */

/* 宏定义 ------------------------------------------------------------------------------------------*/

/* 变量定义 ----------------------------------------------------------------------------------------*/
uint32_t duty_u_ref = 0,duty_v_ref = 0,duty_w_ref = 0;        /* 三相参考占空比(不移相的基准值) */
uint32_t duty_u = 0,duty_v = 0,duty_w = 0;                    /* 三相当前占空比(写入比较寄存器的值) */
int32_t duty_u_offset = 0,duty_v_offset = 0,duty_w_offset = 0;    /* 三相移相量(正为右移,负为左移) */
float temp1 = 0,temp2 = 0,temp3 = 0;                          /* 串口上传用临时浮点变量 */
uint8_t uart_data[16] = {0};                                  /* 串口发送数据缓冲区(16字节) */
/* 函数定义 -----------------------------------------------------------------------------------------*/


/**
  * @brief 主函数
  * @param 无
  * @retval 无
  */
int main(void)
{
    SCB->VTOR = FLASH_BASE | 0x4000;    /* 设置中断向量表到APP区基址(偏移0x4000,由Bootloader引导) */
    __enable_irq();                     /* 使能全局中断 */
    
    systick_init();                     /* 初始化滴答定时器(1ms系统节拍) */
    led_init();                         /* 初始化LED指示灯 */
    usart_init();                       /* 初始化调试串口 */
    led_off(LED1);                      /* 熄灭LED1 */
    led_off(LED2);                      /* 熄灭LED2 */
    led_off(LED3);                      /* 熄灭LED3 */
    DRV8323RS_init();                   /* 初始化DRV8323RS栅极驱动器(SPI寄存器配置/CSA校准) */
    
    motor_hardware_init();              /* 初始化电机硬件(PWM/ADC注入组/驱动使能) */
    
    rcu_periph_clock_enable(USER_IO1_CLK);    /* 使能USER_IO1端口时钟 */
    rcu_periph_clock_enable(USER_IO2_CLK);    /* 使能USER_IO2端口时钟 */
    rcu_periph_clock_enable(USER_IO3_CLK);    /* 使能USER_IO3端口时钟 */
    gpio_pin_remap_config(GPIO_SWJ_SWDPENABLE_REMAP, ENABLE);    /* SWJ重映射:仅保留SWD,释放JTAG引脚作普通IO */
    
    gpio_init(USER_IO1_PORT, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ,USER_IO1_PIN);    /* USER_IO1推挽输出,50MHz */
    gpio_init(USER_IO2_PORT, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ,USER_IO2_PIN);    /* USER_IO2推挽输出,50MHz */
    gpio_init(USER_IO3_PORT, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ,USER_IO3_PIN);    /* USER_IO3推挽输出,50MHz */
    
    gpio_bit_write(USER_IO1_PORT,USER_IO1_PIN,RESET);    /* USER_IO1输出低电平 */
    gpio_bit_write(USER_IO2_PORT,USER_IO2_PIN,RESET);    /* USER_IO2输出低电平 */
    gpio_bit_write(USER_IO3_PORT,USER_IO3_PIN,RESET);    /* USER_IO3输出低电平 */

    /* 初始化占空比 */
    duty_u_ref = (float)MOTOR_PWM_PERIOD / 3;          /* 33% */
    duty_v_ref = (float)MOTOR_PWM_PERIOD / 2;          /* 50% */
    duty_w_ref = ((float)MOTOR_PWM_PERIOD * 2) / 3;    /* 66% */
    
        while(1)    /* 主循环:仅闪烁系统LED,占空比更新在中断中完成 */
	{
        led_toggle(LED_SYS);            /* 翻转系统LED,指示程序存活 */
        systick_delay(500);             /* 延时500ms */
	}
}


/**
  * @brief TIMER0更新中断服务函数(上溢/下溢均触发)
  * @note  仅在上溢时翻转USER_IO3,供示波器测量PWM周期
  * @param 无
  * @retval 无
  */
void TIMER0_UP_IRQHandler(void)
{
    timer_interrupt_flag_clear(TIMER0,TIMER_INT_FLAG_UP);    /* 清除更新中断标志 */
    if(timer_counter_read(TIMER0) > MOTOR_PWM_PERIOD / 2)    /* 计数值大于半周期:本次为向上溢出 */
    {
        /* 上溢和下溢都会触发UP中断,只有在计数值向上溢出的时候才需要翻转GPIO */
        /* 翻转USER_IO3电平(翻转点即上溢时刻,供示波器观测) */
        gpio_bit_write(USER_IO3_PORT,USER_IO3_PIN,(bit_status)(1-gpio_input_bit_get(USER_IO3_PORT,USER_IO3_PIN)));
    }
}

/**
  * @brief TIMER0刹车中断服务函数(硬件故障保护时触发)
  * @param 无
  * @retval 无
  */
void TIMER0_BRK_IRQHandler(void)
{
    timer_channel_output_mode_config(TIMER0,TIMER_CH_0,TIMER_OC_MODE_INACTIVE);    /* 将W相通道(CH0)置为匹配时无效电平,封锁PWM */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_1,TIMER_OC_MODE_INACTIVE);    /* 将V相通道(CH1)置为匹配时无效电平,封锁PWM */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_2,TIMER_OC_MODE_INACTIVE);    /* 将U相通道(CH2)置为匹配时无效电平,封锁PWM */
/*    timer_primary_output_config(TIMER0,DISABLE);    (备选做法:直接关闭主输出,已注释停用) */
    /* 清除定时器中断标志 */
    timer_interrupt_flag_clear(TIMER0,TIMER_INT_FLAG_BRK);    /* 清除刹车中断标志 */
    timer_disable(TIMER0);              /* 停止TIMER0计数 */
    timer_disable(TIMER1);              /* 停止TIMER1计数 */
    
    led_on(LED_FAULT);                  /* 点亮故障指示LED */
}

/**
  * @brief TIMER0通道中断服务函数(CH3比较匹配触发,单电阻采样时序核心)
  * @note  在PWM周期中点前后分两次更新比较值,实现左右半周期移相
  * @param 无
  * @retval 无
  */
void TIMER0_Channel_IRQHandler(void)
{
    timer_interrupt_flag_clear(TIMER0,TIMER_INT_FLAG_CH3);    /* 清除通道3比较中断标志 */
    
    /* 先更新上一个周期的PWM 在计数器到0的时候会自动更新 */
    timer_channel_output_pulse_value_config(TIMER0,TIMER_CH_0,duty_u);    /* 写入U相左半侧占空比(计数到0时装载) */
    timer_channel_output_pulse_value_config(TIMER0,TIMER_CH_1,duty_v);    /* 写入V相左半侧占空比(计数到0时装载) */
    timer_channel_output_pulse_value_config(TIMER0,TIMER_CH_2,duty_w);    /* 写入W相左半侧占空比(计数到0时装载) */

    /* 单电阻电流重构 */
    /* 这里暂时不进行电流重构,只需要验证PWM移相 */
    
    /* FOC运算 */
    /* 这里不需要FOC运算,但是还是需要运行跟FOC计算差不多时间的函数,否则时序无法对应 */
    /* 实际的代码请不要加while等待 */
    while(timer_counter_read(TIMER0) <= 300);    /* 空等待模拟FOC运算耗时,保证与实际算法时序一致 */
    
    /* 更新上一个周期的PWM移相后的值 这个函数在计数器到最大值之前执行 在计数器到最大值的时候自动更新PWM */
    /* 下面代码计算的是右半侧PWM占空比寄存器的值 */
    duty_u = duty_u - duty_u_offset - duty_u_offset;    /* 由左半侧值推算U相右半侧占空比(减2倍移相量) */
    duty_v = duty_v - duty_v_offset - duty_v_offset;    /* 由左半侧值推算V相右半侧占空比(减2倍移相量) */
    duty_w = duty_w - duty_w_offset - duty_w_offset;    /* 由左半侧值推算W相右半侧占空比(减2倍移相量) */
    timer_channel_output_pulse_value_config(TIMER0,TIMER_CH_0,duty_u);    /* 写入U相右半侧占空比(计数到最大值时装载) */
    timer_channel_output_pulse_value_config(TIMER0,TIMER_CH_1,duty_v);    /* 写入V相右半侧占空比(计数到最大值时装载) */
    timer_channel_output_pulse_value_config(TIMER0,TIMER_CH_2,duty_w);    /* 写入W相右半侧占空比(计数到最大值时装载) */

    /* 移相计算 */
    /* U相向左移动10% offset < 0 */
    /* V相不移动 */
    /* W相向右移动10% offset > 0 */
    duty_u_offset = -((float)MOTOR_PWM_PERIOD / 10);    /* U相移相量:-1/10周期(向左移) */
    duty_v_offset = 0;                  /* V相不移相 */
    duty_w_offset = (float)MOTOR_PWM_PERIOD / 10;    /* W相移相量:+1/10周期(向右移) */
/* 备选方案:三相均不移相(验证基准时序),已注释停用 */
/*    duty_u_offset = 0; */
/*    duty_v_offset = 0; */
/*    duty_w_offset = 0; */
    
    /* 下面代码计算的是左半侧PWM占空比寄存器的值 */
    duty_u = duty_u_ref + duty_u_offset;    /* 计算U相左半侧占空比 = 参考值 + 移相量 */
    duty_v = duty_v_ref + duty_v_offset;    /* 计算V相左半侧占空比 = 参考值 + 移相量 */
    duty_w = duty_w_ref + duty_w_offset;    /* 计算W相左半侧占空比 = 参考值 + 移相量 */
    
    temp1 = (float)duty_u;              /* U相左半侧占空比装入上传缓冲区 */
    memcpy(&uart_data[0],&temp1,4);     /* 第1个数据填入发送缓冲区 */
    temp2 = (float)duty_u_offset;       /* U相移相量装入上传缓冲区 */
    memcpy(&uart_data[4],&temp2,4);     /* 第2个数据填入发送缓冲区 */
    temp3 = (float)duty_w;              /* W相左半侧占空比装入上传缓冲区 */
    memcpy(&uart_data[8],&temp3,4);     /* 第3个数据填入发送缓冲区 */
    uart_data[sizeof(uart_data)-2] = 0x80;      /* 填写帧尾标志字节1 */
    uart_data[sizeof(uart_data)-1] = 0x7f;      /* 填写帧尾标志字节2 */
    usart_send_data(uart_data,sizeof(uart_data));    /* 串口发送16字节数据帧(供上位机绘图) */
}


/***************************************** 文件结束 *********************************************/
