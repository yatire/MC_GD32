/*
*******************************************************************************************************
*
* 文件名称 : motor_config.h
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 电机参数配置头文件
*
*******************************************************************************************************
*/
#ifndef _MOTOR_CONFIG_H_                             /* 防止头文件重复包含的条件编译 */
#define _MOTOR_CONFIG_H_                             /* 头文件包含保护宏 */

#ifdef __cplusplus                                   /* C++兼容条件编译 */
extern "C"{                                          /* C++编译环境下使用C语言链接 */
#endif                                               /* 结束__cplusplus条件编译 */

/* 头文件包含 ------------------------------------------------------------------------------------*/



/* 宏定义 ------------------------------------------------------------------------------------------*/
#define ADC_FULLSCALE_VOLT              (float)3.3   /* ADC满量程参考电压（伏特） */
#define ADC_FULL_BIT                    (1<<12)      /* ADC满量程码值（12位ADC = 4096） */
#define SHUNT_RES                       (float)0.005 /* 电流采样电阻阻值（欧姆，5毫欧） */
#define SHUNT_OPA_GAIN                  (float)20    /* 相电流采样运放放大倍数（20倍） */
#define ONE_SHUNT_OPA_GAIN              (float)8     /* 单电阻采样运放放大倍数（8倍） */

#define VDC_SERIES_RES                  (float)100000    /* 母线电压采样分压串联电阻（欧姆，100k） */
#define VDC_PARALLEL_RES                (float)5100      /* 母线电压采样分压并联电阻（欧姆，5.1k） */

/* ADC码值到相电流的换算系数（安培/码值） */
#define ADC_TO_CURRENT_COEF             (float)(ADC_FULLSCALE_VOLT/ADC_FULL_BIT/SHUNT_RES/SHUNT_OPA_GAIN)
/* ADC码值到母线电压的换算系数（伏特/码值，含分压比还原） */
#define ADC_TO_VDC_COEF                 (float)((VDC_SERIES_RES+VDC_PARALLEL_RES)/VDC_PARALLEL_RES*ADC_FULLSCALE_VOLT/ADC_FULL_BIT)

#define PHASE_OVER_CURRENT_AMP          (float)15    /* 相电流过流保护阈值（安培） */
/* 过流保护比较器DAC阈值（ADC码值，由过流电流阈值经采样电阻和运放增益换算） */
#define PHASE_OVER_CURRENT_DAC_VAULE    (float)(2048.0f + PHASE_OVER_CURRENT_AMP*SHUNT_RES*SHUNT_OPA_GAIN*ADC_FULL_BIT/ADC_FULLSCALE_VOLT)

#define SYSTEM_CORE_CLOCK               120000000    /* 系统主频（赫兹，120MHz） */
#define PWM_PRESCALER                   0            /* 定时器预分频系数（0=不分频） */
#define MOTOR_PWM_FREQ_HZ               16000        /* 电机PWM频率（赫兹，16kHz） */
/* PWM周期计数值（120MHz/16kHz/2-1 = 3749，对应中央对齐计数模式） */
#define MOTOR_PWM_PERIOD                ((SYSTEM_CORE_CLOCK/(PWM_PRESCALER+1)/MOTOR_PWM_FREQ_HZ/2)-1)

#define HALL_TIMER_PRESCALER            119          /* 霍尔定时器预分频系数（120MHz/120 = 1MHz） */
#define HALL_TIMER_FREQ_HZ              (SYSTEM_CORE_CLOCK/(HALL_TIMER_PRESCALER+1))   /* 霍尔定时器计数频率（赫兹，1MHz） */

/* 变量定义 ----------------------------------------------------------------------------------------*/


/* 函数定义 -----------------------------------------------------------------------------------------*/


#ifdef __cplusplus                                   /* C++兼容条件编译 */
extern "C"{                                          /* C++编译环境下使用C语言链接 */
#endif                                               /* 结束__cplusplus条件编译 */

#endif /* _MOTOR_CONFIG_H_ */

/***************************************** 文件结束 *********************************************/
