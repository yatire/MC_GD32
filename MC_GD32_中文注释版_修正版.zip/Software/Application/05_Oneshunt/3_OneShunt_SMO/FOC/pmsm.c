/*
*******************************************************************************************************
*
* 文件名称 : pmsm.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : PMSM(永磁同步电机)FOC驱动文件
*
*******************************************************************************************************
*/


/* 头文件包含 ----------------------------------------------------------------------------------------*/
#include "pmsm.h"               /* PMSM电机控制结构体与对外接口定义 */
#include "foc.h"                /* FOC核心算法接口(Clark/Park/反Park/SVPWM/PI) */
#include "smcpos.h"             /* 滑模观测器(SMO/SMC)位置估算接口 */
#include "userparms.h"          /* 用户参数配置(PI参数/电机参数/开环启动参数) */
#include "motor_hardware.h"     /* 电机硬件层定义(PWM定时器/通道/PWM频率) */
/* 宏定义 ------------------------------------------------------------------------------------------*/


/* 变量定义 ----------------------------------------------------------------------------------------*/
pmsm_foc_t pmsm_foc_param;      /* FOC算法运行参数(坐标变量/PI调节器/电压指令等) */
pmsm_mc_t pmsm_mc_param;        /* 电机控制状态参数(运行标志/开闭环/速度给定等) */
smc_t smc1;                     /* 滑模观测器运行状态(估算电流/反电动势/滑模控制量/角度/速度) */

float theta_error = 0;              /* 开环切闭环时记录的角度误差偏置(弧度) */
float iq_error = 0;                 /* q轴电流误差记录变量 */
uint32_t iq_error_count = 0;        /* q轴电流误差计数器 */

/* 函数定义 -----------------------------------------------------------------------------------------*/
static void pmsm_foc_init_control_parameters(void);    /* FOC控制参数(PI参数)初始化 */
static void calculate_park_angle(void);                /* Park变换角度计算(开环启动/切闭环处理) */
static void pid_control(void);                         /* 电流环与速度环PI控制 */

/**
  * @brief PMSM FOC初始化(初始化PI参数/开环启动参数/滑模观测器)
  * @param 无
  * @retval 无
  * @note
  */
void pmsm_foc_init(void)
{
	/* 滑模观测器(SMC)初始化 */
	
	pmsm_foc_init_control_parameters();    /* 初始化d/q轴电流环与速度环PI参数 */
	
	pmsm_mc_param.run_motor = 1;           /* 置电机运行标志 */
	pmsm_mc_param.openloop = 1;            /* 上电先进入开环启动模式 */
	pmsm_mc_param.change_mode = 1;         /* 置控制模式切换标志 */
	pmsm_mc_param.startup_lock_count = 0;  /* 转子预定位计数器清零 */
	pmsm_mc_param.startup_ramp = 0;        /* 开环角度斜坡增量清零 */
    
    pmsm_mc_param.vel_input = NOMINAL_SPEED_RAD_PER_SEC_ELEC;    /* 速度给定=额定电角速度 */
    
    smc_init_parameters(&smc1);    /* 初始化滑模观测器参数(电机参数/增益/滤波系数) */
}

/**
  * @brief FOC循环执行函数(在PWM/ADC中断中按PWM周期调用)
  * @param 无
  * @retval 无
  * @note
  */
void pmsm_foc_run(void)
{
    if(pmsm_mc_param.run_motor)    /* 电机运行标志有效:执行FOC算法 */
    {
        clark(&pmsm_foc_param);    /* Clark变换:三相电流→αβ两相静止坐标系 */
        park(&pmsm_foc_param);     /* Park变换:αβ→dq两相旋转坐标系 */
        
        smc1.ialpha = pmsm_foc_param.ialpha;    /* 送入α轴电流 */
        smc1.ibeta = pmsm_foc_param.ibeta;      /* 送入β轴电流 */
        smc1.valpha = pmsm_foc_param.valpha * pmsm_mc_param.max_phase_voltage;    /* α轴电压(标幺值×最大相电压=实际电压) */
        smc1.vbeta = pmsm_foc_param.vbeta * pmsm_mc_param.max_phase_voltage;      /* β轴电压(标幺值×最大相电压=实际电压) */
        smc_position_estimation(&smc1);    /* 滑模观测器解算:估算转子电角度与速度 */
        pmsm_mc_param.actual_speed = smc1.omega_fltred;    /* 取观测器滤波后电角速度作为实际转速 */
        
        calculate_park_angle();    /* 计算Park变换角度(含开环启动与切闭环处理) */
        
        pid_control();    /* 电流环/速度环PI运算,得到vd/vq电压给定 */
        
        sin_cos(&pmsm_foc_param);    /* 计算当前电角度的正弦/余弦值 */
        
        inv_park(&pmsm_foc_param);    /* 反Park变换:dq电压→αβ静止坐标系 */
        
        svpwm(&pmsm_foc_param);    /* SVPWM空间矢量调制:更新三相PWM占空比 */
    }
    else
    {
        /* 禁止U相上管PWM输出 */
        timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_U_CHANNEL,TIMER_CCX_DISABLE);
        /* 禁止V相上管PWM输出 */
        timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_V_CHANNEL,TIMER_CCX_DISABLE);
        /* 禁止W相上管PWM输出 */
        timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_W_CHANNEL,TIMER_CCX_DISABLE);
        /* 禁止U相下管互补PWM输出 */
        timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_U_CHANNEL,TIMER_CCXN_DISABLE);
        /* 禁止V相下管互补PWM输出 */
        timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_V_CHANNEL,TIMER_CCXN_DISABLE);
        /* 禁止W相下管互补PWM输出 */
        timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_W_CHANNEL,TIMER_CCXN_DISABLE);
    }
}

/* 局部函数 -----------------------------------------------------------------------------------*/
/**
  * @brief 控制参数初始化(d/q轴电流环与速度环PI参数)
  * @param 无
  * @retval 无
  * @note
  */
static void pmsm_foc_init_control_parameters(void)
{
	pmsm_foc_param.pi_d.kp = DKP;          /* d轴电流环PI:比例系数 */
	pmsm_foc_param.pi_d.ki = DKI;          /* d轴电流环PI:积分系数 */
	pmsm_foc_param.pi_d.kc = DKC;          /* d轴电流环PI:积分抗饱和回授系数 */
	pmsm_foc_param.pi_d.out_max = DOUTMAX; /* d轴PI输出限幅(vd最大值) */
	pmsm_foc_param.pi_d.out_min = -pmsm_foc_param.pi_d.out_max;    /* d轴PI输出下限(负对称) */

	init_pi(&pmsm_foc_param.pi_d);    /* 初始化d轴PI(积分器与输出清零) */

	pmsm_foc_param.pi_q.kp = QKP;          /* q轴电流环PI:比例系数 */
	pmsm_foc_param.pi_q.ki = QKI;          /* q轴电流环PI:积分系数 */
	pmsm_foc_param.pi_q.kc = QKC;          /* q轴电流环PI:积分抗饱和回授系数 */
	pmsm_foc_param.pi_q.out_max = QOUTMAX; /* q轴PI输出限幅(vq最大值) */
	pmsm_foc_param.pi_q.out_min = -pmsm_foc_param.pi_q.out_max;    /* q轴PI输出下限(负对称) */

	init_pi(&pmsm_foc_param.pi_q);    /* 初始化q轴PI(积分器与输出清零) */
    
	pmsm_foc_param.pi_w.kp = WKP;          /* 速度环PI:比例系数 */
	pmsm_foc_param.pi_w.ki = WKI;          /* 速度环PI:积分系数 */
	pmsm_foc_param.pi_w.kc = WKC;          /* 速度环PI:积分抗饱和回授系数 */
	pmsm_foc_param.pi_w.out_max = WOUTMAX; /* 速度环PI输出限幅(iq给定最大值) */
	pmsm_foc_param.pi_w.out_min = -pmsm_foc_param.pi_w.out_max;    /* 速度环PI输出下限(负对称) */
	
	init_pi(&pmsm_foc_param.pi_w);    /* 初始化速度环PI(积分器与输出清零) */
}


/**
  * @brief 角度计算(开环启动/开环切闭环/闭环角度处理)
  * @param 无
  * @retval 无
  * @note
  */
static void calculate_park_angle(void)
{
	if(pmsm_mc_param.openloop)    /* 开环启动阶段:角度由斜坡积分生成 */
	{
		/* 从预定位锁定序列开始,进行转子磁场对齐 */
		if(pmsm_mc_param.startup_lock_count < LOCK_COUNTER)    /* 预定位时间未到 */
		{
			pmsm_mc_param.startup_lock_count++;    /* 预定位计数累加 */
		}
		else if(pmsm_mc_param.startup_ramp < END_SPEED_RADS_ELEC_COUNTER)    /* 预定位完成:未达开环终止速度则继续加速 */
		{
			pmsm_mc_param.startup_ramp += OPENLOOP_RAMPSPEED_INCREASERATE;    /* 每周期增大角度增量 */
		}
		else    /* 已达开环终止速度:准备切入闭环 */
		{
            theta_error = pmsm_foc_param.angle - smc1.theta;    /* 记录开环角度与观测器估算角度之差 */
#ifndef OPEN_LOOP_MODE    /* 未定义为纯开环模式时执行切闭环 */
            if((pmsm_foc_param.angle < M_PI) && (smc1.theta < M_PI))    /* 开环角度与观测角度均小于π(避免跨零切换)时切入闭环 */
            {
                pmsm_mc_param.change_mode = 1;    /* 置模式切换标志 */
                pmsm_mc_param.openloop = 0;    /* 退出开环,进入闭环 */
            }
#endif
		}
		pmsm_foc_param.angle += pmsm_mc_param.startup_ramp;    /* 开环角度按斜坡增量累加 */
        if(pmsm_foc_param.angle > ANGLE_2PI)    /* 角度归一化到[0,2π) */
            pmsm_foc_param.angle = pmsm_foc_param.angle - ANGLE_2PI;    /* 大于2π则减去2π */
	}
	else    /* 闭环运行阶段 */
	{
        pmsm_foc_param.angle = smc1.theta + theta_error;    /* 角度=观测器估算角度+切换误差偏置 */
        if((fabsf(theta_error) > 0.01f))    /* 偏置绝对值大于0.01rad时逐步衰减 */
        {
            if (theta_error < 0)    /* 负偏置向0收敛 */
            {
                theta_error += 0.01f;    /* 每周期增加0.01rad */
            }
            else    /* 正偏置向0收敛 */
            {
                theta_error -= 0.01f;    /* 每周期减小0.01rad */
            }
        }
        else
        {
            theta_error = 0;    /* 偏置足够小,直接清零 */
        }
	}
}

/**
  * @brief PI控制(开环阶段仅电流环,闭环阶段电流环+速度环)
  * @param 无
  * @retval 无
  * @note
  */
static void pid_control(void)
{
	if(pmsm_mc_param.openloop)    /* 开环阶段:固定电流给定,仅闭环电流环 */
	{
		if(pmsm_mc_param.change_mode)    /* 首次进入开环模式处理 */
		{
			pmsm_mc_param.change_mode = 0;    /* 清除模式切换标志 */
            pmsm_mc_param.id_ref = 0;    /* d轴电流给定清零 */
		}
        
        pmsm_mc_param.iq_ref = OPEN_LOOP_CURRENT;    /* q轴电流给定=开环启动电流 */
        
        /* q轴电流环PI调节 */
        pmsm_foc_param.pi_q.meas = pmsm_foc_param.iq;    /* q轴反馈电流 */
        pmsm_foc_param.pi_q.ref  = pmsm_mc_param.iq_ref;    /* q轴给定电流 */
        calc_pi(&pmsm_foc_param.pi_q);    /* q轴PI计算 */
        pmsm_foc_param.vq = pmsm_foc_param.pi_q.out;    /* PI输出作为q轴电压给定 */
       
        /* d轴电流环PI调节 */
        pmsm_foc_param.pi_d.meas = pmsm_foc_param.id;    /* d轴反馈电流 */
        pmsm_foc_param.pi_d.ref  = pmsm_mc_param.id_ref;    /* d轴给定电流 */
        calc_pi(&pmsm_foc_param.pi_d);    /* d轴PI计算 */
        pmsm_foc_param.vd = pmsm_foc_param.pi_d.out;    /* PI输出作为d轴电压给定 */
        
#ifdef OPEN_LOOP_VF_VQ    /* 若定义了开环V/F固定电压宏,则强制Vq=V/F给定 */
        pmsm_foc_param.vq = OPEN_LOOP_VF_VQ;    /* q轴电压取固定宏值 */
        pmsm_foc_param.vd = 0;    /* d轴电压置0 */
#endif

	}
	else    /* 闭环阶段 */
	{
        float vd_squared = 0;      /* vd电压平方(用于电压圆限幅) */
        float vq_squared_max = 0;  /* q轴电压平方上限 */

		if(pmsm_mc_param.change_mode)    /* 首次切入闭环模式处理 */
		{
            pmsm_mc_param.change_mode = 0;    /* 清除模式切换标志 */
            pmsm_mc_param.vel_ref = END_SPEED_RADS_ELEC;    /* 速度斜坡给定预置为开环终止速度(平滑切换) */
            pmsm_mc_param.id_ref = 0;    /* d轴电流给定清零 */
            pmsm_foc_param.pi_w.sum = OPEN_LOOP_CURRENT;    /* 速度环积分器预置开环电流(无扰切换) */
            pmsm_mc_param.speed_loop_count = SPEED_LOOP_CYCLE;    /* 速度环分频计数预置(下个周期立即执行) */
		}
        pmsm_mc_param.vel_diff =  pmsm_mc_param.vel_input - pmsm_mc_param.vel_ref;    /* 速度给定与斜坡给定之差 */

       /* 速度斜坡限幅器实现 */
        if(pmsm_mc_param.vel_diff >= CL_SPEED_HYSTERESIS)    /* 给定高于斜坡值超过滞环:升速 */
        {
             pmsm_mc_param.vel_ref += CL_SPEED_RAMP_RATE_DELTA;   /* 斜坡给定按步长递增 */
        }
        else if(pmsm_mc_param.vel_diff <=- CL_SPEED_HYSTERESIS)    /* 给定低于斜坡值超过滞环:降速 */
        {
             pmsm_mc_param.vel_ref -= CL_SPEED_RAMP_RATE_DELTA; /* 斜坡给定按步长递减 */
        }
        else
        {
             pmsm_mc_param.vel_ref = pmsm_mc_param.vel_input;    /* 差值在滞环内:斜坡给定直接跟踪给定 */
        }
        
#ifdef TORQUE_MODE    /* 转矩模式:iq给定由外部决定,不运行速度环PI,仅更新SMO速度滤波系数 */
/*        pmsm_mc_param.iq_ref = OPEN_LOOP_CURRENT; */
        if(pmsm_mc_param.speed_loop_count++ >= SPEED_LOOP_CYCLE)    /* 分频计数递增,达到分频周期后持续执行(转矩模式未清零计数) */
        {
            smc1.kslf = LOOPTIME_SEC * smc1.omega_fltred;  /* 滤波系数=T*2π*fc,fc为电频率(erps),即T×电角速度 */
            smc1.filt_omega_coef = smc1.kslf_final = smc1.kslf;    /* 更新SMO速度低通滤波系数(kslf_final保存最终值) */
        }
#else    /* 速度模式:按分频周期运行速度环 */
        if(pmsm_mc_param.speed_loop_count++ >= SPEED_LOOP_CYCLE)    /* 速度环分频:每SPEED_LOOP_CYCLE个周期执行一次 */
        {
            pmsm_mc_param.speed_loop_count = 0;    /* 分频计数清零 */
            /* 速度环PI调节 */
            pmsm_foc_param.pi_w.meas = smc1.omega_fltred;    /* 反馈速度(SMO滤波后电角速度) */
            pmsm_foc_param.pi_w.ref  = pmsm_mc_param.vel_ref;    /* 速度给定(斜坡后) */
            calc_pi(&pmsm_foc_param.pi_w);    /* 速度环PI计算 */
            pmsm_mc_param.iq_ref = pmsm_foc_param.pi_w.out;    /* PI输出作为q轴电流给定 */
            
            smc1.kslf = LOOPTIME_SEC * smc1.omega_fltred;  /* 滤波系数=T*2π*fc,fc为电频率(erps),即T×电角速度 */
            smc1.filt_omega_coef = smc1.kslf_final = smc1.kslf;    /* 更新SMO速度低通滤波系数(kslf_final保存最终值) */
        }
#endif
            
        /* d轴电流环PI调节 */
        pmsm_foc_param.pi_d.meas = pmsm_foc_param.id;    /* d轴反馈电流 */
        pmsm_foc_param.pi_d.ref  = pmsm_mc_param.id_ref;    /* d轴给定电流 */
        calc_pi(&pmsm_foc_param.pi_d);    /* d轴PI计算 */
        pmsm_foc_param.vd = pmsm_foc_param.pi_d.out;    /* PI输出作为d轴电压给定 */
        
        vd_squared = pmsm_foc_param.vd * pmsm_foc_param.vd;    /* 计算vd平方 */
        vq_squared_max = 0.99f - vd_squared;    /* 电压圆限幅:剩余幅值平方(0.99为限幅系数) */
		arm_sqrt_f32(vq_squared_max,&pmsm_foc_param.pi_q.out_max);    /* 开方得到q轴电压输出上限 */
        pmsm_foc_param.pi_q.out_min = -pmsm_foc_param.pi_q.out_max;    /* q轴输出下限(负对称) */

        /* q轴电流环PI调节 */
        pmsm_foc_param.pi_q.meas = pmsm_foc_param.iq;    /* q轴反馈电流 */
        pmsm_foc_param.pi_q.ref  = pmsm_mc_param.iq_ref;    /* q轴给定电流 */
        calc_pi(&pmsm_foc_param.pi_q);    /* q轴PI计算 */
        pmsm_foc_param.vq = pmsm_foc_param.pi_q.out;    /* PI输出作为q轴电压给定 */

	}
}

/***************************************** 文件结束 *********************************************/
