/*
*******************************************************************************************************
*
* 文件名称 : motor_app.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 电机控制主文件(单电阻采样+SMO无感FOC:任务调度/状态机/LCD显示/CAN上报)
* 
*******************************************************************************************************
*/

/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "motor_app.h"  /* 电机应用任务接口(状态机/参数结构) */
#include "adc_simple.h"  /* 简易ADC采样接口(NTC温度/母线电压/母线电流) */
#include "lcd.h"  /* LCD显示驱动接口 */
#include "uart.h"  /* 调试串口驱动接口 */
#include "encoder.h"  /* 正交编码器与按键接口 */
#include "single_shunt_cs.h"  /* 单电阻电流重构接口(移相偏移/扇区重构/零点标定) */
#include "pmsm.h"  /* PMSM FOC算法接口(参数结构与运行函数) */
#include "userparms.h"  /* 电机参数配置(极对数/速度/PI参数等) */

/* 宏定义 ------------------------------------------------------------------------------------------*/

/* 变量定义 ----------------------------------------------------------------------------------------*/
motor_control_t motor1 = {0};  /* 电机控制状态结构体(电流采样/温度电压/状态机) */
can_trasnmit_message_struct transmit_message;  /* CAN发送报文 */

extern uint32_t idc_offset;  /* 母线电流ADC零点偏置(单电阻采样标定均值) */
extern uint32_t idc_offset_sum;  /* 零点偏置累加和(用于求平均) */
extern uint8_t adc_calibration;  /* 零点标定完成标志(0=标定中,1=已完成) */

/* 局部函数 -----------------------------------------------------------------------------------*/
static void motor_ui_init(void);  /* LCD界面初始化(仅本文件使用) */
static void motor_ui_updata(void);  /* LCD界面刷新(仅本文件使用) */
static void motor_can_transmit(void);  /* CAN报文发送(仅本文件使用) */

/* 全局函数 ----------------------------------------------------------------------------------*/

/**
  * @brief motor app init
  * @param 无
  * @retval 无
  */
void motor_app_init(void)
{
    motor1.state = INIT;  /* 状态机置为初始化状态 */
    
    transmit_message.tx_sfid = 0x7ab;  /* 标准帧ID:0x7AB */
    transmit_message.tx_efid = 0x00;  /* 扩展帧ID:不使用 */
    transmit_message.tx_ft = CAN_FT_DATA;  /* 帧类型:数据帧 */
    transmit_message.tx_ff = CAN_FF_STANDARD;  /* 帧格式:标准帧 */
    transmit_message.tx_dlen = 8;  /* 数据长度:8字节 */
    
    transmit_message.tx_data[0] = 0x00;  /* 数据字节0初值 */
    transmit_message.tx_data[1] = 0xA1;  /* 数据字节1初值 */
    transmit_message.tx_data[2] = 0xA2;  /* 数据字节2初值 */
    transmit_message.tx_data[3] = 0xA3;  /* 数据字节3初值 */
    transmit_message.tx_data[4] = 0xA4;  /* 数据字节4初值 */
    transmit_message.tx_data[5] = 0xA5;  /* 数据字节5初值 */
    transmit_message.tx_data[6] = 0xA6;  /* 数据字节6初值 */
    transmit_message.tx_data[7] = 0xA7;  /* 数据字节7初值 */
    
    motor_ui_init();  /* 初始化LCD显示界面 */
}

/**
  * @brief 电机10ms任务(采集/编码器/按键处理)
  * @param 无
  * @retval 无
  */
void motor_app_task10ms(void)
{
    encoder_code_t encoder_code = ENCODER_NONE;  /* 编码器动作码 */
    uint8_t key_code = KEY_NONE;  /* 按键动作码 */
    
    motor1.ntc_adc = adc_read_data(ADC_CH_NTC);  /* 读取NTC通道ADC值(均值滤波) */
    motor1.vdc_adc = adc_read_data(ADC_CH_VDC);  /* 读取母线电压通道ADC值 */
    motor1.idc_adc = adc_read_data(ADC_CHIDC_AVER);  /* 读取母线平均电流通道ADC值 */
    motor1.mosfet_temp = calculate_temperature_float(motor1.ntc_adc);  /* NTC查表计算MOS管温度(℃) */
    motor1.vdc = motor1.vdc_adc * ADC_TO_VDC_COEF;  /* ADC值换算母线电压(V) */
    if(motor1.idc_adc > (ADC_FULL_BIT / 2))  /* 采样值超过中点2048,视为有电流 */
        motor1.idc = (motor1.idc_adc - 2048) * ADC_TO_CURRENT_COEF;  /* 去中点偏置后换算母线电流(A) */
    else
        motor1.idc = 0;  /* 否则母线电流为0 */
    
    encoder_code = encoder_get();  /* 读取编码器动作码 */
    key_scan();  /* 按键扫描 */
    key_code = key_get();  /* 获取按键动作码 */
    
    if(pmsm_mc_param.run_motor == 1)  /* 电机运行允许标志有效 */
    {
        /* SMO观测器滤波后电角速度换算机械转速rpm:60/(2π×极对数) */
        motor1.speed_rpm = pmsm_mc_param.actual_speed * ((float)60 / ANGLE_2PI / MOTOR_NOPOLESPAIRS);
        if(encoder_code == ENCODER_INC)  /* 编码器正转:加速 */
        {
            if(pmsm_mc_param.vel_input < NOMINAL_SPEED_RAD_PER_SEC_ELEC)  /* 未达额定电角速度才允许加速 */
            {
                pmsm_mc_param.vel_input = pmsm_mc_param.vel_input + 1.0f;  /* 速度给定加1(电弧度/秒) */
            }
        }
        else if(encoder_code == ENCODER_DEC)  /* 编码器反转:减速 */
        {      
            if(pmsm_mc_param.vel_input > END_SPEED_RADS_ELEC)  /* 高于结束电角速度才允许减速 */
            {
                pmsm_mc_param.vel_input = pmsm_mc_param.vel_input - 1.0f;  /* 速度给定减1(电弧度/秒) */
            }
        }
    }
    
    if(key_code == KEY_0_RELEASE)  /* 按键0短按释放:启停切换 */
    {
        if(motor1.state == RUN)  /* 运行中则停机 */
        {
            motor_pwm_disable();  /* 关闭三相PWM输出 */
            motor1.state = STOP;  /* 状态机置为停止 */
        }
        else if(motor1.state == STOP)  /* 停止中则启动 */
        {
            motor_pwm_enable();  /* 使能三相PWM输出 */
            pmsm_foc_init();  /* 复位FOC参数(PI积分器等) */
            motor1.state = RUN;  /* 状态机置为运行 */
        }
    }
    else if(key_code == KEY_0_LONG_PRESS)  /* 按键0长按(暂无处理) */
    {
        
    }
    
    motor_can_transmit();  /* 发送电机状态CAN报文 */
    
}

/**
  * @brief 电机100ms任务(空实现)
  * @param 无
  * @retval 无
  */
void motor_app_task100ms(void)
{
    
}

/**
  * @brief 电机500ms任务(空实现)
  * @param 无
  * @retval 无
  */
void motor_app_task500ms(void)
{
    
}

/**
  * @brief 电机1s任务(刷新LCD显示)
  * @param 无
  * @retval 无
  */
void motor_app_task1s(void)
{
    motor_ui_updata();  /* 刷新LCD显示界面 */
}

/**
  * @brief 电机空闲任务(ADC轮询采样)
  * @param 无
  * @retval 无
  */
void motor_app_idle(void)
{
    adc_task();  /* ADC轮询采样与通道轮换 */
}

/**
  * @brief 电机中断服务函数,由PWM周期中断调用(FOC主流程)
  * @param 无
  * @retval 无
  */
void motor_app_isr(void)
{
    float temp1 = 0;  /* 临时变量:待发送数据 */
    float temp2 = 0;  /* 临时变量:待发送数据 */
    float temp3 = 0;  /* 临时变量:待发送数据 */
    uint8_t uart_data[16] = {0};  /* 串口发送缓冲区 */
    
    switch(motor1.state)  /* 按电机状态机分派处理 */
    {
        case INIT:  /* 初始化完成 */
            motor1.state = ADC_CAL;  /* 进入ADC零点标定状态 */
            break;
        case ADC_CAL:  /* ADC零点标定:累计零电流时的母线电流采样值 */
            if(adc_calibration == 0)  /* 尚未完成零点标定 */
            {
                motor_get_phase_current_zero();  /* 采样母线电流零点并累加,完成后自动置标定标志 */
                return;  /* 标定未完成,本周期结束FOC处理 */
            }
            else  /* 零点标定已完成 */
            {
                motor1.state = START_DELAY;  /* 进入启动延时状态 */
            }
            
            break;
        case START_DELAY:  /* 启动延时:等待上电稳定 */
            if(motor1.start_delay_tick < START_DELAY_TICK)  /* 未达启动延时(2s对应PWM周期数) */
            {
                motor1.start_delay_tick++;  /* 延时计数加1 */
            }
            else
            {
                motor1.state = RUN;  /* 延时到,进入运行状态 */
                motor_pwm_enable();  /* 使能三相PWM输出 */
            }
            break;
        case STOP:  /* 停止状态:无处理 */
            break;
        case RUN:  /* 运行状态:单电阻采样FOC主流程 */
            {
                pmsm_mc_param.max_phase_voltage = motor1.vdc * ONE_BY_SQRT3;  /* 最大相电压=母线电压/√3,SVPWM限幅用 */
                
                /* 先更新上一个周期的PWM 在计数器到0的时候会自动更新 */
                motor_pwm_set_duty(duty_u,duty_v,duty_w);  /* 将上一周期移相后的三相占空比写入PWM */
                
                /* 单电阻电流重构 */
                motor_get_phase_current(pmsm_foc_param.sector);  /* 按扇区读取两采样点母线电流并重构三相电流 */
                
                /* FOC运算 */
                pmsm_foc_run();  /* Clark/Park/PI/SMO观测器/SVPWM一次迭代 */
                
                /* 更新上一个周期的PWM移相后的值 这个函数在计数器到最大值之前执行 在计数器到最大值的时候自动更新PWM */
                duty_u = duty_u - duty_u_offset - duty_u_offset;  /* U相占空比减去2倍移相偏移 */
                duty_v = duty_v - duty_v_offset - duty_v_offset;  /* V相占空比减去2倍移相偏移 */
                duty_w = duty_w - duty_w_offset - duty_w_offset;  /* W相占空比减去2倍移相偏移 */
                motor_pwm_set_duty(duty_u,duty_v,duty_w);  /* 写入移相后的三相占空比 */

                /* 移相计算 */
                duty_u = pmsm_foc_param.pwma;  /* 取FOC输出的U相占空比 */
                duty_v = pmsm_foc_param.pwmb;  /* 取FOC输出的V相占空比 */
                duty_w = pmsm_foc_param.pwmc;  /* 取FOC输出的W相占空比 */
                motor_phase_current_sampling_shift(pmsm_foc_param.sector);  /* 按扇区计算下一周期采样点移相偏移 */
                
                temp1 = (float)pmsm_foc_param.ia;  /* 重构后的U相电流 */
                memcpy(&uart_data[0],&temp1,4);  /* 复制到帧第0~3字节 */
                temp2 = (float)pmsm_foc_param.ib;  /* 重构后的V相电流 */
                memcpy(&uart_data[4],&temp2,4);  /* 复制到帧第4~7字节 */
                temp3 = (float)pmsm_foc_param.ic;  /* 重构后的W相电流 */
                memcpy(&uart_data[8],&temp3,4);  /* 复制到帧第8~11字节 */
                uart_data[sizeof(uart_data)-2] = 0x80;  /* 帧尾第3字节0x80 */
                uart_data[sizeof(uart_data)-1] = 0x7f;  /* 帧尾第4字节0x7f(合成小端float +∞) */
                usart_send_data(uart_data,sizeof(uart_data));  /* 经串口发送16字节调试数据 */
            }
            break;
        case FAULT:  /* 故障状态:无处理 */
            break;
        default:  /* 其他状态:无处理 */
            break;
    }
}

/* 局部函数 -----------------------------------------------------------------------------------*/

/**
  * @brief 电机LCD界面初始化
  * @param 无
  * @retval 无
  */
static void motor_ui_init(void)
{
    LCD_ShowString(0,0,(const uint8_t *)"tSpd",BLACK,WHITE,24,0);  /* 目标转速标签 */
    LCD_ShowIntNum(52,0,(uint16_t)pmsm_mc_param.vel_input,5,BLUE,WHITE,24);  /* 显示速度给定值 */
    LCD_ShowString(120,0,(const uint8_t *)"aSpd",BLACK,WHITE,24,0);  /* 实际转速标签 */
    LCD_ShowIntNum(175,0,(uint16_t)pmsm_mc_param.actual_speed,5,BLUE,WHITE,24);  /* 显示实际转速 */
    
    LCD_ShowString(0,24,(const uint8_t *)"qRef",BLACK,WHITE,24,0);  /* q轴电流给定标签 */
    LCD_ShowFloatNum2(52,24,pmsm_mc_param.iq_ref,3,BLUE,WHITE,24);  /* 显示q轴电流给定 */
    LCD_ShowString(120,24,(const uint8_t *)"qMea",BLACK,WHITE,24,0);  /* q轴电流反馈标签 */
    LCD_ShowFloatNum2(175,24,pmsm_foc_param.iq,3,BLUE,WHITE,24);  /* 显示q轴电流反馈 */
    
    LCD_ShowString(0,48,(const uint8_t *)"dRef",BLACK,WHITE,24,0);  /* d轴电流给定标签 */
    LCD_ShowFloatNum2(52,48,pmsm_mc_param.id_ref,3,BLUE,WHITE,24);  /* 显示d轴电流给定 */
    LCD_ShowString(120,48,(const uint8_t *)"dMea",BLACK,WHITE,24,0);  /* d轴电流反馈标签 */
    LCD_ShowFloatNum2(175,48,pmsm_foc_param.id,3,BLUE,WHITE,24);  /* 显示d轴电流反馈 */
    
    LCD_ShowString(0,72,(const uint8_t *)"Vdc",BLACK,WHITE,24,0);  /* 母线电压标签 */
    LCD_ShowFloatNum2(52,72,motor1.vdc,3,BLUE,WHITE,24);  /* 显示母线电压 */
    LCD_ShowString(120,72,(const uint8_t *)"Idc",BLACK,WHITE,24,0);  /* 母线电流标签 */
    LCD_ShowFloatNum2(175,72,motor1.idc,3,BLUE,WHITE,24);  /* 显示母线电流 */
    
    LCD_ShowString(0,96,(const uint8_t *)"Temp",BLACK,WHITE,24,0);  /* MOS管温度标签 */
    LCD_ShowFloatNum2(52,96,motor1.mosfet_temp,4,BLUE,WHITE,24);  /* 显示MOS管温度 */
    LCD_ShowString(120,96,(const uint8_t *)"STA",BLACK,WHITE,24,0);  /* 状态标签 */
    LCD_ShowString(175,96,(const uint8_t *)"INIT",BLACK,WHITE,24,0);  /* 显示初始状态 */
}

/**
  * @brief 电机LCD界面刷新
  * @param 无
  * @retval 无
  */
static void motor_ui_updata(void)
{
    /* 刷新速度给定显示:电角速度换算为机械转速rpm */
    LCD_ShowIntNum(52,0,(uint16_t)(pmsm_mc_param.vel_input * ((float)60 / ANGLE_2PI / MOTOR_NOPOLESPAIRS)),5,BLUE,WHITE,24);
    LCD_ShowIntNum(175,0,(uint16_t)motor1.speed_rpm,5,BLUE,WHITE,24);  /* 刷新实际转速显示 */
    
    LCD_ShowFloatNum2(52,24,pmsm_mc_param.iq_ref,3,BLUE,WHITE,24);  /* 刷新q轴电流给定 */
    LCD_ShowFloatNum2(175,24,pmsm_foc_param.iq,3,BLUE,WHITE,24);  /* 刷新q轴电流反馈 */
    
    LCD_ShowFloatNum2(52,48,pmsm_mc_param.id_ref,3,BLUE,WHITE,24);  /* 刷新d轴电流给定 */
    LCD_ShowFloatNum2(175,48,pmsm_foc_param.id,3,BLUE,WHITE,24);  /* 刷新d轴电流反馈 */
    
    LCD_ShowFloatNum2(52,72,motor1.vdc,3,BLUE,WHITE,24);  /* 刷新母线电压 */
    LCD_ShowFloatNum2(175,72,motor1.idc,3,BLUE,WHITE,24);  /* 刷新母线电流 */
    
    LCD_ShowFloatNum2(52,96,motor1.mosfet_temp,4,BLUE,WHITE,24);  /* 刷新MOS管温度 */
    
    if(motor1.state == RUN)  /* 运行状态 */
    {
        LCD_ShowString(175,96,(const uint8_t *)"RUN  ",BLUE,WHITE,24,0);  /* 显示RUN */
    }
    else if(motor1.state == STOP)  /* 停止状态 */
    {
        LCD_ShowString(175,96,(const uint8_t *)"STOP",BLUE,WHITE,24,0);  /* 显示STOP */
    }
    else if(motor1.state == FAULT)  /* 故障状态 */
    {
        LCD_ShowString(175,96,(const uint8_t *)"FLT  ",BLUE,WHITE,24,0);  /* 显示FLT */
    }
    else  /* 其他状态 */
    {
        LCD_ShowString(175,96,(const uint8_t *)"NONE",BLUE,WHITE,24,0);  /* 显示NONE */
    }
}

/**
  * @brief 电机CAN报文发送任务
  * @param 无
  * @retval 无
  */
static void motor_can_transmit(void)
{
    uint8_t mosfet_temperature = 0;  /* 偏移后的温度字节(-40℃对应0) */
    if(motor1.mosfet_temp < -40)  /* 低于-40℃钳位为0 */
        mosfet_temperature = 0;  /* 温度字节置0 */
    else
        mosfet_temperature = motor1.mosfet_temp + 40;  /* 温度加40℃偏移转为无符号 */
    
    transmit_message.tx_data[0] = mosfet_temperature;  /* 字节0:MOS管温度(+40℃偏移) */
    transmit_message.tx_data[1] = (uint8_t)(motor1.idc * 10);  /* 字节1:母线电流×10(0.1A分辨率) */
    transmit_message.tx_data[2] = (uint8_t)(motor1.vdc * 6);  /* 字节2:母线电压×6 */
    transmit_message.tx_data[3] = pmsm_foc_param.iq * 10;  /* 字节3:q轴电流×10(0.1A分辨率) */
    transmit_message.tx_data[4] = motor1.speed_rpm & 0xff;  /* 字节4:转速低8位 */
    transmit_message.tx_data[5] = motor1.speed_rpm >> 8;  /* 字节5:转速高8位 */
    transmit_message.tx_data[6] = 0;  /* 字节6:预留 */
    transmit_message.tx_data[7] = 0;  /* 字节7:预留 */
    
    can_message_transmit(CAN0, &transmit_message);  /* 经CAN0发送报文 */
}

/************************************************文件结束************************************************/
