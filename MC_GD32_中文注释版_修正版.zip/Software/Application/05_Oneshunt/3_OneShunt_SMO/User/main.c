/*
*******************************************************************************************************
*
* 文件名称 : main.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 主函数文件(单电阻采样SMO无感FOC例程)
*
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include <string.h> /* C字符串/内存操作库头文件(memcpy等) */
#include "gd32f30x.h" /* GD32F30x芯片外设寄存器与固件库头文件 */
#include "gd32f30x_libopt.h" /* GD32F30x固件库外设包含配置头文件 */
#include "motor_hardware.h" /* 电机硬件接口配置头文件(PWM/ADC/用户IO) */
#include "motor_config.h" /* 电机参数配置头文件(PWM频率/采样电阻/换算系数) */
#include "led.h" /* LED驱动头文件 */
#include "uart.h" /* 串口驱动头文件 */
#include "encoder.h" /* 编码器(旋钮)驱动头文件 */
#include "drv8323rs.h" /* DRV8323RS栅极驱动器SPI驱动头文件 */
#include "lcd.h" /* LCD显示驱动头文件(绘图/填充/显示字符串) */
#include "lcd_init.h" /* LCD初始化及硬件引脚配置头文件 */
#include "systick.h" /* 滴答定时器配置头文件(系统节拍/延时) */
#include "adc_simple.h" /* 简易ADC采样头文件(母线电压/NTC温度) */
#include "foc.h" /* FOC算法头文件(Clark/Park变换/SVPWM) */
#include "pmsm.h" /* PMSM电机控制头文件(FOC参数与主运算) */
#include "userparms.h" /* 用户参数配置头文件(电机极对数/PI参数等) */
#include "task.h" /* 任务调度器头文件(任务初始化/时间片调度) */
#include "motor_app.h" /* 电机应用层头文件(状态机/启动控制) */
#include "single_shunt_cs.h" /* 单电阻电流采样头文件(采样时序/扇区重构/零点标定) */

/* 宏定义 ------------------------------------------------------------------------------------------*/

/* 变量定义 ----------------------------------------------------------------------------------------*/
float temp1 = 0,temp2 = 0,temp3 = 0; /* 串口上传用临时浮点变量(历史遗留,未引用) */
uint8_t uart_data[16] = {0}; /* 串口发送数据缓冲区(历史遗留变量,未引用) */

uint32_t start_delay = 3000; /* 启动延时计数(历史遗留变量,未引用,实际延时用motor1.start_delay_tick) */

extern uint8_t adc_calibration; /* 单电阻零点标定完成标志(定义于single_shunt_cs.c,0=标定中,1=已完成) */

/* 函数定义 -----------------------------------------------------------------------------------------*/


/**
  * @brief 主函数
  * @param 无
  * @retval 无
  */
int main(void)
{
    SCB->VTOR = FLASH_BASE | 0x4000; /* 设置中断向量表到APP区基址(偏移0x4000,由Bootloader引导) */
    __enable_irq(); /* 使能全局中断 */
    
    systick_init(); /* 初始化滴答定时器(1ms系统节拍) */
    led_init(); /* 初始化LED指示灯 */
    usart_init(); /* 初始化调试串口 */
    adc1_init(); /* 初始化ADC1(软件触发采样NTC温度/母线电压) */
    encoder_init(); /* 初始化编码器(旋钮)接口 */
    LCD_Init(); /* 初始化LCD(电机应用界面显示用) */
    LCD_Fill(0,0,LCD_W,LCD_H,WHITE); /* 全屏填充白色背景 */
    led_off(LED1); /* 熄灭LED1 */
    led_off(LED2); /* 熄灭LED2 */
    led_off(LED3); /* 熄灭LED3 */
    DRV8323RS_init(); /* 初始化DRV8323RS栅极驱动器(SPI寄存器配置/CSA校准) */
    task_init(); /* 任务调度器初始化(内部调用电机应用初始化) */
    
    motor_hardware_init(); /* 初始化电机硬件(NVIC/PWM/ADC/单电阻采样定时器) */
    
/* 设置单电阻双采样点:第一采样点比较值=周期/2(触发注入组),第二采样点比较值=周期值(触发规则组) */
    motor_pwm_set_adc_trigger_point(MOTOR_PWM_PERIOD / 2, MOTOR_PWM_PERIOD);
    
    motor_phase_current_sampling_init(); /* 单电阻采样时序参数初始化(计算采样延迟/最小采样窗口的PWM计数值) */
    pmsm_foc_param.pwm_period = (float)MOTOR_PWM_PERIOD*0.98f; /* 设置SVPWM调制满量程计数值(周期值×0.98,留出过调制余量) */
    pmsm_foc_init(); /* PMSM FOC初始化(计算启动参数) */
    
	while(1) /* 主循环:运行时间片任务调度器 */
	{
        task_scheduler(); /* 轮询调度1ms/5ms等周期任务 */
	}
}


/**
  * @brief TIMER0刹车中断服务函数(硬件故障保护时触发)
  * @param 无
  * @retval 无
  */
void TIMER0_BRK_IRQHandler(void)
{
    timer_channel_output_mode_config(TIMER0,TIMER_CH_0,TIMER_OC_MODE_INACTIVE); /* 将W相通道(CH0)置为匹配时无效电平,封锁PWM */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_1,TIMER_OC_MODE_INACTIVE); /* 将V相通道(CH1)置为匹配时无效电平,封锁PWM */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_2,TIMER_OC_MODE_INACTIVE); /* 将U相通道(CH2)置为匹配时无效电平,封锁PWM */
/*    timer_primary_output_config(TIMER0,DISABLE); */
    /* 清除定时器中断标志 */
    timer_interrupt_flag_clear(TIMER0,TIMER_INT_FLAG_BRK); /* 清除刹车中断标志 */
    timer_disable(TIMER0); /* 停止TIMER0计数,彻底关闭PWM输出 */
    timer_disable(TIMER1); /* 停止TIMER1计数,关闭单电阻采样触发定时 */
    
    led_on(LED_FAULT); /* 点亮故障指示LED */
}

/**
  * @brief TIMER0通道中断服务函数(CH3比较匹配触发)
  * @param 无
  * @retval 无
  */
void TIMER0_Channel_IRQHandler(void)
{
    timer_interrupt_flag_clear(TIMER0,TIMER_INT_FLAG_CH3); /* 清除通道3比较中断标志 */
    
    motor_app_isr(); /* 调用电机应用中断处理(单电阻双采样点电流重构/SMO观测/FOC运算) */
}


/***************************************** 文件结束 *********************************************/
