/*
*******************************************************************************************************
*
* 文件名称 : motor_hardware.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 电机控制硬件配置文件(单电阻采样+SMO方案:TIMER0互补PWM/TIMER1双触发点ADC采样/DAC过流保护)
*
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "motor_hardware.h"    /* 电机硬件接口头文件(引脚宏/通道宏/接口声明) */
#include "motor_config.h"    /* 电机参数配置头文件(PWM周期/采样系数/过流阈值) */
#include "systick.h"    /* 滴答定时器头文件(系统节拍/延时) */

/* 宏定义 ------------------------------------------------------------------------------------------*/


/* 变量定义 ----------------------------------------------------------------------------------------*/

/* 函数定义 -----------------------------------------------------------------------------------------*/
static void pwm_gpio_init(void);    /* PWM输出引脚GPIO初始化(三相互补输出+刹车输入) */
static void pwm_timer_config(void);    /* PWM定时器配置(TIMER0互补PWM+TIMER1采样触发定时器) */
static void adc_gpio_init(void);    /* ADC采样引脚GPIO初始化(母线电流两路信号) */
static void adc0_config(void);    /* ADC0配置(注入组+规则组,分别由TIMER1_CH0/CH1触发) */
static void hall_timer_config(void);    /* 霍尔信号定时器配置(TIMER2输入捕获+复位从模式) */

/**
  * @brief GPIO与定时器配置(电机硬件外设总初始化)
  * @param 无
  * @retval 无
  */
void motor_hardware_init(void)
{
    interrupt_init();    /* 配置NVIC中断优先级 */
    pwm_gpio_init();    /* 初始化PWM输出引脚(三相上/下桥臂+刹车输入) */
    pwm_timer_config();    /* 配置TIMER0互补PWM与TIMER1采样触发定时器 */
    motor_pwm_disable();    /* 封锁三相PWM输出(上电默认关闭,电机启动时再使能) */
    hall_init();    /* 初始化霍尔传感器接口(TIMER2输入捕获) */
    adc0_init();    /* 初始化ADC0(母线电流采样) */
}

/**
  * @brief NVIC中断优先级配置
  * @param 无
  * @retval 无
  */
void interrupt_init(void)
{
    nvic_irq_enable(TIMER0_Channel_IRQn, 1, 3);    /* 使能TIMER0通道中断(抢占1子3):CH3比较中断作FOC主循环入口 */
    nvic_irq_enable(TIMER0_BRK_IRQn, 0, 0);    /* 使能TIMER0刹车中断(抢占0子0,最高优先级硬件故障保护) */
    
/*    nvic_irq_enable(TIMER0_UP_IRQn, 1, 2);    (已注释停用:TIMER0更新中断) */
/*    nvic_irq_enable(TIMER1_IRQn, 0, 2);    (已注释停用:TIMER1仅作ADC触发源,不进中断) */
/*    nvic_irq_enable(ADC0_1_IRQn, 0, 2);    (已注释停用:FOC中断内直接读取ADC数据寄存器) */
/*    nvic_irq_enable(TIMER2_IRQn, 1, 1);    (已注释停用:TIMER2霍尔捕获中断) */
}

/**
  * @brief 更新三相PWM占空比
  * @param duty_u-U相占空比
  * @param duty_v-V相占空比
  * @param duty_w-W相占空比
  * @retval 无
  */
void motor_pwm_set_duty(uint16_t duty_u,uint16_t duty_v,uint16_t duty_w)
{
    timer_channel_output_pulse_value_config(MOTOR_PWM_TIMER,PWM_U_CHANNEL,duty_u);    /* 设置U相通道比较值 */
    timer_channel_output_pulse_value_config(MOTOR_PWM_TIMER,PWM_V_CHANNEL,duty_v);    /* 设置V相通道比较值 */
    timer_channel_output_pulse_value_config(MOTOR_PWM_TIMER,PWM_W_CHANNEL,duty_w);    /* 设置W相通道比较值 */
}

/**
  * @param trigger_point0-第一采样点比较值(触发注入组采样)
  * @param trigger_point1-第二采样点比较值(触发规则组采样)
  * @param None
  * @retval 无
  * @note 触发点值由单电阻采样移相算法按当前扇区计算写入(见single_shunt_cs.c)
  */
void motor_pwm_set_adc_trigger_point(uint16_t trigger_point0, uint16_t trigger_point1)
{
    timer_channel_output_pulse_value_config(TIMER1,TIMER_CH_0,trigger_point0);    /* 写入TIMER1_CH0比较值(注入组触发) */
    timer_channel_output_pulse_value_config(TIMER1,TIMER_CH_1,trigger_point1);    /* 写入TIMER1_CH1比较值(规则组触发) */
}

/**
  * @param p_ia-第一采样点母线电流ADC值(注入组读取)
  * @param p_ib-第二采样点母线电流ADC值(规则组读取)
  * @param None
  * @retval 无
  * @note 母线电流经电流重构算法还原为两相电流(见single_shunt_cs.c)
  */
void motor_get_phase_current_adc(int16_t *p_ia, int16_t *p_ib)
{
	*p_ia = adc_inserted_data_read(ADC0, IDC_INSERTED_CHANNEL);    /* 读注入组数据寄存器(第一采样点母线电流) */
	*p_ib = adc_regular_data_read(ADC0);    /* 读规则组数据寄存器(第二采样点母线电流) */
}

/**
  * @brief ADC初始化
  * @param 无
  * @retval 无
  */
void adc0_init(void)
{
    adc_gpio_init();    /* 初始化ADC采样引脚(模拟输入) */
    adc0_config();    /* 配置ADC0(通道/触发源/校准) */
}

/**
  * @brief DAC过流保护配置(DAC1输出相电流过流阈值)
  * @param 无
  * @retval 无
  * @note 本函数在本工程中未被调用,预留作比较器过流保护用途
  */
void comp_protect_init(void)
{
    /* 使能外设时钟 */
    rcu_periph_clock_enable(RCU_GPIOA);    /* 使能GPIOA端口时钟(DAC输出引脚PA5) */
    rcu_periph_clock_enable(RCU_DAC);    /* 使能DAC外设时钟 */
    
    /* DAC使能后,对应GPIO引脚自动连接到DAC转换器输出 */
    gpio_init(GPIOA, GPIO_MODE_AIN, GPIO_OSPEED_50MHZ, GPIO_PIN_5);    /* PA5配置为模拟输入(DAC1输出引脚) */
    
    dac_deinit();    /* 复位DAC外设 */
    /* 配置DAC1(原注释DAC0为笔误,按实际代码更正) */
    dac_wave_mode_config(DAC1, DAC_WAVE_MODE_LFSR);    /* 配置DAC1波形发生模式为LFSR伪噪声波 */
    dac_lfsr_noise_config(DAC1, DAC_LFSR_BITS10_0);    /* 配置LFSR噪声波位宽为10_0 */
    
    /* 使能DAC1并写入数据 */
    dac_enable(DAC1);    /* 使能DAC1转换器 */
/*    dac_data_set(DAC1, DAC_ALIGN_12B_R, PHASE_OVER_CURRENT_DAC_VAULE);    (重复赋值行,已注释停用) */
    dac_data_set(DAC1, DAC_ALIGN_12B_R, PHASE_OVER_CURRENT_DAC_VAULE);    /* 设置DAC输出值为相电流过流阈值(供比较器过流保护) */
}

/**
  * @brief 霍尔传感器接口初始化
  * @param 无
  * @retval 无
  */
void hall_init(void)
{
    /* 使能GPIO时钟 */
    rcu_periph_clock_enable(HALLA_GPIO_CLK);    /* 使能霍尔A相端口时钟(PC6) */
    rcu_periph_clock_enable(HALLB_GPIO_CLK);    /* 使能霍尔B相端口时钟(PC7) */
    rcu_periph_clock_enable(HALLC_GPIO_CLK);    /* 使能霍尔C相端口时钟(PC8) */
    rcu_periph_clock_enable(RCU_AF);    /* 使能复用功能时钟 */
    
    gpio_pin_remap_config(GPIO_TIMER2_FULL_REMAP,ENABLE);    /* TIMER2完全重映射(霍尔信号映射到PC6/PC7/PC8) */
    
    gpio_init(HALLA_GPIO_PORT,GPIO_MODE_IN_FLOATING,GPIO_OSPEED_50MHZ,HALLA_GPIO_PIN);    /* 霍尔A相引脚浮空输入 */
    gpio_init(HALLB_GPIO_PORT,GPIO_MODE_IN_FLOATING,GPIO_OSPEED_50MHZ,HALLB_GPIO_PIN);    /* 霍尔B相引脚浮空输入 */
    gpio_init(HALLC_GPIO_PORT,GPIO_MODE_IN_FLOATING,GPIO_OSPEED_50MHZ,HALLC_GPIO_PIN);    /* 霍尔C相引脚浮空输入 */
    
    hall_timer_config();    /* 配置霍尔定时器(TIMER2输入捕获) */
}

/**
  * @brief 读取霍尔传感器状态
  * @param 无
  * @retval 无
  */
uint8_t hall_get(void)
{
    uint8_t ret = 0;    /* 霍尔状态组合值(3位:bit0=A相,bit1=B相,bit2=C相) */
    
    ret |= gpio_input_bit_get(HALLA_GPIO_PORT,HALLA_GPIO_PIN);    /* 读A相信号置入bit0 */
    ret |= gpio_input_bit_get(HALLB_GPIO_PORT,HALLB_GPIO_PIN) << 1;    /* 读B相信号左移1位置入bit1 */
    ret |= gpio_input_bit_get(HALLC_GPIO_PORT,HALLC_GPIO_PIN) << 2;    /* 读C相信号左移2位置入bit2 */
    
    return ret;    /* 返回霍尔状态组合值 */
}

/**
  * @brief 将PWM引脚恢复为定时器复用输出模式
  * @param 无
  * @retval 无
  */
void motor_pwm_pin_enable(void)
{
    gpio_init(PWM_UH_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_UH_GPIO_PIN);    /* U相上桥臂引脚复用推挽 */
    gpio_init(PWM_VH_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_VH_GPIO_PIN);    /* V相上桥臂引脚复用推挽 */
    gpio_init(PWM_WH_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_WH_GPIO_PIN);    /* W相上桥臂引脚复用推挽 */

    gpio_init(PWM_UL_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_UL_GPIO_PIN);    /* U相下桥臂引脚复用推挽 */
    gpio_init(PWM_VL_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_VL_GPIO_PIN);    /* V相下桥臂引脚复用推挽 */
    gpio_init(PWM_WL_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_WL_GPIO_PIN);    /* W相下桥臂引脚复用推挽 */
}

/**
  * @brief 将PWM引脚切换为普通GPIO输出(输出低电平)
  * @param 无
  * @retval 无
  */
void motor_pwm_pin_disable(void)
{
    gpio_bit_write(PWM_UH_GPIO_PORT, PWM_UH_GPIO_PIN,RESET);    /* U相上桥臂引脚输出低电平 */
    gpio_bit_write(PWM_VH_GPIO_PORT, PWM_VH_GPIO_PIN,RESET);    /* V相上桥臂引脚输出低电平 */
    gpio_bit_write(PWM_WH_GPIO_PORT, PWM_WH_GPIO_PIN,RESET);    /* W相上桥臂引脚输出低电平 */

    gpio_bit_write(PWM_UL_GPIO_PORT, PWM_UL_GPIO_PIN,RESET);    /* U相下桥臂引脚输出低电平 */
    gpio_bit_write(PWM_VL_GPIO_PORT, PWM_VL_GPIO_PIN,RESET);    /* V相下桥臂引脚输出低电平 */
    gpio_bit_write(PWM_WL_GPIO_PORT, PWM_WL_GPIO_PIN,RESET);    /* W相下桥臂引脚输出低电平 */
    
    gpio_init(PWM_UH_GPIO_PORT,GPIO_MODE_OUT_PP,GPIO_OSPEED_50MHZ,PWM_UH_GPIO_PIN);    /* U相上桥臂推挽输出 */
    gpio_init(PWM_VH_GPIO_PORT,GPIO_MODE_OUT_PP,GPIO_OSPEED_50MHZ,PWM_VH_GPIO_PIN);    /* V相上桥臂推挽输出 */
    gpio_init(PWM_WH_GPIO_PORT,GPIO_MODE_OUT_PP,GPIO_OSPEED_50MHZ,PWM_WH_GPIO_PIN);    /* W相上桥臂推挽输出 */

    gpio_init(PWM_UL_GPIO_PORT,GPIO_MODE_OUT_PP,GPIO_OSPEED_50MHZ,PWM_UL_GPIO_PIN);    /* U相下桥臂推挽输出 */
    gpio_init(PWM_VL_GPIO_PORT,GPIO_MODE_OUT_PP,GPIO_OSPEED_50MHZ,PWM_VL_GPIO_PIN);    /* V相下桥臂推挽输出 */
    gpio_init(PWM_WL_GPIO_PORT,GPIO_MODE_OUT_PP,GPIO_OSPEED_50MHZ,PWM_WL_GPIO_PIN);    /* W相下桥臂推挽输出 */
}

/**
  * @brief 封锁PWM输出(关闭三相通道)
  * @param 无
  * @retval 无
  */
void motor_pwm_disable(void)
{
    timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_U_CHANNEL,TIMER_CCX_DISABLE);    /* 关闭U相主输出通道 */
    timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_V_CHANNEL,TIMER_CCX_DISABLE);    /* 关闭V相主输出通道 */
    timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_W_CHANNEL,TIMER_CCX_DISABLE);    /* 关闭W相主输出通道 */
    /* 关闭U相互补输出通道 */
    timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_U_CHANNEL,TIMER_CCXN_DISABLE);
    /* 关闭V相互补输出通道 */
    timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_V_CHANNEL,TIMER_CCXN_DISABLE);
    /* 关闭W相互补输出通道 */
    timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_W_CHANNEL,TIMER_CCXN_DISABLE);
}

/**
  * @brief 使能PWM输出(打开三相通道)
  * @param 无
  * @retval 无
  */
void motor_pwm_enable(void)
{
    timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_U_CHANNEL,TIMER_CCX_ENABLE);    /* 使能U相主输出通道 */
    timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_V_CHANNEL,TIMER_CCX_ENABLE);    /* 使能V相主输出通道 */
    timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_W_CHANNEL,TIMER_CCX_ENABLE);    /* 使能W相主输出通道 */
    /* 使能U相互补输出通道 */
    timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_U_CHANNEL,TIMER_CCXN_ENABLE);
    /* 使能V相互补输出通道 */
    timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_V_CHANNEL,TIMER_CCXN_ENABLE);
    /* 使能W相互补输出通道 */
    timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_W_CHANNEL,TIMER_CCXN_ENABLE);
}

/* 局部函数 -----------------------------------------------------------------------------------------*/

/**
  * @brief PWM输出引脚GPIO初始化
  * @param 无
  * @retval 无
  */
static void pwm_gpio_init(void)
{
    rcu_periph_clock_enable(RCU_GPIOA);    /* 使能GPIOA端口时钟(上桥臂引脚) */
    rcu_periph_clock_enable(RCU_GPIOB);    /* 使能GPIOB端口时钟(下桥臂/刹车引脚) */
    rcu_periph_clock_enable(RCU_AF);    /* 使能复用功能时钟 */

    /*configure PA8 PA9 PA10(TIMER0 CH0 CH1 CH2) 为复用推挽输出(W/V/U相上桥臂)*/
    gpio_init(PWM_UH_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_UH_GPIO_PIN);    /* U相上桥臂引脚PA10 */
    gpio_init(PWM_VH_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_VH_GPIO_PIN);    /* V相上桥臂引脚PA9 */
    gpio_init(PWM_WH_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_WH_GPIO_PIN);    /* W相上桥臂引脚PA8 */

    /*configure PB13 PB14 PB15(TIMER0 CH0N CH1N CH2N) 为复用推挽输出(W/V/U相下桥臂)*/
    gpio_init(PWM_UL_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_UL_GPIO_PIN);    /* U相下桥臂引脚PB15 */
    gpio_init(PWM_VL_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_VL_GPIO_PIN);    /* V相下桥臂引脚PB14 */
    gpio_init(PWM_WL_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_WL_GPIO_PIN);    /* W相下桥臂引脚PB13 */

    /*configure PB12(TIMER0 BKIN) 为刹车输入引脚*/
    /* 刹车输入BKIN引脚PB12(浮空输入) */
    gpio_init(PWM_BKIN_GPIO_PORT,GPIO_MODE_IN_FLOATING,GPIO_OSPEED_50MHZ,PWM_BKIN_GPIO_PIN);
}

/**
  * @brief ADC采样引脚GPIO初始化
  * @param 无
  * @retval 无
  */
static void adc_gpio_init(void)
{
    /* 使能GPIO时钟 */
    rcu_periph_clock_enable(IDC_ADC_CLK);    /* 使能母线电流采样引脚端口时钟(PB1) */
    rcu_periph_clock_enable(IDC_AVER_ADC_CLK);    /* 使能母线电流平均值采样引脚时钟(PA3) */
    
    gpio_init(IDC_ADC_PORT, GPIO_MODE_AIN, GPIO_OSPEED_MAX, IDC_ADC_PIN);    /* 母线电流采样引脚(模拟输入) */
    gpio_init(IDC_AVER_ADC_PORT, GPIO_MODE_AIN, GPIO_OSPEED_MAX, IDC_AVER_ADC_PIN);    /* 母线电流平均值采样引脚 */
}

/**
  * @brief PWM定时器配置(TIMER0互补PWM+TIMER1采样触发)
  * @param 无
  * @retval 无
  */
static void pwm_timer_config(void)
{
    /* 系统主频systemcoreclock = 120MHz 
    *  PWM频率 = systemcoreclock / (prescaler+1) / period / 2 (中央对齐模式一个周期上下各计数一次)
    *  死区时间 = 1.2us
    */
    timer_oc_parameter_struct timer_ocintpara;    /* 输出通道配置结构体(极性/使能/空闲状态) */
    timer_parameter_struct timer_initpara;    /* 定时器时基配置结构体 */
    timer_break_parameter_struct timer_breakpara;    /* 刹车/死区/自动输出配置结构体 */

    rcu_periph_clock_enable(RCU_TIMER0);    /* 使能TIMER0时钟(电机PWM定时器) */
    rcu_periph_clock_enable(RCU_TIMER1);    /* 使能TIMER1时钟(ADC采样触发定时器) */
    
    /* TIMER1配置(ADC采样触发定时器) */
    timer_deinit(TIMER1);    /* 复位TIMER1 */

    timer_initpara.prescaler         = 0;    /* 预分频:0(计数频率120MHz) */
    timer_initpara.alignedmode       = TIMER_COUNTER_CENTER_UP;    /* 中央对齐模式(比较标志在向上计数时置位) */
    timer_initpara.counterdirection  = TIMER_COUNTER_UP;    /* 向上计数(中央对齐模式下计数方向由硬件控制) */
    timer_initpara.period            = MOTOR_PWM_PERIOD;    /* 自动重装载值(16kHz中央对齐PWM对应3749) */
    timer_initpara.clockdivision     = TIMER_CKDIV_DIV1;    /* 时钟分割:不分频(死区时钟基准t_DTS=1/120MHz) */
    timer_initpara.repetitioncounter = 0;    /* 重复计数器:0(每个周期都产生更新事件) */
    timer_init(TIMER1,&timer_initpara);    /* 初始化TIMER1时基 */

    /* CH0/CH1输出通道结构体配置(原注释PWM0模式与后文PWM1配置不符,按实际更正) */
    timer_ocintpara.outputstate  = TIMER_CCX_ENABLE;    /* 主输出通道使能 */
    timer_ocintpara.outputnstate = TIMER_CCXN_ENABLE;    /* 互补输出通道使能 */
    timer_ocintpara.ocpolarity   = TIMER_OC_POLARITY_HIGH;    /* 主输出高电平有效 */
    timer_ocintpara.ocnpolarity  = TIMER_OCN_POLARITY_HIGH;    /* 互补输出高电平有效 */
    timer_ocintpara.ocidlestate  = TIMER_OC_IDLE_STATE_LOW;    /* 空闲状态时主输出为低 */
    timer_ocintpara.ocnidlestate = TIMER_OCN_IDLE_STATE_LOW;    /* 空闲状态时互补输出为低 */
    timer_channel_output_config(TIMER1,TIMER_CH_0,&timer_ocintpara);    /* 配置TIMER1_CH0输出通道(注入组触发) */
    timer_channel_output_config(TIMER1,TIMER_CH_1,&timer_ocintpara);    /* 配置TIMER1_CH1输出通道(规则组触发) */

    /* CHx 必须配置为 PWM1,这样在周期的前半段才能产生上升沿触发ADC */
    timer_channel_output_pulse_value_config(TIMER1,TIMER_CH_0,timer_initpara.period/2);    /* CH0比较值初值=半周期 */
    timer_channel_output_mode_config(TIMER1,TIMER_CH_0,TIMER_OC_MODE_PWM1);    /* CH0输出模式PWM1 */
    timer_channel_output_shadow_config(TIMER1,TIMER_CH_0,TIMER_OC_SHADOW_ENABLE);    /* CH0影子寄存器使能 */
    
    timer_channel_output_pulse_value_config(TIMER1,TIMER_CH_1,timer_initpara.period/2);    /* CH1比较值初值=半周期 */
    timer_channel_output_mode_config(TIMER1,TIMER_CH_1,TIMER_OC_MODE_PWM1);    /* CH1输出模式PWM1 */
    timer_channel_output_shadow_config(TIMER1,TIMER_CH_1,TIMER_OC_SHADOW_ENABLE);    /* CH1影子寄存器使能 */

    /* 自动重装载预装载使能 */
    timer_auto_reload_shadow_enable(TIMER1);    /* ARR影子寄存器使能(周期值下个更新事件生效) */
    /* 选择主从模式 */
    timer_master_slave_mode_config(TIMER1,TIMER_MASTER_SLAVE_MODE_ENABLE);    /* 主从模式使能(触发同步延迟2时钟周期) */
    /* TIMER1主输出触发源TRGO选择(原注释"更新事件"与库定义不符,按实际更正) */
    timer_master_output_trigger_source_select(TIMER1,TIMER_TRI_OUT_SRC_ENABLE);    /* TRGO=CEN使能信号 */

    timer_interrupt_enable(TIMER1,TIMER_INT_CH0);    /* 使能TIMER1_CH0比较中断(NVIC未开启TIMER1中断,仅置标志) */
    timer_interrupt_enable(TIMER1,TIMER_INT_CH1);    /* 使能TIMER1_CH1比较中断(NVIC未开启TIMER1中断,仅置标志) */

    /* TIMER0配置(电机三相互补PWM) */
    timer_deinit(TIMER0);    /* 复位TIMER0 */

    timer_initpara.prescaler         = 0;    /* 预分频:0(计数频率120MHz) */
    timer_initpara.alignedmode       = TIMER_COUNTER_CENTER_DOWN;    /* 中央对齐模式(比较标志在向下计数时置位) */
    timer_initpara.counterdirection  = TIMER_COUNTER_UP;    /* 向上计数(中央对齐模式下计数方向由硬件控制) */
    timer_initpara.period            = MOTOR_PWM_PERIOD;    /* 自动重装载值(与TIMER1一致保证同步) */
    timer_initpara.clockdivision     = TIMER_CKDIV_DIV1;    /* 时钟分割:不分频(死区时钟基准t_DTS=1/120MHz) */
    timer_initpara.repetitioncounter = 0;    /* 重复计数器:0 */
    timer_init(TIMER0,&timer_initpara);    /* 初始化TIMER0时基 */

     /* CH0/CH0N,CH1/CH1N和CH2/CH2N通道结构体配置 */
    timer_ocintpara.outputstate  = TIMER_CCX_ENABLE;    /* 主输出通道使能 */
    timer_ocintpara.outputnstate = TIMER_CCXN_ENABLE;    /* 互补输出通道使能 */
    timer_ocintpara.ocpolarity   = TIMER_OC_POLARITY_HIGH;    /* 主输出高电平有效 */
    timer_ocintpara.ocnpolarity  = TIMER_OCN_POLARITY_HIGH;    /* 互补输出高电平有效 */
    timer_ocintpara.ocidlestate  = TIMER_OC_IDLE_STATE_LOW;    /* 空闲状态时主输出为低 */
    timer_ocintpara.ocnidlestate = TIMER_OCN_IDLE_STATE_LOW;    /* 空闲状态时互补输出为低 */

    timer_channel_output_config(TIMER0,TIMER_CH_0,&timer_ocintpara);    /* 配置TIMER0_CH0输出通道(W相) */
    timer_channel_output_config(TIMER0,TIMER_CH_1,&timer_ocintpara);    /* 配置TIMER0_CH1输出通道(V相) */
    timer_channel_output_config(TIMER0,TIMER_CH_2,&timer_ocintpara);    /* 配置TIMER0_CH2输出通道(U相) */
    timer_channel_output_config(TIMER0,TIMER_CH_3,&timer_ocintpara);    /* 配置TIMER0_CH3通道(无引脚输出,仅内部使用) */

    timer_channel_output_pulse_value_config(TIMER0,TIMER_CH_0,1000);    /* W相比较值初值1000(约27%占空比,由FOC更新) */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_0,TIMER_OC_MODE_PWM0);    /* W相输出模式PWM0 */
    timer_channel_output_shadow_config(TIMER0,TIMER_CH_0,TIMER_OC_SHADOW_ENABLE);    /* W相影子寄存器使能 */

    timer_channel_output_pulse_value_config(TIMER0,TIMER_CH_1,1000);    /* V相比较值初值1000 */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_1,TIMER_OC_MODE_PWM0);    /* V相输出模式PWM0 */
    timer_channel_output_shadow_config(TIMER0,TIMER_CH_1,TIMER_OC_SHADOW_ENABLE);    /* V相影子寄存器使能 */

    timer_channel_output_pulse_value_config(TIMER0,TIMER_CH_2,1000);    /* U相比较值初值1000 */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_2,TIMER_OC_MODE_PWM0);    /* U相输出模式PWM0 */
    timer_channel_output_shadow_config(TIMER0,TIMER_CH_2,TIMER_OC_SHADOW_ENABLE);    /* U相影子寄存器使能 */
    
    timer_channel_output_pulse_value_config(TIMER0,TIMER_CH_3,300);    /* CH3比较值300:向下计数匹配时触发FOC主循环中断 */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_3,TIMER_OC_MODE_PWM0);    /* CH3输出模式PWM0 */
    timer_channel_output_shadow_config(TIMER0,TIMER_CH_3,TIMER_OC_SHADOW_DISABLE);    /* CH3影子寄存器禁止 */


    /* 自动输出使能、刹车、死区和锁定配置 */
    timer_breakpara.runoffstate      = TIMER_ROS_STATE_ENABLE;    /* 运行模式关闭状态(ROS=1:MOE=1期间通道按CHxEN/CHxNEN正常输出) */
    timer_breakpara.ideloffstate     = TIMER_IOS_STATE_ENABLE ;    /* 空闲模式关闭状态选择:输出无效电平 */
    timer_breakpara.deadtime         = 0x88;        /* 1.2us */
    timer_breakpara.breakpolarity    = TIMER_BREAK_POLARITY_LOW;    /* 刹车输入低电平有效(BRK拉低触发保护) */
    timer_breakpara.outputautostate  = TIMER_OUTAUTO_ENABLE;    /* 自动输出使能:刹车恢复后更新事件自动重新使能主输出 */
    timer_breakpara.protectmode      = TIMER_CCHP_PROT_OFF;    /* 写保护:关闭 */
    timer_breakpara.breakstate       = TIMER_BREAK_ENABLE;    /* 使能刹车输入功能 */
    timer_break_config(TIMER0,&timer_breakpara);    /* 写入刹车/死区配置(更新CCHP寄存器) */
    
    /* TIMER0主输出使能 */
    timer_primary_output_config(TIMER0,ENABLE);    /* 使能主输出MOE(互补通道输出的总开关) */
    
    /* TIMER0从模式选择 */
    timer_slave_mode_select(TIMER0,TIMER_SLAVE_MODE_EVENT);    /* 从模式:触发模式(TRGI上升沿启动计数) */
    timer_input_trigger_source_select(TIMER0,TIMER_SMCFG_TRGSEL_ITI1);    /* 触发源:内部触发ITI1(来自TIMER1的TRGO) */

    /* TIMER0更新中断使能 */
/*    timer_interrupt_enable(TIMER0,TIMER_INT_UP);    (已注释停用:更新中断未使用) */
    /* TIMER0刹车中断使能 */
    timer_interrupt_enable(TIMER0,TIMER_INT_BRK);    /* 使能刹车中断(故障保护处理) */
    
    timer_interrupt_enable(TIMER0,TIMER_INT_CH3);    /* 使能CH3比较中断(每PWM周期触发一次FOC运算) */

    /* 定时器计数使能 */
/*    timer_enable(TIMER0);    (已注释停用:TIMER0由TIMER1的TRGO触发启动) */
    timer_enable(TIMER1);    /* 使能TIMER1计数(TRGO产生使能信号,同步启动TIMER0) */
}

/**
  * @brief ADC0配置(单电阻母线电流采样)
  * @param 无
  * @retval 无
  * @note ADC转换时间 = (12.5+采样时间) × (1/CLK_ADC)
  *       CLK_ADC = APB2 / 4 = 30MHz
  *       采样时间 = 1.5周期
  *       单通道ADC转换时间 = (12.5+1.5) × (1/30MHz) = 0.466us
  */
static void adc0_config(void)
{
    /* 使能ADC0时钟 */
    rcu_periph_clock_enable(RCU_ADC0);    /* 使能ADC0外设时钟 */
    /* 配置ADC时钟 */
    rcu_adc_clock_config(RCU_CKADC_CKAPB2_DIV4);    /* ADC时钟=APB2四分频=30MHz */
    
    /* ADC工作模式配置 */
    adc_mode_config(ADC_MODE_FREE);     /* 独立模式(ADC0/ADC1互不同步) */
    /* ADC特殊功能配置 */
    adc_special_function_config(ADC0, ADC_SCAN_MODE, DISABLE);    /* 扫描模式禁止(每次触发只转换一个通道) */
    adc_special_function_config(ADC0, ADC_CONTINUOUS_MODE, DISABLE);      /* 连续转换模式禁止(单次触发单次转换) */
    /* ADC数据对齐配置 */
    adc_data_alignment_config(ADC0, ADC_DATAALIGN_RIGHT);    /* 数据右对齐 */

    /* 注入组通道长度配置 */
    adc_channel_length_config(ADC0, ADC_INSERTED_CHANNEL, 1);    /* 注入组序列长度1(仅1个通道) */
    /* 注入组通道配置 */
    /* 注入组序位0挂接母线电流通道IDC(PB1),采样时间1.5周期 */
    adc_inserted_channel_config(ADC0, IDC_INSERTED_CHANNEL, IDC_ADC_CHANNEL, ADC_SAMPLETIME_1POINT5);
/*    adc_inserted_channel_config(ADC0, ONE_SHUNT_IDC_AVER_INSERTED_CHANNEL, IDC_AVER_ADC_CHANNEL, ADC_SAMPLETIME_1POINT5);    (已注释停用:本版注入组仅1通道,平均值通道未启用) */
    /* ADC外部触发配置 */
    /* 注入组触发源:TIMER1_CH0比较事件(硬件外部触发) */
    adc_external_trigger_source_config(ADC0, ADC_INSERTED_CHANNEL, ADC0_1_EXTTRIG_INSERTED_T1_CH0); 
    /* ADC外部触发使能 */
    adc_external_trigger_config(ADC0, ADC_INSERTED_CHANNEL, ENABLE);    /* 使能注入组硬件外部触发 */
    
    
    /* 规则组通道长度配置 */
    adc_channel_length_config(ADC0, ADC_REGULAR_CHANNEL, 1);    /* 规则组序列长度1 */
    /* 规则组通道配置 */
    /* 规则组序位0挂接母线电流通道IDC(PB1),与注入组同一信号 */
    adc_regular_channel_config(ADC0, 0, IDC_ADC_CHANNEL, ADC_SAMPLETIME_1POINT5);
    /* ADC外部触发配置 */
    /* 规则组触发源:TIMER1_CH1比较事件(硬件外部触发) */
    adc_external_trigger_source_config(ADC0, ADC_REGULAR_CHANNEL, ADC0_1_EXTTRIG_REGULAR_T1_CH1); 
    /* ADC外部触发使能 */
    adc_external_trigger_config(ADC0, ADC_REGULAR_CHANNEL, ENABLE);    /* 使能规则组硬件外部触发 */
    
    
    /* 清除ADC中断标志 */
    adc_interrupt_flag_clear(ADC0, ADC_INT_FLAG_EOC);    /* 清除规则组转换完成标志 */
    adc_interrupt_flag_clear(ADC0, ADC_INT_FLAG_EOIC);    /* 清除注入组转换完成标志 */
    /* 使能ADC中断 */
/*    adc_interrupt_enable(ADC0, ADC_INT_FLAG_EOC);    (已注释停用:本版不使用ADC中断,FOC中断中直接读取数据) */
/*    adc_interrupt_enable(ADC0, ADC_INT_FLAG_EOIC);    (已注释停用:同上) */

    /* 使能ADC接口 */
    adc_enable(ADC0);    /* 使能ADC0 */
    systick_delay(1);    /* 上电稳定延时1ms */
    /* ADC校准并复位校准 */
    adc_calibration_enable(ADC0);    /* 启动ADC自校准 */
}

/**
  * @brief 霍尔定时器TIMER2配置(输入捕获)
  * @param 无
  * @retval 无
  */
static void hall_timer_config(void)
{
    /* TIMER2配置:输入捕获模式 */
    timer_ic_parameter_struct timer_icinitpara;    /* 输入捕获通道配置结构体 */
    timer_parameter_struct timer_initpara;    /* 定时器时基配置结构体 */

    rcu_periph_clock_enable(RCU_TIMER2);    /* 使能TIMER2时钟 */

    timer_deinit(TIMER2);    /* 复位TIMER2 */

    /* TIMER2时基配置 */
    timer_initpara.prescaler         = HALL_TIMER_PRESCALER;    /* 预分频119:计数频率1MHz */
    timer_initpara.alignedmode       = TIMER_COUNTER_EDGE;    /* 边沿对齐计数模式 */
    timer_initpara.counterdirection  = TIMER_COUNTER_UP;    /* 向上计数 */
    timer_initpara.period            = 0xFFFF;    /* 自动重装载值:最大65535 */
    timer_initpara.clockdivision     = TIMER_CKDIV_DIV1;    /* 时钟分割:不分频 */
    timer_initpara.repetitioncounter = 0;    /* 重复计数器:0 */
    timer_init(TIMER2,&timer_initpara);    /* 初始化TIMER2时基 */

    /* TIMER2配置 */
    /* TIMER2三通道输入捕获参数配置(CH0/CH1/CH2均为上升沿捕获) */
    timer_icinitpara.icpolarity  = TIMER_IC_POLARITY_RISING;    /* 上升沿触发捕获 */
    timer_icinitpara.icselection = TIMER_IC_SELECTION_ITS;    /* 捕获通道输入源选择:TRC(内部触发输入) */
    timer_icinitpara.icprescaler = TIMER_IC_PSC_DIV1;    /* 捕获分频:不分频(每个有效边沿都捕获) */
    timer_icinitpara.icfilter    = 0x0;    /* 输入滤波器:0(不滤波) */
    timer_input_capture_config(TIMER2,TIMER_CH_0,&timer_icinitpara);    /* 配置TIMER2_CH0输入捕获 */
    
    timer_icinitpara.icpolarity  = TIMER_IC_POLARITY_RISING;    /* 上升沿触发捕获 */
    timer_icinitpara.icselection = TIMER_IC_SELECTION_ITS;    /* 捕获通道输入源选择:TRC(内部触发输入) */
    timer_icinitpara.icprescaler = TIMER_IC_PSC_DIV1;    /* 捕获分频:不分频(每个有效边沿都捕获) */
    timer_icinitpara.icfilter    = 0x0;    /* 输入滤波器:0(不滤波) */
    timer_input_capture_config(TIMER2,TIMER_CH_1,&timer_icinitpara);    /* 配置TIMER2_CH1输入捕获 */
    
    timer_icinitpara.icpolarity  = TIMER_IC_POLARITY_RISING;    /* 上升沿触发捕获 */
    timer_icinitpara.icselection = TIMER_IC_SELECTION_ITS;    /* 捕获通道输入源选择:TRC(内部触发输入) */
    timer_icinitpara.icprescaler = TIMER_IC_PSC_DIV1;    /* 捕获分频:不分频(每个有效边沿都捕获) */
    timer_icinitpara.icfilter    = 0x0;    /* 输入滤波器:0(不滤波) */
    timer_input_capture_config(TIMER2,TIMER_CH_2,&timer_icinitpara);    /* 配置TIMER2_CH2输入捕获 */
    
    /* TIMER2从模式选择 */
    timer_input_trigger_source_select(TIMER2,TIMER_SMCFG_TRGSEL_CI0F_ED);    /* 触发源:CH0滤波后任意边沿(霍尔任一相跳变) */
    timer_slave_mode_select(TIMER2,TIMER_SLAVE_MODE_RESTART);    /* 从模式:复位模式(触发时计数器复位重新计数) */
    
    /* 霍尔模式配置 */
    timer_hall_mode_config(TIMER2, TIMER_HALLINTERFACE_ENABLE);    /* 使能霍尔接口(CH0输入=三路霍尔信号异或) */

    /* 自动重装载预装载使能 */
    timer_auto_reload_shadow_enable(TIMER2);    /* ARR影子寄存器使能 */
    /* 清除通道0中断标志 */
    timer_interrupt_flag_clear(TIMER2,TIMER_INT_FLAG_CH0);    /* 清除CH0捕获中断标志 */
    /* 通道0中断使能 */
    timer_interrupt_enable(TIMER2,TIMER_INT_CH0);    /* 使能CH0捕获中断 */

    /* TIMER2计数器使能 */
    timer_enable(TIMER2);    /* 启动TIMER2计数 */
}

/***************************************** 文件结束 *********************************************/
