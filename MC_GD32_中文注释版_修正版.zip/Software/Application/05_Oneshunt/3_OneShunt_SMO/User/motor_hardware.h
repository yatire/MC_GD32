/*
*******************************************************************************************************
*
* 文件名称 : motor_hardware.h
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 电机控制硬件配置头文件(PWM/ADC采样/霍尔/用户IO引脚定义,单电阻SMO方案)
* 
*******************************************************************************************************
*/
#ifndef _MOTOR_HARDWARE_H_    /* 头文件保护宏,防止重复包含 */
#define _MOTOR_HARDWARE_H_    /* 定义头文件保护宏 */

#ifdef __cplusplus    /* C++编译兼容处理 */
extern "C"{    /* 按C语言方式导出接口 */
#endif    /* 结束条件编译 */

/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "gd32f30x.h"    /* GD32F30x固件库总头文件 */
#include "motor_config.h"    /* 电机硬件参数配置(PWM频率/电流电压换算系数等) */


/* 宏定义 ------------------------------------------------------------------------------------------*/
#define MOTOR_PWM_TIMER     TIMER0    /* 电机PWM定时器:TIMER0高级定时器(互补输出+死区) */
#define PWM_U_CHANNEL       TIMER_CH_2    /* U相PWM输出通道(TIMER0_CH2) */
#define PWM_V_CHANNEL       TIMER_CH_1    /* V相PWM输出通道(TIMER0_CH1) */
#define PWM_W_CHANNEL       TIMER_CH_0    /* W相PWM输出通道(TIMER0_CH0) */

#define PWM_UH_GPIO_PORT    GPIOA    /* U相上桥臂PWM输出端口 */
#define PWM_UH_GPIO_PIN     GPIO_PIN_10    /* U相上桥臂PWM输出引脚PA10(TIMER0_CH2) */
#define PWM_VH_GPIO_PORT    GPIOA    /* V相上桥臂PWM输出端口 */
#define PWM_VH_GPIO_PIN     GPIO_PIN_9    /* V相上桥臂PWM输出引脚PA9(TIMER0_CH1) */
#define PWM_WH_GPIO_PORT    GPIOA    /* W相上桥臂PWM输出端口 */
#define PWM_WH_GPIO_PIN     GPIO_PIN_8    /* W相上桥臂PWM输出引脚PA8(TIMER0_CH0) */

#define PWM_UL_GPIO_PORT    GPIOB    /* U相下桥臂PWM输出端口 */
#define PWM_UL_GPIO_PIN     GPIO_PIN_15    /* U相下桥臂PWM输出引脚PB15(TIMER0_CH2N互补输出) */
#define PWM_VL_GPIO_PORT    GPIOB    /* V相下桥臂PWM输出端口 */
#define PWM_VL_GPIO_PIN     GPIO_PIN_14    /* V相下桥臂PWM输出引脚PB14(TIMER0_CH1N互补输出) */
#define PWM_WL_GPIO_PORT    GPIOB    /* W相下桥臂PWM输出端口 */
#define PWM_WL_GPIO_PIN     GPIO_PIN_13    /* W相下桥臂PWM输出引脚PB13(TIMER0_CH0N互补输出) */

#define PWM_BKIN_GPIO_PORT    GPIOB    /* 刹车输入(BKIN)端口 */
#define PWM_BKIN_GPIO_PIN     GPIO_PIN_12    /* 刹车输入(BKIN)引脚PB12 */

#define MOTOR_CURRENT_ADC       ADC0    /* 电流采样ADC外设(ADC0) */
#define IU_INSERTED_CHANNEL     ADC_INSERTED_CHANNEL_0    /* U相电流ADC注入组序位0(单电阻方案中挂接母线电流) */
#define IV_INSERTED_CHANNEL     ADC_INSERTED_CHANNEL_1    /* V相电流ADC注入组序位1(本方案未使用) */
#define IW_INSERTED_CHANNEL     ADC_INSERTED_CHANNEL_2    /* W相电流ADC注入组序位2(本方案未使用) */
#define IDC_AVER_INSERTED_CHANNEL    ADC_INSERTED_CHANNEL_3    /* 母线平均电流ADC注入组序位3(本方案未使用) */

/* 单电阻采样:注入组实际挂接的通道序位(经adc0_config核对,仅使用序位0) */
#define IDC_INSERTED_CHANNEL                    ADC_INSERTED_CHANNEL_0    /* 母线电流(单电阻采样)ADC注入组序位0 */
#define ONE_SHUNT_IDC_AVER_INSERTED_CHANNEL     ADC_INSERTED_CHANNEL_1    /* 母线平均电流ADC注入组序位1(当前未启用) */

#define IU_ADC_PORT         GPIOC    /* U相电流采样端口 */
#define IU_ADC_PIN          GPIO_PIN_4    /* U相电流采样引脚PC4 */
#define IU_ADC_CLK          RCU_GPIOC    /* U相电流采样端口时钟 */
#define IU_ADC_CHANNEL      ADC_CHANNEL_14    /* U相电流采样ADC通道14 */

#define IV_ADC_PORT         GPIOC    /* V相电流采样端口 */
#define IV_ADC_PIN          GPIO_PIN_5    /* V相电流采样引脚PC5 */
#define IV_ADC_CLK          RCU_GPIOC    /* V相电流采样端口时钟 */
#define IV_ADC_CHANNEL      ADC_CHANNEL_15    /* V相电流采样ADC通道15 */

#define IW_ADC_PORT         GPIOB    /* W相电流采样端口 */
#define IW_ADC_PIN          GPIO_PIN_0    /* W相电流采样引脚PB0 */
#define IW_ADC_CLK          RCU_GPIOB    /* W相电流采样端口时钟 */
#define IW_ADC_CHANNEL      ADC_CHANNEL_8    /* W相电流采样ADC通道8 */

#define IDC_ADC_PORT        GPIOB    /* 母线电流采样端口 */
#define IDC_ADC_PIN         GPIO_PIN_1    /* 母线电流采样引脚PB1(单电阻采样输入) */
#define IDC_ADC_CLK         RCU_GPIOB    /* 母线电流采样端口时钟 */
#define IDC_ADC_CHANNEL     ADC_CHANNEL_9    /* 母线电流采样ADC通道9 */

#define IDC_AVER_ADC_PORT        GPIOA    /* 母线平均电流采样端口 */
#define IDC_AVER_ADC_PIN         GPIO_PIN_3    /* 母线平均电流采样引脚PA3 */
#define IDC_AVER_ADC_CLK         RCU_GPIOA    /* 母线平均电流采样端口时钟 */
#define IDC_AVER_ADC_CHANNEL     ADC_CHANNEL_3    /* 母线平均电流采样ADC通道3 */

#define BEMFU_ADC_PORT      GPIOA    /* U相反电动势采样端口 */
#define BEMFU_ADC_PIN       GPIO_PIN_0    /* U相反电动势采样引脚PA0 */
#define BEMFU_ADC_CLK       RCU_GPIOA    /* U相反电动势采样端口时钟 */
#define BEMFU_ADC_CHANNEL   ADC_CHANNEL_0    /* U相反电动势采样ADC通道0 */

#define BEMFV_ADC_PORT      GPIOA    /* V相反电动势采样端口 */
#define BEMFV_ADC_PIN       GPIO_PIN_1    /* V相反电动势采样引脚PA1 */
#define BEMFV_ADC_CLK       RCU_GPIOA    /* V相反电动势采样端口时钟 */
#define BEMFV_ADC_CHANNEL   ADC_CHANNEL_1    /* V相反电动势采样ADC通道1 */

#define BEMFW_ADC_PORT      GPIOA    /* W相反电动势采样端口 */
#define BEMFW_ADC_PIN       GPIO_PIN_2    /* W相反电动势采样引脚PA2 */
#define BEMFW_ADC_CLK       RCU_GPIOA    /* W相反电动势采样端口时钟 */
#define BEMFW_ADC_CHANNEL   ADC_CHANNEL_2    /* W相反电动势采样ADC通道2 */

#define USER_IO1_PORT       GPIOB    /* 用户IO1端口 */
#define USER_IO1_PIN        GPIO_PIN_6    /* 用户IO1引脚PB6 */
#define USER_IO1_CLK        RCU_GPIOB    /* 用户IO1端口时钟 */

#define USER_IO3_PORT       GPIOC    /* 用户IO3端口 */
#define USER_IO3_PIN        GPIO_PIN_0    /* 用户IO3引脚PC0 */
#define USER_IO3_CLK        RCU_GPIOC    /* 用户IO3端口时钟 */

#define USER_IO2_PORT       GPIOB    /* 用户IO2端口 */
#define USER_IO2_PIN        GPIO_PIN_7    /* 用户IO2引脚PB7 */
#define USER_IO2_CLK        RCU_GPIOB    /* 用户IO2端口时钟 */

#define HALLA_GPIO_PORT     GPIOC    /* 霍尔传感器A相端口 */
#define HALLA_GPIO_PIN      GPIO_PIN_6    /* 霍尔传感器A相引脚PC6(TIMER2_CH0) */
#define HALLA_GPIO_CLK      RCU_GPIOC    /* 霍尔传感器A相端口时钟 */

#define HALLB_GPIO_PORT     GPIOC    /* 霍尔传感器B相端口 */
#define HALLB_GPIO_PIN      GPIO_PIN_7    /* 霍尔传感器B相引脚PC7(TIMER2_CH1) */
#define HALLB_GPIO_CLK      RCU_GPIOC    /* 霍尔传感器B相端口时钟 */

#define HALLC_GPIO_PORT     GPIOC    /* 霍尔传感器C相端口 */
#define HALLC_GPIO_PIN      GPIO_PIN_8    /* 霍尔传感器C相引脚PC8(TIMER2_CH2) */
#define HALLC_GPIO_CLK      RCU_GPIOC    /* 霍尔传感器C相端口时钟 */

/* 变量定义 ----------------------------------------------------------------------------------------*/


/* 函数定义 -----------------------------------------------------------------------------------------*/
void motor_hardware_init(void);    /* 电机硬件总初始化(PWM/ADC/霍尔等) */
void adc0_init(void);    /* ADC0初始化(注入组/规则组由TIMER1 CH0/CH1触发,单电阻母线电流采样) */
void interrupt_init(void);    /* 中断初始化(NVIC优先级配置) */
void comp_protect_init(void);    /* 过流保护初始化(DAC1经PA5输出比较器过流阈值) */
void hall_init(void);    /* 霍尔传感器初始化(TIMER2霍尔异或接口,PC6/7/8) */
uint8_t hall_get(void);    /* 读取霍尔状态(A/B/C三位组合) */
void motor_pwm_set_duty(uint16_t duty_u,uint16_t duty_v,uint16_t duty_w);    /* 设置三相PWM占空比 */
/* 设置ADC采样触发点(TIMER1 CH0/CH1比较值) */
void motor_pwm_set_adc_trigger_point(uint16_t trigger_point0, uint16_t trigger_point1);
void motor_get_phase_current_adc(int16_t *p_ia, int16_t *p_ib);    /* 读取电流ADC原始值(注入组母线电流+规则组,供单电阻重构) */
void motor_pwm_pin_disable(void);    /* 6个PWM引脚切为普通GPIO输出并全部拉低(封锁输出) */
void motor_pwm_pin_enable(void);    /* 6个PWM引脚恢复定时器复用推挽输出 */
void motor_pwm_disable(void);    /* 关闭三相PWM正/互补通道输出(CHx/CHxN) */
void motor_pwm_enable(void);    /* 使能三相PWM正/互补通道输出(CHx/CHxN) */

#ifdef __cplusplus    /* C++编译兼容处理 */
extern "C"{    /* 按C语言方式导出接口(此块为文件尾重复的历史遗留写法,原样保留) */
#endif    /* 结束条件编译 */

#endif /* _MOTOR_HARDWARE_H_ */

/***************************************** 文件结束 *********************************************/
