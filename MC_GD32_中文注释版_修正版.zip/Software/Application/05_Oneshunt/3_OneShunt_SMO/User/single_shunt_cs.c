/*
*******************************************************************************************************
*
* 文件名称 : single_shunt_cs.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 单电阻电流采样文件
*
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include <stddef.h>                                  /* 标准定义头文件（NULL等通用定义） */
#include "single_shunt_cs.h"                         /* 单电阻电流采样模块头文件 */
#include "motor_hardware.h"                          /* 电机硬件层头文件（PWM周期、ADC采样接口等） */
#include "foc.h"                                     /* FOC矢量控制算法头文件 */
#include "pmsm.h"                                    /* PMSM电机模型头文件（FOC参数结构体、电流换算系数） */
/* 宏定义 ------------------------------------------------------------------------------------------*/
#define MIN_EDGE_WIDTH  50                           /* 最小边沿宽度（PWM计数值），占空比移位时保证的最小窗口余量 */

#define ONE_SHUNT_IA    0x01                         /* 采样模式标志位：第一采样点有效（可重构最小占空比相电流） */
#define ONE_SHUNT_IB    0X02                         /* 采样模式标志位：第二采样点有效（可重构最大占空比相电流） */
#define ONE_SHUNT_IAIB  (ONE_SHUNT_IA|ONE_SHUNT_IB)  /* 采样模式标志位：两个采样点均有效（IA|IB按位或） */

/* 变量定义 ----------------------------------------------------------------------------------------*/
int32_t duty_u_offset = 0;                           /* U相占空比偏移量（PWM计数值，用于采样点移相补偿） */
int32_t duty_v_offset = 0;                           /* V相占空比偏移量（PWM计数值，用于采样点移相补偿） */
int32_t duty_w_offset = 0;                           /* W相占空比偏移量（PWM计数值，用于采样点移相补偿） */
uint16_t trigger_point1 = 0;                         /* 第一ADC触发点（PWM计数值，对应最小占空比相） */
uint16_t trigger_point2 = 0;                         /* 第二ADC触发点（PWM计数值，对应中间占空比相） */
int32_t duty_u = 0;                                  /* U相占空比（PWM计数值，可被移位函数就地修改） */
int32_t duty_v = 0;                                  /* V相占空比（PWM计数值，可被移位函数就地修改） */
int32_t duty_w = 0;                                  /* W相占空比（PWM计数值，可被移位函数就地修改） */
uint32_t _pwm_period = MOTOR_PWM_PERIOD;             /* PWM周期计数值（初值取电机配置的PWM周期宏） */
uint16_t t_sample_delay_cycle = MOTOR_PWM_PERIOD / 20;   /* 采样延迟计数值（初值=PWM周期/20，初始化时按死区等时间校准） */
uint16_t t_min_dur_cycle = MOTOR_PWM_PERIOD / 10;        /* 最小采样持续时间计数值（初值=PWM周期/10，初始化时校准） */

int16_t signle_shunt_ia = 0;                         /* 第一采样点母线电流ADC值（对应最小相电流的负值） */
int16_t signle_shunt_ib = 0;                         /* 第二采样点母线电流ADC值（对应最大相电流） */

uint8_t sector_last = 0;                             /* 上一PWM周期的SVPWM扇区号（1~6） */

uint8_t sample_mode = 0;                             /* 本周期采样模式（ONE_SHUNT_IA/IB按位组合） */
uint8_t sample_mode_last = 0;                        /* 上一周期采样模式（电流重构时按此选择公式） */

uint32_t idc_offset = 0;                             /* 母线电流ADC零点偏置（多次采样平均值） */
uint32_t idc_offset_sum = 0;                         /* 零点偏置累加和（用于求平均） */
uint8_t adc_calibration;                             /* 零点标定完成标志（0=标定中，1=已完成） */

/* 函数定义 -----------------------------------------------------------------------------------------*/

/**
  * @brief 相电流采样初始化
  * @param 无
  * @retval 无
  * @note
  */
void motor_phase_current_sampling_init(void)
{
    float sample_delay_time = 0;                 /* 采样延迟时间（秒，死区+驱动延迟+振荡稳定时间） */
    float sample_time = 0;                       /* ADC采样保持时间（秒） */
    float min_dur_time = 0;                      /* 最小采样窗口时间（秒）= 采样延迟+采样时间 */
    float pwm_period_time = 0;                   /* PWM周期时间（秒） */

    sample_time = CIRCUIT_SAMPLE_TIME_S;         /* 读取电路ADC采样保持时间 */
    /* 采样延迟时间 = 死区时间 + PWM输出延迟时间 + 采样振荡稳定时间 */
    sample_delay_time = CIRCUIT_DEAD_TIME_S + CIRCUIT_PWM_DELAY_TIME_S + CIRCUIT_SAMPLE_VIBRATE_TIME_S;
    pwm_period_time = (1.0f / MOTOR_PWM_FREQ_HZ);   /* 计算PWM周期时间 = 1/PWM频率（秒） */
    min_dur_time = sample_delay_time + sample_time; /* 最小采样窗口时间 = 采样延迟 + 采样时间 */
    /* 采样延迟时间换算为PWM计数值（+1留余量） */
    t_sample_delay_cycle = (uint16_t)(sample_delay_time * (float)_pwm_period / pwm_period_time) + 1;
    /* 最小采样窗口时间换算为PWM计数值（+1留余量） */
    t_min_dur_cycle = (uint16_t)(min_dur_time * (float)_pwm_period / pwm_period_time) + 1;
}

/**
  * @brief 母线电流零点偏置标定
  * @param 无
  * @retval 无
  * @note
  */
void motor_get_phase_current_zero(void)
{
    if(adc_calibration == 0)                         /* 尚未完成零点标定时循环采集 */
    {
        static uint16_t cnt = 0;                     /* 标定采样次数计数器（静态变量，跨调用保持） */
        int16_t adc_dc0 = 0;                         /* ADC通道0采样值（母线电流） */
        int16_t adc_dc1 = 0;                         /* ADC通道1采样值 */
        cnt++;                                       /* 采样次数累加 */
        motor_get_phase_current_adc(&adc_dc0,&adc_dc1);   /* 读取母线电流两路ADC采样值 */
        idc_offset_sum += adc_dc0;                   /* 累加通道0采样值用于求零点均值 */
        if(cnt >= (1<<10))                           /* 累计1024次后求平均并结束标定 */
        {
            int16_t error = 0;                       /* 零点偏置与ADC量程中点的偏差 */
            adc_calibration = 1;                     /* 置零点标定完成标志 */
            idc_offset = idc_offset_sum >> 10;       /* 右移10位（除以1024）得到平均零点偏置 */
            error = idc_offset - (ADC_FULL_BIT >> 1);     /* 计算偏置与ADC量程中点的偏差 */
            if((error > 500) || (error < -500))      /* 偏差超出±500说明零点采样异常 */
            {
                idc_offset = ADC_FULL_BIT >> 1;      /* 改用ADC量程中点作为零点偏置 */
            }
        }
    }
}

/**
  * @brief 3相电流采样重构
  * @param sector-SVPWM扇区
  * @retval 无
  * @note
  */
void motor_get_phase_current(uint8_t sector)
{
    float iu = 0,iv = 0,iw = 0;                          /* 三相重构电流（ADC码值，iu/iv/iw对应U/V/W相） */
        motor_get_phase_current_adc(&signle_shunt_ia,&signle_shunt_ib);   /* 读取两个采样点的母线电流ADC值 */
    signle_shunt_ia = signle_shunt_ia - idc_offset;      /* 第一采样值减去零点偏置 */
    signle_shunt_ib = signle_shunt_ib - idc_offset;      /* 第二采样值减去零点偏置 */


    if(sample_mode_last == ONE_SHUNT_IAIB)               /* 上一周期两个采样点均有效 */
    {
        switch(sector_last)                              /* 按上一周期扇区号选择重构公式 */
        {
            case 1:                                      /* 扇区1：U相占空比最大、V相居中、W相最小 */
                iw = -signle_shunt_ia;                   /* W相电流 = -第一采样值（最小相下管导通窗口内采样） */
                iu =  signle_shunt_ib;                   /* U相电流 = 第二采样值（最大相电流） */
                iv = 0 + signle_shunt_ia - signle_shunt_ib;   /* V相电流由KCL求出：iv = -(iu+iw) */
                break;
            case 2:                                      /* 扇区2：V相占空比最大、U相居中、W相最小 */
                iw = -signle_shunt_ia;                   /* W相电流 = -第一采样值（最小相下管导通窗口内采样） */
                iv =  signle_shunt_ib;                   /* V相电流 = 第二采样值（最大相电流） */
                iu = 0 + signle_shunt_ia - signle_shunt_ib;   /* U相电流由KCL求出：iu = -(iv+iw) */
                break;
            case 3:                                      /* 扇区3：V相占空比最大、W相居中、U相最小 */
                iu = -signle_shunt_ia;                   /* U相电流 = -第一采样值（最小相下管导通窗口内采样） */
                iv =  signle_shunt_ib;                   /* V相电流 = 第二采样值（最大相电流） */
                iw = 0 + signle_shunt_ia - signle_shunt_ib;   /* W相电流由KCL求出：iw = -(iu+iv) */
                break;
            case 4:                                      /* 扇区4：W相占空比最大、V相居中、U相最小 */
                iu = -signle_shunt_ia;                   /* U相电流 = -第一采样值（最小相下管导通窗口内采样） */
                iw =  signle_shunt_ib;                   /* W相电流 = 第二采样值（最大相电流） */
                iv = 0 + signle_shunt_ia - signle_shunt_ib;   /* V相电流由KCL求出：iv = -(iu+iw) */
                break;
            case 5:                                      /* 扇区5：W相占空比最大、U相居中、V相最小 */
                iv = -signle_shunt_ia;                   /* V相电流 = -第一采样值（最小相下管导通窗口内采样） */
                iw =  signle_shunt_ib;                   /* W相电流 = 第二采样值（最大相电流） */
                iu = 0 + signle_shunt_ia - signle_shunt_ib;   /* U相电流由KCL求出：iu = -(iv+iw) */
                break;
            case 6:                                      /* 扇区6：U相占空比最大、W相居中、V相最小 */
                iv = -signle_shunt_ia;                   /* V相电流 = -第一采样值（最小相下管导通窗口内采样） */
                iu =  signle_shunt_ib;                   /* U相电流 = 第二采样值（最大相电流） */
                iw = 0 + signle_shunt_ia - signle_shunt_ib;   /* W相电流由KCL求出：iw = -(iu+iv) */
                break;
            default:
                break;
        }
    }
    else if(sample_mode_last == ONE_SHUNT_IA)            /* 上一周期仅第一采样点有效 */
    {
        switch(sector_last)                              /* 按上一周期扇区号选择重构公式 */
        {
            case 1:                                      /* 扇区1最小相为W：仅可重构W相电流 */
                iw = -signle_shunt_ia;                   /* W相电流 = -第一采样值 */
                break;
            case 2:                                      /* 扇区2最小相为W：仅可重构W相电流 */
                iw = -signle_shunt_ia;                   /* W相电流 = -第一采样值 */
                break;
            case 3:                                      /* 扇区3最小相为U：仅可重构U相电流 */
                iu = -signle_shunt_ia;                   /* U相电流 = -第一采样值 */
                break;
            case 4:                                      /* 扇区4最小相为U：仅可重构U相电流 */
                iu = -signle_shunt_ia;                   /* U相电流 = -第一采样值 */
                break;
            case 5:                                      /* 扇区5最小相为V：仅可重构V相电流 */
                iv = -signle_shunt_ia;                   /* V相电流 = -第一采样值 */
                break;
            case 6:                                      /* 扇区6最小相为V：仅可重构V相电流 */
                iv = -signle_shunt_ia;                   /* V相电流 = -第一采样值 */
                break;
            default:
                break;
        }
    }
    else if(sample_mode_last == ONE_SHUNT_IB)            /* 上一周期仅第二采样点有效 */
    {
        switch(sector_last)                              /* 按上一周期扇区号选择重构公式 */
        {
            case 1:                                      /* 扇区1最大相为U：仅可重构U相电流 */
                iu =  signle_shunt_ib;                   /* U相电流 = 第二采样值 */
                break;
            case 2:                                      /* 扇区2最大相为V：仅可重构V相电流 */
                iv =  signle_shunt_ib;                   /* V相电流 = 第二采样值 */
                break;
            case 3:                                      /* 扇区3最大相为V：仅可重构V相电流 */
                iv =  signle_shunt_ib;                   /* V相电流 = 第二采样值 */
                break;
            case 4:                                      /* 扇区4最大相为W：仅可重构W相电流 */
                iw =  signle_shunt_ib;                   /* W相电流 = 第二采样值 */
                break;
            case 5:                                      /* 扇区5最大相为W：仅可重构W相电流 */
                iw =  signle_shunt_ib;                   /* W相电流 = 第二采样值 */
                break;
            case 6:                                      /* 扇区6最大相为U：仅可重构U相电流 */
                iu =  signle_shunt_ib;                   /* U相电流 = 第二采样值 */
                break;
            default:
                break;
        }
    }
    else
    {
        sector_last = sector;                            /* 采样模式无效时仅更新扇区记录 */
    }
    sector_last = sector;                                /* 记录本周期扇区号供下一周期重构使用 */

    pmsm_foc_param.ia = iu * ADC_TO_CURRENT_COEF;        /* U相电流（A相）乘系数换算为安培存入FOC参数 */
    pmsm_foc_param.ib = iv * ADC_TO_CURRENT_COEF;        /* V相电流（B相）乘系数换算为安培存入FOC参数 */
    pmsm_foc_param.ic = iw * ADC_TO_CURRENT_COEF;        /* W相电流（C相）乘系数换算为安培存入FOC参数 */
}


/**
  * @brief 相电流采样点偏移
  * @param sector-SVPWM扇区
  * @retval 无
  * @note 单电阻采样方式,需要根据PWM占空比在合适位置采样,当某两相的占空比相等时,
          采样窗口时间为0,所以需要进行偏移
  */
void motor_phase_current_sampling_shift(uint8_t sector)
{
        /* 带PWM相位偏移的采样点设置 */
        int32_t *duty_min = NULL, *duty_mid = NULL, *duty_max = NULL;      /* 指向最小/中间/最大占空比变量的指针 */
        /* 指向对应相占空比偏移量变量的指针 */
        int32_t *duty_min_offset = NULL, *duty_mid_offset = NULL, *duty_max_offset = NULL;

        /* 计算占空比最小值 中间值 最大值 */
    trigger_point1  = 0;                         /* 清零第一ADC触发点 */
    trigger_point2 = 0;                          /* 清零第二ADC触发点 */
    duty_u_offset = 0;                           /* 清零U相占空比偏移量 */
    duty_v_offset = 0;                           /* 清零V相占空比偏移量 */
    duty_w_offset = 0;                           /* 清零W相占空比偏移量 */
    sample_mode_last = sample_mode;              /* 保存本周期采样模式，供下一周期电流重构判断 */

        /* 按当前扇区建立最大/中间/最小占空比指针映射 */
        switch(sector)
        {
                case 1:                          /* 扇区1：U相占空比最大、V相居中、W相最小 */
                        duty_max = &duty_u;              /* 最大占空比指针指向U相占空比 */
                        duty_min = &duty_w;              /* 最小占空比指针指向W相占空比 */
                        duty_mid = &duty_v;              /* 中间占空比指针指向V相占空比 */
                        duty_max_offset = &duty_u_offset;    /* 最大相偏移指针指向U相偏移量 */
                        duty_min_offset = &duty_w_offset;    /* 最小相偏移指针指向W相偏移量 */
                        duty_mid_offset = &duty_v_offset;    /* 中间相偏移指针指向V相偏移量 */
                        break;                           /* 结束本case */
                case 2:                          /* 扇区2：V相占空比最大、U相居中、W相最小 */
                        duty_max = &duty_v;              /* 最大占空比指针指向V相占空比 */
                        duty_min = &duty_w;              /* 最小占空比指针指向W相占空比 */
                        duty_mid = &duty_u;              /* 中间占空比指针指向U相占空比 */
                        duty_max_offset = &duty_v_offset;    /* 最大相偏移指针指向V相偏移量 */
                        duty_min_offset = &duty_w_offset;    /* 最小相偏移指针指向W相偏移量 */
                        duty_mid_offset = &duty_u_offset;    /* 中间相偏移指针指向U相偏移量 */
                        break;                           /* 结束本case */
                case 3:                          /* 扇区3：V相占空比最大、W相居中、U相最小 */
                        duty_max = &duty_v;              /* 最大占空比指针指向V相占空比 */
                        duty_min = &duty_u;              /* 最小占空比指针指向U相占空比 */
                        duty_mid = &duty_w;              /* 中间占空比指针指向W相占空比 */
                        duty_max_offset = &duty_v_offset;    /* 最大相偏移指针指向V相偏移量 */
                        duty_min_offset = &duty_u_offset;    /* 最小相偏移指针指向U相偏移量 */
                        duty_mid_offset = &duty_w_offset;    /* 中间相偏移指针指向W相偏移量 */
                        break;                           /* 结束本case */
                case 4:                          /* 扇区4：W相占空比最大、V相居中、U相最小 */
                        duty_max = &duty_w;              /* 最大占空比指针指向W相占空比 */
                        duty_min = &duty_u;              /* 最小占空比指针指向U相占空比 */
                        duty_mid = &duty_v;              /* 中间占空比指针指向V相占空比 */
                        duty_max_offset = &duty_w_offset;    /* 最大相偏移指针指向W相偏移量 */
                        duty_min_offset = &duty_u_offset;    /* 最小相偏移指针指向U相偏移量 */
                        duty_mid_offset = &duty_v_offset;    /* 中间相偏移指针指向V相偏移量 */
                        break;                           /* 结束本case */
                case 5:                          /* 扇区5：W相占空比最大、U相居中、V相最小 */
                        duty_max = &duty_w;              /* 最大占空比指针指向W相占空比 */
                        duty_min = &duty_v;              /* 最小占空比指针指向V相占空比 */
                        duty_mid = &duty_u;              /* 中间占空比指针指向U相占空比 */
                        duty_max_offset = &duty_w_offset;    /* 最大相偏移指针指向W相偏移量 */
                        duty_min_offset = &duty_v_offset;    /* 最小相偏移指针指向V相偏移量 */
                        duty_mid_offset = &duty_u_offset;    /* 中间相偏移指针指向U相偏移量 */
                        break;                           /* 结束本case */
                case 6:                          /* 扇区6：U相占空比最大、W相居中、V相最小 */
                        duty_max = &duty_u;              /* 最大占空比指针指向U相占空比 */
                        duty_min = &duty_v;              /* 最小占空比指针指向V相占空比 */
                        duty_mid = &duty_w;              /* 中间占空比指针指向W相占空比 */
                        duty_max_offset = &duty_u_offset;    /* 最大相偏移指针指向U相偏移量 */
                        duty_min_offset = &duty_v_offset;    /* 最小相偏移指针指向V相偏移量 */
                        duty_mid_offset = &duty_w_offset;    /* 中间相偏移指针指向W相偏移量 */
                        break;                           /* 结束本case */
                default:                         /* 异常扇区号时按U最大、V居中、W最小处理 */
                        duty_max = &duty_u;              /* 最大占空比指针指向U相占空比 */
                        duty_min = &duty_v;              /* 最小占空比指针指向V相占空比 */
                        duty_mid = &duty_w;              /* 中间占空比指针指向W相占空比 */
                        duty_max_offset = &duty_u_offset;    /* 最大相偏移指针指向U相偏移量 */
                        duty_min_offset = &duty_v_offset;    /* 最小相偏移指针指向V相偏移量 */
                        duty_mid_offset = &duty_w_offset;    /* 中间相偏移指针指向W相偏移量 */
                        break;                           /* 结束本case */
        }

    /* MAX MIN 首先固定移动到最靠边位置 */
    sample_mode = 0;                             /* 清零采样模式标志，之后按条件重新置位 */
    if(MIN_EDGE_WIDTH < *duty_min)               /* 最小相占空比大于最小边沿宽度时向下移位 */
    {
        /* duty_min_offset < 0 */
        *duty_min_offset = MIN_EDGE_WIDTH - *duty_min;       /* 计算负偏移，将最小相占空比移到MIN_EDGE_WIDTH */
        *duty_min += *duty_min_offset;           /* 就地修正最小相占空比（向下限移动，腾出边沿余量） */
    }
    if(*duty_max <= (_pwm_period / 2))           /* 最大相占空比不超过半周期时 */
    {
        *duty_max_offset = *duty_max - MIN_EDGE_WIDTH;       /* 仅记录正偏移供外部将最大相移到MIN_EDGE_WIDTH */
    }
    else
    {
        if((_pwm_period-MIN_EDGE_WIDTH) > *duty_max)         /* 最大相占空比未贴近上边界时向上移位 */
        {
            /* duty_max_offset > 0 */
            *duty_max_offset = _pwm_period - MIN_EDGE_WIDTH - *duty_max;   /* 计算正偏移，将最大相移到上边界 */
            *duty_max += *duty_max_offset;       /* 就地修正最大相占空比（向上限移动，腾出边沿余量） */
        }
    }
    if(*duty_mid <= (_pwm_period / 2))           /* 中间相占空比在下半周期时 */
    {
        /* duty_mid_offset >= 0 */
        sample_mode |= ONE_SHUNT_IB;             /* 先默认第二采样点可用，标记可采样IB */
        if(((_pwm_period / 2) - *duty_mid) < *duty_mid)      /* 中间相过半周期中点时移到半周期处 */
        {
            *duty_mid_offset = (_pwm_period / 2) - *duty_mid;   /* 偏移为正：移到半周期位置 */
        }
        else
        {
            *duty_mid_offset = *duty_mid;        /* 否则偏移等于当前值：占空比加倍向半周期靠近 */
        }
        *duty_mid += *duty_mid_offset;           /* 就地修正中间相占空比（向上移位，远离最小相） */
        if((*duty_mid - *duty_min) > t_min_dur_cycle)        /* 移位后与最小相拉开足够采样窗口 */
        {
            sample_mode |= ONE_SHUNT_IA;         /* 第一采样点有效，标记可采样IA */
        }
    }
    else
    {
        /* duty_mid_offset < 0 */
        sample_mode |= ONE_SHUNT_IA;             /* 先默认第一采样点可用，标记可采样IA */
        if((*duty_mid - (_pwm_period / 2)) < (_pwm_period - *duty_mid))   /* 中相距半周期较近时移到半周期处 */
        {
            *duty_mid_offset = (_pwm_period / 2) - *duty_mid;   /* 负偏移：向上移到半周期位置 */
        }
        else
        {
            *duty_mid_offset = -(_pwm_period - *duty_mid);   /* 否则负偏移更大：向半周期对称位置移位 */
        }
        *duty_mid += *duty_mid_offset;           /* 就地修正中间相占空比（向下移位，远离最大相） */
        if((*duty_max - *duty_mid) > t_min_dur_cycle)        /* 移位后与最大相拉开足够采样窗口 */
        {
            sample_mode |= ONE_SHUNT_IB;         /* 第二采样点有效，标记可采样IB */
        }
    }


/*
    sample_mode = 0;
    if((*duty_mid - *duty_min) > t_min_dur_cycle)
    {
        trigger_point1 = *duty_min + t_sample_delay_cycle;
        sample_mode |= ONE_SHUNT_IA;
    }
    if((*duty_max - *duty_mid) > t_min_dur_cycle)
    {
        trigger_point2 = *duty_mid + t_sample_delay_cycle;
        sample_mode |= ONE_SHUNT_IB;
    }
*/

    trigger_point1 = *duty_min + t_sample_delay_cycle;       /* 第一触发点=最小相占空比+采样延迟（最小相导通窗口内采样） */
    trigger_point2 = *duty_mid + t_sample_delay_cycle;       /* 第二触发点=中间相移位后占空比+采样延迟 */
    motor_pwm_set_adc_trigger_point(trigger_point1, trigger_point2);     /* 设置定时器两路ADC触发比较点 */
}


/* 局部函数定义 -----------------------------------------------------------------------------------*/
/**
  * @brief
  * @param 无
  * @retval 无
  */


/***************************************** 文件结束 *********************************************/
