/*
*******************************************************************************************************
*
* 文件名称 : luenberger.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : PMSM龙伯格(Luenberger)观测器控制文件
* 
*******************************************************************************************************
*/

/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "luenberger.h"   /* 龙伯格观测器接口头文件 */
#include "foc.h"          /* FOC核心结构与PI调节器接口 */
#include "userparms.h"    /* 用户参数配置(电机相电阻/相电感/环路周期/增益K1,K2等) */

/* 宏定义 ------------------------------------------------------------------------------------------*/

/* 变量定义 ----------------------------------------------------------------------------------------*/


/* 局部函数 -----------------------------------------------------------------------------------*/


/* 全局函数 ----------------------------------------------------------------------------------*/
/**
  * @brief 初始化龙伯格(Luenberger)观测器结构体
  * @param *s -  指向龙伯格观测器结构体的指针
  * @retval void
  * @note
  */
void sto_luenberger_init(sto_luenberger_t *s)
{
    s->C1 = LOOPTIME_SEC / MOTOR_PHASE_INDUCTANCE;                           /* 观测器增益C1：环路周期/相电感 */
    s->C2 = 1-(MOTOR_PHASE_RESISTANCE*LOOPTIME_SEC/MOTOR_PHASE_INDUCTANCE);  /* 观测器增益C2：1-(相电阻*环路周期/相电感) */
    s->C3 = K1 * LOOPTIME_SEC;                                               /* 电流校正增益C3：K1*环路周期 */
    s->C4 = K2 * LOOPTIME_SEC;                                               /* 反电动势校正增益C4：K2*环路周期 */
    
    s->ialpha_est = 0;      /* α轴定子电流估计值清零 */
    s->ibeta_est = 0;       /* β轴定子电流估计值清零 */
    s->ealpha_est = 0;      /* α轴反电动势(BEMF)估计值清零 */
    s->ebeta_est = 0;       /* β轴反电动势(BEMF)估计值清零 */
    
    s->pll_pi_regulator.kp = 0.004;      /* PLL用PI调节器比例系数（随后被覆盖） */
    s->pll_pi_regulator.ki = 0.0004;     /* PLL用PI调节器积分系数（随后被覆盖） */
    s->pll_pi_regulator.kp = 60;         /* PLL用PI调节器比例系数 */
    s->pll_pi_regulator.ki = 0.1;        /* PLL用PI调节器积分系数 */
    s->pll_pi_regulator.kc = 0;          /* 积分抗饱和回授系数 */
    s->pll_pi_regulator.out_max = 100000 / 60 * ANGLE_2PI;       /* 输出上限：100000r/min换算为电角速度 */
    s->pll_pi_regulator.out_min = -s->pll_pi_regulator.out_max;  /* 输出下限：取输出上限的负值 */
    init_pi(&s->pll_pi_regulator);       /* 初始化PLL用PI调节器（清积分与输出状态） */
}

/**
  * @brief 调用龙伯格观测器，估算电角速度与电角度
  * @param *s -  指向龙伯格观测器结构体的指针
  * @retval void
  * @note
  */
void sto_luenberger_estimation(sto_luenberger_t *s)
{
    float ialpha_est_next = 0;      /* α轴电流估计值下一步暂存 */
    float ibeta_est_next = 0;       /* β轴电流估计值下一步暂存 */
    float ealpha_est_next = 0;      /* α轴反电动势估计值下一步暂存 */
    float ebeta_est_next = 0;       /* β轴反电动势估计值下一步暂存 */
    float sin_value = 0;            /* 当前电角度正弦值 */
    float cos_value = 0;            /* 当前电角度余弦值 */
    
    /* 龙伯格电流观测方程：C2*上拍电流估计 + C1*(α轴电压-α轴反电动势估计) + C3*电流估计误差校正 */
    ialpha_est_next = s->C2*s->ialpha_est + s->C1*(s->valpha - s->ealpha_est) + s->C3 * (s->ialpha_est - s->ialpha);
    /* β轴电流观测方程，与α轴对称 */
    ibeta_est_next = s->C2*s->ibeta_est + s->C1*(s->vbeta - s->ebeta_est) + s->C3 * (s->ibeta_est - s->ibeta);
    
    /* 龙伯格反电动势观测方程：上拍估计 - 环路周期*电角速度*正交轴反电动势 + C4*电流估计误差校正 */
    ealpha_est_next = s->ealpha_est - LOOPTIME_SEC * s->omega * s->ebeta_est + s->C4 * (s->ialpha_est - s->ialpha);
    /* β轴反电动势观测方程，交叉耦合项符号与α轴相反 */
    ebeta_est_next = s->ebeta_est + LOOPTIME_SEC * s->omega * s->ealpha_est + s->C4 * (s->ibeta_est - s->ibeta);
    
    s->ialpha_est = ialpha_est_next;    /* 更新α轴电流估计值 */
    s->ibeta_est = ibeta_est_next;      /* 更新β轴电流估计值 */
    s->ealpha_est = ealpha_est_next;    /* 更新α轴反电动势估计值 */
    s->ebeta_est = ebeta_est_next;      /* 更新β轴反电动势估计值 */
    
    cos_value = arm_cos_f32(s->theta);    /* 计算当前电角度余弦值 */
    sin_value = arm_sin_f32(s->theta);    /* 计算当前电角度正弦值 */
    s->pll_pi_regulator.ref = -s->ealpha_est * cos_value;    /* PLL鉴相给定项：-ealpha_est*cos(θ) */
    s->pll_pi_regulator.meas = s->ebeta_est * sin_value;     /* PLL鉴相反馈项：ebeta_est*sin(θ)，误差∝真实与估计角度之差 */
    calc_pi(&s->pll_pi_regulator);    /* PI调节器运算(误差=给定-反馈)，输出电角速度 */
    
    s->omega = s->pll_pi_regulator.out;              /* PI输出即电角速度估计值 */
    s->theta = s->theta + s->omega * LOOPTIME_SEC;   /* 电角度积分：角度 += 角速度*环路周期 */
    if(s->theta >= ANGLE_2PI)      /* 电角度不小于2π，减2π归一化 */
    {
        s->theta = s->theta - ANGLE_2PI;
    }
    if(s->theta <= 0)              /* 电角度不大于0，加2π归一化 */
    {
        s->theta = s->theta + ANGLE_2PI;
    }
}

/*==================================================================================================
*                                       局部函数
==================================================================================================*/

/* 以下为已弃用的旧版PLL计算代码(基于SMO结构smc_t)，仅留作参考 */
/*static void calc_pll(smc_t *psmc) */
/*{ */
/*    float sin_value = 0; */
/*    float cos_value = 0; */
/* */
/*    cos_value = arm_cos_f32(psmc->theta + psmc->theta_offset); */
/*    sin_value = arm_sin_f32(psmc->theta + psmc->theta_offset); */
/* */
/*    psmc->pll_err = -psmc->ealpha_final * cos_value - psmc->ebeta_final * sin_value; */

/*    psmc->pll_err = (psmc->pll_err > PI/6)  ?  (PI/6) : (psmc->pll_err); */
/*    psmc->pll_err = (psmc->pll_err < -PI/6) ? (-PI/6) : (psmc->pll_err); */
/* */
/*    psmc->pll_err_sum += psmc->pll_err; */
/* */
/*    psmc->omega = psmc->pll_err * psmc->pll_kp + psmc->pll_err_sum * psmc->pll_ki; */
/* */
/*    psmc->theta       = psmc->theta + (psmc->omega)*(LOOPTIME_SEC); */
/*    if(psmc->theta >= ANGLE_2PI) */
/*    { */
/*        psmc->theta = psmc->theta - ANGLE_2PI; */
/*    } */
/*    if(psmc->theta <= 0) */
/*    { */
/*        psmc->theta = psmc->theta + ANGLE_2PI; */
/*    } */
/*    psmc->omega_fltred = psmc->omega_fltred + psmc->filt_omega_coef * (psmc->omega - psmc->omega_fltred); */
/*} */

/************************************************文件结束************************************************/
