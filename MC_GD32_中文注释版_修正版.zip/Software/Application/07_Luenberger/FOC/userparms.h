/*
*******************************************************************************************************
*
* 文件名称 : userparms.h
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 电机控制用户参数定义(电流环/速度环PI参数、电机参数、观测器参数等)
*
*******************************************************************************************************
*/

#ifndef _USERPARMS_H    /* 头文件保护宏,防止重复包含 */
#define _USERPARMS_H    /* 定义头文件保护宏 */

#ifdef __cplusplus    /* C++编译兼容处理 */
extern "C"{    /* 按C语言方式导出接口 */
#endif    /* 结束条件编译 */

/*==================================================================================================
*                                        头文件包含
* 1) 系统和工程包含文件
* 2) 所需的外部单元接口
* 3) 本单元的内部和外部接口
==================================================================================================*/
#include <stdint.h>    /* 标准整型类型定义 */
#include "motor_config.h"    /* 硬件配置头文件(PWM频率/采样电阻等) */
/*==================================================================================================
*                                      宏定义
==================================================================================================*/
/*************** 通用参数 ********************************************/
#define RPM_TO_RADS                                     ((float)2*M_PI/60)    /* 转速单位换算系数:转/分 → 弧度/秒 */

/*************** 电机参数 *********************************************/
/* 24V电机参数组 */
/* #define MOTOR_PHASE_RESISTANCE                          ((float)0.42)  相电阻(欧姆) */
/* #define MOTOR_PHASE_INDUCTANCE                          ((float)0.000334f)  相电感(亨) */
/* #define MOTOR_NOPOLESPAIRS                               2  极对数 */

/* 12V电机参数组 */
/* #define     MOTOR_PHASE_RESISTANCE                          ((float)0.2f)  相电阻(欧姆) */
/* #define     MOTOR_PHASE_INDUCTANCE                          ((float)0.000188f)  相电感(亨) */
/* #define     MOTOR_NOPOLESPAIRS                                        2  极对数 */

/* 57BL电机参数组 */
/* #define MOTOR_PHASE_RESISTANCE                          ((float)0.42)  相电阻(欧姆) */
/* #define MOTOR_PHASE_INDUCTANCE                          ((float)0.00112)  相电感(亨) */
/* #define MOTOR_PHASE_INDUCTANCE_DIV_2_PI                 ((float)(MOTOR_PHASE_INDUCTANCE/(2*M_PI)))  相电感除以2π(亨) */
/* #define MOTOR_BACK_EMF_Vpeak                            (float)4.27  反电动势线电压峰值(伏) */
/* #define MOTOR_NOPOLESPAIRS                               2  极对数 */


/* 60V直流母线电机参数组 */
/* #define MOTOR_PHASE_RESISTANCE                          ((float)0.6)  相电阻(欧姆) */
/* #define MOTOR_PHASE_INDUCTANCE                          ((float)0.000242)  相电感(亨) */
/* #define MOTOR_PHASE_INDUCTANCE_DIV_2_PI                 ((float)(MOTOR_PHASE_INDUCTANCE/(2*M_PI)))  相电感除以2π(亨) */
/* #define MOTOR_BACK_EMF_Vpeak                            (float)1.24  反电动势线电压峰值(伏) */
/* #define MOTOR_NOPOLESPAIRS                               2  极对数 */

/* 105V直流母线电机参数组 */
#define MOTOR_PHASE_RESISTANCE                          ((float)6.97)    /* 相电阻6.97欧姆 */
#define MOTOR_PHASE_INDUCTANCE                          ((float)0.00535)    /* 相电感5.35毫亨 */
#define MOTOR_PHASE_INDUCTANCE_DIV_2_PI                 ((float)(MOTOR_PHASE_INDUCTANCE/(2*M_PI)))    /* 相电感除以2π(亨) */
#define MOTOR_BACK_EMF_Vpeak                            (float)12.25    /* 反电动势线电压峰值12.25伏 */
#define MOTOR_NOPOLESPAIRS                               2    /* 电机极对数 */

/* 25.2V 500W电机参数组 */
/* #define MOTOR_PHASE_RESISTANCE                          ((float)0.15)  相电阻(欧姆) */
/* #define MOTOR_PHASE_INDUCTANCE                          ((float)0.000100)  相电感(亨) */
/* #define MOTOR_NOPOLESPAIRS                               2  极对数 */

/* 2808电机参数组 */
/* #define MOTOR_PHASE_RESISTANCE                          ((float)0.6)  相电阻(欧姆) */
/* #define MOTOR_PHASE_INDUCTANCE                          ((float)0.000242)  相电感(亨) */
/* #define MOTOR_NOPOLESPAIRS                               7  极对数 */

/* ZSDN-390-2-1电机参数组 */
/* #define MOTOR_PHASE_RESISTANCE                          ((float)0.0246)  相电阻(欧姆) */
/* #define MOTOR_PHASE_INDUCTANCE                          ((float)0.00000641)  相电感(亨) */
/* #define MOTOR_NOPOLESPAIRS                               2  极对数 */


/*************** PWM与控制时序参数 ****************************/
#define PWMFREQUENCY_HZ                                 (float)MOTOR_PWM_FREQ_HZ    /* PWM频率(赫兹),取自硬件配置 */
#define LOOPTIME_SEC                                    (float)(1/PWMFREQUENCY_HZ)    /* 控制环执行周期(秒)=1/PWM频率 */

/*************** 启动参数 *******************************************/
#define OPEN_LOOP_CURRENT                               2    /* 开环阶段q轴电流给定(安) */

#define SPEED_LOOP_CYCLE                                10    /* 速度环分频执行:每10个电流环周期计算一次 */

#define LOCK_TIME_SEC  		                            1    /* 转子预定位(对齐)时间(秒) */
#define LOCK_COUNTER                                    (unsigned int)((float)LOCK_TIME_SEC/(float)LOOPTIME_SEC)    /* 预定位时间折算成控制环周期数 */

#define OPENLOOPTIMEINSEC 	                            1    /* 开环加速阶段总时长(秒) */
#define OPEN_LOOP_END_SPEED_RPM                         500    /* 开环阶段结束转速(转/分) */

#define END_SPEED_RADS_MECH                             (float)(OPEN_LOOP_END_SPEED_RPM*RPM_TO_RADS)    /* 开环结束机械角速度(弧度/秒) */
#define END_SPEED_RADS_ELEC                             (float)(END_SPEED_RADS_MECH*MOTOR_NOPOLESPAIRS)    /* 开环结束电角速度(电弧度/秒) */
#define END_SPEED_RADS_ELEC_COUNTER                     (float)(END_SPEED_RADS_ELEC * LOOPTIME_SEC)    /* 开环结束时每个周期电角度步进(电弧度) */
#define OPENLOOP_RAMPSPEED_INCREASERATE                 (float)(END_SPEED_RADS_ELEC_COUNTER/(OPENLOOPTIMEINSEC/LOOPTIME_SEC))    /* 开环加速时每周期开环角度步进增量(累加到startup_ramp,电弧度/周期,使电角速度线性升至开环结束转速) */
    
#define CL_RAMP_RATE_RPM_SEC                             500 /* 闭环速度斜率(转/分/秒) */
#define CL_RAMP_RATE_RPS_SEC                             ((float)CL_RAMP_RATE_RPM_SEC/60) /* 闭环速度斜率(转/秒²) */
#define CL_RAMP_RATE_RADS_PER_SEC2_MECH                  (float)(CL_RAMP_RATE_RPS_SEC*2*M_PI) /* 闭环速度斜率(机械弧度/秒²) */
#define CL_RAMP_RATE_RADS_PER_SEC2_ELEC                  (float)(CL_RAMP_RATE_RADS_PER_SEC2_MECH*MOTOR_NOPOLESPAIRS) /* 闭环速度斜率(电弧度/秒²) */
#define CL_SPEED_RAMP_RATE_DELTA                         (float)(CL_RAMP_RATE_RADS_PER_SEC2_ELEC*LOOPTIME_SEC) /* 每个控制周期的速度斜坡增量(电弧度/秒) */
#define CL_SPEED_HYSTERESIS                              (float)(5*CL_SPEED_RAMP_RATE_DELTA)    /* 速度斜坡启停迟滞带(电弧度/秒) */
    
#define NOMINAL_SPEED_RPM                                (float)3000 /* 额定转速(转/分) */
#define NOMINAL_SPEED_RAD_PER_SEC_ELEC                   (float)(((NOMINAL_SPEED_RPM/60)*2*M_PI)*MOTOR_NOPOLESPAIRS) /* 额定电角速度(电弧度/秒) */

/*************** 状态观测器(STO)参数 ***********************************************/
#define K1	        -28767    /* 龙伯格观测器增益1(乘控制周期得离散系数C3) */
#define K2          16875 /* 龙伯格观测器增益2(乘控制周期得离散系数C4),备选值140000 */

/*************** PI调节器参数 ***********************************************/

/* ******** D轴电流环系数 ******* */
#define     DKP        (0.02)    /* D轴电流环比例系数 */
#define     DKI        (0.0002)    /* D轴电流环积分系数 */
#define     DKC        (0.5)    /* D轴电流环抗积分饱和回算系数 */
#define     DOUTMAX    (0.99999)    /* D轴电流环输出上限(标幺值) */

/* ******** Q轴电流环系数 ******* */
#define     QKP        (0.02)    /* Q轴电流环比例系数 */
#define     QKI        (0.0002)    /* Q轴电流环积分系数 */
#define     QKC        (0.5)    /* Q轴电流环抗积分饱和回算系数 */
#define     QOUTMAX    (0.99999)    /* Q轴电流环输出上限(标幺值) */

/* *** 速度环系数 ***** */
#define     WKP        (0.01)    /* 速度环比例系数 */
#define     WKI        (0.000001)    /* 速度环积分系数 */
#define     WKC        (0.999)    /* 速度环抗积分饱和回算系数 */
#define     WOUTMAX    (10)    /* 速度环输出上限,即q轴电流给定限幅(安) */


/* #define OPEN_LOOP_MODE  开环模式开关(未启用) */
/* #define OPEN_LOOP_VF_VQ     0.2f  开环V/F方式q轴电压幅值给定(标幺值) */
/* #define TORQUE_MODE  转矩模式开关(未启用) */

#ifdef __cplusplus    /* C++编译兼容处理 */
}
#endif    /* 结束条件编译 */

#endif /* _USERPARMS_H */

/************************************************文件结束************************************************/
