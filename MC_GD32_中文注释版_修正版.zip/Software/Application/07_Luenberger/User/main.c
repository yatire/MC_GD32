/*
*******************************************************************************************************
*
* 文件名称 : main.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 主函数文件
*
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include <string.h>             /* C标准字符串库头文件 */
#include "gd32f30x.h"           /* GD32F30x设备头文件(寄存器与中断定义) */
#include "gd32f30x_libopt.h"    /* 固件库外设包含选项文件 */
#include "systick.h"            /* SysTick系统滴答与延时 */
#include "led.h"                /* LED驱动 */
#include "motor_hardware.h"     /* 电机控制硬件层(PWM/ADC/霍尔接口) */
#include "uart.h"               /* 调试串口驱动 */
#include "i2c.h"                /* I2C驱动 */
#include "encoder.h"            /* 旋转编码器与按键驱动 */
#include "eeprom.h"             /* EEPROM(24C02)驱动 */
#include "delay.h"              /* TIMER6延时 */
#include "adc_simple.h"         /* 简易ADC采样(NTC温度/母线电压/母线电流平均) */
#include "lcd.h"                /* LCD底层驱动 */
#include "lcd_init.h"           /* LCD初始化与引脚配置 */
#include "can.h"                /* CAN总线驱动 */
#include "drv8323rs.h"          /* DRV8323RS栅极驱动器SPI驱动 */
#include "foc.h"                /* FOC基础算法(Clark/Park/SVPWM/PI) */
#include "pmsm.h"               /* PMSM电机控制结构与接口 */
#include "userparms.h"          /* FOC控制参数配置 */
#include "task.h"               /* 任务调度器 */
#include "motor_app.h"          /* 电机控制应用(状态机与中断处理) */

/* 宏定义 ------------------------------------------------------------------------------------------*/
#define START_DELAY_SEC     (float)2    /* 启动延时时间2秒(与motor_app.h中定义相同) */
/* 启动延时对应的PWM周期数 = 启动延时秒数×PWM频率 = 2s×16kHz = 32000 */
#define START_DELAY_TICK    (uint32_t)((float)START_DELAY_SEC/(1/(float)MOTOR_PWM_FREQ_HZ))

/* 变量定义 ----------------------------------------------------------------------------------------*/
uint8_t adc_calibration = 0;    /* ADC标定完成标志(本工程未引用, 保留变量) */
/* 三相电流与母线电流零点偏置(本工程未引用, 实际使用motor1结构体成员) */
uint32_t ia_offset = 0,ib_offset = 0,ic_offset = 0,idc_offset = 0;
/* 三相电流与母线电流ADC采样值(本工程未引用, 实际使用motor1结构体成员) */
uint16_t adc1_ia = 0,adc1_ib = 0,adc1_ic = 0,adc1_idc = 0;

uint32_t start_delay_tick = 0;    /* 启动延时计数器(本工程未引用, 实际使用motor1.start_delay_tick) */
extern uint16_t speed_rpm;    /* 转速(rpm)外部声明(本工程未定义未使用, 其他版本遗留) */
extern uint16_t vdc_bus_adc;    /* 母线电压ADC采样值外部声明(本工程未定义未使用, 其他版本遗留) */

/* 函数定义 -----------------------------------------------------------------------------------------*/


/**
  * @brief 主函数
  * @param 无
  * @retval 无
  */
int main(void)
{
    SCB->VTOR = FLASH_BASE | 0x4000;  /* 设置向量表偏移到APP起始地址0x08004000(前16KB为Bootloader) */
    __enable_irq();     /* 使能全局中断 */
    
    systick_init();     /* 初始化SysTick系统滴答定时器 */
    led_init();         /* LED初始化 */
    usart_init();       /* 调试串口初始化 */
    adc1_init();        /* ADC1初始化(NTC温度/母线电压/母线电流平均轮询采样) */
    can_bus_init();     /* CAN总线初始化 */
    encoder_init();     /* 旋转编码器与按键初始化(TIMER3正交解码+按键FIFO变量) */
    LCD_Init();         /* LCD初始化 */
    LCD_Fill(0,0,LCD_W,LCD_H,WHITE);  /* LCD全屏填充白色(清屏) */
    DRV8323RS_init();   /* DRV8323RS栅极驱动器初始化 */
    task_init();        /* 任务调度器初始化(内部调用motor_app_init) */
    
    motor_hardware_init();    /* 电机硬件初始化(PWM/ADC/霍尔接口/NVIC) */
    pmsm_foc_param.pwm_period = (float)MOTOR_PWM_PERIOD * 0.95f;  /* PWM周期计数值取满周期的95%(SVPWM比较值上限) */
    pmsm_foc_init();    /* FOC参数与状态初始化 */
    
    while(1)    /* 主循环 */
    {
        task_scheduler();    /* 轮询调度各周期任务 */
    }
}

/**
  * @brief TIMER0刹车中断服务函数
  * @param 无
  * @retval 无
  */
void TIMER0_BRK_IRQHandler(void)
{
    timer_channel_output_mode_config(TIMER0,TIMER_CH_0,TIMER_OC_MODE_INACTIVE);  /* 将W相(CH0)置为匹配时无效电平(封锁PWM) */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_1,TIMER_OC_MODE_INACTIVE);  /* 将V相(CH1)置为匹配时无效电平(封锁PWM) */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_2,TIMER_OC_MODE_INACTIVE);  /* 将U相(CH2)置为匹配时无效电平(封锁PWM) */
    /* 清除TIMER中断标志 */
    timer_interrupt_flag_clear(TIMER0,TIMER_INT_FLAG_BRK);  /* 清除刹车中断标志(BRK) */
    
    led_on(LED_FAULT);    /* 点亮故障指示灯 */
}

/**
  * @brief ADC0_1中断服务函数(注入组转换完成)
  * @param 无
  * @retval 无
  */
void ADC0_1_IRQHandler(void)
{
    /* 清除ADC中断标志 */
    adc_interrupt_flag_clear(ADC0, ADC_INT_FLAG_EOIC);  /* 清除注入组转换结束标志EOIC */
    
    motor_app_isr();    /* FOC主循环(相电流采样/闭环计算/占空比更新) */
}

/*!
    \brief      CAN0接收中断服务函数(与USB低优先级中断共用该向量)
    \param[in]  无
    \param[out] 无
    \retval     无
*/
void USBD_LP_CAN0_RX0_IRQHandler(void)
{
    can_receive_message_struct receive_message;    /* CAN接收报文结构体(读出后未使用) */
    /* 从CAN0 FIFO0读出一条报文并释放邮箱(本例程未对报文内容做处理) */
    can_message_receive(CAN0, CAN_FIFO0, &receive_message);
}


/***************************************** 文件结束 *********************************************/
