/*
*******************************************************************************************************
*
* 文件名称 : encoder.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 正交编码器驱动文件
*
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "encoder.h" /* 编码器A/B相引脚宏与动作码枚举定义 */

/* 宏定义 ------------------------------------------------------------------------------------------*/


/* 变量定义 ----------------------------------------------------------------------------------------*/
static encoder_code_t encoder_code = ENCODER_NONE; /* 编码器动作码(中断置位,读取后清零) */

/* 局部函数 -----------------------------------------------------------------------------------*/
static void encoder_gpio_init(void); /* 编码器A/B相GPIO初始化 */
static void encoder_timer_init(void); /* TIMER3正交编码器模式初始化 */

/* 函数定义 -----------------------------------------------------------------------------------------*/
/**
  * @brief 编码器初始化(NVIC/GPIO/TIMER3编码器模式)
  * @param 无
  * @retval 无
  */
void encoder_init(void)
{
    nvic_irq_enable(TIMER3_IRQn, 2, 1); /* 使能TIMER3中断,抢占优先级2、子优先级1 */
    encoder_gpio_init(); /* 初始化编码器A/B相输入GPIO */
    encoder_timer_init(); /* TIMER3配置为正交编码器模式 */
}

encoder_code_t encoder_get(void) /* 读取编码器动作码并清除(未动作返回ENCODER_NONE) */
{
    encoder_code_t code = encoder_code; /* 取出当前动作码快照 */
    encoder_code = ENCODER_NONE; /* 动作码清零,保证一次动作只被读取一次 */
    return code; /* 返回取出的动作码 */
}

void TIMER3_IRQHandler(void) /* TIMER3触发中断:编码器计数事件判向 */
{
    int16_t cnt = 0; /* 编码器计数增量(带符号) */
    if(SET == timer_interrupt_flag_get(TIMER3,TIMER_INT_FLAG_TRG)) /* 触发中断标志置位(编码器模式2下CI0每个计数边沿触发) */
    {
        timer_interrupt_flag_clear(TIMER3,TIMER_INT_FLAG_TRG); /* 清除触发中断标志 */
        cnt = timer_counter_read(TIMER3); /* 读取自上次中断以来的计数值(单步转动为±1) */
        timer_counter_value_config(TIMER3,0); /* 计数器清零,为下一次增量测量做准备 */
        if(cnt > 0) /* 计数值为正:一个中断间隔内计数器递增 */
        {
            encoder_code = ENCODER_INC; /* 置编码器增方向动作码 */
        }
        else
        {
            encoder_code = ENCODER_DEC; /* 计数值非正(计数器递减方向):置编码器减方向动作码 */
        }
    }
}


/* 局部函数 -----------------------------------------------------------------------------------*/
/**
  * @brief 编码器A/B相GPIO初始化
  * @param 无
  * @retval 无
  */
static void encoder_gpio_init(void)
{
    /* 使能GPIO时钟 */
    rcu_periph_clock_enable(ENCODERA_GPIO_CLK); /* 使能编码器A相GPIO时钟 */
    rcu_periph_clock_enable(ENCODERB_GPIO_CLK); /* 使能编码器B相GPIO时钟 */

    gpio_init(ENCODERA_GPIO_PORT,GPIO_MODE_IN_FLOATING,GPIO_OSPEED_50MHZ,ENCODERA_GPIO_PIN); /* 编码器A相引脚浮空输入 */
    gpio_init(ENCODERB_GPIO_PORT,GPIO_MODE_IN_FLOATING,GPIO_OSPEED_50MHZ,ENCODERB_GPIO_PIN); /* 编码器B相引脚浮空输入 */
}


static void encoder_timer_init(void) /* TIMER3正交编码器模式配置 */
{
    /* TIMER3配置:先配置输入捕获通道,再切入正交编码器模式 */
    timer_ic_parameter_struct timer_icinitpara; /* 输入捕获通道参数结构体 */
    timer_parameter_struct timer_initpara; /* 定时器时基参数结构体 */

    rcu_periph_clock_enable(RCU_TIMER3); /* 使能TIMER3时钟 */

    timer_deinit(TIMER3); /* 复位TIMER3到默认状态 */

    /* TIMER3时基配置 */
    timer_initpara.prescaler         = 0; /* 预分频0:计数时钟=定时器输入时钟 */
    timer_initpara.alignedmode       = TIMER_COUNTER_EDGE; /* 边沿对齐计数模式 */
    timer_initpara.counterdirection  = TIMER_COUNTER_UP; /* 向上计数(编码器模式下实际方向由脉冲相位决定) */
    timer_initpara.period            = 0xFFFF; /* 周期65535:16位全范围,双向计数负增量以回绕表示 */
    timer_initpara.clockdivision     = TIMER_CKDIV_DIV1; /* 时钟分割DIV1(数字滤波器采样基准) */
    timer_initpara.repetitioncounter = 0; /* 重复计数器0 */
    timer_init(TIMER3,&timer_initpara); /* 初始化TIMER3时基 */

    /* TIMER3捕获通道配置 */
    /* TIMER3输入捕获参数配置 */
    timer_icinitpara.icpolarity  = TIMER_IC_POLARITY_RISING; /* 捕获极性:上升沿 */
    timer_icinitpara.icselection = TIMER_IC_SELECTION_DIRECTTI; /* 输入直接映射到捕获通道 */
    timer_icinitpara.icprescaler = TIMER_IC_PSC_DIV1; /* 不分频:每个有效边沿都捕获 */
    timer_icinitpara.icfilter    = 0x10; /* 数字滤波系数0x10(滤除窄脉冲毛刺) */
    timer_input_capture_config(TIMER3,TIMER_CH_0,&timer_icinitpara); /* 配置CI0(编码器A相)输入捕获 */
    timer_input_capture_config(TIMER3,TIMER_CH_1,&timer_icinitpara); /* 配置CI1(编码器B相)输入捕获 */

    timer_input_trigger_source_select(TIMER3,TIMER_SMCFG_TRGSEL_CI0FE0); /* 触发源选滤波后的CI0:编码器计数边沿产生触发事件 */
    /* 正交编码器模式2:计数器在CI0与CI1两路输入的所有边沿计数(4倍频),计数方向由两相信号正交相位关系决定 */
    timer_quadrature_decoder_mode_config(TIMER3,TIMER_ENCODER_MODE2,TIMER_IC_POLARITY_RISING,TIMER_IC_POLARITY_RISING);
    
    timer_interrupt_enable(TIMER3,TIMER_INT_TRG); /* 使能触发中断:每个编码器计数事件进入一次中断 */

    /* 使能TIMER3计数器(原注释TIMER2为笔误) */
    timer_enable(TIMER3); /* 启动TIMER3开始计数 */
}

/***************************************** 文件结束 *********************************************/
