/*
*******************************************************************************************************
*
* 文件名称 : key_fifo.h
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 按键驱动头文件
* 
*******************************************************************************************************
*/

#ifndef _KEY_FIFO_H   /* 头文件保护宏 */
#define _KEY_FIFO_H   /* 定义头文件保护宏 */



/* 头文件包含 -----------------------------------------------------------*/
#include "gd32f30x.h"   /* 包含GD32F30x固件库头文件(uint类型等定义) */



/* 宏定义 -----------------------------------------------------------*/

/* 按键端口定义 */
#define KEY0_GPIO_PORT       GPIOC        /* KEY0所用GPIO端口:GPIOC */
#define KEY0_GPIO_PIN        GPIO_PIN_0   /* KEY0所用引脚:PC0 */
#define KEY0_GPIO_CLK        RCU_GPIOC    /* KEY0端口时钟使能:RCU_GPIOC */

/* 按键个数 */
#define KEY_COUNT 1       /* 按键个数:1 */
/* 按键滤波时间 单位10ms */
#define KEY_FILTER_TIME   5       /* 按键滤波时间:5*10ms=50ms */
/* 按键长按时间 单位10ms */
#define KEY_LONG_TIME     100     /* 长按判定时间:100*10ms=1s */
/* 定义按键FIFO缓冲区大小 */
#define KEY_FIFO_SIZE	4   /* 按键FIFO缓冲区长度:4 */



/* 类型定义 -----------------------------------------------------------*/

/* 按键是否按下 */
typedef enum
{
	KEY_ISDOWN = 0,      /* 按键处于按下状态 */
	KEY_NOTDOWN,         /* 按键处于松开状态 */
}KEY_DOWN;


/* 按键类型 */
typedef enum
{
	KEY_NONE = 0,        /* 无按键事件 */
	
	KEY_0_PRESS,         /* KEY0按下事件 */
	KEY_0_RELEASE,       /* KEY0松开事件 */
	KEY_0_LONG_PRESS,    /* KEY0长按事件 */
    
}KEY_ENUM;


/* 按键结构体 */
typedef struct
{
	uint8_t (*IsKeyDownFunc)(void);		/* 按键是否按下的函数指针 */
	
	uint8_t Count;	/* 滤波器计数器 */
	uint16_t LongCount;	/* 长按计数器 */
	uint16_t LongTime;	/* 按键按下的时间 */
	uint8_t State;		/* 按键的当前状态 */
	uint8_t RepeatSpeed;	/* 连续按键周期 */
	uint8_t RepeatCount;		/* 连续按键计数器 */
	
	
}KEY_T;


/* fifo结构体 */
typedef struct
{
	uint8_t Buf[KEY_FIFO_SIZE];        /* 按键事件缓冲区 */
	uint8_t Read;                      /* 读指针(读索引) */
	uint8_t Write;                     /* 写指针(写索引) */
	
}KEY_FIFO;




/* 函数声明 ----------------------------------------------------------*/


void key_fifo_init(void);       /* 按键模块初始化(按键结构体与GPIO配置) */
void key_clear(void);           /* 清空按键FIFO缓冲区 */
uint8_t key_is_init(void);      /* 查询按键模块是否已初始化 */
void key_scan(void);            /* 按键扫描:需周期调用,完成滤波/长按判定并入队按键事件 */
uint8_t key_get(void);          /* 从FIFO读出一个按键事件(读指针前移) */


void key_put(uint8_t keyCode);          /* 向FIFO写入一个按键事件 */
static void key_gpio_config(void);      /* 按键GPIO初始化(内部函数) */
static void key_var_init(void);         /* 按键变量初始化(内部函数) */
static void key_detect(uint8_t i);      /* 单个按键状态检测与滤波(内部函数) */
 
#endif  /* 头文件保护宏结束 */

/***************************** 文件结束 *********************************/
