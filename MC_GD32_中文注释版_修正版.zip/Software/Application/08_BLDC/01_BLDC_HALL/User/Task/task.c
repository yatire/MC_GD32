/*
*******************************************************************************************************
*
* 文件名称 : task.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : BLDC霍尔传感器例程任务调度(时间片轮询软定时器)
*
*******************************************************************************************************
*/

/*******************************************************************************
* 头文件
*******************************************************************************/
#include "task.h"            /* 任务调度接口 */
#include "systick.h"         /* 滴答定时器接口 */
#include "motor_hardware.h"  /* 电机硬件层接口 */
#include "led.h"             /* LED驱动接口 */
#include "adc_simple.h"      /* 简单ADC采样接口 */

/*******************************************************************************
* 宏定义
*******************************************************************************/

/*******************************************************************************
* 宏
*******************************************************************************/
#define TICK_PRD_1MS 			1   /* 1ms任务的时间片周期(单位:ms) */
#define TICK_PRD_5MS 			5   /* 5ms任务的时间片周期(单位:ms) */
#define TICK_PRD_10MS 			10  /* 10ms任务的时间片周期(单位:ms) */
#define TICK_PRD_100MS 			100 /* 100ms任务的时间片周期(单位:ms) */
#define TICK_PRD_500MS 			500 /* 500ms任务的时间片周期(单位:ms) */
#define TICK_PRD_1S 			1000 /* 1s任务的时间片周期(单位:ms) */

/* 计算当前滴答与上次滴答的差值,滴答计数回绕(溢出)后仍能得到正确间隔 */
#define CalcPeriod(curr_tick, lastTick)	(curr_tick >= lastTick) ? \
										(curr_tick - lastTick) : \
									   (0xFFFFFFFF - lastTick + curr_tick)

#define IsPeriodReached(prd) 			(delta >= prd)  /* 判断本任务时间片是否到达,依赖局部变量delta */

/*******************************************************************************
* 全局常量定义
*******************************************************************************/

/*******************************************************************************
* 局部常量定义
*******************************************************************************/

/*******************************************************************************
* 全局变量定义
*******************************************************************************/

/*******************************************************************************
* 局部变量定义
*******************************************************************************/
static uint32_t tick1ms = 0;   /* 1ms任务上次执行的滴答时刻 */
static uint32_t tick5ms = 0;   /* 5ms任务上次执行的滴答时刻 */
static uint32_t tick10ms = 0;  /* 10ms任务上次执行的滴答时刻 */
static uint32_t tick100ms = 0; /* 100ms任务上次执行的滴答时刻 */
static uint32_t tick500ms = 0; /* 500ms任务上次执行的滴答时刻 */
static uint32_t tick1s = 0;    /* 1s任务上次执行的滴答时刻 */


/*******************************************************************************
* 局部函数声明
*******************************************************************************/
static void sch_task1ms(void);   /* 1ms周期任务 */
static void sch_task5ms(void);   /* 5ms周期任务 */
static void sch_task10ms(void);  /* 10ms周期任务 */
static void sch_task100ms(void); /* 100ms周期任务 */
static void sch_task500ms(void); /* 500ms周期任务 */
static void sch_task1s(void);    /* 1s周期任务 */
static void sch_idle(void);      /* 空闲任务 */

/*******************************************************************************
*  全局函数定义
*******************************************************************************/



/**
  * @brief TASK初始化
  * @param 无
  * @retval 无
  * @note
  */
void task_init(void)
{

}

/**
  * @brief 1ms任务
  * @param 无
  * @retval 无
  * @note
  */
static void sch_task1ms(void)
{

}

/**
  * @brief 5ms任务
  * @param 无
  * @retval 无
  * @note
  */
static void sch_task5ms(void)
{

}

/**
  * @brief 10ms任务
  * @param 无
  * @retval 无
  * @note
  */
static void sch_task10ms(void)
{

}

/**
  * @brief 100ms任务
  * @param 无
  * @retval 无
  * @note
  */
static void sch_task100ms(void)
{

}

/**
  * @brief 500ms任务
  * @param 无
  * @retval 无
  * @note
  */
static void sch_task500ms(void)
{
    led_toggle(LED1);  /* 翻转LED1,指示系统正在运行 */
}

/**
  * @brief 1S任务
  * @param 无
  * @retval 无
  * @note
  */
static void sch_task1s(void)
{

}

/**
  * @brief 空闲任务
  * @param 无
  * @retval 无
  * @note
  */
static void sch_idle(void)
{

}

/**
  * @brief 任务调度(在主循环中循环调用,按各自时间片调度各周期任务)
  * @param 无
  * @retval 无
  * @note
  */
void task_scheduler(void)
{
	uint8_t isIdle;               /* 空闲标志:1表示本轮无任何任务到期 */
	uint32_t curr_tick, delta;    /* curr_tick当前滴答值,delta与上次执行的时间间隔 */

	isIdle = 1;                   /* 先假设本轮所有任务都未到期 */
	curr_tick = systick_get_current_tick();  /* 读取当前滴答计数值 */

	delta = CalcPeriod(curr_tick, tick1ms);  /* 计算1ms任务距上次执行的滴答数 */
	if (IsPeriodReached(TICK_PRD_1MS))       /* 达到1ms周期则执行1ms任务 */
	{
		/* 重新装载周期滴答基准 */
		tick1ms = curr_tick;  /* 记录本次执行时刻 */

		sch_task1ms();  /* 执行1ms任务 */

		isIdle = 0;  /* 有任务执行,清除空闲标志 */
	}

	delta = CalcPeriod(curr_tick, tick5ms);  /* 计算5ms任务距上次执行的滴答数 */
	if (IsPeriodReached(TICK_PRD_5MS))       /* 达到5ms周期则执行5ms任务 */
	{
		/* 重新装载周期滴答基准 */
		tick5ms = curr_tick;  /* 记录本次执行时刻 */

		sch_task5ms();  /* 执行5ms任务 */

		isIdle = 0;  /* 有任务执行,清除空闲标志 */
	}

	delta = CalcPeriod(curr_tick, tick10ms);  /* 计算10ms任务距上次执行的滴答数 */
	if (IsPeriodReached(TICK_PRD_10MS))      /* 达到10ms周期则执行10ms任务 */
	{
		/* 重新装载周期滴答基准 */
		tick10ms = curr_tick;  /* 记录本次执行时刻 */

		sch_task10ms();  /* 执行10ms任务 */

		isIdle = 0;  /* 有任务执行,清除空闲标志 */
	}

	delta    = CalcPeriod(curr_tick, tick100ms);  /* 计算100ms任务距上次执行的滴答数 */
	if (IsPeriodReached(TICK_PRD_100MS))     /* 达到100ms周期则执行100ms任务 */
	{
		/* 重新装载周期滴答基准 */
		tick100ms = curr_tick;  /* 记录本次执行时刻 */

		sch_task100ms();  /* 执行100ms任务 */

		isIdle = 0;  /* 有任务执行,清除空闲标志 */
	}

	delta    = CalcPeriod(curr_tick, tick500ms);  /* 计算500ms任务距上次执行的滴答数 */
	if (IsPeriodReached(TICK_PRD_500MS))     /* 达到500ms周期则执行500ms任务 */
	{
		/* 重新装载周期滴答基准 */
		tick500ms = curr_tick;  /* 记录本次执行时刻 */

		sch_task500ms();  /* 执行500ms任务 */

		isIdle = 0;  /* 有任务执行,清除空闲标志 */
	}

	delta    = CalcPeriod(curr_tick, tick1s);  /* 计算1s任务距上次执行的滴答数 */
	if (IsPeriodReached(TICK_PRD_1S))        /* 达到1s周期则执行1s任务 */
	{
		/* 重新装载周期滴答基准 */
		tick1s = curr_tick;  /* 记录本次执行时刻 */

		sch_task1s();  /* 执行1s任务 */

		isIdle = 0;  /* 有任务执行,清除空闲标志 */
	}

	if (isIdle)  /* 所有任务都未到期时 */
	{
		sch_idle();  /* 执行空闲任务 */
	}
}
