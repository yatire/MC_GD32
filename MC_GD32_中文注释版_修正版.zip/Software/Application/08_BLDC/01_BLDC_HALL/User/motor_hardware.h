/*
*******************************************************************************************************
*
* 文件名称 : motor_hardware.h
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 电机控制硬件配置头文件(PWM/ADC/霍尔/下管驱动引脚定义)
*
*******************************************************************************************************
*/

#ifndef _MOTOR_HARDWARE_H_    /* 头文件保护宏,防止重复包含 */
#define _MOTOR_HARDWARE_H_    /* 定义头文件保护宏 */

#ifdef __cplusplus    /* C++编译兼容处理 */
extern "C"{    /* 按C语言方式导出接口 */
#endif    /* 结束条件编译 */

/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "gd32f30x.h"    /* GD32F30x固件库总头文件 */
#include "motor_config.h"    /* 电机硬件参数配置(母线电压/过流阈值等) */


/* 宏定义 ------------------------------------------------------------------------------------------*/
#define MOTOR_PWM_TIMER     TIMER0    /* 电机PWM定时器:TIMER0高级定时器 */
#define PWM_U_CHANNEL       TIMER_CH_2    /* U相高侧PWM输出通道 */
#define PWM_V_CHANNEL       TIMER_CH_1    /* V相高侧PWM输出通道 */
#define PWM_W_CHANNEL       TIMER_CH_0    /* W相高侧PWM输出通道 */

#define MOTOR_CURRENT_ADC       ADC0    /* 电流采样ADC:ADC0 */
#define IU_INSERTED_CHANNEL     ADC_INSERTED_CHANNEL_0    /* U相电流ADC注入组通道0 */
#define IV_INSERTED_CHANNEL     ADC_INSERTED_CHANNEL_1    /* V相电流ADC注入组通道1 */
#define IW_INSERTED_CHANNEL     ADC_INSERTED_CHANNEL_2    /* W相电流ADC注入组通道2 */
#define IDC_AVER_INSERTED_CHANNEL    ADC_INSERTED_CHANNEL_3    /* 母线电流平均值ADC注入组通道3 */

#define IU_ADC_PORT         GPIOC    /* U相电流采样端口 */
#define IU_ADC_PIN          GPIO_PIN_4    /* U相电流采样引脚PC4 */
#define IU_ADC_CLK          RCU_GPIOC    /* U相电流采样端口时钟 */
#define IU_ADC_CHANNEL      ADC_CHANNEL_14    /* U相电流ADC通道14 */

#define IV_ADC_PORT         GPIOC    /* V相电流采样端口 */
#define IV_ADC_PIN          GPIO_PIN_5    /* V相电流采样引脚PC5 */
#define IV_ADC_CLK          RCU_GPIOC    /* V相电流采样端口时钟 */
#define IV_ADC_CHANNEL      ADC_CHANNEL_15    /* V相电流ADC通道15 */

#define IW_ADC_PORT         GPIOB    /* W相电流采样端口 */
#define IW_ADC_PIN          GPIO_PIN_0    /* W相电流采样引脚PB0 */
#define IW_ADC_CLK          RCU_GPIOB    /* W相电流采样端口时钟 */
#define IW_ADC_CHANNEL      ADC_CHANNEL_8    /* W相电流ADC通道8 */

#define IDC_ADC_PORT        GPIOB    /* 母线电流采样端口 */
#define IDC_ADC_PIN         GPIO_PIN_1    /* 母线电流采样引脚PB1 */
#define IDC_ADC_CLK         RCU_GPIOB    /* 母线电流采样端口时钟 */
#define IDC_ADC_CHANNEL     ADC_CHANNEL_9    /* 母线电流ADC通道9 */

#define IDC_AVER_ADC_PORT        GPIOA    /* 母线电流平均值采样端口 */
#define IDC_AVER_ADC_PIN         GPIO_PIN_3    /* 母线电流平均值采样引脚PA3 */
#define IDC_AVER_ADC_CLK         RCU_GPIOA    /* 母线电流平均值采样端口时钟 */
#define IDC_AVER_ADC_CHANNEL     ADC_CHANNEL_3    /* 母线电流平均值ADC通道3 */

#define BEMFU_ADC_PORT      GPIOA    /* U相反电动势采样端口 */
#define BEMFU_ADC_PIN       GPIO_PIN_0    /* U相反电动势采样引脚PA0 */
#define BEMFU_ADC_CLK       RCU_GPIOA    /* U相反电动势采样端口时钟 */
#define BEMFU_ADC_CHANNEL   ADC_CHANNEL_0    /* U相反电动势ADC通道0 */

#define BEMFV_ADC_PORT      GPIOA    /* V相反电动势采样端口 */
#define BEMFV_ADC_PIN       GPIO_PIN_1    /* V相反电动势采样引脚PA1 */
#define BEMFV_ADC_CLK       RCU_GPIOA    /* V相反电动势采样端口时钟 */
#define BEMFV_ADC_CHANNEL   ADC_CHANNEL_1    /* V相反电动势ADC通道1 */

#define BEMFW_ADC_PORT      GPIOA    /* W相反电动势采样端口 */
#define BEMFW_ADC_PIN       GPIO_PIN_2    /* W相反电动势采样引脚PA2 */
#define BEMFW_ADC_CLK       RCU_GPIOA    /* W相反电动势采样端口时钟 */
#define BEMFW_ADC_CHANNEL   ADC_CHANNEL_2    /* W相反电动势ADC通道2 */

#define USER_IO1_PORT       GPIOB    /* 用户IO1端口 */
#define USER_IO1_PIN        GPIO_PIN_6    /* 用户IO1引脚PB6 */
#define USER_IO1_CLK        RCU_GPIOB    /* 用户IO1端口时钟 */

#define USER_IO3_PORT       GPIOC    /* 用户IO3端口 */
#define USER_IO3_PIN        GPIO_PIN_0    /* 用户IO3引脚PC0 */
#define USER_IO3_CLK        RCU_GPIOC    /* 用户IO3端口时钟 */

#define USER_IO2_PORT       GPIOB    /* 用户IO2端口 */
#define USER_IO2_PIN        GPIO_PIN_7    /* 用户IO2引脚PB7 */
#define USER_IO2_CLK        RCU_GPIOB    /* 用户IO2端口时钟 */

#define HALLA_GPIO_PORT     GPIOC    /* 霍尔传感器A相信号端口 */
#define HALLA_GPIO_PIN      GPIO_PIN_6    /* 霍尔传感器A相信号引脚PC6 */
#define HALLA_GPIO_CLK      RCU_GPIOC    /* 霍尔传感器A相端口时钟 */

#define HALLB_GPIO_PORT     GPIOC    /* 霍尔传感器B相信号端口 */
#define HALLB_GPIO_PIN      GPIO_PIN_7    /* 霍尔传感器B相信号引脚PC7 */
#define HALLB_GPIO_CLK      RCU_GPIOC    /* 霍尔传感器B相端口时钟 */

#define HALLC_GPIO_PORT     GPIOC    /* 霍尔传感器C相信号端口 */
#define HALLC_GPIO_PIN      GPIO_PIN_8    /* 霍尔传感器C相信号引脚PC8 */
#define HALLC_GPIO_CLK      RCU_GPIOC    /* 霍尔传感器C相端口时钟 */

#define PWMUL_GPIO_PORT     GPIOB    /* U相下管驱动端口 */
#define PWMUL_GPIO_PIN      GPIO_PIN_15    /* U相下管驱动引脚PB15 */
#define PWMUL_GPIO_CLK      RCU_GPIOB    /* U相下管驱动端口时钟 */

#define PWMVL_GPIO_PORT     GPIOB    /* V相下管驱动端口 */
#define PWMVL_GPIO_PIN      GPIO_PIN_14    /* V相下管驱动引脚PB14 */
#define PWMVL_GPIO_CLK      RCU_GPIOB    /* V相下管驱动端口时钟 */

#define PWMWL_GPIO_PORT     GPIOB    /* W相下管驱动端口 */
#define PWMWL_GPIO_PIN      GPIO_PIN_13    /* W相下管驱动引脚PB13 */
#define PWMWL_GPIO_CLK      RCU_GPIOB    /* W相下管驱动端口时钟 */

/* 变量定义 ----------------------------------------------------------------------------------------*/


/* 函数定义 -----------------------------------------------------------------------------------------*/
void motor_hardware_init(void);    /* 电机硬件外设总初始化 */
void adc0_init(void);    /* ADC0初始化(注入组采集相电流/母线电流) */
void interrupt_init(void);    /* 中断配置 */
void comp_protect_init(void);    /* 比较器过流保护初始化 */
void hall_init(void);    /* 霍尔传感器接口初始化 */
uint8_t hall_get(void);    /* 读取霍尔状态字(3位组合,1~6) */
void motor_pwm_set_duty(uint16_t duty_u,uint16_t duty_v,uint16_t duty_w);    /* 设置三相PWM占空比(六步换相) */

#ifdef __cplusplus    /* C++编译兼容处理 */
extern "C"{    /* 按C语言方式导出接口 */
#endif    /* 结束条件编译 */

#endif /* _MOTOR_HARDWARE_H_ */

/***************************************** 文件结束 *********************************************/
