/*
*******************************************************************************************************
*
* 文件名称 : bldc_hall.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : BLDC霍尔驱动文件
*
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "motor_hardware.h"    /* 电机硬件接口头文件(PWM通道/下桥臂GPIO/霍尔引脚/BEMF采样通道宏) */
#include "bldc_hall.h"    /* BLDC霍尔控制头文件(电机状态结构体/方向与运行标志宏/速度环PI参数) */
#include "systick.h"    /* 系统节拍定时器头文件(systick_delay毫秒延时函数声明) */

/* 宏定义 ------------------------------------------------------------------------------------------*/


/* 局部函数 -----------------------------------------------------------------------------------*/
/*  六步换相 */
static void m1_uhvl(void);    /* 换相状态5:U相高侧管PWM调制,V相低侧管导通(W相悬空) */
static void m1_uhwl(void);    /* 换相状态1:U相高侧管PWM调制,W相低侧管导通(V相悬空) */
static void m1_vhwl(void);    /* 换相状态3:V相高侧管PWM调制,W相低侧管导通(U相悬空) */
static void m1_vhul(void);    /* 换相状态2:V相高侧管PWM调制,U相低侧管导通(W相悬空) */
static void m1_whul(void);    /* 换相状态6:W相高侧管PWM调制,U相低侧管导通(V相悬空) */
static void m1_whvl(void);    /* 换相状态4:W相高侧管PWM调制,V相低侧管导通(U相悬空) */

static uint8_t uemf_edge(uint8_t val);    /* 检测信号跳变:返回0=信号变为0,1=信号变为1,2=无变化(用于测速) */
static uint32_t hallsensor_get_state(void);    /* 读取霍尔A/B/C引脚电平并组合为状态值 */

/* 变量定义 ----------------------------------------------------------------------------------------*/

_bldc_obj g_bldc_motor = {0};   /* 电机结构体初始值 */

/*  六步换向函数指针数组 */
pctr pfunclist_m1[6] =    /* 下标0~5依次对应换相状态1~6:UHWL,VHUL,VHWL,WHVL,UHVL,WHUL */
{
    &m1_uhwl, &m1_vhul, &m1_vhwl,
    &m1_whvl, &m1_uhvl, &m1_whul
};

/* 悬空相反电动势(BEMF)采样通道表:下标0~5对应换相状态1~6,元素为该状态下悬空相的BEMF采样通道 */
uint8_t adc_channel[6] = 
{
    BEMFV_ADC_CHANNEL,BEMFW_ADC_CHANNEL,BEMFU_ADC_CHANNEL,
    BEMFU_ADC_CHANNEL,BEMFW_ADC_CHANNEL,BEMFV_ADC_CHANNEL
};

/* 函数定义 -----------------------------------------------------------------------------------------*/
void bldc_init(void)    /* BLDC控制参数初始化:方向/计数/占空比/转速/运行标志与速度环PI参数 */
{
    g_bldc_motor.dir = CW;    /* 默认旋转方向:顺时针(CW) */
    g_bldc_motor.count_j = 0;    /* 测速计数清零 */
    g_bldc_motor.lock_time = 0;    /* 堵转时间计数清零 */
    g_bldc_motor.pwm_duty = 0;    /* PWM占空比清零 */
    g_bldc_motor.speed = 0;    /* 转速清零 */
    g_bldc_motor.run_flag = STOP;    /* 运行标志置为停止 */
    
	g_bldc_motor.speed_pi.kp = WKP;    /* 速度环PI比例系数 */
	g_bldc_motor.speed_pi.ki = WKI;    /* 速度环PI积分系数 */
	g_bldc_motor.speed_pi.kc = WKC;    /* 速度环PI抗积分饱和回算系数 */
	g_bldc_motor.speed_pi.out_max = WOUTMAX;    /* 速度环PI输出上限(对应最大占空比) */
	g_bldc_motor.speed_pi.out_min = MIN_PWM_DUTY;    /* 速度环PI输出下限(对应最小占空比) */
	
	init_pi(&g_bldc_motor.speed_pi);    /* 初始化PI控制器内部状态(积分项清零等) */
}

/**
 * @brief       BLDC控制函数
 * @param       dir :电机方向, Duty:PWM占空比
 * @retval      无
 */
void bldc_ctrl(int32_t dir,float duty)    /* 设置电机旋转方向与PWM占空比 */
{
	g_bldc_motor.dir = dir;            /* 方向 */
	g_bldc_motor.pwm_duty = duty;      /* 占空比 */
}

/* 关闭电机运转 */
void stop_motor(void)    /* 停止电机:封锁三相PWM输出 */
{
	/* 关闭 PWM 输出 */
    timer_channel_output_mode_config(TIMER0,PWM_U_CHANNEL,TIMER_OC_MODE_INACTIVE);    /* U相通道输出无效电平,封锁该相PWM */
    timer_channel_output_mode_config(TIMER0,PWM_V_CHANNEL,TIMER_OC_MODE_INACTIVE);    /* V相通道输出无效电平,封锁该相PWM */
    timer_channel_output_mode_config(TIMER0,PWM_W_CHANNEL,TIMER_OC_MODE_INACTIVE);    /* W相通道输出无效电平,封锁该相PWM */
	/* 上下桥臂全部关断 */
	motor_pwm_set_duty(0,0,0);    /* 三相占空比全部置0 */
}

/* 开启电机运转 */
void start_motor(void)    /* 启动电机:恢复三相PWM输出 */
{
	/* 使能 PWM 输出 */
    timer_channel_output_mode_config(TIMER0,PWM_U_CHANNEL,TIMER_OC_MODE_PWM0);    /* U相通道恢复PWM0输出模式 */
    timer_channel_output_mode_config(TIMER0,PWM_V_CHANNEL,TIMER_OC_MODE_PWM0);    /* V相通道恢复PWM0输出模式 */
    timer_channel_output_mode_config(TIMER0,PWM_W_CHANNEL,TIMER_OC_MODE_PWM0);    /* W相通道恢复PWM0输出模式 */
}

void bldc_mainfunction(void)    /* BLDC核心处理:霍尔换相/测速/速度环,需由主循环周期调用 */
{
    int32_t temp_speed=0;    /* 本次测得的临时转速(rpm) */
    if(g_bldc_motor.run_flag == RUN)    /* 仅在运行标志为RUN时执行换相与测速 */
    {
        if(g_bldc_motor.dir == CW)                                     /* 正转 */
        {
            g_bldc_motor.step_sta = hallsensor_get_state();     /* 顺序6,2,3,1,5,4 */
        }
        else                                                            /* 反转 */
        {
            g_bldc_motor.step_sta = 7 - hallsensor_get_state(); /* 顺序5,1,3,2,6,4 。使用7减完后可与数组pfunclist_m1对应上顺序 实际霍尔值为：2,6,4,5,1,3*/
        }
        
        if((g_bldc_motor.step_sta <= 6)&&(g_bldc_motor.step_sta >= 1))/* 判断霍尔组合值是否正常 */
        {
            pfunclist_m1[g_bldc_motor.step_sta-1]();                   /* 通过数组成员查找对应的函数指针 */
            /* 注:以下代码已被注释停用——按换相状态把对应BEMF通道挂接到ADC0注入组(采样时间1.5个ADC时钟周期) */
            /* adc_inserted_channel_config(ADC0, IU_INSERTED_CHANNEL, adc_channel[g_bldc_motor.step_sta-1], ADC_SAMPLETIME_1POINT5); */
        }
        else                                                            /* 霍尔传感器错误、接触不良、断开等情况 */
        {
            stop_motor();    /* 封锁PWM输出 */
            g_bldc_motor.run_flag = STOP;    /* 运行标志置停止 */
        }
        
        /******************************* 速度计算 *******************************/
        g_bldc_motor.count_j++;                /* 计算速度专用计数值 */
        g_bldc_motor.hall_sta_edge = uemf_edge(g_bldc_motor.step_sta & 0X01);/* 检测单个霍尔信号的变化 */
        if(g_bldc_motor.hall_sta_edge == 0)    /* 统计单个霍尔信号的高电平时间，当只有一对级的时候，旋转一圈为一个完整脉冲。一高一低相加即旋转一圈所花的时间*/
        {
            /*计算速度*/
            if(g_bldc_motor.dir == CW)    /* 正转:按测速计数换算转速(rpm) */
                temp_speed = (60*MOTOR_PWM_FREQ_HZ)/g_bldc_motor.count_j/2/MOTOR_NOPOLESPAIRS;    /* 换算转速 */
            else
                temp_speed = (60*MOTOR_PWM_FREQ_HZ/g_bldc_motor.count_j/2/MOTOR_NOPOLESPAIRS);    /* 换算转速 */
            FirstOrderRC_LPF(g_bldc_motor.speed,temp_speed,0.2379f);   /* 一阶滤波 */
            g_bldc_motor.no_single = 0;    /* 无信号(未换向)计数清零 */
            g_bldc_motor.count_j = 0;    /* 测速计数清零,开始统计下一个脉冲周期 */
        }
        if(g_bldc_motor.hall_sta_edge == 1)    /* 当采集到上升沿(uemf_edge返回1)时数据清0 */
        {
            g_bldc_motor.no_single = 0;    /* 无信号计数清零 */
            g_bldc_motor.count_j = 0;    /* 测速计数清零 */
        }
        if(g_bldc_motor.hall_sta_edge == 2)    /* 霍尔值一直不变代表未换向 */
        {
            g_bldc_motor.no_single++;          /* 不换相时间累计 超时则判定速度为0 */
            
            if(g_bldc_motor.no_single > 15000)    /* 长时间未换相,判定电机停转 */
            {
                stop_motor();    /* 封锁PWM输出 */
                g_bldc_motor.run_flag = STOP;    /* 运行标志置停止 */
                g_bldc_motor.no_single = 0;    /* 无信号计数清零 */
                g_bldc_motor.speed = 0;        /* 超时换向 判定为停止 速度为0 */
            }
        }
        /******************************* PID控制 *******************************/
#if(SPEED_LOOP == 1)    /* 速度闭环使能(SPEED_LOOP=1)时执行速度环PI调节 */
        g_bldc_motor.speed_pi.meas = g_bldc_motor.speed;    /* 速度环测量值:滤波后的实测转速 */
        g_bldc_motor.speed_pi.ref = g_bldc_motor.target_speed;    /* 速度环给定值:目标转速 */
        calc_pi(&g_bldc_motor.speed_pi);    /* 执行速度环PI计算 */
        g_bldc_motor.pwm_duty = g_bldc_motor.speed_pi.out;    /* PI输出作为PWM占空比 */
#endif
    }
}


/* 局部函数 -----------------------------------------------------------------------------------*/

/**
* @brief 获取霍尔传感器引脚状态
* @param 无
* @retval 霍尔传感器引脚状态
*/
static uint32_t hallsensor_get_state(void)
{
	__IO static uint32_t State ;    /* 霍尔组合状态值(__IO防编译器优化) */
	State = 0;    /* 状态值清零 */
	if(gpio_input_bit_get(HALLA_GPIO_PORT,HALLA_GPIO_PIN) != RESET) /* 霍尔 1 传感器状态获取 */
	{
		State |= 0x01U;    /* 置位霍尔A位(bit0) */
	}
	if(gpio_input_bit_get(HALLB_GPIO_PORT,HALLB_GPIO_PIN) != RESET) /* 霍尔 2 传感器状态获取 */
	{
		State |= 0x02U;    /* 置位霍尔B位(bit1) */
	}
	if(gpio_input_bit_get(HALLC_GPIO_PORT,HALLC_GPIO_PIN) != RESET) /* 霍尔 3 传感器状态获取 */
	{
		State |= 0x04U;    /* 置位霍尔C位(bit2) */
	}
	return State;    /* 返回霍尔组合状态值1~6 */
}

/**
 * @brief       检测输入信号是否发生变化
 * @param       val :输入信号
 * @note        测量速度使用，获取输入信号状态翻转情况，计算速度
 * @retval      0：计算高电平时间，1：计算低电平时间，2：信号未改变
 */
static uint8_t uemf_edge(uint8_t val)
{
    /* 主要是检测val信号从0 - 1 在从 1 - 0的过程，即高电平所持续的过程 */
    static uint8_t oldval=0;    /* 上一次的信号值(静态变量保存) */
    if(oldval != val)    /* 信号发生跳变 */
    {
        oldval = val;    /* 更新信号历史值 */
        if(val == 0) return 0;    /* 新值为0(信号下降沿),返回0 */
        else return 1;    /* 新值为1(信号上升沿),返回1 */
    }
    return 2;    /* 信号无变化,返回2 */
}

/* 上下桥臂的导通情况，共 6 种，也称为 6 步换向 */
void m1_uhvl(void)    /* 换相状态5:U相高侧管PWM调制,V相低侧管导通(W相悬空) */
{
    motor_pwm_set_duty(g_bldc_motor.pwm_duty,0,0);    /* U相高侧管输出PWM(占空比pwm_duty),V/W相高侧管关闭 */
    gpio_bit_write(PWMUL_GPIO_PORT, PWMUL_GPIO_PIN, RESET);    /* U相低侧管关断 */
    gpio_bit_write(PWMVL_GPIO_PORT, PWMVL_GPIO_PIN, SET);    /* V相低侧管导通 */
    gpio_bit_write(PWMWL_GPIO_PORT, PWMWL_GPIO_PIN, RESET);    /* W相低侧管关断 */
}

void m1_uhwl(void)    /* 换相状态1:U相高侧管PWM调制,W相低侧管导通(V相悬空) */
{
    motor_pwm_set_duty(g_bldc_motor.pwm_duty,0,0);    /* U相高侧管输出PWM(占空比pwm_duty),V/W相高侧管关闭 */
    gpio_bit_write(PWMUL_GPIO_PORT, PWMUL_GPIO_PIN, RESET);    /* U相低侧管关断 */
    gpio_bit_write(PWMVL_GPIO_PORT, PWMVL_GPIO_PIN, RESET);    /* V相低侧管关断 */
    gpio_bit_write(PWMWL_GPIO_PORT, PWMWL_GPIO_PIN, SET);    /* W相低侧管导通 */
}

void m1_vhwl(void)    /* 换相状态3:V相高侧管PWM调制,W相低侧管导通(U相悬空) */
{
    motor_pwm_set_duty(0,g_bldc_motor.pwm_duty,0);    /* V相高侧管输出PWM(占空比pwm_duty),U/W相高侧管关闭 */
    gpio_bit_write(PWMUL_GPIO_PORT, PWMUL_GPIO_PIN, RESET);    /* U相低侧管关断 */
    gpio_bit_write(PWMVL_GPIO_PORT, PWMVL_GPIO_PIN, RESET);    /* V相低侧管关断 */
    gpio_bit_write(PWMWL_GPIO_PORT, PWMWL_GPIO_PIN, SET);    /* W相低侧管导通 */
}

void m1_vhul(void)    /* 换相状态2:V相高侧管PWM调制,U相低侧管导通(W相悬空) */
{
    motor_pwm_set_duty(0,g_bldc_motor.pwm_duty,0);    /* V相高侧管输出PWM(占空比pwm_duty),U/W相高侧管关闭 */
    gpio_bit_write(PWMUL_GPIO_PORT, PWMUL_GPIO_PIN, SET);    /* U相低侧管导通 */
    gpio_bit_write(PWMVL_GPIO_PORT, PWMVL_GPIO_PIN, RESET);    /* V相低侧管关断 */
    gpio_bit_write(PWMWL_GPIO_PORT, PWMWL_GPIO_PIN, RESET);    /* W相低侧管关断 */
}

void m1_whul(void)    /* 换相状态6:W相高侧管PWM调制,U相低侧管导通(V相悬空) */
{
    motor_pwm_set_duty(0,0,g_bldc_motor.pwm_duty);    /* W相高侧管输出PWM(占空比pwm_duty),U/V相高侧管关闭 */
    gpio_bit_write(PWMUL_GPIO_PORT, PWMUL_GPIO_PIN, SET);    /* U相低侧管导通 */
    gpio_bit_write(PWMVL_GPIO_PORT, PWMVL_GPIO_PIN, RESET);    /* V相低侧管关断 */
    gpio_bit_write(PWMWL_GPIO_PORT, PWMWL_GPIO_PIN, RESET);    /* W相低侧管关断 */
}

void m1_whvl(void)    /* 换相状态4:W相高侧管PWM调制,V相低侧管导通(U相悬空) */
{
    motor_pwm_set_duty(0,0,g_bldc_motor.pwm_duty);    /* W相高侧管输出PWM(占空比pwm_duty),U/V相高侧管关闭 */
    gpio_bit_write(PWMUL_GPIO_PORT, PWMUL_GPIO_PIN, RESET);    /* U相低侧管关断 */
    gpio_bit_write(PWMVL_GPIO_PORT, PWMVL_GPIO_PIN, SET);    /* V相低侧管导通 */
    gpio_bit_write(PWMWL_GPIO_PORT, PWMWL_GPIO_PIN, RESET);    /* W相低侧管关断 */
}

/***************************************** 文件结束 *********************************************/
