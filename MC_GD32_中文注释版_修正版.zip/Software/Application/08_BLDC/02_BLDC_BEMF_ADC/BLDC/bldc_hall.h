/*
*******************************************************************************************************
*
* 文件名称 : bldc_hall.h
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : BLDC 霍尔传感器换相控制接口(电机对象/速度环参数/控制函数声明)
* 
*******************************************************************************************************
*/
#ifndef _BLDC_HALL_H_ /* 头文件保护宏：防止重复包含 */
#define _BLDC_HALL_H_ /* 定义头文件保护宏 */

#ifdef __cplusplus /* C++ 兼容处理 */
extern "C"{ /* 以 C 语言方式编译 */
#endif /* __cplusplus 条件编译结束 */

/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "gd32f30x.h" /* GD32F30x 固件库总头文件 */
#include "pid.h" /* PI 控制器定义(速度环用) */

/* 类型定义 ------------------------------------------------------------------------------------------*/
typedef struct { /* BLDC 电机控制对象结构体 */
    __IO uint8_t    run_flag;       /* 运行标志 */
    __IO uint8_t    locked_rotor;   /* 堵转标记 */
    __IO uint8_t    step_sta;       /* 本次霍尔状态 */
    __IO uint8_t    hall_sta_edge;  /* 单个霍尔状态跳变 */
    __IO uint8_t    step_last;      /* 上次霍尔状态 */
    __IO uint8_t    dir;            /* 电机旋转方向 */
    __IO int32_t    pos;            /* 电机位置 */
    __IO int32_t    target_speed;   /* 期望转速 */
    __IO int32_t    speed;          /* 电机速度 */
    __IO int16_t    current;        /* 电机电流 */
    __IO uint16_t   pwm_duty;       /* 电机占空比 */
    __IO uint32_t   hall_keep_t;    /* 霍尔保持时间 */
    __IO uint32_t   hall_pul_num;   /* 霍尔传感器脉冲数 */
    __IO uint32_t   lock_time;      /* 电机堵转时间 */
    __IO uint32_t   no_single;    /* 无信号(未换相)计数：超时判定电机停转 */
    __IO uint32_t   count_j;      /* 测速计数：统计两个霍尔脉冲间的定时器计数 */
    pid_control_t   speed_pi; /* 速度环 PI 控制器 */
} _bldc_obj; /* BLDC 电机对象类型 */

/* 宏定义 ------------------------------------------------------------------------------------------*/
#define SPEED_LOOP                  0 /* 速度闭环使能开关：0=关闭速度环(开环运行) */

#define MAX_PWM_DUTY                ((float)MOTOR_PWM_PERIOD*0.96)        /* 最大占空比限制 */
#define MIN_PWM_DUTY                ((float)MOTOR_PWM_PERIOD*0.2)        /* 最小占空比限制 */

#define     WKP        (0.5) /* 速度环 PI 比例系数 */
#define     WKI        (0.0001) /* 速度环 PI 积分系数 */
#define     WKC        (0.5) /* 速度环 PI 抗积分饱和回算系数 */
#define     WOUTMAX    MAX_PWM_DUTY /* 速度环 PI 输出上限(对应最大占空比) */

typedef void(*pctr) (void); /* 换相处理函数指针类型(六步换相表用) */

#define CCW                         (1)                 /* 逆时针 */
#define CW                          (2)                 /* 顺时针 */
#define HALL_ERROR                  (0xF0)              /* 霍尔错误标志 */
#define RUN                         (1)                 /* 电机运动标志 */
#define STOP                        (0)                 /* 电机停机标志 */

#define FirstOrderRC_LPF(Yn_1,Xn,a) Yn_1 = (1-a)*Yn_1 + a*Xn;   /* Yn:输出;Xn:输入;a:滤波系数 */

#define MOTOR_NOPOLESPAIRS          2 /* 电机极对数 */
#define MAX_SPEED                   5000 /* 最大转速限制(rpm) */
#define MIN_SPEED                   100 /* 最小转速限制(rpm) */

/* 变量定义 ----------------------------------------------------------------------------------------*/
extern _bldc_obj g_bldc_motor; /* BLDC 电机控制全局对象 */

/* 函数定义 -----------------------------------------------------------------------------------------*/
void bldc_init(void); /* BLDC 控制参数初始化(方向/计数/占空比/速度环 PI) */
void bldc_ctrl(int32_t dir,float duty); /* 设置电机旋转方向与 PWM 占空比 */
void stop_motor(void); /* 停止电机：封锁三相 PWM 输出 */
void start_motor(void); /* 启动电机：恢复三相 PWM 输出 */
void bldc_mainfunction(void); /* BLDC 核心处理(霍尔换相/测速/速度环)，主循环周期调用 */

#ifdef __cplusplus /* C++ 兼容处理 */
extern "C"{ /* 以 C 语言方式编译 */
#endif /* __cplusplus 条件编译结束 */

#endif /* _BLDC_HALL_H_ */

/***************************************** 文件结束 *********************************************/
