/*
*******************************************************************************************************
*
* 文件名称 : main.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 主函数文件(BLDC反电动势ADC采样方案例程)
*
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include <string.h> /* C字符串/内存操作库头文件(memcpy等) */
#include "gd32f30x.h" /* GD32F30x芯片外设寄存器与固件库头文件 */
#include "gd32f30x_libopt.h" /* GD32F30x固件库外设包含配置头文件 */
#include "systick.h" /* 滴答定时器配置头文件(系统节拍/延时) */
#include "led.h" /* LED驱动头文件 */
#include "motor_hardware.h" /* 电机硬件接口配置头文件(PWM/ADC/BEMF采样/霍尔引脚) */
#include "uart.h" /* 串口驱动头文件 */
#include "i2c.h" /* I2C驱动头文件 */
#include "eeprom.h" /* EEPROM(24C02)读写驱动头文件 */
#include "delay.h" /* 忙等待延时函数头文件 */
#include "adc_simple.h" /* 简易ADC采样头文件(母线电压/NTC温度) */
#include "lcd.h" /* LCD显示驱动头文件 */
#include "lcd_init.h" /* LCD初始化及硬件引脚配置头文件 */
#include "can.h" /* CAN总线驱动头文件 */
#include "drv8323rs.h" /* DRV8323RS栅极驱动器SPI驱动头文件 */
#include "bldc_hall.h" /* BLDC霍尔方波控制算法头文件(电机状态结构体/换相控制) */
#include "encoder.h" /* 编码器(旋钮)驱动头文件 */
#include "key_fifo.h" /* 按键FIFO驱动头文件(扫描/读取键值) */

/* 宏定义 ------------------------------------------------------------------------------------------*/


/* 变量定义 ----------------------------------------------------------------------------------------*/
float temp1 = 0,temp2 = 0,temp3 = 0; /* 串口上传用临时浮点变量(3个通道数据) */
uint8_t uart_data[16] = {0}; /* 串口发送数据缓冲区(16字节,含帧尾标志) */

uint32_t tick = 0; /* 主循环软定时计数器(单位:ms) */
uint8_t key = KEY_NONE; /* 当前按键值(初始为无按键) */
encoder_code_t encoder_code = ENCODER_NONE; /* 编码器动作码(无动作/增量/减量) */

uint16_t adc1_ia = 0; /* ADC注入组序位0采样值(本方案配置为U相反电动势BEMFU通道) */
uint16_t adc1_ib = 0; /* ADC注入组序位1采样值(本方案配置为V相反电动势BEMFV通道) */
uint16_t adc1_ic = 0; /* ADC注入组序位2采样值(本方案配置为W相反电动势BEMFW通道) */
uint16_t adc1_idc = 0; /* ADC注入组序位3采样值(母线电流平均值IDC_AVER通道) */
/* 函数定义 -----------------------------------------------------------------------------------------*/


/**
  * @brief 主函数
  * @param 无
  * @retval 无
  */
int main(void)
{
    SCB->VTOR = FLASH_BASE | 0x4000; /* 设置中断向量表到APP区基址(偏移0x4000,由Bootloader引导) */
    __enable_irq(); /* 使能全局中断 */
    
    systick_init(); /* 初始化滴答定时器(1ms系统节拍) */
    led_init(); /* 初始化LED指示灯 */
    usart_init(); /* 初始化调试串口 */
    encoder_init(); /* 初始化编码器(旋钮)接口 */
    key_fifo_init(); /* 初始化按键FIFO */
    DRV8323RS_init(); /* 初始化DRV8323RS栅极驱动器(SPI寄存器配置/CSA校准) */
    
    motor_hardware_init(); /* 初始化电机硬件(NVIC/PWM/霍尔接口/ADC注入组) */
    
    timer_enable(TIMER0); /* 使能TIMER0计数器,开始输出PWM */
    
    /* 初始化用户IO3(PC0)为推挽输出(ADC中断耗时测量探针) */
    gpio_init(USER_IO3_PORT, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ,USER_IO3_PIN);
    gpio_bit_write(USER_IO3_PORT, USER_IO3_PIN,SET); /* 用户IO3输出高电平(初始电平) */
    
    systick_delay(2000); /* 延时2秒,等待驱动芯片上电稳定 */
    
    bldc_init(); /* BLDC控制参数初始化(方向/占空比/速度环PI) */
    g_bldc_motor.dir = CCW; /* 设置旋转方向为逆时针 */
    g_bldc_motor.run_flag = RUN;           /* 开启运行 */
    g_bldc_motor.pwm_duty = 750; /* 初始占空比750(开环占空比模式,SPEED_LOOP=0) */
    g_bldc_motor.target_speed = 300; /* 目标转速300rpm(速度环模式使用) */
        start_motor();                         /* 开启运行 */
    
    while(1) /* 主循环:周期处理LED/按键/编码器事件 */
    {
        tick++; /* 软定时器累加(主循环含systick_delay(10),每循环约10ms) */
        if(tick >= 50) /* 计满50次(约500ms)刷新一次LED状态 */
        {
            tick = 0; /* 软定时器清零重新计数 */
            led_toggle(LED_SYS); /* 翻转系统LED,指示程序存活 */
            if(g_bldc_motor.run_flag == RUN) /* 电机处于运行状态 */
            {
                led_on(LED1); /* 点亮LED1指示电机运行中 */
            }
            else
            {
                led_off(LED1); /* 熄灭LED1指示电机停止 */
            }
        }
        
        key_scan(); /* 按键扫描(状态机消抖) */
        key = key_get(); /* 从FIFO取出键值 */
        switch(key) /* 按键事件分发 */
        {
        case KEY_0_RELEASE: /* KEY0短按释放:启停切换 */
            if(g_bldc_motor.run_flag == RUN) /* 若电机正在运行 */
            {
                g_bldc_motor.run_flag = STOP; /* 置停止标志 */
                stop_motor(); /* 停止电机(封锁PWM输出) */
            }
            else
            {
                g_bldc_motor.run_flag = RUN; /* 置运行标志 */
                start_motor(); /* 启动电机(恢复PWM输出,进入换相控制) */
            }
            break; /* 退出switch */
        case KEY_0_LONG_PRESS: /* KEY0长按:暂不处理 */
            break; /* 退出switch */
        default:
            break; /* 退出switch */
        }

        encoder_code = encoder_get(); /* 读取编码器旋转动作 */
        switch(encoder_code) /* 编码器事件分发 */
        {
        case ENCODER_NONE: /* 编码器无动作 */
            break; /* 退出switch */
        case ENCODER_INC: /* 编码器增量旋转:加大目标 */
#if(SPEED_LOOP == 1) /* 速度环模式:编码器调节目标转速 */
            if(g_bldc_motor.run_flag == RUN) /* 若电机正在运行 */
            {
                if(g_bldc_motor.target_speed < MAX_SPEED) /* 未超过最大转速 */
                    g_bldc_motor.target_speed += 100; /* 目标转速加100rpm */
            }
#else /* 开环占空比模式:编码器调节占空比 */
            if(g_bldc_motor.run_flag == RUN) /* 若电机正在运行 */
            {
                if(g_bldc_motor.pwm_duty < MAX_PWM_DUTY) /* 未超过最大占空比 */
                    g_bldc_motor.pwm_duty += 100; /* 占空比加100(计数) */
            }
#endif /* 结束条件编译 */
            break; /* 退出switch */
        case ENCODER_DEC: /* 编码器减量旋转:减小目标 */
#if(SPEED_LOOP == 1) /* 速度环模式:编码器调节目标转速 */
            if(g_bldc_motor.run_flag == RUN) /* 若电机正在运行 */
            {
                if(g_bldc_motor.target_speed > MIN_SPEED) /* 未低于最小转速 */
                    g_bldc_motor.target_speed -= 100; /* 目标转速减100rpm */
            }
#else /* 开环占空比模式:编码器调节占空比 */
            if(g_bldc_motor.run_flag == RUN) /* 若电机正在运行 */
            {
                if(g_bldc_motor.pwm_duty > MIN_PWM_DUTY) /* 未低于最小占空比 */
                    g_bldc_motor.pwm_duty -= 100; /* 占空比减100(计数) */
            }
#endif /* 结束条件编译 */
            break; /* 退出switch */
        }
        
        systick_delay(10); /* 延时10ms,主循环周期 */
    }
}

/**
  * @brief TIMER0刹车中断服务函数(硬件故障保护时触发)
  * @param 无
  * @retval 无
  */
void TIMER0_BRK_IRQHandler(void)
{
    timer_channel_output_mode_config(TIMER0,TIMER_CH_0,TIMER_OC_MODE_INACTIVE); /* 将W相通道(CH0)置为匹配时无效电平,封锁PWM */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_1,TIMER_OC_MODE_INACTIVE); /* 将V相通道(CH1)置为匹配时无效电平,封锁PWM */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_2,TIMER_OC_MODE_INACTIVE); /* 将U相通道(CH2)置为匹配时无效电平,封锁PWM */
    /* 清除定时器中断标志 */
    timer_interrupt_flag_clear(TIMER0,TIMER_INT_FLAG_BRK); /* 清除刹车中断标志 */
    
    led_on(LED_FAULT); /* 点亮故障指示LED */
}

/**
  * @brief TIMER0通道中断服务函数(CH3比较匹配触发)
  * @param 无
  * @retval 无
  */
void TIMER0_Channel_IRQHandler(void)
{
    timer_interrupt_flag_clear(TIMER0,TIMER_INT_FLAG_CH3); /* 清除通道3比较中断标志 */
}

/**
  * @brief ADC0/ADC1中断服务函数(注入组转换完成中断)
  * @param 无
  * @retval 无
  */
void ADC0_1_IRQHandler(void)
{
    /* 清除ADC中断标志 */
    adc_interrupt_flag_clear(ADC0, ADC_INT_FLAG_EOIC); /* 清除注入组转换完成中断标志 */
    gpio_bit_write(USER_IO3_PORT, USER_IO3_PIN,SET); /* 用户IO3置高,标记中断处理开始(配合示波器测中断耗时) */
    
    adc1_ia = adc_inserted_data_read(ADC0, IU_INSERTED_CHANNEL); /* 读取注入组序位0采样值(U相反电动势BEMFU) */
    adc1_ib = adc_inserted_data_read(ADC0, IV_INSERTED_CHANNEL); /* 读取注入组序位1采样值(V相反电动势BEMFV) */
    adc1_ic = adc_inserted_data_read(ADC0, IW_INSERTED_CHANNEL); /* 读取注入组序位2采样值(W相反电动势BEMFW) */
    adc1_idc = adc_inserted_data_read(ADC0, IDC_AVER_INSERTED_CHANNEL); /* 读取注入组序位3采样值(母线电流平均值IDC_AVER) */
    
    bldc_mainfunction(); /* 执行BLDC换相主函数(霍尔换相/测速/速度环) */
    
    /* 备用代码(已注释停用):占空比处于有效区间时,以当前占空比更新CH3比较值(即ADC注入组触发点) */
/*    if((g_bldc_motor.pwm_duty > MIN_PWM_DUTY) && (g_bldc_motor.pwm_duty < MAX_PWM_DUTY / 2)) */
/*        timer_channel_output_pulse_value_config(TIMER0,TIMER_CH_3,g_bldc_motor.pwm_duty); */
    
    temp1 = (float)adc1_ia * ADC_TO_VDC_COEF; /* U相反电动势采样值换算为电压值 */
    memcpy(&uart_data[0],&temp1,4); /* 填入发送缓冲区(低4字节) */
    temp2 = (float)adc1_ib * ADC_TO_VDC_COEF; /* V相反电动势采样值换算为电压值 */
    memcpy(&uart_data[4],&temp2,4); /* 填入发送缓冲区(中4字节) */
    temp3 = (float)g_bldc_motor.pwm_duty; /* 当前占空比作为第3通道上传数据 */
    memcpy(&uart_data[8],&temp3,4); /* 填入发送缓冲区(高4字节) */
    uart_data[sizeof(uart_data)-2] = 0x80; /* 填写帧尾标志字节1(0x80) */
    uart_data[sizeof(uart_data)-1] = 0x7f; /* 填写帧尾标志字节2(0x7f),4字节帧尾为小端float +∞(0x7F800000) */
    usart_send_data(uart_data,sizeof(uart_data)); /* 串口发送16字节数据帧(供上位机绘图) */
    
    gpio_bit_write(USER_IO3_PORT, USER_IO3_PIN,RESET); /* 用户IO3置低,标记中断处理结束 */
    
    /* 以下为备用的调试上传代码(换相状态/转速/未换向计数),已注释停用 */
/*    temp1 = (float)g_bldc_motor.step_sta; */
/*    memcpy(&uart_data[0],&temp1,4); */
/*    temp2 = (float)g_bldc_motor.speed; */
/*    memcpy(&uart_data[4],&temp2,4); */
/*    temp3 = (float)g_bldc_motor.no_single; */
/*    memcpy(&uart_data[8],&temp3,4); */
/*    uart_data[sizeof(uart_data)-2] = 0x80; */
/*    uart_data[sizeof(uart_data)-1] = 0x7f; */
/*    usart_send_data(uart_data,sizeof(uart_data)); */
}


/***************************************** 文件结束 *********************************************/
