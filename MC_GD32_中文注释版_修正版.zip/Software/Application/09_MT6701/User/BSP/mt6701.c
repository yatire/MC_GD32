/*
*******************************************************************************************************
*
* 文件名称 : mt6701.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : MT6701 磁编码器驱动(SPI/SSI 读取14位原始角度、CRC-6 校验与角度换算)
* 
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "mt6701.h" /* MT6701 接口声明与引脚宏定义 */
#include "spi.h" /* SPI 外设初始化与收发接口 */

/* 宏定义 ------------------------------------------------------------------------------------------*/


/* 变量定义 ----------------------------------------------------------------------------------------*/


/* 函数定义 -----------------------------------------------------------------------------------------*/
static uint8_t crc6(uint8_t *data, uint8_t length); /* CRC-6 校验计算(局部函数声明) */


/**
  * @brief MT6701 初始化(SPI2 与片选引脚)
  * @param 无
  * @retval 无
  */
void mt6701_init(void)
{
    spi2_init(); /* 初始化 SPI2 外设 */
    
    rcu_periph_clock_enable(MT6701_CS_CLK); /* 使能 MT6701 片选引脚 GPIO 时钟 */
    gpio_init(MT6701_CS_PORT, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, MT6701_CS_PIN); /* 片选引脚配置为推挽输出 */
    gpio_bit_write(MT6701_CS_PORT,MT6701_CS_PIN,SET); /* 片选拉高：未选中(空闲状态) */
}

/**
  * @brief 读取 mt6701 角度
  * @param angle:返回原始的14位角度数据
  * @retval 1-读取成功   0-CRC错误
  * @note SPI_PSC_4 时读取一次耗时约 4.15us
  */
uint8_t mt6701_read_angle0(uint16_t *angle)
{
    uint32_t mt6701_data = 0; /* 暂存 SPI 读回的 24 位数据帧 */
    uint8_t crc_buf[3] = {0}; /* 待校验数据：高18位按6位一组拆为3字节 */
    uint8_t crc_calc = 0; /* 计算得到的 CRC 校验值 */
    gpio_bit_write(MT6701_CS_PORT,MT6701_CS_PIN,RESET); /* 片选拉低：选中 MT6701，开始 SSI 通信 */
    mt6701_data |= spi2_transmit_receive_data(0xFF) << 16; /* SPI 收发第1字节：数据帧第23~16位 */
    mt6701_data |= spi2_transmit_receive_data(0xFF) << 8; /* 第2字节：第15~8位 */
    mt6701_data |= spi2_transmit_receive_data(0xFF); /* 第3字节：第7~0位 */
    gpio_bit_write(MT6701_CS_PORT,MT6701_CS_PIN,SET); /* 片选拉高：结束本次读取 */
    crc_buf[0] = mt6701_data >> 18; /* 取第23~18位作为校验字节1 */
    crc_buf[1] = mt6701_data >> 12; /* 取第17~12位作为校验字节2 */
    crc_buf[2] = mt6701_data >> 6; /* 取第11~6位作为校验字节3 */
    
    crc_calc = crc6(crc_buf, 3); /* 计算 CRC-6 校验值 */
    if(crc_calc == (mt6701_data & 0x3f)) /* 与数据帧最低6位(收到的CRC)比较 */
    {
        *angle = mt6701_data >> 10; /* 高14位为原始角度(0~16383)，输出 */
        return 1; /* 校验通过：读取成功 */
    }
    return 0; /* CRC 校验失败 */
}

/**
  * @brief 读取 mt6701 角度
  * @param angle:返回0-360度角度数据
  * @retval 1-读取成功   0-CRC错误
  * @note SPI_PSC_4 时读取一次耗时约 4.15us
  */
uint8_t mt6701_read_angle1(float *angle)
{
    uint32_t mt6701_data = 0; /* 暂存 SPI 读回的 24 位数据帧 */
    uint8_t crc_buf[3] = {0}; /* 待校验数据：高18位按6位一组拆为3字节 */
    uint8_t crc_calc = 0; /* 计算得到的 CRC 校验值 */
    float angle_f = 0; /* 角度浮点暂存 */
    
    gpio_bit_write(MT6701_CS_PORT,MT6701_CS_PIN,RESET); /* 片选拉低：选中 MT6701，开始 SSI 通信 */
    mt6701_data |= spi2_transmit_receive_data(0xFF) << 16; /* SPI 收发第1字节：数据帧第23~16位 */
    mt6701_data |= spi2_transmit_receive_data(0xFF) << 8; /* 第2字节：第15~8位 */
    mt6701_data |= spi2_transmit_receive_data(0xFF); /* 第3字节：第7~0位 */
    gpio_bit_write(MT6701_CS_PORT,MT6701_CS_PIN,SET); /* 片选拉高：结束本次读取 */
    crc_buf[0] = mt6701_data >> 18; /* 取第23~18位作为校验字节1 */
    crc_buf[1] = mt6701_data >> 12; /* 取第17~12位作为校验字节2 */
    crc_buf[2] = mt6701_data >> 6; /* 取第11~6位作为校验字节3 */
    
    crc_calc = crc6(crc_buf, 3); /* 计算 CRC-6 校验值 */
    if(crc_calc == (mt6701_data & 0x3f)) /* 与数据帧最低6位(收到的CRC)比较 */
    {
        mt6701_data >>= 10; /* 右移10位得到14位原始角度 */
        angle_f = (float)mt6701_data * 360 / 16384.0; /* 换算为 0~360 度角度 */
        *angle = angle_f; /* 输出角度 */
        return 1; /* 校验通过：读取成功 */
    }
    return 0; /* CRC 校验失败 */
}

/**
  * @brief 读取 mt6701 角度
  * @param angle:返回0-2PI角度数据
  * @retval 1-读取成功   0-CRC错误
  * @note SPI_PSC_4 时读取一次耗时约 4.15us
  */
uint8_t mt6701_read_angle2(float *angle)
{
    uint32_t mt6701_data = 0; /* 暂存 SPI 读回的 24 位数据帧 */
    uint8_t crc_buf[3] = {0}; /* 待校验数据：高18位按6位一组拆为3字节 */
    uint8_t crc_calc = 0; /* 计算得到的 CRC 校验值 */
    float angle_f = 0; /* 角度浮点暂存 */
    
    gpio_bit_write(MT6701_CS_PORT,MT6701_CS_PIN,RESET); /* 片选拉低：选中 MT6701，开始 SSI 通信 */
    mt6701_data |= spi2_transmit_receive_data(0xFF) << 16; /* SPI 收发第1字节：数据帧第23~16位 */
    mt6701_data |= spi2_transmit_receive_data(0xFF) << 8; /* 第2字节：第15~8位 */
    mt6701_data |= spi2_transmit_receive_data(0xFF); /* 第3字节：第7~0位 */
    gpio_bit_write(MT6701_CS_PORT,MT6701_CS_PIN,SET); /* 片选拉高：结束本次读取 */
    crc_buf[0] = mt6701_data >> 18; /* 取第23~18位作为校验字节1 */
    crc_buf[1] = mt6701_data >> 12; /* 取第17~12位作为校验字节2 */
    crc_buf[2] = mt6701_data >> 6; /* 取第11~6位作为校验字节3 */
    
    crc_calc = crc6(crc_buf, 3); /* 计算 CRC-6 校验值 */
    if(crc_calc == (mt6701_data & 0x3f)) /* 与数据帧最低6位(收到的CRC)比较 */
    {
        mt6701_data >>= 10; /* 右移10位得到14位原始角度 */
        angle_f = (float)mt6701_data * 6.283185 / 16384.0; /* 换算为 0~2π 弧度角度 */
        *angle = angle_f; /* 输出角度 */
        return 1; /* 校验通过：读取成功 */
    }
    return 0; /* CRC 校验失败 */
}

/* 局部函数定义 -----------------------------------------------------------------------------------*/
/**
  * @brief CRC-6 校验计算(用于 MT6701 SSI 数据帧校验)
  * @param data: 待校验数据缓冲区
  *        length: 待校验字节数
  * @retval 6位CRC校验值
  */
static uint8_t crc6(uint8_t *data, uint8_t length)
{  
	uint8_t i; /* 循环变量 */
	uint8_t crc = 0;    /* CRC 初始值 */
	
	while(length--) /* 逐字节处理待校验数据 */
	{  
		 crc ^= *data++; /* crc ^= *data; data++;(与当前字节异或后指针后移) */
		for (i=6; i>0; --i) /* 每字节循环移位6次 */
        { 
            if (crc & 0x20) /* 最高有效位(bit5)为1时 */
                crc = (crc << 1) ^ 0x03; /* 左移一位并异或多项式0x03 */
            else
                crc = (crc << 1); /* 仅左移一位 */
        }
	 }  
	return crc&0x3f; /* 返回6位CRC校验值 */
} 

/***************************************** 文件结束 *********************************************/
