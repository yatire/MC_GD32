/*
*******************************************************************************************************
*
* 文件名称 : motor_app.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 电机控制主应用文件
*
*******************************************************************************************************
*/

/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "motor_app.h"    /* 电机应用任务头文件(电机状态机/标定状态机定义) */
#include "adc_simple.h"    /* 简单ADC采样接口(NTC温度/母线电压/母线电流) */
#include "lcd.h"    /* LCD显示驱动 */
#include "uart.h"    /* 串口驱动(调试数据帧发送) */
#include "encoder.h"    /* 正交编码器旋钮与按键接口(调速/启停) */
#include "mt6701.h"    /* MT6701磁编码器驱动(读取机械角度) */
#include "pmsm.h"    /* PMSM FOC算法接口 */
#include "userparms.h"    /* 用户参数配置(电机参数/PI参数/开环启动参数) */

/* 宏定义 ------------------------------------------------------------------------------------------*/

/* 变量定义 ----------------------------------------------------------------------------------------*/
motor_control_t motor1 = {0};    /* 电机1控制结构体(状态机/ADC偏置/运行数据) */
static uint32_t ia_sum = 0,ib_sum = 0,ic_sum = 0;    /* ADC标定期三相电流采样累加和 */

can_trasnmit_message_struct transmit_message;    /* CAN发送报文结构体 */

float sensor_mech_angle = 0;    /* MT6701测得的转子机械角度(0~2π rad) */
float sensor_last_mech_angle = 0;    /* 上一次采样的机械角度(用于差分测速) */
float sensor_elec_angle = 0;    /* 机械角度×极对数换算的电角度(0~2π rad) */

#ifndef OFFSET_ANGLE_CAL_DONE    /* 未定义:零偏角/方向/极对数需上电标定 */
float sensor_offset_angle = 0;    /* 零电角度偏移量(rad,标定获得) */
uint8_t sensor_dir = SENSOR_DIR_POS;    /* 传感器方向:0-正向 1-反向 */
uint8_t motor_poles = 0;    /* 电机极对数(标定获得) */
#else    /* 已定义:标定值由用户直接填入 */
/* 如果标定完成,这三个参数可以直接填进去 */
float sensor_offset_angle = 0;    /* 零电角度偏移量(rad,直接填入) */
uint8_t sensor_dir = SENSOR_DIR_POS;    /* 传感器方向:0-正向 1-反向 */
uint8_t motor_poles = 0;    /* 电机极对数(直接填入) */
#endif    /* 结束条件编译 */


uint8_t sensor_cal_dir = SENSOR_DIR_POS;    /* 方向标定结果(临时值) */
uint8_t sensor_offset_cal_done =0;    /* 零偏角标定完成标志:1-完成 */
float offset_total_angle = 0;    /* 零偏角采样累加和(求平均用) */
uint32_t offset_angle_cal_index = 0;    /* 标定采样计数器 */
uint32_t offset_angle_cal_delay = 0;    /* 标定前等待稳定延时计数器 */

float delta_mech_angle = 0;    /* 相邻两周期机械角度增量(已处理跨零) */
float delta_mech_angle_total = 0;    /* 方向标定期机械角度增量累加和 */
static float motor_omega = 0;    /* 电角速度(rad/s,PLL观测得到) */
static float motor_mech_omega = 0;    /* 机械角速度(rad/s,角度差分得到) */

float last_foc_angle = 0;    /* 上一次FOC输出电角度(极对数标定用) */

uint32_t rotor_turns = 0;   /* 转子圈数 */

/* 局部函数 -----------------------------------------------------------------------------------*/
static void motor_can_transmit(void);    /* CAN状态报文发送任务 */
static float calc_elec_speed(float angle);    /* 计算电角速度(PLL锁相环测速) */
static float calc_mech_speed(float angle);    /* 计算机械角速度(角度差分测速) */

/* 全局函数 -----------------------------------------------------------------------------------*/

/**
  * @brief 电机应用初始化
  * @param 无
  * @retval 无
  */
void motor_app_init(void)
{
    motor1.state = INIT;    /* 状态机置为初始化状态 */
    motor1.start = 1;    /* 上电默认置启动标志 */
    
    motor1.sensor_cal_state = WAIT_STABLE;    /* 标定子状态机置为等待稳定 */
    
    transmit_message.tx_sfid = 0x7ab;    /* 标准帧ID:0x7AB */
    transmit_message.tx_efid = 0x00;    /* 扩展帧ID:不使用 */
    transmit_message.tx_ft = CAN_FT_DATA;    /* 帧类型:数据帧 */
    transmit_message.tx_ff = CAN_FF_STANDARD;    /* 帧格式:标准帧 */
    transmit_message.tx_dlen = 8;    /* 数据长度:8字节 */
    
    /* 预填测试数据0xA1~0xA7,实际发送时被实时数据覆盖 */
    transmit_message.tx_data[0] = 0x00;
    transmit_message.tx_data[1] = 0xA1;
    transmit_message.tx_data[2] = 0xA2;
    transmit_message.tx_data[3] = 0xA3;
    transmit_message.tx_data[4] = 0xA4;
    transmit_message.tx_data[5] = 0xA5;
    transmit_message.tx_data[6] = 0xA6;
    transmit_message.tx_data[7] = 0xA7;

}

/**
  * @brief 电机任务10ms
  * @param 无
  * @retval 无
  */
void motor_app_task10ms(void)
{
    encoder_code_t encoder_code = ENCODER_NONE;    /* 编码器旋钮事件:无/增/减 */
    uint8_t key_code = KEY_NONE;    /* 按键事件码 */
    
    motor1.ntc_adc = adc_read_data(ADC_CH_NTC);    /* 读取NTC温度通道ADC滤波值 */
    motor1.vdc_adc = adc_read_data(ADC_CH_VDC);    /* 读取母线电压通道ADC滤波值 */
    motor1.idc_adc = adc_read_data(ADC_CHIDC_AVER);    /* 读取母线电流通道ADC平均值 */
    motor1.mosfet_temp = calculate_temperature_float(motor1.ntc_adc);    /* NTC阻值换算MOS管温度(℃) */
    motor1.vdc = motor1.vdc_adc * ADC_TO_VDC_COEF;    /* ADC值换算母线电压(V) */
    if(motor1.idc_adc > (ADC_FULL_BIT / 2))    /* 母线电流采样以ADC中点(2048)为零点 */
        motor1.idc = (motor1.idc_adc - 2048) * ADC_TO_CURRENT_COEF;    /* 中点以上:换算为正向母线电流(A) */
    else
        motor1.idc = 0;    /* 中点以下:母线电流按0处理 */
    
    encoder_code = encoder_get();    /* 读取编码器旋钮转动事件 */
    key_scan();    /* 按键状态扫描(含消抖) */
    key_code = key_get();    /* 从按键FIFO取出一个按键事件 */
    
    if(pmsm_mc_param.run_motor == 1)    /* 电机运行中才允许旋钮调速 */
    {
        motor1.speed_rpm = pmsm_mc_param.actual_speed * ((float)60 / ANGLE_2PI);    /* 角速度换算转速(rpm) */
        if(encoder_code == ENCODER_INC)    /* 编码器旋钮增量动作 */
        {
            if(pmsm_mc_param.vel_input < NOMINAL_SPEED_RAD_PER_SEC_MECH)    /* 限幅:不超过额定机械角速度 */
            {
                pmsm_mc_param.vel_input = pmsm_mc_param.vel_input + 1.0f;    /* 速度给定每次加1 rad/s */
            }
        }
        else if(encoder_code == ENCODER_DEC)    /* 编码器旋钮减量动作 */
        {      
            if(pmsm_mc_param.vel_input > END_SPEED_RADS_MECH)    /* 限幅:不低于开环结束机械角速度 */
            {
                pmsm_mc_param.vel_input = pmsm_mc_param.vel_input - 1.0f;    /* 速度给定每次减1 rad/s */
            }
        }
    }
    
    if(key_code == KEY_0_RELEASE)    /* KEY0短按释放:翻转启停标志 */
    {
        if(motor1.start)    /* 当前已置启动标志 */
        {
            motor1.start = 0;    /* 切换为停机请求 */
        }
        else
        {
            motor1.start = 1;    /* 切换为启动请求 */
        }
    }
    else if(key_code == KEY_0_LONG_PRESS)    /* KEY0长按:预留无处理 */
    {
        
    }
    
    motor_can_transmit();    /* 发送电机状态CAN报文 */
    
}

/**
  * @brief 电机任务100ms
  * @param 无
  * @retval 无
  */
void motor_app_task100ms(void)
{
    
}

/**
  * @brief 电机任务500ms
  * @param 无
  * @retval 无
  */
void motor_app_task500ms(void)
{
    
}

/**
  * @brief 电机任务1s
  * @param 无
  * @retval 无
  */
void motor_app_task1s(void)
{

}

/**
  * @brief 电机空闲任务
  * @param 无
  * @retval 无
  */
void motor_app_idle(void)
{
    adc_task();    /* 空闲时执行ADC后台滤波任务 */
}

/**
  * @brief 电机中断服务函数,在PWM中断中调用
  * @param 无
  * @retval 无
  */
void motor_app_isr(void)
{
    float temp1 = 0;    /* 调试帧临时变量1 */
    float temp2 = 0;    /* 调试帧临时变量2 */
    float temp3 = 0;    /* 调试帧临时变量3 */
    uint8_t uart_data[16] = {0};    /* 串口调试数据帧缓冲(16字节) */
    
    mt6701_read_angle2(&sensor_mech_angle);    /* 读取MT6701机械角度(0~2π rad) */
    if(sensor_dir == SENSOR_DIR_REV)    /* 传感器反装:角度按2π-x镜像 */
    {
        sensor_mech_angle = ANGLE_2PI - sensor_mech_angle;    /* 方向取反 */
    }
    motor_mech_omega = calc_mech_speed(sensor_mech_angle);    /* 机械角度差分求机械角速度(rad/s) */
#ifndef OFFSET_ANGLE_CAL_DONE    /* 未定义标定完成宏:运行时标定 */
    if(sensor_offset_cal_done)    /* 零偏角标定完成后才换算 */
    {
        sensor_elec_angle = sensor_mech_angle * motor_poles;    /* 机械角度×极对数=电角度 */
        utils_norm_angle_rad(&sensor_elec_angle);    /* 电角度归一化到0~2π */
        motor_omega = calc_elec_speed(sensor_elec_angle);    /* PLL观测计算电角速度 */
    }
#else    /* 编译期已定义标定宏:直接换算 */
        sensor_elec_angle = sensor_mech_angle * motor_poles;    /* 机械角度×极对数=电角度 */
        utils_norm_angle_rad(&sensor_elec_angle);    /* 电角度归一化到0~2π */
        motor_omega = calc_elec_speed(sensor_elec_angle);    /* PLL观测计算电角速度 */
#endif    /* 结束条件编译 */
    
    
    if(sensor_offset_cal_done)    /* 标定完成后重新换算(与上方分支等效) */
    {
        sensor_elec_angle = sensor_mech_angle * motor_poles;
        utils_norm_angle_rad(&sensor_elec_angle);
        motor_omega = calc_elec_speed(sensor_elec_angle);
    }
    
    switch(motor1.state)    /* 电机主状态机 */
    {
        case INIT:    /* 初始化完成:转入ADC标定 */
            motor1.state = ADC_CAL;
            break;
        case ADC_CAL:    /* ADC零点标定:采样求三相零点偏置 */
            if(motor1.adc_cal_cnt < ADC_CAL_COUNT)    /* 未满标定采样次数(1024次) */
            {
                motor1.adc_cal_cnt++;    /* 采样计数加1 */
                motor1.adc_ia = adc_inserted_data_read(ADC0, IU_INSERTED_CHANNEL);    /* 读取A相电流ADC注入组值 */
                motor1.adc_ib = adc_inserted_data_read(ADC0, IV_INSERTED_CHANNEL);    /* 读取B相电流ADC注入组值 */
                motor1.adc_ic = adc_inserted_data_read(ADC0, IW_INSERTED_CHANNEL);    /* 读取C相电流ADC注入组值 */
                
                ia_sum += motor1.adc_ia;    /* 累加A相采样值 */
                ib_sum += motor1.adc_ib;    /* 累加B相采样值 */
                ic_sum += motor1.adc_ic;    /* 累加C相采样值 */
            }
            else
            {
                motor1.ia_offset = ia_sum / motor1.adc_cal_cnt;    /* A相电流零点偏置(均值) */
                motor1.ib_offset = ib_sum / motor1.adc_cal_cnt;    /* B相电流零点偏置(均值) */
                motor1.ic_offset = ic_sum / motor1.adc_cal_cnt;    /* C相电流零点偏置(均值) */
                motor1.state = START_DELAY;    /* 转入启动延时状态 */
            }
            break;
        case START_DELAY:    /* 启动延时:上电稳定等待(约2秒) */
            if(motor1.start_delay_tick < START_DELAY_TICK)    /* 延时未到(START_DELAY_TICK个周期) */
            {
                motor1.start_delay_tick++;    /* 延时计数累加 */
            }
            else
            {
#ifndef OFFSET_ANGLE_CAL_DONE    /* 未定义标定宏:需先执行标定 */
                motor1.state = SENSOR_OFFSET_CAL;    /* 转入传感器标定状态 */
#else    /* 标定宏已定义 */
                motor1.state = RUN;    /* 直接进入运行状态 */
#endif    /* 结束条件编译 */
                motor_pwm_channel_enable(ENABLE);    /* 使能三相PWM输出 */
            }
            break;
        case STOP:    /* 停机状态:等待启动命令 */
            if(motor1.start == 1)    /* 启动标志有效 */
            {
                pmsm_foc_init();    /* 重新初始化FOC参数 */
                motor_pwm_channel_enable(ENABLE);    /* 使能三相PWM输出 */
                motor1.state = RUN;    /* 转入运行状态 */
            }
            break;
        case SENSOR_OFFSET_CAL:    /* 传感器标定状态:开环强制驱动转子旋转 */
            {
                /* 读取ADC注入组数据寄存器 */
                motor1.adc_ia = adc_inserted_data_read(ADC0, IU_INSERTED_CHANNEL);    /* 读取A相电流ADC原始值 */
                motor1.adc_ib = adc_inserted_data_read(ADC0, IV_INSERTED_CHANNEL);    /* 读取B相电流ADC原始值 */
                motor1.adc_ic = adc_inserted_data_read(ADC0, IW_INSERTED_CHANNEL);    /* 读取C相电流ADC原始值 */
                
                /* ADC原始值减零点偏置后换算为实际相电流(A) */
                pmsm_foc_param.ia = ((float)motor1.adc_ia - motor1.ia_offset) * ADC_TO_CURRENT_COEF;
                pmsm_foc_param.ib = ((float)motor1.adc_ib - motor1.ib_offset) * ADC_TO_CURRENT_COEF;
                pmsm_foc_param.ic = ((float)motor1.adc_ic - motor1.ic_offset) * ADC_TO_CURRENT_COEF;
                
                switch(motor1.sensor_cal_state)    /* 标定子状态机 */
                {
                    case WAIT_STABLE:    /* 等待开环旋转稳定 */
                        offset_angle_cal_delay++;    /* 稳定延时计数累加 */
                        if(offset_angle_cal_delay >= OFFSET_ANGLE_CAL_DELAY_TICK)    /* 等待满(约3秒) */
                        {
                            motor1.sensor_cal_state = DIR_CAL;    /* 转入方向标定 */
                            offset_angle_cal_index = 0;    /* 复位采样计数 */
                        }
                        break;
                    case DIR_CAL:    /* 方向标定:累计机械角度增量判方向 */
                        delta_mech_angle_total += delta_mech_angle;    /* 累加每周期机械角度增量 */
                        offset_angle_cal_index++;    /* 采样计数加1 */
                        if(offset_angle_cal_index >= OFFSET_ANGLE_CAL_COUNT)    /* 累计满16000个周期 */
                        {
                            offset_angle_cal_index = 0;    /* 复位计数 */
                            if(delta_mech_angle_total > 0)    /* 开环正转期间机械角度净增:同向 */
                            {
                                sensor_cal_dir = SENSOR_DIR_POS;    /* 传感器方向为正向 */
                            }
                            else
                            {
                                sensor_cal_dir = SENSOR_DIR_REV;    /* 传感器方向为反向 */
                            }
                            sensor_dir = sensor_cal_dir;    /* 应用标定出的传感器方向 */
                            motor1.sensor_cal_state = POLES_CAL;    /* 转入极对数标定 */
                            last_foc_angle = pmsm_foc_param.angle;    /* 记录当前FOC电角度 */
                            rotor_turns = 0;    /* 复位转子圈数计数 */
                        }
                        break;
                    case POLES_CAL:    /* 极对数标定:统计机械一圈内电角度翻转次数 */
                        if(rotor_turns >= 3)    /* 转过3整圈后统计第4圈 */
                        {
                            if(pmsm_foc_param.angle < last_foc_angle)    /* FOC电角度回落:翻转过零一次 */
                            {
                                /* 电角度换向了 */
                                motor_poles++;    /* 极对数加1 */
                            }
                            last_foc_angle = pmsm_foc_param.angle;    /* 更新上次FOC电角度 */
                            if(rotor_turns >= 4)    /* 统计满一整圈 */
                            {
                                motor1.sensor_cal_state = OFFSET_CAL;    /* 转入偏移角标定 */
                            }
                        }
                        else
                        {
                            last_foc_angle = pmsm_foc_param.angle;    /* 前3圈仅记录不统计 */
                        }
                        
                        break;
                    case OFFSET_CAL:    /* 偏移角标定:求零电角度偏移 */
                        sensor_elec_angle = sensor_mech_angle * motor_poles;    /* 机械角度×极对数=电角度 */
                        utils_norm_angle_rad(&sensor_elec_angle);    /* 电角度归一化到0~2π */
                        sensor_offset_angle = pmsm_foc_param.angle - sensor_elec_angle;    /* FOC角度-传感器电角度 */
                        utils_norm_angle_rad(&sensor_offset_angle);    /* 零偏角归一化到0~2π */

                        offset_total_angle += sensor_offset_angle;    /* 累加零偏角采样 */
                        offset_angle_cal_index++;    /* 采样计数加1 */
                        if(offset_angle_cal_index >= OFFSET_ANGLE_CAL_COUNT)    /* 累计满16000个周期 */
                        {
                            /* 累加值取平均得最终零偏角 */
                            sensor_offset_angle = offset_total_angle / (float)OFFSET_ANGLE_CAL_COUNT;
                            sensor_offset_cal_done = 1;    /* 置标定完成标志 */
                            motor1.sensor_cal_state = CAL_DONE;    /* 标定全部结束 */
                        }
                        break;
                    case CAL_DONE:    /* 标定完成状态 */
                        motor1.state = STOP;    /* 回停机状态等待启动 */
                        break;
                    case CAL_ERROR:    /* 标定出错:预留 */
                        break;
                    default:
                        break;
                }
                

                
                pmsm_mc_param.openloop = 1;    /* 强制开环模式驱动转子 */
                pmsm_foc_run();    /* 执行FOC运算(开环角度驱动) */
                
                temp1 = (float)sensor_mech_angle;    /* 机械角度存入临时变量 */
                memcpy(&uart_data[0],&temp1,4);    /* float按4字节复制到帧偏移0 */
                temp2 = (float)pmsm_foc_param.angle;    /* FOC输出电角度存入临时变量 */
                memcpy(&uart_data[4],&temp2,4);    /* 复制到帧偏移4 */
                temp3 = (float)motor_poles;    /* 极对数存入临时变量 */
                memcpy(&uart_data[8],&temp3,4);    /* 复制到帧偏移8 */
                uart_data[sizeof(uart_data)-2] = 0x80;    /* 帧尾第1字节0x80 */
                uart_data[sizeof(uart_data)-1] = 0x7f;    /* 帧尾第2字节0x7f */
                usart_send_data(uart_data,sizeof(uart_data));    /* 串口发送16字节调试帧(上位机绘图用) */
                
                /* 将FOC输出的三相占空比写入PWM定时器 */
                motor_pwm_set_duty(pmsm_foc_param.pwma,pmsm_foc_param.pwmb,pmsm_foc_param.pwmc);
            }
            break;
        case RUN:    /* 闭环运行状态 */
            {
                if(motor1.start == 0)    /* 启动标志撤销:请求停机 */
                {
                    motor_pwm_channel_enable(DISABLE);    /* 封锁三相PWM输出 */
                    motor1.state = STOP;    /* 转入停机状态 */
                    break;
                }
                
                /* 读取ADC注入组数据寄存器 */
                motor1.adc_ia = adc_inserted_data_read(ADC0, IU_INSERTED_CHANNEL);    /* 读取A相电流ADC原始值 */
                motor1.adc_ib = adc_inserted_data_read(ADC0, IV_INSERTED_CHANNEL);    /* 读取B相电流ADC原始值 */
                motor1.adc_ic = adc_inserted_data_read(ADC0, IW_INSERTED_CHANNEL);    /* 读取C相电流ADC原始值 */
                
                /* ADC原始值减零点偏置后换算为实际相电流(A) */
                pmsm_foc_param.ia = ((float)motor1.adc_ia - motor1.ia_offset) * ADC_TO_CURRENT_COEF;
                pmsm_foc_param.ib = ((float)motor1.adc_ib - motor1.ib_offset) * ADC_TO_CURRENT_COEF;
                pmsm_foc_param.ic = ((float)motor1.adc_ic - motor1.ic_offset) * ADC_TO_CURRENT_COEF;
                
                pmsm_mc_param.openloop = 0;    /* 闭环模式 */
                /* FOC角度=传感器电角度+零偏角+90°电角度(q轴对齐) */
                pmsm_foc_param.angle = sensor_elec_angle + sensor_offset_angle + 1.57f;
                utils_norm_angle_rad(&pmsm_foc_param.angle);    /* 角度归一化到0~2π */
                pmsm_mc_param.actual_speed = motor_mech_omega;    /* 更新实际机械角速度(速度环反馈) */
                
                pmsm_foc_run();    /* 执行FOC运算(电流环+速度环) */
                
                temp1 = (float)sensor_mech_angle;    /* 机械角度存入临时变量 */
                memcpy(&uart_data[0],&temp1,4);    /* float按4字节复制到帧偏移0 */
                temp2 = (float)pmsm_foc_param.angle;    /* FOC输出电角度存入临时变量 */
                memcpy(&uart_data[4],&temp2,4);    /* 复制到帧偏移4 */
                temp3 = (float)motor_mech_omega;    /* 机械角速度存入临时变量 */
                memcpy(&uart_data[8],&temp3,4);    /* 复制到帧偏移8 */
                uart_data[sizeof(uart_data)-2] = 0x80;    /* 帧尾第1字节0x80 */
                uart_data[sizeof(uart_data)-1] = 0x7f;    /* 帧尾第2字节0x7f */
                usart_send_data(uart_data,sizeof(uart_data));    /* 串口发送16字节调试帧 */
                
                /* 将FOC输出的三相占空比写入PWM定时器 */
                motor_pwm_set_duty(pmsm_foc_param.pwma,pmsm_foc_param.pwmb,pmsm_foc_param.pwmc);
            }
            break;
        case FAULT:    /* 故障状态:预留 */
            break;
        default:    /* 未知状态:不做处理 */
            break;
    }
}

/* 局部函数 -----------------------------------------------------------------------------------*/

/**
  * @brief 电机CAN报文发送任务
  * @param 无
  * @retval 无
  */
static void motor_can_transmit(void)
{
    uint8_t mosfet_temperature = 0;    /* MOS管温度编码值(偏移+40℃) */
    if(motor1.mosfet_temp < -40)    /* 温度低于-40℃按最小值编码 */
        mosfet_temperature = 0;
    else
        mosfet_temperature = motor1.mosfet_temp + 40;    /* 温度+40℃偏移映射到0~255 */
    
    transmit_message.tx_data[0] = mosfet_temperature;    /* 字节0:MOS管温度(+40℃偏移编码) */
    transmit_message.tx_data[1] = (uint8_t)(motor1.idc * 10);    /* 字节1:母线电流×10(0.1A分辨率) */
    transmit_message.tx_data[2] = (uint8_t)(motor1.vdc * 6);    /* 字节2:母线电压×6量化 */
    transmit_message.tx_data[3] = pmsm_foc_param.iq * 10;    /* 字节3:q轴电流×10(0.1A分辨率) */
    transmit_message.tx_data[4] = motor1.speed_rpm & 0xff;    /* 字节4:转速低字节 */
    transmit_message.tx_data[5] = motor1.speed_rpm >> 8;    /* 字节5:转速高字节 */
    transmit_message.tx_data[6] = 0;    /* 字节6:预留 */
    transmit_message.tx_data[7] = 0;    /* 字节7:预留 */
    
    can_message_transmit(CAN0, &transmit_message);    /* 启动CAN报文发送 */
}

/**
  * @brief 计算电机机械角速度
  * @param angle - 电机机械角度
  * @retval 无
  */
static float calc_mech_speed(float angle)
{
    delta_mech_angle = angle - sensor_last_mech_angle;    /* 本次与上次机械角度之差 */
    sensor_last_mech_angle = angle;    /* 保存本次角度供下次差分 */
    if(delta_mech_angle < -M_PI)    /* 差分小于-π:角度跨2π过零(正转) */
    {
        delta_mech_angle += ANGLE_2PI;    /* 补2π还原真实增量 */
        rotor_turns++;    /* 转子圈数加1 */
    }
    else if(delta_mech_angle > M_PI)    /* 差分大于π:角度跨2π过零(反转) */
    {
        delta_mech_angle -= ANGLE_2PI;    /* 减2π还原真实增量 */
        rotor_turns++;    /* 转子圈数加1 */
    }
    return delta_mech_angle * MOTOR_PWM_FREQ_HZ;    /* 每周期角度增量×PWM频率=机械角速度(rad/s) */
}

/**
  * @brief 计算电机电角速度(PLL锁相环测速)
  * @param angle - 电机电角度
  * @retval 无
  */
static float calc_elec_speed(float angle)
{
    static float theta_pll = 0;    /* PLL跟踪角度(rad) */
    static float pll_sum = 0;    /* PI控制器积分累加和 */
    static float omega_pll = 0;    /* PLL输出的电角速度(rad/s) */
    static float omega_pll_filter = 0;    /* 低通滤波后的电角速度输出(rad/s) */
    
    /* 1. 定义时间相关参数（需确保PWM_FREQ单位正确） */
    #define PWM_PERIOD_SEC      (1.0f / MOTOR_PWM_FREQ_HZ)  /* PWM周期（秒） */
    /* 2. 定义PLL参数（浮点数，显式标注单位） */
    #define SpeedPllBandWidth   600.0f      /* 环路带宽（rad/s） */
    #define SpeedPllKp          (2.0f * SpeedPllBandWidth)                /* Kp = 2*Wn */
    #define SpeedPllKi          (SpeedPllBandWidth * SpeedPllBandWidth * PWM_PERIOD_SEC)  /* Ki=Wn^2*Ts */
    /* #define OmegaToTheta        (PWM_PERIOD_SEC * 16384.0f * 32768.0f / (2.0f * PI))   角速度→角度转换因子(已停用) */
        #define OmegaToTheta  (PWM_PERIOD_SEC)  /* 直接使用PWM周期作为积分系数 */
    /* 3. 霍尔信号积分（预测角度） */
    /*stcHallAngle.hallAngle += stcHallAngle.hallspeed;  (历史代码,已注释停用)*/
    /* 4. 生成实际角度的正弦/余弦信号 */
        float sin = arm_sin_f32(angle);    /* 实际角度正弦值 */
        float cos = arm_cos_f32(angle);    /* 实际角度余弦值 */
        float sin_pll = arm_sin_f32(theta_pll);    /* PLL角度正弦值 */
        float cos_pll = arm_cos_f32(theta_pll);    /* PLL角度余弦值 */
    /* 6. 算相位误差（浮点数运算） */
    float delta_theta_pll = sin * cos_pll - cos * sin_pll;    /* sin(angle-θpll)=两角度相位误差 */
    /* 7. 积分相位误差（PI控制器的积分项） */
    pll_sum += delta_theta_pll;    /* 相位误差积分累加 */
    /* 8. PI控制器计算角速度 */
    omega_pll = SpeedPllKp * delta_theta_pll + SpeedPllKi * pll_sum;    /* PI输出=Kp×误差+Ki×积分 */
    /* 9. 更新PLL角度（浮点数积分） */
    theta_pll += omega_pll * OmegaToTheta;    /* PLL角度按角速度积分 */
    /* 10. 角度归一化（防止溢出，可选） */
    if (theta_pll > ANGLE_2PI)    /* 大于2π则回卷 */
    {
        theta_pll -= ANGLE_2PI;    /* 减2π回卷 */
    } 
    else if (theta_pll < 0)    /* 小于0则回卷 */
    {
        theta_pll += ANGLE_2PI;    /* 加2π回卷 */
    }
    /* 11. 低通滤波输出角速度（一阶滤波，时间常数=1/0.005≈200个PWM周期） */
    omega_pll_filter += 0.005f * (omega_pll - omega_pll_filter);    /* 一阶低通滤波(滤波系数0.005) */
    
    return omega_pll_filter;    /* 返回滤波后的电角速度(rad/s) */
}

/************************************************文件结束************************************************/
