/*
*******************************************************************************************************
*
* 文件名称 : motor_app.h
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 电机控制应用接口文件
*
*******************************************************************************************************
*/
/* 防止头文件重复包含 */
#ifndef _MOTOR_APP_H_
#define _MOTOR_APP_H_

#ifdef __cplusplus /* 若按C++编译环境编译 */
extern "C"{ /* 以C语言链接方式导出符号 */
#endif

/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "motor_hardware.h" /* 电机硬件层配置(PWM/ADC引脚与通道定义) */
#include "motor_config.h" /* 电机硬件参数配置(PWM频率MOTOR_PWM_FREQ_HZ等) */

/* 宏定义 ------------------------------------------------------------------------------------------*/
#define START_DELAY_SEC             (float)2 /* 启动延时时间2秒 */
/* 启动延时时间折算为PWM周期数:2s*16kHz=32000个PWM周期 */
#define START_DELAY_TICK            (uint32_t)((float)START_DELAY_SEC/(1/(float)MOTOR_PWM_FREQ_HZ))

#define ADC_CAL_COUNT               1024 /* ADC零点标定采样次数 */

#define OFFSET_ANGLE_CAL_COUNT          16000 /* 零偏角标定采样次数(16000个PWM周期即1秒) */
#define OFFSET_ANGLE_CAL_DELAY_SEC      (float)3 /* 零偏角标定前等待转速稳定时间3秒 */
/* 等待稳定时间折算为PWM周期数:3s*16kHz=48000个PWM周期 */
#define OFFSET_ANGLE_CAL_DELAY_TICK     (uint32_t)((float)OFFSET_ANGLE_CAL_DELAY_SEC/(1/(float)MOTOR_PWM_FREQ_HZ))
    
#define SENSOR_DIR_POS              0 /* 传感器方向:正向 */
#define SENSOR_DIR_REV              1 /* 传感器方向:反向 */

typedef enum{ /* 电机运行状态机状态 */
    INIT = 0, /* 初始化 */
    ADC_CAL, /* ADC零点标定(采集三相电流偏置) */
    START_DELAY, /* 启动延时等待 */
    STOP, /* 停机 */
    SENSOR_OFFSET_CAL, /* 传感器零偏角/方向/极对数标定 */
    RUN, /* 运行 */
    FAULT, /* 故障 */
}motor_state_t;

typedef enum{ /* 传感器标定子状态机状态 */
    WAIT_STABLE = 0,        /* 等待开环运行稳定 */
    DIR_CAL,                /* 方向标定 */
    POLES_CAL,              /* 极对数标定 */
    OFFSET_CAL,             /* 偏移角标定 */
    CAL_DONE,               /* 标定结束 */
    CAL_ERROR, /* 标定出错 */
}sensor_cal_state_t;

typedef struct{ /* 电机控制数据结构体 */
    uint16_t adc_ia; /* A相电流ADC原始值 */
    uint16_t adc_ib; /* B相电流ADC原始值 */
    uint16_t adc_ic; /* C相电流ADC原始值 */
    uint16_t ia_offset; /* A相电流零点偏置 */
    uint16_t ib_offset; /* B相电流零点偏置 */
    uint16_t ic_offset; /* C相电流零点偏置 */
    uint32_t adc_cal_cnt; /* ADC标定采样计数器 */
    
    uint32_t start_delay_tick; /* 启动延时计数器 */
    
    uint16_t ntc_adc; /* NTC温度ADC采样值 */
    uint16_t vdc_adc; /* 母线电压ADC采样值 */
    uint16_t idc_adc; /* 母线电流ADC采样值 */
    float mosfet_temp; /* MOSFET温度(摄氏度) */
    float vdc; /* 母线电压(伏) */
    float idc; /* 母线电流(安) */
    
    uint16_t speed_rpm; /* 转速(转/分) */
    
    uint8_t start; /* 启动/停止命令标志 */
    
    motor_state_t state; /* 电机运行状态机当前状态 */
    sensor_cal_state_t sensor_cal_state; /* 传感器标定状态机当前状态 */
}motor_control_t;

/* 变量定义 ----------------------------------------------------------------------------------------*/


/* 函数定义 -----------------------------------------------------------------------------------------*/
void motor_app_init(void); /* 电机应用初始化:状态机置INIT/置启动标志/配置CAN报文格式 */
void motor_app_isr(void); /* 电机中断服务函数(在PWM中断中调用,FOC主循环) */
void motor_app_task10ms(void); /* 10ms周期任务:编码器调速/按键处理/ADC数据换算 */
void motor_app_task100ms(void); /* 100ms周期任务(本例程为空实现) */
void motor_app_task500ms(void); /* 500ms周期任务(本例程为空实现) */
void motor_app_task1s(void); /* 1s周期任务(本例程为空实现) */
void motor_app_idle(void); /* 空闲任务:后台执行ADC轮询滤波(adc_task) */

#ifdef __cplusplus /* 若按C++编译环境编译 */
extern "C"{ /* 以C语言链接方式导出符号(历史遗留写法,此处本应为右花括号) */
#endif /* 结束C++兼容条件编译 */

#endif /* _MOTOR_APP_H_ */

/***************************************** 文件结束 *********************************************/
