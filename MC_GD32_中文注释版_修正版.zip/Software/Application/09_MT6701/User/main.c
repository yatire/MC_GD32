/*
*******************************************************************************************************
*
* 文件名称 : main.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 主函数文件(MT6701磁编码器FOC例程)
*
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include <string.h> /* C字符串/内存操作库头文件(memcpy等) */
#include "gd32f30x.h" /* GD32F30x芯片外设寄存器与固件库头文件 */
#include "gd32f30x_libopt.h" /* GD32F30x固件库外设包含配置头文件 */
#include "systick.h" /* 滴答定时器配置头文件(系统节拍/延时) */
#include "led.h" /* LED驱动头文件 */
#include "motor_hardware.h" /* 电机硬件接口配置头文件(PWM/ADC/霍尔接口) */
#include "uart.h" /* 串口驱动头文件 */
#include "i2c.h" /* I2C驱动头文件 */
#include "eeprom.h" /* EEPROM(24C02)读写驱动头文件 */
#include "delay.h" /* 忙等待延时函数头文件 */
#include "adc_simple.h" /* 简易ADC采样头文件(母线电压/NTC温度) */
#include "lcd.h" /* LCD显示驱动头文件 */
#include "lcd_init.h" /* LCD初始化及硬件引脚配置头文件 */
#include "can.h" /* CAN总线驱动头文件 */
#include "encoder.h" /* 编码器(旋钮)驱动头文件 */
#include "drv8323rs.h" /* DRV8323RS栅极驱动器SPI驱动头文件 */
#include "mt6701.h" /* MT6701磁编码器驱动头文件(SPI读取角度) */
#include "task.h" /* 任务调度器头文件(任务初始化/时间片调度) */
#include "motor_app.h" /* 电机应用层头文件(状态机/标定/启动控制) */
#include "foc.h" /* FOC算法头文件(Clark/Park变换/SVPWM) */
#include "pmsm.h" /* PMSM电机控制头文件(FOC参数与主运算) */
#include "userparms.h" /* 用户参数配置头文件(电机极对数/PI参数等) */

/* 宏定义 ------------------------------------------------------------------------------------------*/
#define START_DELAY_SEC     (float)2 /* 启动延时时间:2秒 */
/* 启动延时对应的PWM周期数(2秒×16kHz=32000,与motor_app.h中同名宏重复) */
#define START_DELAY_TICK    (uint32_t)((float)START_DELAY_SEC/(1/(float)MOTOR_PWM_FREQ_HZ))
    
/* 相移角度:45°电角度对应的弧度值(45/180×2π,历史遗留宏,当前版本未引用) */
#define PHASE_SHIFT_ANGLE (float)       (45.0f/180.0f*ANGLE_2PI)

/* 变量定义 ----------------------------------------------------------------------------------------*/
uint8_t adc_calibration = 0; /* ADC零点标定完成标志(历史遗留变量,当前版本未引用) */
uint32_t ia_offset = 0,ib_offset = 0,ic_offset = 0,idc_offset = 0; /* 三相/母线电流ADC零点偏置(历史遗留,标定量存于motor1结构体) */
uint16_t adc1_ia = 0,adc1_ib = 0,adc1_ic = 0,adc1_idc = 0; /* 注入组相电流/母线电流采样原始值(历史遗留变量,未引用) */

uint32_t start_delay_tick = 0; /* 启动延时计数器(历史遗留变量,当前版本未引用) */

float delta_angle = 0; /* 相邻两次采样的角度增量(历史遗留变量,未引用) */
float angle_last = 0; /* 上次采样的角度值(历史遗留变量,未引用) */
float angle_init = 0; /* 初始角度值(历史遗留变量,未引用) */
float angle = 0; /* 当前角度值(历史遗留变量,未引用) */
float mt6701_speed = 0; /* MT6701测得的电机转速(历史遗留变量,未引用) */
uint16_t angle_u16 = 0; /* 角度值16位整型表示(历史遗留变量,未引用) */

uint16_t speed_filter_count = 0; /* 转速均值滤波计数(历史遗留变量,未引用) */
float speed_buf[10] = {0}; /* 转速均值滤波缓冲区(历史遗留变量,未引用) */
float speed_sum = 0; /* 转速累加和(历史遗留变量,未引用) */

float sensor_angle_offset = 0; /* 传感器安装偏置角(历史遗留变量,未引用,标定偏置存于motor1结构体) */

/* 函数定义 -----------------------------------------------------------------------------------------*/


/**
  * @brief 主函数
  * @param 无
  * @retval 无
  */
int main(void)
{
    SCB->VTOR = FLASH_BASE | 0x4000; /* 设置中断向量表到APP区基址(偏移0x4000,由Bootloader引导) */
    __enable_irq(); /* 使能全局中断 */
    
    systick_init(); /* 初始化滴答定时器(1ms系统节拍) */
    led_init(); /* 初始化LED指示灯 */
    usart_init(); /* 初始化调试串口 */
    adc1_init(); /* 初始化ADC1(软件触发采样NTC温度/母线电压) */
    can_bus_init(); /* 初始化CAN总线(波特率/过滤器) */
    encoder_init(); /* 初始化编码器(旋钮)接口 */
    DRV8323RS_init(); /* 初始化DRV8323RS栅极驱动器(SPI寄存器配置/CSA校准) */
    mt6701_init(); /* 初始化MT6701磁编码器(SPI2接口与片选引脚) */

    task_init(); /* 任务调度器初始化(内部调用电机应用初始化) */

    motor_hardware_init(); /* 初始化电机硬件(NVIC/PWM/ADC注入组/霍尔接口) */
    pmsm_foc_param.pwm_period = (float)MOTOR_PWM_PERIOD * 0.96f; /* 设置SVPWM调制满量程计数值(周期值×0.96,留出过调制余量) */
    pmsm_foc_init(); /* PMSM FOC初始化(计算启动参数) */
    
    while(1) /* 主循环:运行时间片任务调度器 */
    {
        task_scheduler(); /* 轮询调度1ms/5ms等周期任务 */
    }
}

/**
  * @brief TIMER0刹车中断服务函数(硬件故障保护时触发)
  * @param 无
  * @retval 无
  */
void TIMER0_BRK_IRQHandler(void)
{
    timer_channel_output_mode_config(TIMER0,TIMER_CH_0,TIMER_OC_MODE_INACTIVE); /* 将W相通道(CH0)置为匹配时无效电平,封锁PWM */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_1,TIMER_OC_MODE_INACTIVE); /* 将V相通道(CH1)置为匹配时无效电平,封锁PWM */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_2,TIMER_OC_MODE_INACTIVE); /* 将U相通道(CH2)置为匹配时无效电平,封锁PWM */
    /* 清除定时器中断标志 */
    timer_interrupt_flag_clear(TIMER0,TIMER_INT_FLAG_BRK); /* 清除刹车中断标志 */
    
    led_on(LED_FAULT); /* 点亮故障指示LED */
}

/**
  * @brief ADC0/ADC1中断服务函数(注入组转换完成中断)
  * @param 无
  * @retval 无
  */
void ADC0_1_IRQHandler(void)
{
    float temp1 = 0; /* 调试临时变量1(未使用的历史遗留局部变量) */
    float temp2 = 0; /* 调试临时变量2(未使用的历史遗留局部变量) */
    float temp3 = 0; /* 调试临时变量3(未使用的历史遗留局部变量) */
    uint8_t uart_data[16] = {0}; /* 串口调试帧缓冲(未使用的历史遗留局部变量) */
    uint16_t i = 0; /* 循环变量(未使用的历史遗留局部变量) */
    
    /* 清除ADC中断标志 */
    adc_interrupt_flag_clear(ADC0, ADC_INT_FLAG_EOIC); /* 清除注入组转换完成中断标志 */
    motor_app_isr(); /* 调用电机应用中断处理(MT6701测角/FOC电流环) */
}

/*!
    \brief      TIMER2中断服务函数(霍尔接口定时器遗留中断,本例程已改用MT6701测角)
    \param[in]  无
    \param[out] 无
    \retval     无
*/
void TIMER2_IRQHandler(void)
{
    /* 霍尔测速公式: hall_speed = 2π / (6 * delta_t) */
    /* delta_t = hall_timer_counter / timer_clk(定时器计数值/定时器时钟) */
    if(SET == timer_interrupt_flag_get(TIMER2,TIMER_INT_FLAG_CH0)) /* 判断CH0捕获中断标志是否置位 */
    {
        /* 清除通道0中断标志 */
        timer_interrupt_flag_clear(TIMER2,TIMER_INT_FLAG_CH0); /* 清除TIMER2通道0捕获中断标志 */
    }
}

/***************************************** 文件结束 *********************************************/
