/*
*******************************************************************************************************
*
* 文件名称 : eeprom.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 24C02-EEPROM驱动文件
*
*******************************************************************************************************
*/



/* 头文件 -----------------------------------------------------------*/
#include "eeprom.h"    /* 24C02 EEPROM驱动头文件(器件地址/页大小宏与读写接口声明) */


/* 宏定义 -----------------------------------------------------------*/


/* 变量 -------------------------------------------------------------*/


/* 函数声明 ---------------------------------------------------------*/
/* 页写入函数声明(单次最多写一页,供eeprom_write拆分调用) */
static void eeprom_page_write(uint8_t mem_addr,uint8_t *pbuffer, uint8_t num_byte_to_write);


/**
  * @brief 向EEPROM写入指定长度数据
  * @param mem_addr-存储器内部地址
  * @param pbuffer-待写入的数据
  * @param num_byte_to_write-数据长度
  * @retval	无
  */
void eeprom_write(uint8_t mem_addr,uint8_t *pbuffer, uint16_t num_byte_to_write)
{
	uint8_t num_of_page = 0, num_of_single = 0, addr = 0, count = 0;

	addr = mem_addr % EEPROM_PAGESIZE;    /* 写入地址在页内的偏移量 */
	count = EEPROM_PAGESIZE - addr;    /* 当前页剩余空间(从写地址到页尾) */
	num_of_page =  num_byte_to_write / EEPROM_PAGESIZE;    /* 可整页写入的页数 */
	num_of_single = num_byte_to_write % EEPROM_PAGESIZE;    /* 整页写完后剩余的字节数 */

	/* 写入地址和页对齐  */
	if(addr == 0) 
	{
		/* 写入数据长度小于页长度，直接按长度写 */
		if(num_of_page == 0) 
		{
			eeprom_page_write(mem_addr, pbuffer, num_of_single);    /* 不足一页,按剩余字节数写入 */
		}
		/* 写入数据长度大于页长度，先写满一页的，后写剩余的 */
		else  
		{
			while(num_of_page--)    /* 逐页写满整页数据 */
			{
				eeprom_page_write(mem_addr, pbuffer, EEPROM_PAGESIZE);     /* 每次写满一页 */ 
				mem_addr +=  EEPROM_PAGESIZE;    /* 存储地址移到下一页起始 */
				pbuffer += EEPROM_PAGESIZE;    /* 数据指针移到下一页数据 */
			}

			if(num_of_single!=0)    /* 还有不足一页的剩余字节 */
			{
				eeprom_page_write(mem_addr, pbuffer, num_of_single);    /* 写入剩余字节 */
			}
		}
	}
	/* 写入地址和页不对齐  */
	else 
	{
		/* 待写入数据长度小于页大小 */
		if(num_of_page== 0) 
		{
			eeprom_page_write(mem_addr, pbuffer, num_of_single);    /* 不足一页,按剩余字节数写入 */
		}
		/* 待写入数据长度大于页大小 */
		else
		{
			num_byte_to_write -= count;    /* 扣除首页剩余空间,剩余数据从下一页页首对齐 */
			num_of_page =  num_byte_to_write / EEPROM_PAGESIZE;    /* 重新计算整页页数 */
			num_of_single = num_byte_to_write % EEPROM_PAGESIZE;	/* 重新计算最后剩余字节数 */

			if(count != 0)    /* 首页还有剩余空间 */
			{  
				eeprom_page_write(mem_addr, pbuffer, count);    /* 先写满首页剩余空间 */
				mem_addr += count;    /* 地址移到下一页页首 */
				pbuffer += count;    /* 数据指针同步后移 */
			} 

			while(num_of_page--)    /* 逐页写入中间的整页数据 */
			{
				eeprom_page_write(mem_addr, pbuffer, EEPROM_PAGESIZE);    /* 每次写满一页 */
				mem_addr +=  EEPROM_PAGESIZE;    /* 存储地址移到下一页起始 */
				pbuffer += EEPROM_PAGESIZE;      /* 数据指针移到下一页数据 */  
			}
			if(num_of_single != 0)    /* 末尾还有不足一页的剩余字节 */
			{
				eeprom_page_write(mem_addr, pbuffer, num_of_single);     /* 写入末尾剩余字节 */ 
			}
		}
	}  
}





/**
  * @brief 从EEPROM读取指定长度数据
  * @param mem_addr-存储器内部地址
  * @param pbuffer-读取数据缓冲区
  * @param num_byte_to_read-数据长度
  * @retval	无
  */
void eeprom_read(uint8_t mem_addr,uint8_t *pbuffer, uint16_t num_byte_to_read)
{
	/* 随机读:先写入存储地址,重复起始后读出数据,超时1000ms */
	i2c_mem_read(EEPROM_ADDRESS,mem_addr,I2C_MEMADD_8BIT,pbuffer,num_byte_to_read,1000);
}





/**
  * @brief 向EEPROM写入一页数据
  * @param mem_addr-存储器内部地址
  * @param pbuffer-待写入的数据
  * @param num_byte_to_write-数据长度
  * @retval	无
  * @note 数据长度不能超过EEPROM一页的大小
  */
static void eeprom_page_write(uint8_t mem_addr,uint8_t *pbuffer, uint8_t num_byte_to_write)
{
	/* 页写入:向器件连续写入一页数据,超时1000ms */
	i2c_mem_write(EEPROM_ADDRESS,mem_addr,I2C_MEMADD_8BIT,pbuffer,num_byte_to_write,1000);
}




/***************************************** 文件结束 *********************************************/
