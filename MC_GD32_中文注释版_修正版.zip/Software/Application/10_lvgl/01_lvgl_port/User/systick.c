/*
*******************************************************************************************************
*
* 文件名称 : systick.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 滴答定时器(SysTick)配置文件，提供系统时基、延时与时间差计算接口
*
*******************************************************************************************************
*/

/*
    版权所有 (c) 2020, 兆易创新科技集团(GigaDevice Semiconductor Inc.)

    在满足以下条件的前提下，允许以源代码和二进制形式对本软件进行再发布与使用(无论是否修改)：

    1. 源代码的再发布必须保留上述版权声明、本条件列表及以下免责声明。
    2. 以二进制形式再发布时，必须在随附的文档和/或其他分发材料中重现上述版权声明、
       本条件列表及以下免责声明。
    3. 未经事先书面许可，不得使用版权持有人或贡献者的名义为本软件的衍生产品背书或推广。

    本软件由版权持有人和贡献者"按原样"提供，不提供任何明示或默示的保证，包括但不限于
    对适销性和特定用途适用性的默示保证。在任何情况下，无论因何原因产生或基于何种责任理论
    (合同责任、严格责任或侵权行为，包括过失或其他)，版权持有人或贡献者均不对任何直接的、
    间接的、偶然的、特殊的、惩罚性的或后果性的损害(包括但不限于替代商品或服务的采购、
    使用、数据或利润损失、或业务中断)承担责任，即使已被告知可能发生此类损害。
*/

#include "gd32f30x.h"   /* GD32F30x固件库总头文件(芯片寄存器与库函数定义) */
#include "systick.h"    /* 滴答定时器接口声明头文件 */
#include "lvgl.h"       /* LVGL图形库总头文件(lv_tick_inc时基接口) */

volatile static uint32_t tick_cnt = 0;      /* 1ms时基计数器(volatile修饰,在SysTick中断中递增) */

/**
  * @brief 滴答定时器初始化
  * @param void
  * @retval	void
  * @note
  */
void systick_init(void)
{
    /* 配置滴答定时器为1000Hz(1ms周期)中断 */
    if (SysTick_Config(SystemCoreClock / 1000U)){   /* 装载重载值并启动计数,返回非0表示配置失败 */
        /* 配置失败(捕获错误) */
        while (1){      /* 死循环停机,便于排查系统时基异常 */
        }
    }
    /* 配置滴答定时器中断优先级 */
    NVIC_SetPriority(SysTick_IRQn, 0x00U);      /* 设置SysTick中断优先级为0(最高),保证系统时基精准 */
}

/**
  * @brief 滴答定时器反初始化
  * @param void
  * @retval	void
  * @note
  */
void systick_deinit(void)
{
	NVIC_DisableIRQ(SysTick_IRQn);                      /* 在NVIC中禁止SysTick中断 */
	SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;          /* 清除SysTick使能位,停止计数器 */
}

/**
  * @brief 获取当前时间
  * @param void
  * @retval	返回当前时基计数值(1ms计数)
  * @note
  */
uint32_t systick_get_current_tick(void)
{
	return tick_cnt;        /* 返回1ms时基计数值 */
}


/**
  * @brief 滴答定时器低精度阻塞延时函数
  * @param ms-需要延时的ms数
  * @retval	无
  * @note 精度1ms
  */
void systick_delay(uint32_t ms)
{
	uint32_t last_tick = systick_get_current_tick();        /* 记录延时起始时基 */
	uint32_t current_tick = systick_get_current_tick();     /* 当前时基 */
	uint32_t delta = 0;     /* 已延时的时基差值 */
	for(;;)                 /* 循环轮询直到延时时间到 */
	{
		current_tick = systick_get_current_tick();      /* 刷新当前时基 */
		/* 计算起始时基到当前的差值(处理32位计数回绕:未回绕直接相减,回绕则从0xFFFFFFFF补算) */
		delta = (current_tick >= last_tick)?(current_tick - last_tick):(0xFFFFFFFF - last_tick + current_tick);
		if(delta >= ms)         /* 差值达到设定的延时ms数 */
			return;             /* 延时结束,返回 */
	}
}

/**
  * @brief 返回系统时钟跟输入参数的差值
  * @param tick:需要比较的时基数
  * @retval 返回差值
  * @note
  */
uint32_t systick_time_diff(uint32_t tick)
{
	uint32_t delta = 0;     /* 时基差值 */
	uint32_t current_tick = systick_get_current_tick();     /* 读取当前时基 */
	/* 计算输入时基到当前的差值(处理32位计数回绕:未回绕直接相减,回绕则从0xFFFFFFFF补算) */
	delta = (current_tick >= tick)?(current_tick - tick):(0xFFFFFFFF - tick + current_tick);
	return delta;           /* 返回时间差(ms) */

}


/**
  * @brief 滴答定时器中断服务函数(1ms周期)
  * @param void
  * @retval	无
  * @note 系统时基与LVGL图形库时基均由本中断提供
  */
void SysTick_Handler(void)
{
    tick_cnt++;             /* 1ms时基计数递增 */
    lv_tick_inc(1);         /* 通知LVGL已过去1ms(驱动图形库内部时序) */
}
