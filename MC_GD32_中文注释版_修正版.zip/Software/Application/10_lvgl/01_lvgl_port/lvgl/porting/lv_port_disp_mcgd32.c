/*
*******************************************************************************************************
*
* 文件名称 : lv_port_disp_mcgd32.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : LVGL显示驱动移植层(GD32平台,LCD基础版,逐点刷新)
*
*******************************************************************************************************
*/

 /* 将此文件复制为 "lv_port_disp.c" 并将此值置 "1" 以启用本文件内容 */
#if 1 /* 置1启用本移植层文件,置0则禁用 */

/*********************
 *      头文件包含
 *********************/
#include "lv_port_disp_mcgd32.h"
#include "lv_conf.h"
#include "lcd.h"
/*********************
 *      宏定义
 *********************/

/**********************
 *      类型定义
 **********************/

/**********************
 *    静态函数声明
 **********************/
static void disp_init(void); /* 显示外设初始化函数声明 */

/* 显示刷新回调函数声明: 把缓冲区内容写到 LCD 指定区域 */
static void disp_flush(lv_disp_drv_t * disp_drv, const lv_area_t * area, lv_color_t * color_p);

/**********************
 *     静态变量定义
 **********************/

/**********************
 *        宏
 **********************/

/**********************
 *      全局函数定义
 **********************/

/* LVGL 显示端口初始化: 初始化显示外设、创建绘制缓冲区并注册显示驱动 */
void lv_port_disp_init(void)
{
    /*-------------------------
     * 初始化你的显示屏
     * -----------------------*/
    disp_init(); /* 调用显示外设初始化 */

    /*-----------------------------
     * 创建绘制缓冲区
     *----------------------------*/

    /* LittlevGL 需要一块用于绘制图形对象的缓冲区, 缓冲区必须大于 1 行显示像素
     *
     * 有三种缓冲配置方案:
     * 1. 创建一块包含若干行的缓冲区:
     *      LittlevGL 把显示内容绘制到这里, 再由你写入显示屏
     *
     * 2. 创建两块包含若干行的缓冲区:
     *      LittlevGL 把显示内容绘制到一块缓冲区并写入你的显示屏.
     *      应使用 DMA 把缓冲区内容写到显示屏.
     *      这样在第一块缓冲区数据发送期间, LittlevGL 可以把屏幕的下一部分
     *      绘制到另一块缓冲区, 使渲染与刷新并行进行.
     *
     * 3. 创建两块整屏大小的缓冲区:
     *      与方案 2) 类似, 但缓冲区必须为整屏大小. LittlevGL 绘制完成后
     *      会把整帧数据交给显示器, 这样只需修改帧缓冲地址而无需拷贝像素.
     * */

    /* 示例 1) */
/*    static lv_disp_buf_t disp_buf_1; */
/*    static lv_color_t buf1_1[LV_HOR_RES_MAX * 10]; */                   /*缓冲区: 存 10 行数据*/
/*    lv_disp_buf_init(&disp_buf_1, buf1_1, NULL, LV_HOR_RES_MAX * 10); */   /*初始化显示缓冲区*/

    /* 示例 2) */
    static lv_disp_buf_t disp_buf_2; /* 显示缓冲区描述结构体 */
    static lv_color_t buf2_1[LV_HOR_RES_MAX * 10];                        /* 缓冲区1: 存 10 行数据 */
    static lv_color_t buf2_2[LV_HOR_RES_MAX * 10];                        /* 缓冲区2: 存 10 行数据(双缓冲) */
    lv_disp_buf_init(&disp_buf_2, buf2_1, buf2_2, LV_HOR_RES_MAX * 10);   /* 初始化显示缓冲区 */

    /* 示例 3) */
/*    static lv_disp_buf_t disp_buf_3; */
/*    static lv_color_t buf3_1[LV_HOR_RES_MAX * LV_VER_RES_MAX]; */         /*整屏大小缓冲区*/
/*    static lv_color_t buf3_2[LV_HOR_RES_MAX * LV_VER_RES_MAX]; */         /*另一块整屏大小缓冲区*/
/*    lv_disp_buf_init(&disp_buf_3, buf3_1, buf3_2, LV_HOR_RES_MAX * LV_VER_RES_MAX); */   /*初始化显示缓冲区*/


    /*-----------------------------------
     * 向 LittlevGL 注册显示屏
     *----------------------------------*/

    lv_disp_drv_t disp_drv;                         /* 显示驱动描述结构体 */
    lv_disp_drv_init(&disp_drv);                    /* 驱动结构体默认初始化 */

    /*设置访问你的显示屏所需的函数*/

    /*设置显示屏分辨率*/
    disp_drv.hor_res = LV_HOR_RES_MAX; /* 水平分辨率(像素) */
    disp_drv.ver_res = LV_VER_RES_MAX; /* 垂直分辨率(像素) */

    /*用于把缓冲区内容拷贝到显示屏*/
    disp_drv.flush_cb = disp_flush; /* 注册刷新回调函数 */

    /*绑定显示缓冲区*/
    disp_drv.buffer = &disp_buf_2; /* 绑定上面创建的显示缓冲区 */

    /*最后注册驱动*/
    lv_disp_drv_register(&disp_drv); /* 向 LVGL 注册显示驱动 */
}

/**********************
 *      静态函数定义
 **********************/

/* 初始化显示屏及其所需外设 */
static void disp_init(void)
{
    /*在此添加你的初始化代码*/
}

/* 把内部缓冲区的内容刷新到显示屏的指定区域
 * 可以使用 DMA 或任何硬件加速在后台完成此操作, 但结束时必须调用
 * lv_disp_flush_ready() 通知 LVGL. */
static void disp_flush(lv_disp_drv_t * disp_drv, const lv_area_t * area, lv_color_t * color_p)
{
    /*最简单(但也最慢)的方式是逐个像素写到屏幕上*/

    int32_t x; /* 像素横坐标循环变量 */
    int32_t y; /* 像素纵坐标循环变量 */
    for(y = area->y1; y <= area->y2; y++) { /* 逐行扫描刷新区域 */
        for(x = area->x1; x <= area->x2; x++) { /* 行内逐像素写入 */
            /* 把一个像素写到显示屏, 例如: */
            /* 写入像素 put_px(x, y, *color_p)*/
            LCD_DrawPoint(x, y, color_p->full); /* 画一个像素(颜色为16位全色值) */
            color_p++; /* 移动到缓冲区中下一个像素 */
        }
    }

    /* 重要!!!
     * 告知图形库刷新已完成*/
    lv_disp_flush_ready(disp_drv); /* 通知 LVGL 本区域刷新完成 */
}

#else /* 文件顶部开关为 0 时编译以下内容 */

/* 此哑元类型定义仅用于消除 -Wpedantic 警告 */
typedef int keep_pedantic_happy;
#endif /* 结束文件顶部开关条件编译 */
