/*
*******************************************************************************************************
*
* 文件名称 : main.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 主函数文件(LVGL显示移植例程-DMA刷屏)
*
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include <string.h> /* C字符串/内存操作库头文件(memcpy等) */
#include "gd32f30x.h" /* GD32F30x芯片外设寄存器与固件库头文件 */
#include "gd32f30x_libopt.h" /* GD32F30x固件库外设包含配置头文件 */
#include "systick.h" /* 滴答定时器配置头文件(系统节拍/延时) */
#include "led.h" /* LED驱动头文件 */
#include "lcd.h" /* LCD显示驱动头文件(绘图/填充/显示字符串) */
#include "lcd_init.h" /* LCD初始化及硬件引脚配置头文件 */
#include "lvgl.h" /* LVGL图形库主头文件 */
#include "lv_port_disp_mcgd32.h" /* LVGL显示驱动移植头文件(显示缓冲区/DMA刷屏对接) */
#include "demo.h" /* LVGL官方demo演示头文件 */
#include "benchmark.h" /* LVGL性能基准测试头文件 */
/* 宏定义 ------------------------------------------------------------------------------------------*/

/* 变量定义 ----------------------------------------------------------------------------------------*/


/* 函数定义 -----------------------------------------------------------------------------------------*/
void lv_tutorial_hello_world(void); /* 声明LVGL入门示例函数(在当前屏幕创建Hello world标签) */

/* 以下为刷新率测量函数refresh_rate_test,已整体注释停用 */
/*static void refresh_rate_test() { */
/*    lv_obj_t * label; */
/*    static char buf[32]; */
/*  */
/*    创建一个标签用于显示刷新率 */
/*    label = lv_label_create(lv_scr_act(), NULL); */
/*    lv_label_set_text(label, "Refresh rate:"); */
/*    lv_obj_align(label, LV_ALIGN_TOP_LEFT, 10, 10); */
/*  */
/*    刷新率测量循环 */
/*    uint32_t last_time = lv_tick_get(); */
/*    uint32_t count = 0; */
/*    while(1) { */
/*        uint32_t diff = lv_tick_get() - last_time; */
/*        if(diff >= 1000) { 每1000毫秒刷新一次 */
/*            last_time = lv_tick_get(); */
/*            uint32_t refresh_rate = count * 1000 / diff; */
/*            sprintf(buf, "%d fps", refresh_rate); */
/*            lv_label_set_text(label, buf); */
/*            count = 0; */
/*        } */
/*        count++; */
/*  */
/*        演示其他GUI活动 */
/*        lv_obj_set_pos(label, 10, 40 + 20 * (count % 5)); */
/*  */
/*        处理LVGL任务 */
/*        lv_task_handler(); */
/*        延时以模拟CPU负载(可选) */
/*        lv_tick_inc(1); 模拟经过1毫秒 */
/*    } */
/*} */


/**
  * @brief 主函数
  * @param 无
  * @retval 无
  */
int main(void)
{
    SCB->VTOR = FLASH_BASE | 0x4000; /* 设置中断向量表到APP区基址(偏移0x4000,由Bootloader引导) */
    __enable_irq(); /* 使能全局中断 */
    
    systick_init(); /* 初始化滴答定时器(1ms系统节拍) */
    led_init(); /* 初始化LED指示灯 */
    
    LCD_Init(); /* LCD初始化 */
	LCD_Fill(0,0,LCD_W,LCD_H,BRED); /* 全屏填充BRED色(0xF81F品红色)作为背景 */
/*    LCD_ShowString(0,0,(const uint8_t *)"MC_GD32",BLACK,WHITE,32,0); */
/*    LCD_ShowString(0,32,(const uint8_t *)"GD32F303RCT6",BLACK,WHITE,32,0); */
/*    LCD_ShowString(0,64,(const uint8_t *)"ARM Cortex-M4F",BLACK,WHITE,32,0); */
    
	lv_init(); /* 初始化LVGL图形库内核 */
	lv_port_disp_init(); /* 注册显示驱动(初始化显示缓冲区与刷屏接口) */
    
    /* lv_tutorial_hello_world(); */
    demo_create(); /* 创建LVGL官方demo演示界面 */

	while(1) /* 主循环:周期处理LVGL任务 */
	{
        lv_task_handler(); /* LVGL任务处理(渲染/刷新) */
        led_toggle(LED_SYS); /* 翻转系统LED,指示程序运行 */
        systick_delay(10); /* 延时10ms(LVGL时基由滴答定时器中断lv_tick_inc提供) */
	}
}


/**
 * 创建一个简单的"Hello world!"标签
 */
void lv_tutorial_hello_world(void)
{
    lv_obj_t * scr = lv_disp_get_scr_act(NULL);     /* 获取当前活动屏幕 */

    /* 在当前活动屏幕上创建一个标签 */
    lv_obj_t * label1 =  lv_label_create(scr, NULL); /* 在屏幕上创建标签控件label1 */

    /* 修改标签文本 */
    lv_label_set_text(label1, "Hello world!"); /* 设置标签显示文本 */

    /* 将标签对齐到中心
     * NULL表示相对父对象对齐(此处即屏幕)
     * 末尾的0, 0表示对齐后的x, y偏移量*/
    lv_obj_align(label1, NULL, LV_ALIGN_CENTER, 0, 0); /* 标签居中对齐,无偏移 */
}

/***************************************** 文件结束 *********************************************/
