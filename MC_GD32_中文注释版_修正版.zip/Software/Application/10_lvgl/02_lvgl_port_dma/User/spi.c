/*
*******************************************************************************************************
*
* 文件名称 : spi.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : SPI驱动文件
* 
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "spi.h" /* SPI驱动接口声明 */

/* 宏定义 ------------------------------------------------------------------------------------------*/


/* 变量定义 ----------------------------------------------------------------------------------------*/
static uint16_t spi2_send_array[1] = {0}; /* SPI2 DMA发送数据源数组 */

/* 函数定义 -----------------------------------------------------------------------------------------*/
static void spi_dma_config(void); /* SPI2发送DMA通道配置(局部函数) */

/**
  * @brief SPI2初始化
  * @param 无
  * @retval 无
  */
void spi2_init(void)
{
    spi_parameter_struct spi_init_struct; /* SPI初始化参数结构体 */
    
    rcu_periph_clock_enable(RCU_GPIOB); /* 使能GPIOB时钟 */
    rcu_periph_clock_enable(RCU_SPI2); /* 使能SPI2时钟 */
    
    gpio_pin_remap_config(GPIO_SWJ_SWDPENABLE_REMAP, ENABLE); /* SWJ重映射为仅SWD(禁用JTAG),释放PB3引脚作SPI2_SCK */
    
    /* PB3(SCK)/PB5(MOSI)配置为复用推挽输出 */
    gpio_init(GPIOB, GPIO_MODE_AF_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_3 | GPIO_PIN_5);

    /* SPI2参数配置 */
    spi_init_struct.trans_mode           = SPI_TRANSMODE_FULLDUPLEX; /* 全双工模式 */
    spi_init_struct.device_mode          = SPI_MASTER; /* 主机模式 */
    spi_init_struct.frame_size           = SPI_FRAMESIZE_8BIT; /* 8位数据帧 */
    spi_init_struct.clock_polarity_phase = SPI_CK_PL_LOW_PH_1EDGE; /* 时钟空闲低电平,第1边沿采样(模式0) */
    spi_init_struct.nss                  = SPI_NSS_SOFT; /* 软件控制NSS片选 */
    spi_init_struct.prescale             = 0; /* 波特率预分频值0(2分频) */
    spi_init_struct.endian               = SPI_ENDIAN_MSB; /* MSB高位先行 */
    spi_init(SPI2, &spi_init_struct); /* 按上述参数初始化SPI2 */
    
    spi_enable(SPI2); /* 使能SPI2 */
    
    spi_dma_enable(SPI2, SPI_DMA_TRANSMIT); /* 使能SPI2发送DMA请求 */
    
    spi_dma_config(); /* 配置SPI2发送DMA通道 */
    
    nvic_irq_enable(DMA1_Channel1_IRQn, 2, 2); /* 使能DMA1通道1中断,抢占优先级2,子优先级2 */
    
    dma_interrupt_flag_clear(DMA1,DMA_CH1,DMA_INT_FLAG_FTF); /* 清除DMA传输完成标志 */
    dma_interrupt_enable(DMA1, DMA_CH1, DMA_INT_FTF); /* 使能DMA传输完成中断 */
    
}

/**
  * @brief SPI2发送并接收一个字节数据
  * @param data 待发送的数据
  * @retval 接收到的数据
  */
uint8_t spi2_transmit_receive_data(uint8_t data)
{
    while(RESET == spi_i2s_flag_get(SPI2, SPI_FLAG_TBE)) { /* 等待发送缓冲区空 */
    }
    spi_i2s_data_transmit(SPI2, data); /* 写入数据寄存器启动发送 */
    
    while(RESET == spi_i2s_flag_get(SPI2, SPI_FLAG_RBNE)) { /* 等待接收缓冲区非空 */
    }
    return spi_i2s_data_receive(SPI2); /* 读取并返回接收到的数据 */
}

/* 局部函数 -----------------------------------------------------------------------------------*/
/*!
    \brief      配置DMA外设
    \param[in]  无
    \param[out] 无
    \retval     无
*/
static void spi_dma_config(void)
{
    dma_parameter_struct dma_init_struct; /* DMA初始化参数结构体 */
    
    rcu_periph_clock_enable(RCU_DMA1); /* 使能DMA1时钟 */
    
    /* SPI2发送DMA配置:DMA1-DMA_CH1  */
    dma_deinit(DMA1, DMA_CH1); /* 复位DMA1通道1配置 */
    dma_init_struct.periph_addr  = (uint32_t)&SPI_DATA(SPI2); /* 外设地址:SPI2数据寄存器 */
    dma_init_struct.memory_addr  = (uint32_t)spi2_send_array; /* 存储器地址:发送数据数组 */
    dma_init_struct.direction    = DMA_MEMORY_TO_PERIPHERAL; /* 传输方向:存储器到外设 */
    dma_init_struct.memory_width = DMA_MEMORY_WIDTH_16BIT; /* 存储器数据宽度16位 */
    dma_init_struct.periph_width = DMA_PERIPHERAL_WIDTH_16BIT; /* 外设数据宽度16位 */
    dma_init_struct.priority     = DMA_PRIORITY_LOW; /* 通道优先级:低 */
    dma_init_struct.number       = 1; /* 传输数据数量:1个 */
    dma_init_struct.periph_inc   = DMA_PERIPH_INCREASE_DISABLE; /* 外设地址固定不递增 */
    dma_init_struct.memory_inc   = DMA_MEMORY_INCREASE_ENABLE; /* 存储器地址递增 */
    dma_init(DMA1, DMA_CH1, &dma_init_struct); /* 按上述参数初始化DMA1通道1 */
    /* 配置DMA传输模式:非循环,非存储器到存储器 */
    dma_circulation_disable(DMA1, DMA_CH1);
    dma_memory_to_memory_disable(DMA1, DMA_CH1);
}

/***************************************** 文件结束 *********************************************/
