/*
*******************************************************************************************************
*
* 文件名称 : key_fifo.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 按键驱动文件(FIFO+滤波消抖+长按检测)
* 
*******************************************************************************************************
*/


/* 头文件 -----------------------------------------------------------*/
#include "key_fifo.h" /* 按键驱动接口:宏/类型/函数声明 */


/* 变量 -------------------------------------------------------------*/

static KEY_T key_x[KEY_COUNT];	/* 按键结构体数组(每个按键一个状态控制块) */
static KEY_FIFO key_f;			/* 按键FIFO结构体变量 */

static __IO uint8_t is_init = 0; /* 初始化完成标志(未初始化时调用按键扫描不安全) */





/* 读取按键是否按下的函数:KEY0低电平(RESET)为按下 */
static uint8_t IsKey0Down(void) {if(gpio_input_bit_get(KEY0_GPIO_PORT,KEY0_GPIO_PIN)==RESET)return KEY_ISDOWN;else return KEY_NOTDOWN;}




/**
  * @brief 按键初始化
  * @param 无
  * @retval	None
  * @note 
  */
void key_fifo_init(void)
{
	key_gpio_config(); /* 配置按键GPIO */
	key_var_init(); /* 初始化按键结构体变量 */
	is_init = 1; /* 置初始化完成标志 */
}

/**
  * @brief 读取按键是否初始化
  * @param 无
  * @retval	1-按键已经初始化 0按键没有初始化
  * @note 没有初始化的时候调用按键扫描不安全
  */
uint8_t key_is_init(void)
{
	return is_init; /* 返回初始化标志 */
}


/**
  * @brief 获取按键
  * @param 无
  * @retval	返回按键fifo的一个按键
  * @note 
  */
uint8_t key_get(void)
{
	uint8_t ret; /* 读出的按键事件值 */
	
	if(key_f.Read == key_f.Write)		 /* 读指针==写指针:FIFO空 */
	{
		/* FIFO空 */
		return KEY_NONE;
	}
	else
	{
		/* 从FIFO读出一个数据且读指针加1 */
		ret = key_f.Buf[key_f.Read++];
		

		if(key_f.Read >= KEY_FIFO_SIZE) /* 读指针越界则回卷到0(环形缓冲) */
		{
			key_f.Read = 0; /* 读指针回卷 */
		}
		return ret; /* 返回按键事件 */
	}
}


/**
  * @brief 清空按键fifo
  * @param 无
  * @retval	None
  * @note 
  */
void key_clear(void)
{
	key_f.Read = key_f.Write; /* 读指针追上写指针即清空FIFO */
}


/**
  * @brief 往按键fifo存入一个按键
  * @param keyCode-按键事件码
  * @retval	None
  * @note 
  */
void key_put(uint8_t keyCode)
{
	/* 往FIFO存入一个数据且写指针加1 */
	key_f.Buf[key_f.Write++] = keyCode;
	
	if(key_f.Write >= KEY_FIFO_SIZE) /* 写指针越界则回卷到0(环形缓冲) */
		key_f.Write = 0; /* 写指针回卷 */
}


/**
  * @brief 扫描所有按键
  * @param 无
  * @retval	None
  * @note 必须被周期性调用
  */
void key_scan(void)
{
	uint8_t i=0; /* 按键索引 */
	for(i=0;i<KEY_COUNT;i++) /* 逐个扫描所有按键 */
	{
		key_detect(i); /* 单个按键状态检测(滤波/长按判定并入队事件) */
	}

}



/**
  * @brief 按键GPIO初始化
  * @param 无
  * @retval	None
  * @note 
  */
static void key_gpio_config(void)
{
    rcu_periph_clock_enable(KEY0_GPIO_CLK); /* 使能按键端口时钟 */

    gpio_init(KEY0_GPIO_PORT,GPIO_MODE_IN_FLOATING,GPIO_OSPEED_50MHZ,KEY0_GPIO_PIN); /* KEY0引脚浮空输入(按下拉低) */
}



/**
  * @brief 按键fifo相关结构体变量初始化
  * @param 无
  * @retval	None
  * @note 
  */
static void key_var_init(void)
{
	uint8_t i=0; /* 循环索引 */
	
	key_f.Read = 0; /* FIFO读指针清零 */
	key_f.Write = 0; /* FIFO写指针清零 */
	
	for(i=0;i<KEY_COUNT;i++) /* 初始化每个按键的控制块 */
	{
		key_x[i].LongTime = KEY_LONG_TIME; /* 长按判定时间(KEY_LONG_TIME,单位10ms) */
		key_x[i].Count = KEY_FILTER_TIME / 2; /* 滤波计数器初值取滤波时间一半 */
		key_x[i].State = 0; /* 按键初始状态:未按下 */
		key_x[i].RepeatSpeed = 0; /* 连发周期:0表示长按后不连发 */
		key_x[i].RepeatCount = 0; /* 连发计数器清零 */
		
	}
	
	/* 判断按键是否按下的函数 */
	key_x[0].IsKeyDownFunc = IsKey0Down; /* 绑定KEY0电平检测函数 */
}




/**
  * @brief 检测一个按键
  * @param 无
  * @retval	None
  * @note 这个函数里面判断按键是否按下,并进行滤波
  */
static void key_detect(uint8_t i)
{
	KEY_T *pKey; /* 当前按键控制块指针 */
	
	pKey = &key_x[i]; /* 取第i个按键的控制块 */
	if(pKey->IsKeyDownFunc() == KEY_ISDOWN)		/* 按键按下了 */
	{
		if(pKey->Count < KEY_FILTER_TIME) /* 按下初期:滤波计数预置到滤波时间 */
		{
			pKey->Count = KEY_FILTER_TIME; /* 预置滤波时间 */
		}
		else if(pKey->Count < 2 * KEY_FILTER_TIME) /* 继续计数到2倍滤波时间(确认按下) */
		{
			pKey->Count++; /* 滤波计数+1 */
		}
		else
		{
			/* 滤波消抖后的 */
			if(pKey->State == 0)		/* 按键状态为未按下 */
			{	
				pKey->State = 1;		/* 标记按键状态为按下 */
				
				key_put((uint8_t)(3*i+1));	/* 存入按键按下事件(事件码3*i+1) */
			}
			if(pKey->LongTime > 0)		/* 如果支持长按 */
			{
				if(pKey->LongCount < pKey->LongTime) /* 按下持续时间未达长按阈值 */
				{
					pKey->LongCount++; /* 长按计数+1 */
					if(pKey->LongCount >= pKey->LongTime) /* 达到长按时间 */
					{
						/* 存入按键长按 */
						key_put((uint8_t)(3*i+3));
					} /* 存入长按事件(事件码3*i+3) */
					
				}
				else
				{
					if(pKey->RepeatSpeed>0) /* 配置了连发周期则长按后连发 */
					{
						pKey->RepeatCount++; /* 连发计数+1 */
						if(pKey->RepeatCount >= pKey->RepeatSpeed) /* 达到连发周期 */
						{
							/* 按键长按后,按连发周期定期重发按键按下事件码 */
							pKey->RepeatCount = 0;
							key_put((uint8_t)(3*i+1));
						}
					}
				}
			}
		}
	}
	else		/* 按键未按下 */
	{	
		if(pKey->Count > KEY_FILTER_TIME) /* 释放初期:滤波计数预置到滤波时间 */
		{
			pKey->Count = KEY_FILTER_TIME; /* 预置滤波时间 */
		}
		else if(pKey->Count > 0) /* 继续递减到0(确认释放) */
		{
			pKey->Count--; /* 滤波计数-1 */
		}
		else
		{
			
			if(pKey->State == 1)	/* 按键原来是按下的 */
			{
				
				
				pKey->State = 0; /* 标记按键状态为释放 */
				
				/* 存入按键弹起来 */
				key_put((uint8_t)(3*i+2));
			}
		}
		
		pKey->LongCount = 0; /* 释放后清长按计数 */
		pKey->RepeatCount = 0; /* 释放后清连发计数 */
	}
}



/*****************************  文件结束 *********************************/
