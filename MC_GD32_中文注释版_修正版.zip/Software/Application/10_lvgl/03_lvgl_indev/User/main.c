/*
*******************************************************************************************************
*
* 文件名称 : main.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 主函数文件
*
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include <string.h>    /* 标准字符串处理头文件 */
#include "gd32f30x.h"    /* GD32F30x固件库主头文件(外设寄存器定义与库函数) */
#include "gd32f30x_libopt.h"    /* GD32F30x固件库外设配置头文件(库选项) */
#include "systick.h"    /* 滴答定时器头文件(系统时基) */
#include "led.h"    /* LED驱动头文件 */
#include "encoder.h"    /* 编码器接口头文件 */
#include "key_fifo.h"    /* 按键FIFO头文件 */
#include "lcd.h"    /* LCD显示驱动头文件 */
#include "lcd_init.h"    /* LCD底层初始化头文件 */
#include "lvgl.h"    /* LVGL图形库主头文件 */
#include "lv_port_disp_mcgd32.h"    /* LVGL显示端口移植头文件(GD32屏驱动适配) */
#include "demo.h"    /* LVGL官方演示demo头文件 */
#include "benchmark.h"    /* LVGL性能测试benchmark头文件 */
/* 宏定义 ------------------------------------------------------------------------------------------*/

/* 变量定义 ----------------------------------------------------------------------------------------*/
extern lv_obj_t * tv;    /* 引用demo演示界面创建的tabview选项卡控件指针 */

/* 函数定义 -----------------------------------------------------------------------------------------*/
void lv_tutorial_hello_world(void);    /* 函数声明：LVGL Hello World示例界面函数 */

/**
  * @brief 主函数
  * @param 无
  * @retval 无
  */
int main(void)
{
    uint8_t key = KEY_NONE;    /* 按键事件变量(初值：无事件) */
    encoder_code_t encoder_code = ENCODER_NONE;    /* 编码器事件变量(初值：无事件) */
    
    SCB->VTOR = FLASH_BASE | 0x4000;    /* 重定位中断向量表到应用程序区(FLASH_BASE+0x4000，为Bootloader预留前16KB) */
    __enable_irq();    /* 使能全局中断 */
    
    systick_init();    /* 初始化滴答定时器(系统时基) */
    led_init();    /* 初始化LED */
    key_fifo_init();    /* 初始化按键FIFO */
    encoder_init();    /* 初始化编码器接口 */
    
    LCD_Init();    /* LCD初始化 */
        LCD_Fill(0,0,LCD_W,LCD_H,BRED);    /* LCD整屏填充背景色BRED(清屏) */
/*    LCD_ShowString(0,0,(const uint8_t *)"MC_GD32",BLACK,WHITE,32,0); */    /* 显示字符串(未启用) */
/*    LCD_ShowString(0,32,(const uint8_t *)"GD32F303RCT6",BLACK,WHITE,32,0); */
/*    LCD_ShowString(0,64,(const uint8_t *)"ARM Cortex-M4F",BLACK,WHITE,32,0); */
    
        lv_init();    /* 初始化LVGL图形库 */
        lv_port_disp_init();    /* 初始化LVGL显示端口(注册显示驱动) */
    
    /* lv_tutorial_hello_world(); */    /* Hello World示例界面(未启用) */
    demo_create();    /* 创建LVGL官方演示demo界面 */

        while(1)    /* 主循环：轮询按键/编码器并驱动LVGL刷新 */
        {
        key_scan();    /* 扫描按键状态(更新按键FIFO) */
        key = key_get();    /* 从按键FIFO读取一个按键事件 */
        switch(key)    /* 根据按键事件分发处理 */
        {
        case KEY_0_RELEASE:    /* 按键0释放事件(当前未处理) */
            break;
        case KEY_0_LONG_PRESS:    /* 按键0长按事件(当前未处理) */
            break;
        default:
            break;
        }

        encoder_code = encoder_get();    /* 读取编码器旋转事件 */
        switch(encoder_code)    /* 根据编码器事件分发处理 */
        {
        case ENCODER_NONE:    /* 无编码器事件 */
            break;
        case ENCODER_INC:    /* 编码器顺时针旋转(增量)事件 */
            if(tv)    /* 若tabview控件指针有效 */
            {
                /* 若当前选项卡不是最后一个 */
                if((lv_tabview_get_tab_act(tv)+1) < lv_tabview_get_tab_count(tv))
                    /* 切换到下一个选项卡(带动画) */
                    lv_tabview_set_tab_act(tv,lv_tabview_get_tab_act(tv)+1,LV_ANIM_ON);
            }
            break;
        case ENCODER_DEC:    /* 编码器逆时针旋转(减量)事件 */
            if(tv)    /* 若tabview控件指针有效 */
            {
                if(lv_tabview_get_tab_act(tv) > 0)    /* 若当前选项卡不是第一个 */
                    /* 切换到上一个选项卡(带动画) */
                    lv_tabview_set_tab_act(tv,lv_tabview_get_tab_act(tv)-1,LV_ANIM_ON);
            }
            break;
        }

        lv_task_handler();    /* LVGL任务处理函数(刷新界面/处理输入事件，需周期性调用) */
        
        systick_delay(10);    /* 延时10ms(LVGL心跳节拍) */
        }
}


/**
 * 创建一个简单的'Hello world!'标签
 */
void lv_tutorial_hello_world(void)
{
    lv_obj_t * scr = lv_disp_get_scr_act(NULL);     /* 获取当前活动屏幕 */

    /* 在当前活动屏幕上创建一个标签(label)控件 */
    lv_obj_t * label1 =  lv_label_create(scr, NULL);    /* 在屏幕上创建标签控件 */

    /* 设置标签的文本内容 */
    lv_label_set_text(label1, "Hello world!");    /* 设置标签显示"Hello world!" */

    /* 将标签对齐到中心
     * NULL表示相对父对象对齐(此处即屏幕)
     * 末尾的0, 0表示对齐后的x, y偏移量*/
    lv_obj_align(label1, NULL, LV_ALIGN_CENTER, 0, 0);
}

/***************************************** 文件结束 *********************************************/
