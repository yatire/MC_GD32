/*
*******************************************************************************************************
*
* 文件名称 : pll_estimator.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : PLL锁相环观测器(源自Microchip AN2520应用笔记)
*
*******************************************************************************************************
*/

/* 头文件包含 ------------------------------------------------------------------------------------------------*/
#include "pll_estimator.h"
#include "foc.h" /* FOC公共参数结构体定义(αβ/dq/正余弦) */

/* Park变换：将两相静止坐标系(αβ)分量变换到旋转坐标系(dq) */
void mcLib_ParkTransform(mcParam_AlphaBeta *alphabetaParam , mcParam_SinCos *scParam, mcParam_DQ *dqParam)
{
    /* d轴分量 = α*cosθ + β*sinθ */
    dqParam->d =  alphabetaParam->alpha*scParam->Cos + alphabetaParam->beta*scParam->Sin;
    /* q轴分量 = -α*sinθ + β*cosθ */
    dqParam->q = -alphabetaParam->alpha*scParam->Sin + alphabetaParam->beta*scParam->Cos;
}

/* ***************************************************************************** */
/* ***************************************************************************** */
/* 分节：PLL锁相环观测器程序 */
/* ***************************************************************************** */
/* ***************************************************************************** */
/* PLL锁相环观测器主函数：由αβ轴反电动势估算电角速度qVelEstim与电角度qRho */
void mcLib_PLLEstimator(mcParam_PLLEstimator *pllestimatorParam)
{
        float tempqVelEstim; /* 电角速度估计值绝对值暂存 */
    mcParam_DQ BEMF_DQParam; /* 反电动势dq轴分量结构体 */
    mcParam_AlphaBeta BEMF_AlphaBetaParam; /* 反电动势αβ轴分量结构体 */
    mcParam_SinCos scParam; /* 正余弦计算结构体(角度/正弦/余弦) */
    
    if(pllestimatorParam->qVelEstim < 0) /* 电角速度估计值为负(反转)时 */
    {
        tempqVelEstim = pllestimatorParam->qVelEstim * (-1);     /* 取绝对值 */
    }
    else
    {
        tempqVelEstim = pllestimatorParam->qVelEstim; /* 电角速度为正(或零)直接赋值 */
    }
    
        /* α轴电流差分：本拍电流-上拍电流 */
        pllestimatorParam->qDIalpha     =       (pllestimatorParam->qIalpha-pllestimatorParam->qLastIalpha);
    /* α轴电感压降：Ls*(di/dt)差分近似 */
    pllestimatorParam->qVIndalpha = (pllestimatorParam->qLsDt * pllestimatorParam->qDIalpha);
    /* β轴电流差分：本拍-上拍 */
    pllestimatorParam->qDIbeta  =       (pllestimatorParam->qIbeta-pllestimatorParam->qLastIbeta);
    /* β轴电感压降：Ls*(di/dt)差分近似 */
    pllestimatorParam->qVIndbeta= (pllestimatorParam->qLsDt * pllestimatorParam->qDIbeta);
    
    /* 更新上拍电流LastIalpha/LastIbeta */
    pllestimatorParam->qLastIalpha      =       pllestimatorParam->qIalpha; /* 保存本拍α轴电流供下拍差分 */
    pllestimatorParam->qLastIbeta       =       pllestimatorParam->qIbeta; /* 保存本拍β轴电流供下拍差分 */
    
    /* 定子电压方程：反电动势=上拍电压-电阻压降-电感压降，计算α轴反电动势qEsa */
        pllestimatorParam->qEsa = BEMF_AlphaBetaParam.alpha = pllestimatorParam->qLastValpha -
                                                        ((pllestimatorParam->qRs  * pllestimatorParam->qIalpha))
                                                        - pllestimatorParam->qVIndalpha;
                                                        
    /* β轴反电动势qEsb，与α轴对称 */
        pllestimatorParam->qEsb = BEMF_AlphaBetaParam.beta      =       pllestimatorParam->qLastVbeta -
                                                        ((pllestimatorParam->qRs  * pllestimatorParam->qIbeta ))
                                                        - pllestimatorParam->qVIndbeta;
    
    /* 更新上拍电压：给定电压经最大相电压qMaxPhaseVoltage标幺换算 */
        /* α轴上拍电压 */
        pllestimatorParam->qLastValpha = (pllestimatorParam->qMaxPhaseVoltage * pllestimatorParam->qValpha);
        /* β轴上拍电压 */
        pllestimatorParam->qLastVbeta = (pllestimatorParam->qMaxPhaseVoltage * pllestimatorParam->qVbeta);

    /* 计算Sin(Rho)与Cos(Rho) */
    scParam.Angle       =       pllestimatorParam->qRho + pllestimatorParam->RhoOffset;  /* 估计角度加零偏校准值 */
    scParam.Cos = arm_cos_f32(scParam.Angle); /* 计算余弦值 */
    scParam.Sin = arm_sin_f32(scParam.Angle); /* 计算正弦值 */

    /* 用Park变换将αβ轴反电动势ESA、ESB变换到dq轴ESD、ESQ */ 

    mcLib_ParkTransform(&BEMF_AlphaBetaParam , &scParam, &BEMF_DQParam); /* 执行Park变换 */
    
     pllestimatorParam->qEsd = BEMF_DQParam.d; /* 滤波前d轴反电动势(dq旋转坐标系,Park变换输出) */
     pllestimatorParam->qEsq = BEMF_DQParam.q; /* 滤波前q轴反电动势(dq旋转坐标系,Park变换输出) */
    /* 对Esd与Esq进行一阶低通滤波 */
        pllestimatorParam->qEsdf                        = pllestimatorParam->qEsdf+
                                                          ((pllestimatorParam->qEsd - pllestimatorParam->qEsdf) * pllestimatorParam->qKfilterEsdq) ;

        pllestimatorParam->qEsqf                        = pllestimatorParam->qEsqf+
                                                          ((pllestimatorParam->qEsq - pllestimatorParam->qEsqf) * pllestimatorParam->qKfilterEsdq) ;


    pllestimatorParam->qInvKFi = pllestimatorParam->qInvKFi_Below_Nominal_Speed; /* 反电动势系数倒数：默认取额定转速以下的系数 */
   
        if (tempqVelEstim>pllestimatorParam->qDecimate_Nominal_Speed) /* 高速分支：电角速度估计绝对值大于额定转速的10% */
    {
        if(pllestimatorParam->qEsqf>0) /* Esqf>0(正转) */
        {
            /* Esqf>0(正转)：电角速度=InvKFi*(Esqf-Esdf) */
                pllestimatorParam->qOmegaMr     =       ((pllestimatorParam->qInvKFi*(pllestimatorParam->qEsqf- pllestimatorParam->qEsdf))) ;
        } 
                else
        {
            /* Esqf<=0(反转)：电角速度=InvKFi*(Esqf+Esdf) */
                pllestimatorParam->qOmegaMr     =       ((pllestimatorParam->qInvKFi*(pllestimatorParam->qEsqf + pllestimatorParam->qEsdf)));
        }
    } 
        else /* 低速分支：估计转速<额定转速10%，不能靠Esqf符号判向，改用qVelEstim符号 */
    {
        if(pllestimatorParam->qVelEstim>0) /* 电角速度估计值为正(正转) */
        {
            /* 正转方向：电角速度=InvKFi*(Esqf-Esdf) */
                pllestimatorParam->qOmegaMr     =       ((pllestimatorParam->qInvKFi*(pllestimatorParam->qEsqf- pllestimatorParam->qEsdf))) ;
        } 
                else
        {
            /* 反转方向：电角速度=InvKFi*(Esqf+Esdf) */
                pllestimatorParam->qOmegaMr     =       ((pllestimatorParam->qInvKFi*(pllestimatorParam->qEsqf+ pllestimatorParam->qEsdf))) ;
        }
    }
        
        /* 电角速度的积分得到估计电角度：qRho += qOmegaMr*qDeltaT */
        pllestimatorParam->qRho =       pllestimatorParam->qRho+
                                                        (pllestimatorParam->qOmegaMr)*(pllestimatorParam->qDeltaT);
    
    if(pllestimatorParam->qRho >= ANGLE_2PI) /* 电角度不小于2π，减2π归一化 */
        pllestimatorParam->qRho = pllestimatorParam->qRho - ANGLE_2PI;       /* 减2π */

     if(pllestimatorParam->qRho <= 0) /* 电角度不大于0，加2π归一化 */
        pllestimatorParam->qRho = pllestimatorParam->qRho + ANGLE_2PI;  /* 加2π */
    

    /* 估计转速为上述qOmegaMr的一阶滤波值 */
    /* 滤波实现方法与反电动势dq分量滤波相同 */
        pllestimatorParam->qVelEstim = (pllestimatorParam->qVelEstim+
                                                ( (pllestimatorParam->qOmegaMr-pllestimatorParam->qVelEstim)*pllestimatorParam->qVelEstimFilterK ));
}

