
/*******************************************************************************
  电机控制库接口头文件

  公司:
    Microchip Technology Inc.

  文件名:
    mc_Lib.h

  概要:
    电机控制库头文件。

  描述:
    本文件描述电机控制库用于带FPU的PIC32器件时所使用的宏、结构体和API。
*******************************************************************************/


/* DOM-IGNORE-BEGIN */
/*******************************************************************************
版权所有 (c) <2018> 由 Microchip Technology Inc. 发布。保留所有权利。

Microchip 授予您仅将本软件嵌入式使用于集成到您产品或第三方产品中的
Microchip 微控制器或数字信号控制器上的使用、修改、复制和分发权利
（依据随附许可协议中的再许可条款）。

您应当参考随本软件提供的许可协议，了解有关您的权利和义务的信息。

软件和文档按"原样"提供，不附带任何形式的明示或暗示担保，包括但不限于
对适销性、所有权、不侵权和特定用途适用性的担保。在任何情况下，Microchip
或其许可方均不对因合同、过失、严格责任、违反担保或其他法律或公平理论
引起的任何直接或间接损害负责，包括但不限于任何附带的、特殊的、间接的
或后果性损害、利润损失或数据丢失、采购替代商品、技术或服务的成本，
或任何第三方索赔（包括但不限于任何抗辩）或其他类似成本。
*******************************************************************************/

#ifndef _MC_LIB_H                                    /* 防止头文件重复包含的条件编译 */
#define _MC_LIB_H                                    /* 头文件包含保护宏 */
/* DOM-IGNORE-END */

/* DOM-IGNORE-BEGIN */
#ifdef __cplusplus  /* 提供C++兼容性 */

    extern "C" {                                     /* C++编译环境下使用C语言链接 */

#endif                                               /* 结束__cplusplus条件编译 */
/* DOM-IGNORE-END */

/* *****************************************************************************
*****************************************************************************
分节：常量定义
*****************************************************************************
***************************************************************************** */



#define         SQRT3_BY2                       (float)0.866025403788  /* 定义 sqrt(3)/2 的值 */
#define         ONE_BY_SQRT3                    (float)0.5773502691    /* 定义 1/sqrt(3) 的值 */

#define         ANGLE_2PI               (2*M_PI)               /* 定义 2*PI 的值 */
#define         TABLE_SIZE                      256                    /* 定义正弦/余弦查找表的大小 */
/* 定义正弦/余弦查找表的角度分辨率 */
#define         ANGLE_STEP                      (float)((float)ANGLE_2PI/(float)TABLE_SIZE)

/* *****************************************************************************
*****************************************************************************
分节：数据类型
*****************************************************************************
***************************************************************************** */
/*  定义包含电机控制API输入和输出参数的结构体
*/


/* 包含用于计算SVPWM空间矢量调制占空比的变量的结构体 */
typedef struct  /* SVPWM参数结构体 */
{
    float   PWMPeriod;  /* PWM周期（PWM定时器计数值） */
    float   Vr1;        /* 由改进Clark变换得到的归一化A相电压 */
    float   Vr2;        /* 由改进Clark变换得到的归一化B相电压 */
    float   Vr3;        /* 由改进Clark变换得到的归一化C相电压 */
    float       T1;         /* 矢量T1的长度 */
    float   T2;         /* 矢量T2的长度 */
    float   Ta;         /* Ta = To/2 + T1 + T2 */
    float   Tb;         /* Tb = To/2 + T2 */
    float   Tc;         /* Tc = To/2 */
    float       dPWM_A;      /* A相占空比 */
    float   dPWM_B;      /* B相占空比 */
    float   dPWM_C;      /* C相占空比 */
} mcParam_SVPWM;         /* SVPWM参数结构体类型 */


/* 包含用于电流PI调节器和速度PI调节器控制参考值的变量的结构体 */
typedef struct  /* 控制参考值结构体 */
{
    float   VelInput;   /* 速度输入。速度输入经斜率限幅器后给出速度参考值 */
    float   VelRef;             /* 速度参考值 */
    float   IdRef;              /* D轴电流（磁通）参考值 */
    float   IqRef;              /* Q轴电流（转矩）参考值 */
        float   Diff;           /* 速度输入与速度参考值之差 */
        float   IqRefmax;       /* Q轴电流最大值 */
} mcParam_ControlRef;    /* 控制参考值结构体类型 */

/* 包含用于磁场定向控制(FOC)的变量的结构体 */
typedef struct  /* FOC参数结构体 */
{
    float   OpenLoopAngle;      /* 转子角度（弧度） */
    float   DCBusVoltage;   /* 实测直流母线电压（伏特） */
    float   MaxPhaseVoltage;/* 最大相电压（相到中性点电压） */
        float   VdqNorm;        /* D轴和Q轴电压的归一化矢量和 */
        float   MaxVoltageCircleSquared;    /* 最大相电压的平方 */
        float   VdSquaredDenorm;            /* D轴电压的平方（还原为伏特值） */
        float   VqSquaredDenorm;            /* Q轴电压的平方（还原为伏特值） */
        float   VqRefVoltage;               /* 弱磁控制时估算的Q轴电压（伏特） */

} mcParam_FOC;           /* FOC参数结构体类型 */

/* 包含两相静止参考坐标系分量的结构体 */
typedef struct  /* Alpha-Beta参数结构体 */
{
    float   alpha;     /* 两相静止坐标系中的Alpha轴分量 */
    float   beta;      /* 两相静止坐标系中的Beta轴分量 */

} mcParam_AlphaBeta;     /* Alpha-Beta参数结构体类型 */

/* 包含两相旋转参考坐标系分量的结构体 */
typedef struct  /* D-Q参数结构体 */
{
    float   d;     /* 两相旋转坐标系中的D轴分量 */
    float   q;      /* 两相旋转坐标系中的Q轴分量 */

} mcParam_DQ;            /* D-Q参数结构体类型 */

/* 包含三相静止参考坐标系分量的结构体 */
typedef struct  /* A-B-C参数结构体 */
{
    float   a;      /* 三相静止坐标系中的A轴分量 */
    float   b;      /* 三相静止坐标系中的B轴分量 */
    float   c;      /* 三相静止坐标系中的C轴分量 */
} mcParam_ABC;           /* A-B-C参数结构体类型 */

/* 包含用于正弦和余弦计算的变量的结构体 */
typedef struct  /* 正弦余弦参数结构体 */
{
    float   Angle; /* 需要计算正弦/余弦的角度（弧度） */
    float   Sin;   /* 正弦值Sin(Angle) */
    float   Cos;   /* 余弦值Cosine(Angle) */
} mcParam_SinCos;        /* 正弦余弦参数结构体类型 */


/* 包含PI调节器所用变量的结构体 */
typedef struct  /* PI调节器参数结构体 */
{
    float   qdSum;  /* PI调节器的积分器输出 */
    float   qKp;    /* PI调节器的比例系数 */
    float   qKi;    /* PI调节器的积分系数 */
    float   qKc;    /* PI调节器的抗积分饱和系数 */
    float   qOutMax;/* PI调节器的最大输出限幅 */
    float   qOutMin;/* PI调节器的最小输出限幅 */
    float   qInRef; /* PI调节器的参考输入 */
    float   qInMeas;/* PI调节器的反馈输入 */
    float   qOut;   /* PI调节器的比例+积分输出 */
    float   qErr;   /* PI调节器的误差输入 */
} mcParam_PIController;  /* PI调节器参数结构体类型 */

/* 包含PLL锁相环观测器所用变量的结构体（用于无感转子位置/速度估算） */
typedef struct  /* PLL观测器参数结构体 */
{
    float   qIalpha;                                                /* Alpha轴电流 */
    float   qIbeta;                                                 /* Beta轴电流 */
    float   qValpha;                                                /* Alpha轴电压 */
    float   qVbeta;                                                 /* Beta轴电压 */
    float   qMaxPhaseVoltage;                                       /* 最大相电压 */
    float       qDeltaT;                                                /* 积分时间间隔（PWM周期，秒） */
    float   qRho;                                               /* 估算的转子角度（弧度） */
    float   qOmegaMr;                                                   /* 主速（一阶）速度估算值 */
    float   qLastIalpha;                                                /* 上一次的Ialpha值 */
    float   qLastIbeta;                                                 /* 上一次的Ibeta值 */
    float   qDIalpha;                                                   /* Ialpha的差分值 */
    float   qDIbeta;                                                    /* Ibeta的差分值 */
        float   qEsa;                                                           /* Alpha轴反电动势(BEMF) */
        float   qEsb;                                                           /* Beta轴反电动势(BEMF) */
        float   qEsd;                                                           /* D轴反电动势(BEMF) */
        float   qEsq;                                                           /* Q轴反电动势(BEMF) */
    float       qVIndalpha;                                             /* Alpha轴 dI*Ls/dt 电压分量 */
        float   qVIndbeta;                                              /* Beta轴 dI*Ls/dt 电压分量 */
        float   qEsdf;                                                  /* D轴反电动势滤波值 */
        float   qEsqf;                                                  /* Q轴反电动势滤波值 */
        float   qKfilterEsdq;                                           /* D-Q轴反电动势的滤波系数 */
        float   qVelEstim;                                                      /* 估算速度 */
        float   qVelEstimFilterK;                                       /* 估算速度的滤波系数 */
    float   qLastValpha;                                                /* 上一次控制周期的Valpha值 */
    float   qLastVbeta;                                                 /* 上一次控制周期的Vbeta值 */
        float   RhoOffset;                                      /* 估算转子角度的初始偏移（弧度） */
    float       qRs;                                                            /* Rs值 - 定子电阻（欧姆） */
        float   qLsDt;                                                          /* Ls/dt值 - 定子电感/时间步长（随速度变化的量） */
        float   qInvKFi;                                                /* InvKFi常数（InvKFi = Omega/BEMF） */
    float   qKFi;                               /* 反电动势常数（V-sec/rad，伏·秒/弧度） */
    float   qInvKFi_Below_Nominal_Speed;        /* 电机电角速度低于额定电角速度时的1/(反电动势常数) */
    float   qLs_DIV_2_PI;                       /* 相电感Ls / 2*PI */
    float   qNominal_Speed;                     /* 电机额定电角速度（弧度/秒） */
    float   qDecimate_Nominal_Speed;            /* 电机额定电角速度的1/10 */

} mcParam_PLLEstimator;  /* PLL观测器参数结构体类型 */


/* *****************************************************************************
*****************************************************************************
分节：接口例程
*****************************************************************************
***************************************************************************** */
/*  本节描述用于带FPU的32位MCU电机控制应用的API
*/


/* ***************************************************************************** */
/* 函数:
    void mcLib_ParkTransform(mcParam_AlphaBeta *alphabetaParam ,
                             mcParam_SinCos *scParam,  mcParam_DQ *dqParam)

  概要:
  Park变换（帕克变换）

  描述:
 本函数计算Park变换。
 
  前置条件: 
    无。


  参数:
    *alphabetaParam     - 指向 mcParam_AlphaBeta 类型结构体的指针，
                          该结构体包含Alpha-Beta轴分量
                          （两相静止坐标系）

    *scParam            - 指向 mcParam_SinCos 类型结构体的指针，
                          该结构体包含与正弦和余弦计算
                          相关的参数。

    *dqParam            - 指向 mcParam_DQ 类型结构体的指针，
                          该结构体包含D-Q轴分量
                          （两相旋转坐标系）。
    
  返回值:
    无。

  示例:
    <code>
    mcParam_AlphaBeta mcApp_I_AlphaBetaParam;
    mcParam_SinCos mcApp_SincosParam; 
    mcParam_DQ mcApp_I_DQParam; 
 
    // 角度输入 = 1.571 弧度（90度）
        mcApp_SincosParam.Angle = (float) 1.571;
    
    // 使用 mcLib_SinCosGen 计算正弦和余弦
    mcLib_SinCosGen(&mcApp_SincosParam);
  
      
    // 更新Alpha轴和Beta轴电流
    mcApp_I_AlphaBeta.alpha = 1.2;
    mcApp_I_AlphaBeta.beta = 0.8;  
    

    // 使用 mcLib_ParkTransform 计算Park变换。变换结果
    // 存放在 mcApp_I_DQParam.d 和 mcApp_I_DQParam.q 中
     mcLib_ParkTransform(&mcApp_I_AlphaBetaParam,  &mcApp_SincosParam, &mcApp_I_DQParam);
    </code>

  备注: 
    无。
*/

/* Park变换：将两相静止坐标系(Alpha-Beta)分量变换到两相旋转坐标系(D-Q) */
void mcLib_ParkTransform(mcParam_AlphaBeta *alphabetaParam ,mcParam_SinCos *scParam,  mcParam_DQ *dqParam);





/* ***************************************************************************** */
/* 函数:
    void mcLib_InvParkTransform(mcParam_DQ *dqParam, mcParam_SinCos *scParam, 
                               mcParam_AlphaBeta *alphabetaParam)

  概要:
 反Park变换（反帕克变换）

  描述:
 本函数计算反Park变换

 
  前置条件: 
    无。


  参数:
    *dqParam           - 指向 mcParam_DQ 类型结构体的指针，
                         该结构体包含D-Q轴分量
   
    *scParam           - 指向 mcParam_SinCos 类型结构体的指针，
                         该结构体包含与正弦和余弦计算
                         相关的参数。


    *alphabetaParam    - 指向 mcParam_AlphaBeta 类型结构体的指针，
                         该结构体包含Alpha-Beta轴分量
                         （两相静止坐标系）。
  返回值:
    无。

  示例:
    <code>
    mcParam_DQ                          mcApp_V_DQParam;
    mcParam_SinCos                      mcApp_SincosParam;
    mcParam_AlphaBeta                   mcApp_V_AlphaBetaParam;
  
 
    // 角度输入 = 1.571 弧度（90度）
        mcApp_SincosParam.Angle = (float) 1.571;
    
    // 使用 mcLib_SinCosGen 计算正弦和余弦
    mcLib_SinCosGen(&mcApp_SincosParam);
  
 
    
    // 更新归一化的D轴和Q轴数值
    mcApp_V_DQParam.d = 0;
    mcApp_V_DQParam.q = 0.8;  
    

    // 使用 mcLib_InvParkTransform 计算反Park变换。变换结果
    // 存放在 mcApp_V_AlphaBetaParam.alpha 和
    // mcApp_V_AlphaBetaParam.beta 中
    mcLib_InvParkTransform(&mcApp_V_DQParam,&mcApp_SincosParam,
                           &mcApp_V_AlphaBetaParam);
    </code>

  备注: 
    无。
*/
/* 反Park变换：将两相旋转坐标系(D-Q)分量变换到两相静止坐标系(Alpha-Beta) */
void mcLib_InvParkTransform(mcParam_DQ *dqParam, mcParam_SinCos *scParam,
                            mcParam_AlphaBeta *alphabetaParam);

/* ***************************************************************************** */
/* 函数:
    void mcLib_ClarkeTransform(mcParam_ABC *abcParam, mcParam_AlphaBeta *alphabetaParam)

  概要:
 Clark变换（克拉克变换）

  描述:
 本函数计算Clark变换

  前置条件: 
    无。
 

  参数:
    *abcParam           - 指向 mcParam_ABC 类型结构体的指针，
                          该结构体包含A、B、C轴分量
                          （三相静止坐标系）
    
    *alphabetaParam     - 指向 mcParam_AlphaBeta 类型结构体的指针，
                          该结构体包含Alpha-Beta轴分量
   
      返回值:
        无。

  示例:
    <code>
    mcParam_ABC mcApp_I_ABCParam;
    mcParam_AlphaBeta mcApp_I_AlphaBetaParam;
    
    // 更新Ia和Ib电流值 
    mcApp_I_ABCParam.a = 1.2; // A相电流（安培）
    mcApp_I_ABCParam.b = 0.8; // B相电流（安培）
    

    // 使用 mcLib_ClarkeTransform 计算Clark变换。变换结果
    // 存放在 mcApp_I_AlphaBetaParam.alpha 和 mcApp_I_AlphaBetaParam.beta 中
   mcLib_ClarkeTransform(&mcApp_I_ABCParam, &mcApp_I_AlphaBetaParam);
    </code>

  备注: 
    无。
*/
/* Clark变换：将三相静止坐标系(A-B-C)分量变换到两相静止坐标系(Alpha-Beta) */
void mcLib_ClarkeTransform(mcParam_ABC *abcParam, mcParam_AlphaBeta *alphabetaParam);




/* ***************************************************************************** */
/* 函数:
   void mcLib_SVPWMGen( mcParam_AlphaBeta *alphabetaParam, mcParam_SVPWM *svParam )

  概要:
  SVPWM空间矢量调制生成

  描述:
  本函数计算SVPWM空间矢量调制信号的占空比

  前置条件:
  无。
 

  参数:
    *alphabetaParam     - 指向 mcParam_AlphaBeta 类型结构体的指针，
                          该结构体包含alpha-beta轴归一化的
                          定子电压值
  
    *svParam            - 指向 mcParam_SVPWM 类型结构体的指针，
                          该结构体包含SVPWM参数。

   
  返回值:
    无。

  示例:
    <code>
    mcParam_AlphaBeta                   mcApp_V_AlphaBetaParam; 
    mcParam_SVPWM                                               mcApp_SVGenParam;
   
    
    // 更新归一化的Valpha和Vbeta值 
    mcApp_V_AlphaBetaParam.alpha = 0.1; // 归一化Alpha轴电压
    mcApp_V_AlphaBetaParam.beta = 0.8; // 归一化Beta轴电压
    
    // 以PWM定时器计数值设置PWM周期
    mcApp_SVGenParam.PWMPeriod = 3000; // PWM周期（PWM定时器计数值）
    

    // 使用 mcLib_SVPWMGen 计算SVPWM占空比。结果
    // 存放在 mcApp_SVGenParam.dPWM_A、mcApp_SVGenParam.dPWM_B
    // 和 mcApp_SVGenParam.dPWM_C 中
     mcLib_SVPWMGen(&mcApp_focParam, &mcApp_SVGenParam);
    </code>

  备注: 
    无。
*/
/* SVPWM生成：根据Alpha-Beta轴电压计算三相占空比 */
void mcLib_SVPWMGen( mcParam_AlphaBeta *alphabetaParam, mcParam_SVPWM *svParam );

/* ***************************************************************************** */
/* 函数:
    void mcLib_CalcTimes( mcParam_SVPWM *svParam  );

  概要:
  空间矢量到占空比的换算

  描述:
  本函数将空间矢量持续时间换算为SVPWM的归一化占空比
 值

  前置条件:
  无。
 

  参数:
    *svParam            - 指向 mcParam_SVPWM 类型结构体的指针，
                          该结构体包含SVPWM参数

      输入: 
     *mcParam_SVPWM 类型结构体的以下成员是本函数的
     * 输入
        float   PWMPeriod;        // PWM周期（PWM定时器计数值）
        float   T1;               // T1矢量的归一化持续时间 
        float   T2;               // T2矢量的归一化持续时间 
   
      输出:
     * mcParam_SVPWM 类型结构体的以下成员包含本函数的
     * 输出
        float   Ta;         // Ta = To/2 + T1 + T2
        float   Tb;         // Tb = To/2 + T2
        float   Tc;         // Tc = To/2
                                                                                
  返回值:
    无。

  示例:
    <code>
    
    mcParam_SVPWM                                               mcApp_SVGenParam;
    
        
    // 以PWM定时器计数值设置PWM周期
    mcApp_SVGenParam.PWMPeriod = 3000; // PWM周期（PWM定时器计数值）
    
    // 设置矢量T1和T2的归一化长度
    mcApp_SVGenParam.T1 = 0.8; // 矢量T1的归一化长度
    mcApp_SVGenParam.T2 = 0.2; // 矢量T2的归一化长度

    // 使用 mcLib_CalcTimes 计算SVPWM的归一化占空比。结果
    // 存放在 mcApp_SVGenParam.Ta、mcApp_SVGenParam.Tb
    // 和 mcApp_SVGenParam.Tc 中
     mcLib_CalcTimes(&mcApp_SVGenParam);
    </code>

  备注: 
    无。
*/
/* 空间矢量到占空比的换算：由T1/T2矢量时长计算Ta/Tb/Tc相时间 */
void mcLib_CalcTimes( mcParam_SVPWM *svParam );

/* ***************************************************************************** */
/* 函数:
    void mcLib_InitPI( mcParam_PIController *pParm)

  概要:
  初始化PI调节器

  描述:
  本函数初始化PI调节器，即清零积分累加和与PI输出。

  前置条件:
  无。
 

  参数:
    *pParam            - 指向 mcParam_PIController 类型结构体的指针，该结构体包含PI调节器参数
  
  返回值:
    无。

  示例:
    <code>
    
    mcParam_PIController mcApp_PIParam;
    
        
    // 使用 mcLib_InitPI 初始化PI调节器输出。 
     mcLib_InitPI(&mcApp_PIParam);
    </code>

  备注: 
    无。
*/
/* PI调节器初始化：清零积分累加和与PI输出 */
void mcLib_InitPI( mcParam_PIController *pParam);

/* ***************************************************************************** */
/* 函数:
    void mcLib_CalcPI( mcParam_PIController *pParm)

  概要:
  计算PI调节器输出

  描述:
  本函数计算PI调节器的输出。

  前置条件:
  无。
 

  参数:
    *pParam            - 指向 mcParam_PIController 类型结构体的指针，该结构体包含PI调节器参数。
     
  返回值:
    无。

  示例:
    <code>
    
    mcParam_PIController mcApp_PIParam;
    
        
    // 设置PI调节器系数
    mcApp_PIParam.qKp = 0.5;  // PI调节器的比例系数      
    mcApp_PIParam.qKi = 0.2;  // PI调节器的积分系数            
    mcApp_PIParam.qKc = 0.3;  // PI调节器的抗积分饱和系数     
    
    // 设置PI调节器的饱和限幅
    mcApp_PIParam.qOutMax = 1;// PI调节器的最大输出限幅
    mcApp_PIParam.qOutMin = -1;// PI调节器的最小输出限幅
    
    // 更新PI调节器的参考值输入和反馈值输入 
    mcApp_PIParam.qInRef = <Reference Value>;
    mcApp_PIParam.qInMeas = <Feedback Value>;
        

    // 使用 mcLib_CalcPI 计算PI调节器输出。输出
    // 存放在 mcApp_PIParam.qOut 中
     mcLib_CalcPI(&mcApp_PIParam);
    </code>

  备注: 
    无。
*/
/* PI调节器计算：根据误差计算比例+积分输出（含抗饱和处理） */
void mcLib_CalcPI( mcParam_PIController *pParam);



/* ***************************************************************************** */
/* 函数:
    void mcLib_SinCosGen(mcParam_SinCos *scParam)

  概要:
  计算正弦和余弦值 

  描述:
  本函数计算给定角度（以弧度表示）的正弦和余弦值

  前置条件:
  无。
 

  参数:
    *scParam            - 指向 mcParam_SinCos 类型结构体的指针，该结构体包含与正弦
                          和余弦计算相关的参数。
  
  返回值:
    无。

  示例:
    <code>
    
     mcParam_SinCos mcApp_SincosParam;
 
    // 角度输入 = 1.571 弧度（90度）
        mcApp_SincosParam.Angle = (float) 1.571;
    
    // 使用 mcLib_SinCosGen 计算正弦和余弦。计算得到的正弦和余弦
    // 值分别存放在 mcApp_SincosParam.Sin 和 mcApp_SincosParam.Cos 中
    mcLib_SinCosGen(&mcApp_SincosParam);
        
    </code>

  备注: 
    无。
*/
/* 正弦余弦生成：计算给定角度（弧度）的正弦和余弦值 */
void mcLib_SinCosGen(mcParam_SinCos *scParam);



/* ***************************************************************************** */
/* 函数:
    void mcLib_PLLEstimator(mcParam_PLLEstimator *pllestimatorParam)

  概要:
  估算转子角度位置 

  描述:
  本函数基于反电动势测量，使用PLL（锁相环）型观测器估算转子角度位置

  前置条件:
  无。
 

  参数:
    *pllestimatorParam  - 指向 mcParam_PLLEstimator 类型结构体的指针，该结构体包含
                           PLL观测器参数
                           

  
  返回值:
    无。

  示例:
    <code>
    
     mcParam_SinCos mcApp_SincosParam;
     mcParam_PLLEstimator mcApp_EstimParam;
 
    // 初始化PLL观测器所需的电机参数值 
        mcApp_EstimParam.qLsDt = <Motor Phase Inductance/PWM Period>;
        mcApp_EstimParam.qRs = <Motor Phase Resistance>;
        mcApp_EstimParam.qKFi = <BACK EMF Constant in V-sec/rad>;
        mcApp_EstimParam.qInvKFi_Below_Nominal_Speed = <1/BACK EMF Constant in V-sec/rad>;
    mcApp_EstimParam.qLs_DIV_2_PI = <Motor Phase Inductance / (2*PI)>;
    mcApp_EstimParam.qNominal_Speed = <Motor Nominal Speed>;
    mcApp_EstimParam.qKfilterEsdq = <DQ Filter Coefficient>;
    mcApp_EstimParam.qVelEstimFilterK =<Speed Filter Coefficient>;
    mcApp_EstimParam.qDeltaT = <PWM Period>;
    mcApp_EstimParam.RhoOffset = <OFFSET in Radians>;
    
    
    // 角度输入 = 1.571 弧度（90度）
        mcApp_SincosParam.Angle = (float) 1.571;
    
    // 读取A相和B相电流值
    mcApp_focParam.Ia = <Phase A Current>; 
    mcApp_focParam.Ib = <Phase B Current>;
    
    // 计算Clark变换
    mcLib_ClarkeTransform(&mcApp_focParam);
   
    // 计算Park变换
    mcLib_ParkTransform(&mcApp_focParam);
    
    // 使用 mcLib_PLLEstimator 估算转子位置。估算的转子角度和速度
    // 分别存放在 mcApp_EstimParam.qRho 和 mcApp_EstimParam.qVelEstim 中 
    mcLib_PLLEstimator(&mcApp_EstimParam);
    
   
        
    </code>

  备注: 
    无。
*/
/* PLL锁相环观测器：基于反电动势(BEMF)测量估算转子角度位置和速度 */
void mcLib_PLLEstimator(mcParam_PLLEstimator *pllestimatorParam);




/*DOM-IGNORE-BEGIN*/
#ifdef __cplusplus                                  /* C++兼容条件编译 */
}
#endif                                              /* 结束__cplusplus条件编译 */
/*DOM-IGNORE-END*/

#endif /* #ifndef _MC_LIB_H */                      /* 头文件包含保护结束 */
/*******************************************************************************
 文件结束
*/