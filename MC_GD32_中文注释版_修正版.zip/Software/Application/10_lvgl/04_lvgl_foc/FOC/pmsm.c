/*
*******************************************************************************************************
*
* 文件名称 : pmsm.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : PMSM(永磁同步电机)FOC驱动文件
*
*******************************************************************************************************
*/


/* 头文件包含 ----------------------------------------------------------------------------------------*/
#include "pmsm.h"               /* PMSM电机控制结构体与对外接口定义 */
#include "foc.h"                /* FOC核心算法接口(Clark/Park/反Park/SVPWM/PI) */
#include "pll_estimator.h"      /* PLL转子位置观测器(Microchip AN2520)接口 */
#include "userparms.h"          /* 用户参数配置(PI参数/开环启动参数/模式选择宏) */
#include "motor_hardware.h"     /* 电机硬件层定义(PWM定时器/通道/PWM频率) */
#include "ee_parameter.h"       /* EEPROM参数存储接口(电机参数/开环参数) */
/* 宏定义 ------------------------------------------------------------------------------------------*/


/* 变量定义 ----------------------------------------------------------------------------------------*/
pmsm_foc_t pmsm_foc_param;                 /* FOC算法运行参数(坐标变量/PI调节器/电压指令等) */
pmsm_mc_t pmsm_mc_param;                   /* 电机控制状态参数(运行标志/开闭环/速度给定/PLL变量等) */
mcParam_PLLEstimator mcApp_EstimParam;     /* PLL观测器参数集(输入输出量/电机电气参数) */

float theta_error = 0;              /* 开环切闭环时记录的角度误差偏置(弧度) */
float iq_error = 0;                 /* iq误差记录变量 */
uint32_t iq_error_count = 0;        /* iq误差计数器 */

/* 函数定义 -----------------------------------------------------------------------------------------*/
static void pmsm_foc_init_control_parameters(void);    /* FOC控制参数(PI参数)初始化 */
static void calculate_park_angle(void);                /* Park变换角度计算(开环启动/切闭环处理) */
static void pid_control(void);                         /* 电流环与速度环PI控制 */
static void mcApp_InitEstimParm(void);                 /* PLL观测器电机参数初始化 */
static void hall_speed_pll(float angle);               /* 霍尔角度PLL跟踪测速 */

/**
  * @brief PMSM FOC初始化(初始化PI参数/开环启动状态机/PLL观测器参数)
  * @param 无
  * @retval 无
  * @note
  */
void pmsm_foc_init(void)
{
	/* FOC控制参数与PLL观测器初始化(原SMC初始化注释为SMO模板遗留,本工程无滑模观测器) */
	
	pmsm_foc_init_control_parameters();    /* 初始化d/q轴电流环与速度环PI参数 */
	
	pmsm_mc_param.run_motor = 1;           /* 置电机运行标志 */
	pmsm_mc_param.openloop = 1;            /* 上电先进入开环启动模式 */
	pmsm_mc_param.change_mode = 1;         /* 置控制模式切换标志 */
	pmsm_mc_param.startup_lock_count = 0;  /* 转子预定位计数器清零 */
    pmsm_mc_param.openloop_hold_count = 0; /* 开环保持计数器清零 */
	pmsm_mc_param.startup_ramp = 0;        /* 开环角度斜坡增量清零 */
    pmsm_mc_param.ol_state = ROTOR_LOCK;   /* 开环启动状态机置为转子预定位阶段 */
    
/*    pmsm_mc_param.vel_input = (float)motor_normal_spd*RPM_TO_RADS*motor_pole; */
    
    pmsm_mc_param.lock_counter = (float)rotor_lock_time/((float)LOOPTIME_SEC * 10);    /* 预定位时间换算为循环计数值 */
    pmsm_mc_param.hold_counter = (float)openloop_hold_time/((float)LOOPTIME_SEC * 10);    /* 开环保持时间换算为循环计数值 */
    pmsm_mc_param.open_loop_current = (float)openloop_current / 10.0f;    /* 开环启动电流给定(0.1A单位换算为A) */
    /* 开环终止转速对应的每周期电角度增量(转速(RPM)×极对数×PWM周期) */
    pmsm_mc_param.end_speed_rads_elec_counter = (float)open_loop_speed*RPM_TO_RADS*motor_pole*LOOPTIME_SEC;
    /* 开环加速阶段每周期角度递增量(终止增量/斜坡循环数) */
    pmsm_mc_param.openloop_rampspeed_inc = pmsm_mc_param.end_speed_rads_elec_counter/((float)openloop_ramp_time/10/LOOPTIME_SEC);
    pmsm_mc_param.end_speed = (float)open_loop_speed*RPM_TO_RADS*motor_pole;    /* 开环终止速度(rad/s电角速度) */
    pmsm_mc_param.sensor = motor_sensor;    /* 位置传感器类型(0:无感,1:霍尔) */
    
    mcApp_InitEstimParm();    /* 初始化PLL观测器参数 */
}

/**
  * @brief FOC循环执行函数(在PWM/ADC中断中按PWM周期调用)
  * @param 无
  * @retval 无
  * @note
  */
void pmsm_foc_run(void)
{
    if(pmsm_mc_param.run_motor)    /* 电机运行标志有效:执行FOC算法 */
    {
        clark(&pmsm_foc_param);    /* Clark变换:三相电流→αβ两相静止坐标系 */
        park(&pmsm_foc_param);     /* Park变换:αβ→dq两相旋转坐标系 */
        
        if(pmsm_mc_param.sensor == 0)    /* 无感模式:用PLL观测器估算转子位置与速度 */
        {
            mcApp_EstimParam.qIalpha = pmsm_foc_param.ialpha;    /* 送入α轴电流 */
            mcApp_EstimParam.qIbeta = pmsm_foc_param.ibeta;      /* 送入β轴电流 */
            mcApp_EstimParam.qValpha = pmsm_foc_param.valpha;    /* 送入α轴电压 */
            mcApp_EstimParam.qVbeta = pmsm_foc_param.vbeta;      /* 送入β轴电压 */
            mcApp_EstimParam.qMaxPhaseVoltage = pmsm_mc_param.max_phase_voltage;    /* 送入最大相电压限幅值 */
            mcLib_PLLEstimator(&mcApp_EstimParam);    /* PLL观测器解算:估算转子电角度与速度 */
            pmsm_mc_param.actual_speed = mcApp_EstimParam.qVelEstim;    /* 取估算电角速度作为实际转速 */
            
            calculate_park_angle();    /* 计算Park变换角度(含开环启动与切闭环处理) */
        }
        else
        {
            hall_speed_pll(pmsm_mc_param.hall_theta);    /* 对霍尔角度做PLL跟踪,得到平滑角度与速度 */
            pmsm_foc_param.angle = pmsm_mc_param.theta_pll;    /* PLL跟踪角度作为Park变换角度 */
            pmsm_mc_param.actual_speed = pmsm_mc_param.omega_pll_filter;    /* PLL滤波后角速度作为实际转速 */
            pmsm_mc_param.openloop = 0;    /* 有感模式直接运行于闭环 */
        }
        
        pid_control();    /* 电流环/速度环PI运算,得到vd/vq电压给定 */
        
        sin_cos(&pmsm_foc_param);    /* 计算当前电角度的正弦/余弦值 */
        
        inv_park(&pmsm_foc_param);    /* 反Park变换:dq电压→αβ静止坐标系 */
        
        svpwm(&pmsm_foc_param);    /* SVPWM空间矢量调制:更新三相PWM占空比 */
    }
    else
    {
        /* 禁止U相上管PWM输出 */
        timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_U_CHANNEL,TIMER_CCX_DISABLE);
        /* 禁止V相上管PWM输出 */
        timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_V_CHANNEL,TIMER_CCX_DISABLE);
        /* 禁止W相上管PWM输出 */
        timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_W_CHANNEL,TIMER_CCX_DISABLE);
        /* 禁止U相下管互补PWM输出 */
        timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_U_CHANNEL,TIMER_CCXN_DISABLE);
        /* 禁止V相下管互补PWM输出 */
        timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_V_CHANNEL,TIMER_CCXN_DISABLE);
        /* 禁止W相下管互补PWM输出 */
        timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_W_CHANNEL,TIMER_CCXN_DISABLE);
    }
}

/* 局部函数 -----------------------------------------------------------------------------------*/
/**
  * @brief 控制参数初始化(d/q轴电流环与速度环PI参数)
  * @param 无
  * @retval 无
  * @note
  */
static void pmsm_foc_init_control_parameters(void)
{
	pmsm_foc_param.pi_d.kp = DKP;          /* d轴电流环PI:比例系数 */
	pmsm_foc_param.pi_d.ki = DKI;          /* d轴电流环PI:积分系数 */
	pmsm_foc_param.pi_d.kc = DKC;          /* d轴电流环PI:积分抗饱和回授系数 */
	pmsm_foc_param.pi_d.out_max = DOUTMAX; /* d轴PI输出限幅(vd最大值) */
	pmsm_foc_param.pi_d.out_min = -pmsm_foc_param.pi_d.out_max;    /* d轴PI输出下限(负对称) */

	init_pi(&pmsm_foc_param.pi_d);    /* 初始化d轴PI(积分器与输出清零) */

	pmsm_foc_param.pi_q.kp = QKP;          /* q轴电流环PI:比例系数 */
	pmsm_foc_param.pi_q.ki = QKI;          /* q轴电流环PI:积分系数 */
	pmsm_foc_param.pi_q.kc = QKC;          /* q轴电流环PI:积分抗饱和回授系数 */
	pmsm_foc_param.pi_q.out_max = QOUTMAX; /* q轴PI输出限幅(vq最大值) */
	pmsm_foc_param.pi_q.out_min = -pmsm_foc_param.pi_q.out_max;    /* q轴PI输出下限(负对称) */

	init_pi(&pmsm_foc_param.pi_q);    /* 初始化q轴PI(积分器与输出清零) */
    
	pmsm_foc_param.pi_w.kp = WKP;          /* 速度环PI:比例系数 */
	pmsm_foc_param.pi_w.ki = WKI;          /* 速度环PI:积分系数 */
	pmsm_foc_param.pi_w.kc = WKC;          /* 速度环PI:积分抗饱和回授系数 */
	pmsm_foc_param.pi_w.out_max = WOUTMAX; /* 速度环PI输出限幅(iq给定最大值) */
	pmsm_foc_param.pi_w.out_min = -pmsm_foc_param.pi_w.out_max;    /* 速度环PI输出下限(负对称) */
	
	init_pi(&pmsm_foc_param.pi_w);    /* 初始化速度环PI(积分器与输出清零) */
}


/**
  * @brief 角度计算(开环启动/开环切闭环/闭环角度处理)
  * @param 无
  * @retval 无
  * @note
  */
static void calculate_park_angle(void)
{
	if(pmsm_mc_param.openloop)    /* 开环启动阶段:角度由斜坡积分生成 */
	{
        switch(pmsm_mc_param.ol_state)    /* 开环启动状态机 */
        {
            case ROTOR_LOCK:    /* 转子预定位阶段 */
                if(pmsm_mc_param.startup_lock_count < pmsm_mc_param.lock_counter)    /* 预定位时间未到 */
                {
                    pmsm_mc_param.startup_lock_count++;    /* 预定位计数累加 */
                }
                else
                {
                    pmsm_mc_param.ol_state = RAMP_SPEED;    /* 预定位完成,进入开环加速阶段 */
                }
                break;
            case RAMP_SPEED:    /* 开环斜坡加速阶段 */
                if(pmsm_mc_param.startup_ramp < pmsm_mc_param.end_speed_rads_elec_counter)    /* 未达开环终止速度 */
                {
                    pmsm_mc_param.startup_ramp += pmsm_mc_param.openloop_rampspeed_inc;    /* 每周期增大角度增量 */
                }
                else
                {
                    pmsm_mc_param.ol_state = OL_HOLD;    /* 达到终止速度,进入开环保持阶段 */
                }
                break;
            case OL_HOLD:    /* 开环速度保持阶段 */
                if(pmsm_mc_param.openloop_hold_count < pmsm_mc_param.hold_counter)    /* 保持时间未到 */
                {
                    pmsm_mc_param.openloop_hold_count++;    /* 保持计数累加 */
                }
                else
                {
                    pmsm_mc_param.ol_state = WAIT_CLOSELOOP;    /* 保持完成,等待切入闭环 */
                }
                break;
            case WAIT_CLOSELOOP:    /* 等待切闭环阶段 */
                theta_error = pmsm_foc_param.angle - mcApp_EstimParam.qRho;    /* 记录开环角度与估算角度之差 */
#ifndef OPEN_LOOP_MODE    /* 未定义为纯开环模式时,直接切入闭环 */
                pmsm_mc_param.change_mode = 1;    /* 置模式切换标志 */
                pmsm_mc_param.openloop = 0;    /* 退出开环,进入闭环 */
#endif
                break;
            default:
                break;
        }
		pmsm_foc_param.angle += pmsm_mc_param.startup_ramp;    /* 开环角度按斜坡增量累加 */
        if(pmsm_foc_param.angle > ANGLE_2PI)    /* 角度归一化到[0,2π) */
            pmsm_foc_param.angle = pmsm_foc_param.angle - ANGLE_2PI;    /* 大于2π则减去2π */
	}
	else    /* 闭环运行阶段 */
	{
        pmsm_foc_param.angle = mcApp_EstimParam.qRho + theta_error;    /* 角度=观测器估算角度+切换误差偏置 */
        if((fabsf(theta_error) > 0.05f))    /* 偏置绝对值大于0.05rad时逐步衰减 */
        {
            if (theta_error < 0)    /* 负偏置向0收敛 */
            {
                theta_error += 0.05f;    /* 每周期增加0.05rad */
            }
            else    /* 正偏置向0收敛 */
            {
                theta_error -= 0.05f;    /* 每周期减小0.05rad */
            }
        }
        else
        {
            theta_error = 0;    /* 偏置足够小,直接清零 */
        }
   	    /* 闭环下缓慢减小叠加到观测器估算角度上的偏置 */
   	    if(mcApp_EstimParam.RhoOffset>(M_PI/(float)32767))    /* 偏置大于最小步长时递减 */
            /* 每周期按固定小步长递减一次角度偏置 */
            mcApp_EstimParam.RhoOffset = mcApp_EstimParam.RhoOffset - ((M_PI/(float)32767)) ; 
	}
}

/**
  * @brief PI控制(开环阶段仅电流环,闭环阶段电流环+速度环)
  * @param 无
  * @retval 无
  * @note
  */
static void pid_control(void)
{
	if(pmsm_mc_param.openloop)    /* 开环阶段:固定电流给定,仅闭环电流环 */
	{
		if(pmsm_mc_param.change_mode)    /* 首次进入开环模式处理 */
		{
			pmsm_mc_param.change_mode = 0;    /* 清除模式切换标志 */
            pmsm_mc_param.id_ref = 0;    /* d轴电流给定清零 */
		}
        
        pmsm_mc_param.iq_ref = pmsm_mc_param.open_loop_current;    /* q轴电流给定=开环启动电流 */
        
        /* q轴电流环PI调节 */
        pmsm_foc_param.pi_q.meas = pmsm_foc_param.iq;    /* q轴反馈电流 */
        pmsm_foc_param.pi_q.ref  = pmsm_mc_param.iq_ref;    /* q轴给定电流 */
        calc_pi(&pmsm_foc_param.pi_q);    /* q轴PI计算 */
        pmsm_foc_param.vq = pmsm_foc_param.pi_q.out;    /* PI输出作为q轴电压给定 */
       
        /* d轴电流环PI调节 */
        pmsm_foc_param.pi_d.meas = pmsm_foc_param.id;    /* d轴反馈电流 */
        pmsm_foc_param.pi_d.ref  = pmsm_mc_param.id_ref;    /* d轴给定电流 */
        calc_pi(&pmsm_foc_param.pi_d);    /* d轴PI计算 */
        pmsm_foc_param.vd = pmsm_foc_param.pi_d.out;    /* PI输出作为d轴电压给定 */
        
#ifdef OPEN_LOOP_VF_VQ    /* 若定义了开环V/F固定电压宏,则强制Vq=V/F给定 */
        pmsm_foc_param.vq = OPEN_LOOP_VF_VQ;    /* q轴电压取固定宏值 */
        pmsm_foc_param.vd = 0;    /* d轴电压置0 */
#endif
        
	}
	else    /* 闭环阶段 */
	{
        float vd_squared = 0;      /* vd电压平方(用于电压圆限幅) */
        float vq_squared_max = 0;  /* q轴电压平方上限 */

		if(pmsm_mc_param.change_mode)    /* 首次切入闭环模式处理 */
		{
            pmsm_mc_param.change_mode = 0;    /* 清除模式切换标志 */
            pmsm_mc_param.vel_ref = pmsm_mc_param.end_speed;    /* 速度斜坡给定预置为开环终止速度(平滑切换) */
            pmsm_mc_param.id_ref = 0;    /* d轴电流给定清零 */
            pmsm_foc_param.pi_w.sum = pmsm_mc_param.iq_ref;    /* 速度环积分器预置当前iq给定(无扰切换) */
            pmsm_mc_param.speed_loop_count = SPEED_LOOP_CYCLE;    /* 速度环分频计数预置(下个周期立即执行) */
		}
        pmsm_mc_param.vel_diff =  pmsm_mc_param.vel_input - pmsm_mc_param.vel_ref;    /* 速度给定与斜坡给定之差 */

       /* 速度斜坡限幅器实现 */
        if(pmsm_mc_param.vel_diff >= CL_SPEED_HYSTERESIS)    /* 给定高于斜坡值超过滞环:升速 */
        {
             pmsm_mc_param.vel_ref += CL_SPEED_RAMP_RATE_DELTA;   /* 斜坡给定按步长递增 */
        }
        else if(pmsm_mc_param.vel_diff <=- CL_SPEED_HYSTERESIS)    /* 给定低于斜坡值超过滞环:降速 */
        {
             pmsm_mc_param.vel_ref -= CL_SPEED_RAMP_RATE_DELTA; /* 斜坡给定按步长递减 */
        }
        else
        {
             pmsm_mc_param.vel_ref = pmsm_mc_param.vel_input;    /* 差值在滞环内:斜坡给定直接跟踪给定 */
        }
        
#ifdef TORQUE_MODE    /* 转矩模式:直接使用外部iq给定,不运行速度环 */
/*        pmsm_mc_param.iq_ref = OPEN_LOOP_CURRENT; */
#else    /* 速度模式:按分频周期运行速度环 */
        if(pmsm_mc_param.speed_loop_count++ >= SPEED_LOOP_CYCLE)    /* 速度环分频:每SPEED_LOOP_CYCLE个周期执行一次 */
        {
            pmsm_mc_param.speed_loop_count = 0;    /* 分频计数清零 */
            /* 速度环PI调节 */
            pmsm_foc_param.pi_w.meas = pmsm_mc_param.actual_speed;    /* 反馈速度 */
            pmsm_foc_param.pi_w.ref  = pmsm_mc_param.vel_ref;    /* 速度给定(斜坡后) */
            calc_pi(&pmsm_foc_param.pi_w);    /* 速度环PI计算 */
            pmsm_mc_param.iq_ref = pmsm_foc_param.pi_w.out;    /* PI输出作为q轴电流给定 */
        }
#endif
            
        /* d轴电流环PI调节 */
        pmsm_foc_param.pi_d.meas = pmsm_foc_param.id;    /* d轴反馈电流 */
        pmsm_foc_param.pi_d.ref  = pmsm_mc_param.id_ref;    /* d轴给定电流 */
        calc_pi(&pmsm_foc_param.pi_d);    /* d轴PI计算 */
        pmsm_foc_param.vd = pmsm_foc_param.pi_d.out;    /* PI输出作为d轴电压给定 */
        
        vd_squared = pmsm_foc_param.vd * pmsm_foc_param.vd;    /* 计算vd平方 */
        vq_squared_max = 0.99f - vd_squared;    /* 电压圆限幅:剩余幅值平方(0.99为限幅系数) */
		arm_sqrt_f32(vq_squared_max,&pmsm_foc_param.pi_q.out_max);    /* 开方得到q轴电压输出上限 */
        pmsm_foc_param.pi_q.out_min = -pmsm_foc_param.pi_q.out_max;    /* q轴输出下限(负对称) */

        /* q轴电流环PI调节 */
        pmsm_foc_param.pi_q.meas = pmsm_foc_param.iq;    /* q轴反馈电流 */
        pmsm_foc_param.pi_q.ref  = pmsm_mc_param.iq_ref;    /* q轴给定电流 */
        calc_pi(&pmsm_foc_param.pi_q);    /* q轴PI计算 */
        pmsm_foc_param.vq = pmsm_foc_param.pi_q.out;    /* PI输出作为q轴电压给定 */
	}
}


/**
  * @brief PLL观测器电机参数初始化(从EEPROM电机参数换算)
  * @param 无
  * @retval 无
  * @note
  */
static void mcApp_InitEstimParm(void)  
{
    float l = (float)motor_l / 1000000.0f;               /* 电机相电感(µH换算为H) */
    float r = (float)motor_r / 1000.0f;                  /* 电机相电阻(mΩ换算为Ω) */
    float speed = (float)motor_normal_spd*RPM_TO_RADS*motor_pole;    /* 额定转速(rad/s电角速度) */
    float bemf = (float)motor_bemf / 1000.0f;            /* 反电动势(mV/KRPM换算为V/KRPM) */
    
	mcApp_EstimParam.qLsDt = (float)(l/LOOPTIME_SEC);    /* 定子电感/环路周期(Ls/Ts) */
	mcApp_EstimParam.qRs = r;    /* 定子电阻 */
	mcApp_EstimParam.qKFi = (bemf/1.732f)/1000 * 60/ANGLE_2PI/motor_pole;    /* 反电动势系数Ke(线值转相值并折算单位) */
	mcApp_EstimParam.qInvKFi_Below_Nominal_Speed = (float)(1/mcApp_EstimParam.qKFi);    /* 反电动势系数倒数 */
    mcApp_EstimParam.qLs_DIV_2_PI = l/(2*M_PI);    /* 定子电感/(2π) */
    mcApp_EstimParam.qNominal_Speed = speed;    /* 额定电角速度 */
    mcApp_EstimParam.qDecimate_Nominal_Speed = mcApp_EstimParam.qNominal_Speed / 10.0f;    /* 额定电角速度的1/10 */
  	mcApp_EstimParam.qOmegaMr = 0;    /* 机械角速度清零 */
	 
    mcApp_EstimParam.qKfilterEsdq = KFILTER_ESDQ;    /* d/q轴反电动势低通滤波系数 */
    mcApp_EstimParam.qVelEstimFilterK = KFILTER_VELESTIM;    /* 速度估算低通滤波系数 */

    mcApp_EstimParam.qDeltaT = LOOPTIME_SEC;    /* 环路执行周期(秒) */
    mcApp_EstimParam.RhoOffset = (45 * (M_PI/180));    /* PLL角度初始偏置(45°电角度,切闭环过渡用) */
}

/**
  * @brief 霍尔角度PLL跟踪(锁相环滤波,输出平滑角度与角速度)
  * @param angle 霍尔输出的电角度(弧度)
  * @retval 无
  * @note
  */
static void hall_speed_pll(float angle)
{
    /* 1. 定义时间相关参数（需确保PWM_FREQ单位正确） */
    #define PWM_PERIOD_SEC      (1.0f / MOTOR_PWM_FREQ_HZ)  /* PWM周期（秒） */
    /* 2. 定义PLL参数（浮点数，显式标注单位） */
    #define SpeedPllBandWidth   250.0f      /* 环路带宽（rad/s） */
    #define SpeedPllKp          (2.0f * SpeedPllBandWidth)                /* Kp = 2*Wn */
    #define SpeedPllKi          (SpeedPllBandWidth * SpeedPllBandWidth * PWM_PERIOD_SEC)  /* Ki = Wn^2 * Ts */
    /* #define OmegaToTheta        (PWM_PERIOD_SEC * 16384.0f * 32768.0f / (2.0f * PI))       // 角速度→角度转换因子 */
	#define OmegaToTheta  (PWM_PERIOD_SEC)  /* 直接使用PWM周期作为积分系数 */
    /* 3. 霍尔信号积分（预测角度） */
    /* stcHallAngle.hallAngle += stcHallAngle.hallspeed; */
    /* 4. 生成实际角度的正弦/余弦信号 */
	float sin = arm_sin_f32(angle);    /* 实际霍尔角度正弦值 */
	float cos = arm_cos_f32(angle);    /* 实际霍尔角度余弦值 */
	float sin_pll = arm_sin_f32(pmsm_mc_param.theta_pll);    /* PLL跟踪角度正弦值 */
	float cos_pll = arm_cos_f32(pmsm_mc_param.theta_pll);    /* PLL跟踪角度余弦值 */
    /* 6. 算相位误差（浮点数运算） */
    pmsm_mc_param.delta_theta_pll = sin * cos_pll - cos * sin_pll;    /* 相位误差=sin(实际角-PLL角) */
    /* 7. 积分相位误差（PI控制器的积分项） */
    pmsm_mc_param.pll_sum += pmsm_mc_param.delta_theta_pll;    /* 相位误差累加为积分项 */
    /* 8. PI控制器计算角速度 */
    pmsm_mc_param.omega_pll = 
        SpeedPllKp * pmsm_mc_param.delta_theta_pll + 
        SpeedPllKi * pmsm_mc_param.pll_sum;
    /* 9. 更新PLL角度（浮点数积分） */
    pmsm_mc_param.theta_pll += pmsm_mc_param.omega_pll * OmegaToTheta;
    /* 10. 角度归一化（防止溢出，可选） */
    if (pmsm_mc_param.theta_pll > ANGLE_2PI) 
    {
        pmsm_mc_param.theta_pll -= ANGLE_2PI;
    } 
    else if (pmsm_mc_param.theta_pll < 0) 
    {
        pmsm_mc_param.theta_pll += ANGLE_2PI;
    }
    /* 11. 低通滤波输出角速度（一阶滤波，滤波系数0.005，时间常数约200个环路周期） */
    pmsm_mc_param.omega_pll_filter += 0.005f * (pmsm_mc_param.omega_pll - pmsm_mc_param.omega_pll_filter);
}

/***************************************** 文件结束 *********************************************/
