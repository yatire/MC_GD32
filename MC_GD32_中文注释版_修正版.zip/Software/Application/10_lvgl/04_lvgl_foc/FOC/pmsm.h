/*
*******************************************************************************************************
*
* 文件名称 : pmsm.h
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : PMSM(永磁同步电机)驱动头文件
*
*******************************************************************************************************
*/
/* 防止头文件重复包含 */
#ifndef _PMSM_H_
#define _PMSM_H_

/* 若按 C++ 编译环境编译 */
#ifdef __cplusplus
extern "C"{ /* 以 C 语言链接方式导出符号 */
#endif

/* 头文件包含 ------------------------------------------------------------------------------------*/
#include <stdint.h> /* 标准整型类型定义 */
#include "foc.h" /* FOC 核心算法及 foc 结构体定义 */
#include "pll_estimator.h" /* PLL 观测器及参数结构体定义 */
/* 宏定义 ------------------------------------------------------------------------------------------*/
/* 开环启动状态机状态枚举 */
typedef enum{
    ROTOR_LOCK = 0, /* 状态 0: 转子预定位 */
    RAMP_SPEED, /* 状态 1: 开环斜坡加速 */
    OL_HOLD, /* 状态 2: 开环保持 */
    WAIT_CLOSELOOP /* 状态 3: 等待切换闭环 */
}open_loop_state;

/* PMSM 电机控制参数及状态结构体 */
typedef struct{
	uint8_t openloop;           /* 0-闭环 1-开环 */
	uint8_t run_motor;          /* 0-停止 1-运行 */
	uint8_t change_mode; /* 模式切换请求标志: 1=需要执行开环/闭环切换, 切换完成后清零 */
    uint8_t sensor; /* 位置传感器选择: 0=PLL 无感观测器, 1=霍尔传感器 */

    uint32_t lock_counter;      /* 转子锁定时间折算的循环计数值 */
    uint32_t hold_counter;      /* 开环保持时间折算的循环计数值 */
	/* 转子预定位时间 */
	uint32_t startup_lock_count;    /* 转子锁定计数器 */
	uint32_t openloop_hold_count;   /* 开环保持计数器 */
	/* 开环启动斜坡 */
	float startup_ramp;         /* 开环速度斜坡累加值(rad/控制周期) */

    float max_phase_voltage; /* 最大相电压(供 PLL 观测器估算反电动势使用) */

    float vel_input; /* 速度给定输入(目标电角速度) */
    float vel_ref; /* 斜坡限幅后的速度参考值 */
    float vel_diff; /* 速度给定与参考之差(用于斜坡限速判断) */
    float actual_speed; /* 实际转速(电角速度, 来自观测器或霍尔测速) */

    float id_ref; /* d 轴电流给定(通常为 0) */
    float iq_ref; /* q 轴电流给定(电流环参考值) */

    float hall_speed; /* 霍尔传感器测得的转速 */

    float open_loop_current; /* 开环启动电流给定(iq 参考值) */

    float end_speed_rads_elec_counter; /* 开环结束电角速度对应的角度增量(rad/控制周期, 斜坡目标值) */
    float openloop_rampspeed_inc; /* 开环斜坡每控制周期递增量 */

    uint32_t speed_loop_count; /* 速度环分频计数器(计满 SPEED_LOOP_CYCLE 执行一次速度环) */

	float end_speed; /* 开环结束电角速度(切换闭环时的初始速度参考) */

    /* 速度 PLL 观测器相关变量 */
    float hall_theta_inc; /* 霍尔角度增量 */
    float hall_theta; /* 霍尔传感器角度(电角度) */
    float theta_pll; /* PLL 输出的转子电角度 */
    float omega_pll; /* PLL 输出的电角速度 */
    float omega_pll_filter; /* PLL 电角速度滤波值 */
    float pll_sum; /* PLL 累加器 */
    float delta_theta_pll; /* PLL 角度差(角度误差) */

    open_loop_state ol_state; /* 开环启动状态机当前状态 */

}pmsm_mc_t;



/* 变量定义 ----------------------------------------------------------------------------------------*/
extern pmsm_foc_t pmsm_foc_param; /* FOC 状态变量结构体(电流/电压/角度等, 定义见 foc.h) */
extern pmsm_mc_t pmsm_mc_param; /* PMSM 电机控制参数及状态结构体 */
extern mcParam_PLLEstimator mcApp_EstimParam;; /* PLL 观测器参数结构体(定义见 pll_estimator.h) */

/* 函数定义 ----------------------------------------------------------------------------------------*/
void pmsm_foc_init(void); /* PMSM FOC 初始化(计算启动参数并初始化观测器) */
void pmsm_foc_run(void); /* FOC 主循环函数(每个控制周期调用一次) */


/* 若按 C++ 编译环境编译 */
#ifdef __cplusplus
extern "C"{ /* 以 C 语言链接方式导出符号(原代码为历史遗留写法, 此处本应为右花括号) */
#endif

#endif /* _PMSM_H_ */

/***************************************** 文件结束 *********************************************/
