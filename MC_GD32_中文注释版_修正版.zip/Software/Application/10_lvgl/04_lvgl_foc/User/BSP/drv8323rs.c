/*
*******************************************************************************************************
*
* 文件名称 : drv8323rs.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : DRV8323RS栅极驱动器SPI驱动：寄存器读写/故障检查/初始化配置
*
*******************************************************************************************************
*/

/*
    版权所有 (c) 2023, 德州仪器(Texas Instruments Incorporated)

    在满足以下条件的前提下，允许以源代码和二进制形式对本软件进行再发布与使用(无论是否修改)：

    *  以源代码形式再发布时，必须保留上述版权声明、本条件列表及以下免责声明。

    *  以二进制形式再发布时，必须在随附的文档和/或其他分发材料中重现上述版权声明、
       本条件列表及以下免责声明。

    *  未经事先书面许可，不得使用德州仪器(Texas Instruments Incorporated)或其贡献者的名义
       为本软件的衍生产品进行背书或推广。

    本软件由版权持有人和贡献者"按原样"提供，不提供任何明示或默示的保证，包括但不限于对
    适销性和特定用途适用性的默示保证。在任何情况下，无论因何原因产生或基于何种责任理论，
    无论是合同责任、严格责任还是侵权责任(包括过失或其他)，版权持有人或贡献者均不对任何直接
    的、间接的、偶然的、特殊的、惩罚性的或后果性的损害(包括但不限于替代商品或服务的采购、
    使用、数据或利润损失、或业务中断)承担责任，即使已被告知可能发生此类损害。
*/
#include "drv8323rs.h" /* DRV8323RS寄存器地址/位域定义与控制引脚宏 */
#include "systick.h" /* SysTick毫秒延时函数 */
#include "spi.h" /* SPI0初始化与全双工收发接口 */

/**
 * @brief 保存DRV8323RS可设置的增益值查找表
 */
int8_t drvGain[DRV8323RS_CSA_GAIN_MAX_VALUES] = { 5, 10, 20, 40};

/* DRV8323RS初始化：配置CS/ENABLE/CAL控制引脚与SPI0，先禁用再使能以复位芯片寄存器并清除故障， */
/* 设置VDS过流监视阈值、过流锁断模式与CSA增益，最后读回Gate_Drive_HS寄存器校验SPI通信，异常则死循环 */
void DRV8323RS_init(void)
{
    /* 以下3个故障状态变量已注释停用 */
/*    uint16_t Fault_Status_1 = 0; */
/*    uint16_t VGS_Status_1 = 0; */
/*    uint16_t ocp_reg_data = 0; */
    uint16_t Gate_Drive_HS = 0; /* 高边栅极驱动寄存器读回值，用于校验SPI通信 */
    
    rcu_periph_clock_enable(SPI_CS_GPIO_CLK); /* 使能片选(SPI_CS)引脚端口时钟 */
    rcu_periph_clock_enable(ENABLE_GPIO_CLK); /* 使能ENABLE引脚端口时钟 */
    rcu_periph_clock_enable(CAL_GPIO_CLK); /* 使能CAL引脚端口时钟 */
    
    spi0_init(); /* 初始化SPI0，用于访问DRV8323RS寄存器 */
    
    gpio_init(SPI_CS_GPIO_PORT, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ,SPI_CS_GPIO_PIN); /* 片选(SPI_CS)引脚推挽输出 */
    gpio_init(ENABLE_GPIO_PORT, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ,ENABLE_GPIO_PIN); /* 使能(ENABLE)引脚推挽输出 */
    gpio_init(CAL_GPIO_PORT, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ,CAL_GPIO_PIN); /* 校准(CAL)引脚推挽输出 */

    gpio_bit_write(ENABLE_GPIO_PORT,ENABLE_GPIO_PIN,RESET); /* 先拉低ENABLE引脚，禁用DRV8323RS */
    gpio_bit_write(SPI_CS_GPIO_PORT,SPI_CS_GPIO_PIN,SET); /* 拉高片选，SPI总线空闲 */
    gpio_bit_write(CAL_GPIO_PORT,CAL_GPIO_PIN,SET); /* 拉高CAL(校准)引脚 */
    systick_delay(2); /* 延时2ms，保持CAL高电平 */
    gpio_bit_write(CAL_GPIO_PORT,CAL_GPIO_PIN,RESET); /* 拉低CAL引脚 */
    
    DRV8323RS_disable(); /* 先禁用DRV8323RS，使其休眠并复位全部寄存器 */
    DRV8323RS_enable(); /* 再使能DRV8323RS，寄存器恢复默认配置 */

    DRV8323RS_clearFaults(); /* 清除所有已锁存的故障标志 */
    
    /* Gate_Drive_HS寄存器默认值应为0x3FF */
    Gate_Drive_HS = DRV8323RS_spiRead(DRV8323RS_REG_ADDR_GATE_DRIVE_HS); /* 读回Gate_Drive_HS寄存器默认值 */
    DRV8323RS_setVdsLvl(DRV8323RS_OCP_CONTROL_VDS_LVL_0P130_V); /* 设置VDS过流监视阈值为0.130V */
    DRV8323RS_setOcpMode(DRV8323RS_OCP_CONTROL_OCP_MODE_LATCHED_SHUTDOWN); /* 设置过流处理模式为闭锁关断(故障后锁定关断输出) */
    DRV8323RS_setCsaGain(DRV8323RS_CSA_CONTROL_CSA_GAIN_10VPV); /* 设置电流检测放大器(CSA)增益为10V/V */
    
    if(Gate_Drive_HS != 0x3FF) /* 校验读回值是否等于默认值0x3FF，判断SPI通信是否正常 */
    {
        while(1); /* SPI通信异常，死循环停机排查 */
    }
}

/* 组装16位SPI数据字：位15命令+位14-11寄存器地址+位10-0数据 */
uint16_t DRV8323RS_createSPIDataWord(
                DRV8323RS_SPI_CMD wrCmd, DRV8323RS_REG_ADDR addr, uint16_t data)
{   
    /* 位15为命令位W0：写=0，读=1 */
    uint16_t dataWord = ((wrCmd) << DRV8323RS_SPI_CMD_OFS);

    /* 位14-11：寄存器地址 */
    dataWord |= ((addr << DRV8323RS_SPI_ADDR_OFS) & DRV8323RS_SPI_ADDR_MASK);

    /* 位10-0：11位数据 */
    dataWord |= (data & DRV8323RS_SPI_DATA_MASK);
    return  dataWord; /* 返回组装好的16位SPI数据字 */
}

/* 使能DRV8323RS并等待SPI就绪 */
void DRV8323RS_enable(void)
{
    /* 拉高ENABLE引脚，使能DRV8323RS */
    gpio_bit_write(ENABLE_GPIO_PORT,ENABLE_GPIO_PIN,SET);

    /* 等待DRV8323RS的SPI就绪所需的上电延时 */
    systick_delay(DRV8323RS_SPI_READY_DELAY_MS);
}

/* 禁用DRV8323RS使其进入休眠 */
void DRV8323RS_disable(void)
{
    /* 拉低ENABLE引脚，禁用DRV8323RS */
    gpio_bit_write(ENABLE_GPIO_PORT,ENABLE_GPIO_PIN,RESET);

    /* 使DRV8323RS进入休眠模式，休眠会复位其寄存器值。
    数据手册指出需至少等待1ms，才能确保其
    已进入休眠模式。 */
    systick_delay(DRV8323RS_TURNOFF_DELAY_MS);
}

/* 向指定寄存器写入数据 */
void DRV8323RS_spiWrite(DRV8323RS_REG_ADDR addr, uint16_t data)
{
    uint16_t dataWord = DRV8323RS_createSPIDataWord( /* 构造写命令数据字(命令+地址+数据) */
                                           DRV8323RS_SPI_CMD_WRITE, addr, data);
    gpio_bit_write(SPI_CS_GPIO_PORT,SPI_CS_GPIO_PIN,RESET); /* 拉低片选，选中DRV8323RS */
    spi0_transmit_receive_data(dataWord); /* SPI发送16位写数据 */
    gpio_bit_write(SPI_CS_GPIO_PORT,SPI_CS_GPIO_PIN,SET); /* 拉高片选，释放总线 */
}

/* 读取指定寄存器数据 */
uint16_t DRV8323RS_spiRead(DRV8323RS_REG_ADDR addr)
{
    uint16_t ret = 0; /* 存放读回数据 */
    uint16_t dataWord = DRV8323RS_createSPIDataWord( /* 构造读命令数据字(数据段填哑数据) */
                        DRV8323RS_SPI_CMD_READ, addr, DRV8323RS_SPI_DUMMY_DATA);
    gpio_bit_write(SPI_CS_GPIO_PORT,SPI_CS_GPIO_PIN,RESET); /* 拉低片选，选中DRV8323RS */
    ret = spi0_transmit_receive_data(dataWord); /* 发送读命令，接收寄存器数据 */
    gpio_bit_write(SPI_CS_GPIO_PORT,SPI_CS_GPIO_PIN,SET); /* 拉高片选，释放总线 */
    return ret & DRV8323RS_SPI_DATA_MASK; /* 屏蔽命令位与地址位，仅返回11位数据 */
}

/* 以读-改-写方式更新寄存器：仅修改mask指定位域，其余位保持原值 */
void DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR addr, uint32_t mask, uint16_t data)
{
    uint16_t dataValue; /* 读-改-写数据缓存 */
    dataValue = (uint16_t) DRV8323RS_spiRead(addr); /* 读出寄存器当前值 */
    dataValue &= ~(mask); /* 清除mask指定的位域 */
    dataValue |= data; /* 填入新的位域数据 */
    DRV8323RS_spiWrite(addr, dataValue); /* 将改好的值回写寄存器 */
}

/* 设置SPI寄存器锁定(LOCK位域)，防止寄存器配置被意外改写 */
void DRV8323RS_setSPIRegisterLock(DRV8323RS_GATE_DRIVE_HS_LOCK lock)
{
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_GATE_DRIVE_HS, /* 更新Gate_Drive_HS寄存器的LOCK位域 */
                                    DRV8323RS_GATE_DRIVE_HS_LOCK_MASK, 
                                    (lock << DRV8323RS_GATE_DRIVE_HS_LOCK_OFS));
}

/* 设置高边/低边管栅极峰值拉电流(开通驱动电流，IDRIVEP位域) */
void DRV8323RS_setPeakSourceGateCurr(
                                DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR hsPeakCurr, 
                                DRV8323RS_GATE_DRIVE_PEAK_SOURCE_CUR lsPeakCurr)
{
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_GATE_DRIVE_HS, /* 更新高边管峰值拉电流位域IDRIVEP_HS */
                        DRV8323RS_GATE_DRIVE_HS_IDRIVEP_HS_MASK, 
                        (hsPeakCurr << DRV8323RS_GATE_DRIVE_HS_IDRIVEP_HS_OFS));

    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_GATE_DRIVE_LS, /* 更新低边管峰值拉电流位域IDRIVEP_LS */
                        DRV8323RS_GATE_DRIVE_LS_IDRIVEP_LS_MASK, 
                        (lsPeakCurr << DRV8323RS_GATE_DRIVE_LS_IDRIVEP_LS_OFS));
}

/* 设置高边/低边管栅极峰值灌电流(关断驱动电流，IDRIVEN位域) */
void DRV8323RS_setPeakSinkGateCurr(
                                  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR hsPeakCurr, 
                                  DRV8323RS_GATE_DRIVE_PEAK_SINK_CUR lsPeakCurr)
{
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_GATE_DRIVE_HS, /* 更新高边管峰值灌电流位域IDRIVEN_HS */
                        DRV8323RS_GATE_DRIVE_HS_IDRIVEN_HS_MASK, 
                        (hsPeakCurr << DRV8323RS_GATE_DRIVE_HS_IDRIVEN_HS_OFS));

    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_GATE_DRIVE_LS, /* 更新低边管峰值灌电流位域IDRIVEN_LS */
                        DRV8323RS_GATE_DRIVE_LS_IDRIVEN_LS_MASK, 
                        (lsPeakCurr << DRV8323RS_GATE_DRIVE_LS_IDRIVEN_LS_OFS));
}

/* 设置栅极驱动峰值电流维持时间(TDRIVE位域) */
void DRV8323RS_setPeakGateCurrTime(DRV8323RS_GATE_DRIVE_PEAK_CUR_TIME tdrive)
{
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_GATE_DRIVE_LS, /* 更新TDRIVE位域(栅驱峰值电流时间) */
                        DRV8323RS_GATE_DRIVE_LS_TDRIVE_MASK, 
                        (tdrive << DRV8323RS_GATE_DRIVE_LS_TDRIVE_OFS));
}

/* 设置PWM输入模式(PWM_MODE位域：6PWM/3PWM/1PWM等) */
void DRV8323RS_setPwmMode(DRV8323RS_DRIVER_CONTROL_PWM_MODE pwmMode)
{
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_DRIVER_CONTROL, /* 更新DRIVER_CONTROL寄存器的PWM_MODE位域 */
                            DRV8323RS_DRIVER_CONTROL_PWM_MODE_MASK, 
                            (pwmMode << DRV8323RS_DRIVER_CONTROL_PWM_MODE_OFS));
}

/* 设置VDS过流监视阈值(VDS_LVL位域) */
void DRV8323RS_setVdsLvl(DRV8323RS_OCP_CONTROL_VDS_LVL vdsLvl)
{
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_OCP_CONTROL, /* 更新OCP_CONTROL寄存器的VDS_LVL位域 */
                                DRV8323RS_OCP_CONTROL_VDS_LVL_MASK, 
                                (vdsLvl << DRV8323RS_OCP_CONTROL_VDS_LVL_OFS));
}

/* 设置VDS过流故障去毛刺时间(OCP_DEG位域)，防止误触发 */
void DRV8323RS_setOcpDeg(DRV8323RS_OCP_CONTROL_OCP_DEG ocpDeg)
{
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_OCP_CONTROL, /* 更新OCP_CONTROL寄存器的OCP_DEG位域 */
                                DRV8323RS_OCP_CONTROL_OCP_DEG_MASK, 
                                (ocpDeg << DRV8323RS_OCP_CONTROL_OCP_DEG_OFS));
}

/* 设置过流处理模式(OCP_MODE位域四档:锁存关断/自动重试/仅报告/禁用) */
void DRV8323RS_setOcpMode(DRV8323RS_OCP_CONTROL_OCP_MODE ocpMode)
{
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_OCP_CONTROL, /* 更新OCP_CONTROL寄存器的OCP_MODE位域 */
                               DRV8323RS_OCP_CONTROL_OCP_MODE_MASK, 
                               (ocpMode << DRV8323RS_OCP_CONTROL_OCP_MODE_OFS));
}

/* 设置栅极驱动死区时间(DEAD_TIME位域)，防止上下管直通 */
void DRV8323RS_setDeadtime(DRV8323RS_OCP_CONTROL_DEADTIME deadtime)
{
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_OCP_CONTROL, /* 更新OCP_CONTROL寄存器的DEAD_TIME位域 */
                             DRV8323RS_OCP_CONTROL_DEAD_TIME_MASK, 
                             (deadtime << DRV8323RS_OCP_CONTROL_DEAD_TIME_OFS));
}

/* 设置过流故障后重试等待时间(TRETRY位域) */
void DRV8323RS_setTretry(DRV8323RS_OCP_CONTROL_TRETRY tretry)
{
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_OCP_CONTROL, /* 更新OCP_CONTROL寄存器的TRETRY位域 */
                                  DRV8323RS_OCP_CONTROL_TRETRY_MASK, 
                                  (tretry << DRV8323RS_OCP_CONTROL_TRETRY_OFS));
}

/* 设置电流检测过流阈值(SEN_LVL位域) */
void DRV8323RS_setSenLvl(DRV8323RS_CSA_CONTROL_SEN_LVL senLvl)
{
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_CSA_CONTROL, /* 更新CSA_CONTROL寄存器的SEN_LVL位域 */
                                 DRV8323RS_CSA_CONTROL_SEN_LVL_MASK, 
                                 (senLvl << DRV8323RS_CSA_CONTROL_SEN_LVL_OFS));
}

/* 设置是否禁用电流检测过流保护(DIS_SEN位域) */
void DRV8323RS_setDisSen(DRV8323RS_CSA_CONTROL_DIS_SEN disSen)
{
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_CSA_CONTROL, /* 更新CSA_CONTROL寄存器的DIS_SEN位域 */
                                 DRV8323RS_CSA_CONTROL_DIS_SEN_MASK,
                                 (disSen << DRV8323RS_CSA_CONTROL_DIS_SEN_OFS));
}

/* 设置电流检测放大器(CSA)增益(CSA_GAIN位域：5/10/20/40V/V) */
void DRV8323RS_setCsaGain(DRV8323RS_CSA_CONTROL_CSA_GAIN csaGain)
{
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_CSA_CONTROL, /* 更新CSA_CONTROL寄存器的CSA_GAIN位域 */
                                DRV8323RS_CSA_CONTROL_CSA_GAIN_MASK,
                               (csaGain << DRV8323RS_CSA_CONTROL_CSA_GAIN_OFS));
}

/* 设置低边过流检测参考点(LS_REF位域) */
void DRV8323RS_setLsRef(DRV8323RS_CSA_CONTROL_LS_REF lsRef)
{
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_CSA_CONTROL, /* 更新CSA_CONTROL寄存器的LS_REF位域 */
                                   DRV8323RS_CSA_CONTROL_LS_REF_MASK,
                                   (lsRef << DRV8323RS_CSA_CONTROL_LS_REF_OFS));
}

/* 设置CSA参考电压分压(VREF_DIV位域) */
void DRV8323RS_setVrefDiv(DRV8323RS_CSA_CONTROL_VREF_DIV vrefDiv)
{
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_CSA_CONTROL, /* 更新CSA_CONTROL寄存器的VREF_DIV位域 */
                               DRV8323RS_CSA_CONTROL_VREF_DIV_MASK,
                               (vrefDiv << DRV8323RS_CSA_CONTROL_VREF_DIV_OFS));
}

/* 设置CSA正相输入源(CSA_FET位域：功率管导通压降/外部采样电阻) */
void DRV8323RS_setCsaFet(DRV8323RS_CSA_CONTROL_CSA_FET csaFet)
{
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_CSA_CONTROL, /* 更新CSA_CONTROL寄存器的CSA_FET位域 */
                                 DRV8323RS_CSA_CONTROL_CSA_FET_MASK,
                                 (csaFet << DRV8323RS_CSA_CONTROL_CSA_FET_OFS));
}

/* 以下5个函数为基于TI IQmath定点库的相电流/母线电压读取接口，已注释停用，保留原始代码备查 */
/*_iq DRV8323RS_getIA(void) */
/*{ */
/*    _iq15 adcVal = HAL_getADCVoltage(handle->isena); */
/*    _iq15 offset = _IQdiv2(HAL_getADCRefVoltage(handle->isena)); */
/*    return _IQ15toIQ(_IQ15mpy(adcVal - offset, handle->iSf)); */
/*} */

/*_iq DRV8323RS_getIB(void) */
/*{ */
/*    _iq15 adcVal = HAL_getADCVoltage(handle->isenb); */
/*    _iq15 offset = _IQdiv2(HAL_getADCRefVoltage(handle->isenb)); */
/*    return _IQ15toIQ(_IQ15mpy(adcVal - offset, handle->iSf)); */
/*} */

/*_iq DRV8323RS_getIC(void) */
/*{ */
/*    _iq15 adcVal = HAL_getADCVoltage(handle->isenc); */
/*    _iq15 offset = _IQdiv2(HAL_getADCRefVoltage(handle->isenc)); */
/*    return _IQ15toIQ(_IQ15mpy(adcVal - offset, handle->iSf)); */
/*} */

/*_iq DRV8323RS_getVM(void) */
/*{ */
/*    _iq15 adcVal = (HAL_getADCVoltage(handle->vsenvm)); */
/*    return _IQ15toIQ(_IQ15mpy(adcVal, DRV8323RS_VOLTAGE_SF_IQ15)); */
/*} */

/*void DRV8323RS_setISf(DRV8323RS_CSA_CONTROL_CSA_GAIN  gain, _iq15 rshunt) */
/*{ */
/*    handle->iSf = _IQ15div(_IQ15(1), */
/*                               _IQ15mpy(_IQ15((int32_t)drvGain[gain]), rshunt)); */
/*} */

/* 查询是否发生故障(本工程未接nFAULT检测，恒返回无故障) */
bool DRV8323RS_isFaultOccurred(void)
{
/*    return HAL_getPWMFaultStatus(handle->nfault); */
    return 0; /* 本工程未读取nFAULT状态，恒返回无故障 */
}

/* 读取故障状态寄存器1/2，合并为32位故障状态字返回 */
uint32_t DRV8323RS_getFaults(void)
{
    uint32_t fault_status = 0; /* 32位故障状态字 */
    fault_status = DRV8323RS_spiRead(DRV8323RS_REG_ADDR_FAULT_STATUS_1); /* 读故障状态寄存器1 */
    fault_status <<= 16; /* 左移16位，寄存器1作高16位 */
    fault_status |= DRV8323RS_spiRead(DRV8323RS_REG_ADDR_FAULT_STATUS_2); /* 合并故障状态寄存器2为低16位 */
    
    return fault_status; /* 返回32位故障状态字 */
}

/* 清除DRV8323RS所有已锁存的故障 */
void DRV8323RS_clearFaults(void)
{
/*    HAL_clearPWMFault(handle->nfault); */
    /* 置位DRIVER_CONTROL寄存器的CLR_FLT位，清除全部故障 */
    DRV8323RS_spiUpdateRegister(DRV8323RS_REG_ADDR_DRIVER_CONTROL, 
                                DRV8323RS_DRIVER_CONTROL_CLR_FLT_MASK, 
                                (1 << DRV8323RS_DRIVER_CONTROL_CLR_FLT_OFS));
}
