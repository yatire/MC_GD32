/*
*******************************************************************************************************
*
* 文件名称 : eeprom.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 24C02-EEPROM驱动文件
* 
*******************************************************************************************************
*/



/* 头文件 -----------------------------------------------------------*/
#include "eeprom.h" /* 24C02 EEPROM驱动接口 */
#include "systick.h" /* 系统滴答延时接口 */


/* 宏定义 -----------------------------------------------------------*/


/* 变量 -------------------------------------------------------------*/


/* 函数声明 ---------------------------------------------------------*/
static void eeprom_page_write(uint8_t mem_addr,uint8_t *pbuffer, uint8_t num_byte_to_write); /* 页写入函数声明 */


/**
  * @brief 向EEPROM写入指定长度数据
  * @param mem_addr-存储器内部地址
  * @param pbuffer-待写入的数据
  * @param num_byte_to_write-数据长度
  * @retval	无
  */
void eeprom_write(uint8_t mem_addr,uint8_t *pbuffer, uint16_t num_byte_to_write)
{
	uint8_t num_of_page = 0, num_of_single = 0, addr = 0, count = 0; /* 整页页数、不满一页字节数、页内偏移地址、当前页剩余空间 */

	addr = mem_addr % EEPROM_PAGESIZE; /* 计算写入地址在一页内的偏移 */
	count = EEPROM_PAGESIZE - addr; /* 计算当前页剩余可写字节数 */
	num_of_page =  num_byte_to_write / EEPROM_PAGESIZE; /* 计算需要整页写入的页数 */
	num_of_single = num_byte_to_write % EEPROM_PAGESIZE; /* 计算剩余不足一页的字节数 */

	/* 写入地址和页对齐  */
	if(addr == 0) 
	{
		/* 写入数据长度小于页长度，直接按长度写 */
		if(num_of_page == 0) 
		{
			eeprom_page_write(mem_addr, pbuffer, num_of_single); /* 直接写入不满一页的数据 */
		}
		/* 写入数据长度大于页长度，先写满一页的，后写剩余的 */
		else  
		{
			while(num_of_page--) /* 循环写完整页数据 */
			{
				eeprom_page_write(mem_addr, pbuffer, EEPROM_PAGESIZE);  /* 写入一整页数据 */
				mem_addr +=  EEPROM_PAGESIZE; /* 存储器地址指向下一页 */
				pbuffer += EEPROM_PAGESIZE; /* 数据缓冲区指针指向下一页 */
			}

			if(num_of_single!=0) /* 剩余不足一页的数据 */
			{
				eeprom_page_write(mem_addr, pbuffer, num_of_single); /* 写入剩余数据 */
			}
		}
	}
	/* 写入地址和页不对齐  */
	else 
	{
		/* 待写入数据长度小于一页大小 */
		if(num_of_page== 0) 
		{
			eeprom_page_write(mem_addr, pbuffer, num_of_single); /* 数据不足一页,按剩余长度一次性写入 */
		}
		/* 待写入数据长度大于一页大小 */
		else
		{
			num_byte_to_write -= count; /* 先扣除当前页剩余空间可容纳的字节数 */
			num_of_page =  num_byte_to_write / EEPROM_PAGESIZE; /* 重新计算整页页数 */
			num_of_single = num_byte_to_write % EEPROM_PAGESIZE;	 /* 重新计算剩余不足一页的字节数 */

			if(count != 0) /* 当前页还有剩余空间 */
			{  
				eeprom_page_write(mem_addr, pbuffer, count); /* 先写满当前页的剩余空间 */
				mem_addr += count; /* 地址跳到下一页起始 */
				pbuffer += count; /* 数据指针跳过已写数据 */
			} 

			while(num_of_page--) /* 循环写完整页数据 */
			{
				eeprom_page_write(mem_addr, pbuffer, EEPROM_PAGESIZE); /* 写入一整页数据 */
				mem_addr +=  EEPROM_PAGESIZE; /* 存储器地址指向下一页 */
				pbuffer += EEPROM_PAGESIZE;   /* 数据缓冲区指针指向下一页 */
			}
			if(num_of_single != 0) /* 剩余不足一页的数据 */
			{
				eeprom_page_write(mem_addr, pbuffer, num_of_single);  /* 写入剩余数据 */
			}
		}
	}  
}

/**
  * @brief 从EEPROM读取指定长度数据
  * @param mem_addr-存储器内部地址
  * @param pbuffer-读取数据缓冲区
  * @param num_byte_to_read-数据长度
  * @retval	无
  */
void eeprom_read(uint8_t mem_addr,uint8_t *pbuffer, uint16_t num_byte_to_read)
{
	/* 随机读:先向EEPROM写入存储地址,重复起始后再读出数据 */
	i2c_mem_read(EEPROM_ADDRESS,mem_addr,I2C_MEMADD_8BIT,pbuffer,num_byte_to_read,1000);
}

/**
  * @brief 向EEPROM写入一页数据
  * @param mem_addr-存储器内部地址
  * @param pbuffer-待写入的数据
  * @param num_byte_to_write-数据长度
  * @retval	无
  * @note 数据长度不能超过EEPROM一页的大小
  */
static void eeprom_page_write(uint8_t mem_addr,uint8_t *pbuffer, uint8_t num_byte_to_write)
{
	/* 页写入:写入存储器地址后写入一页数据 */
	i2c_mem_write(EEPROM_ADDRESS,mem_addr,I2C_MEMADD_8BIT,pbuffer,num_byte_to_write,1000);
    systick_delay(5);
}


/***************************************** 文件结束 *********************************************/
