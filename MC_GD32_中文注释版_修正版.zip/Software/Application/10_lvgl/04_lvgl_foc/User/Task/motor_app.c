/*
*******************************************************************************************************
*
* 文件名称 : motor_app.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 电机控制主应用文件(LVGL界面版)
*
*******************************************************************************************************
*/

/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "motor_app.h"    /* 电机应用任务头文件(电机状态机定义) */
#include "adc_simple.h"    /* 简单ADC采样接口(NTC温度/母线电压/母线电流) */
#include "lcd.h"    /* LCD显示驱动 */
#include "uart.h"    /* 串口驱动(调试数据帧发送) */
#include "encoder.h"    /* 正交编码器旋钮与按键接口 */
#include "eeprom.h"    /* EEPROM(24C02)驱动 */
#include "drv8323rs.h"    /* DRV8323RS栅极驱动器(故障读取/清除) */
#include "led.h"    /* LED指示灯 */
#include "pmsm.h"    /* PMSM FOC算法接口 */
#include "userparms.h"    /* 用户参数配置(电机参数/PI参数) */

#include "ee_parameter.h"    /* EEPROM电机参数(额定转速/极对数/传感器类型) */

#include "mainwindow.h"    /* LVGL主窗口与UI事件定义 */
#include "lvgl.h"    /* LVGL图形库 */
#include "lv_port_disp_mcgd32.h"    /* LVGL显示移植层接口 */

/* 宏定义 ------------------------------------------------------------------------------------------*/

/* 变量定义 ----------------------------------------------------------------------------------------*/
motor_control_t motor1 = {0};    /* 电机控制结构体(状态机/ADC偏置/故障标志/运行数据) */
static uint32_t ia_sum = 0,ib_sum = 0,ic_sum = 0;    /* ADC标定期三相电流采样累加和 */

can_trasnmit_message_struct transmit_message;    /* CAN发送报文结构体 */

uint8_t eeprom_read_buf[32] = {0};    /* EEPROM读取数据缓冲区 */

extern uint8_t hall_state;    /* 移植遗留extern声明(本工程无此全局变量;实际霍尔状态为motor1.hall_state成员) */

/* 局部函数 -----------------------------------------------------------------------------------*/
static void motor_can_transmit(void);    /* CAN状态报文发送任务 */
static uint8_t motor_get_fault(void);    /* 查询电机故障状态 */
static void motor_clear_fault(void);    /* 清除电机故障标志 */

/* 全局函数 -----------------------------------------------------------------------------------*/

/**
  * @brief 电机应用初始化(LVGL/EEPROM/电机状态机)
  * @param 无
  * @retval 无
  */
void motor_app_init(void)
{
    lv_init();    /* LVGL图形库初始化 */
	lv_port_disp_init();    /* LVGL显示设备移植层初始化 */
    lvgl_main_app();    /* 创建LVGL主界面 */
    
    eeprom_load_parameter();    /* 从EEPROM恢复电机参数(转速/极对数/传感器类型) */
    
    motor1.state = INIT;    /* 状态机置为初始化状态 */
    motor1.start = 1;    /* 上电默认置启动标志 */
    motor1.rotor_lock_tick = 0;    /* 转子堵转检测计数清零 */
    motor1.rotor_lock_fault = 0;    /* 堵转故障标志清零 */
    motor1.hall_state_fault = 0;    /* 霍尔状态故障标志清零 */
    motor1.motor_sensor = motor_sensor;    /* 记录传感器类型(0-无感 1-霍尔) */

    motor_set_speed(motor_normal_spd);    /* 初始速度给定=EEPROM中的额定转速(rpm) */
    
    transmit_message.tx_sfid = 0x7ab;    /* 标准帧ID:0x7AB */
    transmit_message.tx_efid = 0x00;    /* 扩展帧ID:不使用 */
    transmit_message.tx_ft = CAN_FT_DATA;    /* 帧类型:数据帧 */
    transmit_message.tx_ff = CAN_FF_STANDARD;    /* 帧格式:标准帧 */
    transmit_message.tx_dlen = 8;    /* 数据长度:8字节 */
    
    /* 预填测试数据0xA1~0xA7,实际发送时被实时数据覆盖 */
    transmit_message.tx_data[0] = 0x00;
    transmit_message.tx_data[1] = 0xA1;
    transmit_message.tx_data[2] = 0xA2;
    transmit_message.tx_data[3] = 0xA3;
    transmit_message.tx_data[4] = 0xA4;
    transmit_message.tx_data[5] = 0xA5;
    transmit_message.tx_data[6] = 0xA6;
    transmit_message.tx_data[7] = 0xA7;
    
}

/**
  * @brief 获取电机实时数据(整体拷贝电机控制结构体)
  * @param 无
  * @retval 无
  */
void motor_get_data(motor_control_t *info)
{
    memcpy(info,&motor1,sizeof(motor_control_t));    /* 整体拷贝电机控制结构体给调用者 */
}

/**
  * @brief 设置电机速度给定
  * @param 无
  * @retval 无
  */
void motor_set_speed(uint16_t speed)
{
    if(speed > motor_normal_spd)    /* 给定超过额定转速 */
    {
        motor1.speed_input = motor_normal_spd;    /* 限幅为额定转速(rpm) */
    }
    else
    {
        motor1.speed_input = speed;    /* 保存速度给定(rpm) */
    }
}

/**
  * @brief 电机启动
  * @param 无
  * @retval 无
  */
void motor_start(void)
{
    if(motor1.state == STOP)    /* 停机状态下启动 */
    {
        if(motor_get_fault())    /* 存在故障 */
        {
            motor_forced_stop();    /* 强制停机并进入故障状态 */
        }
        else
        {
            motor_pwm_enable();    /* 使能PWM输出 */
            pmsm_foc_init();    /* 初始化FOC参数 */
            motor1.state = RUN;    /* 转入运行状态 */
            motor1.start = 1;    /* 置启动标志 */
        }
    }
    else if(motor1.state == FAULT)    /* 故障状态下尝试恢复 */
    {
        uint32_t drv8323_fault_status = 0;    /* 栅极驱动器故障状态 */
        motor_clear_fault();    /* 清电机侧故障标志 */
        drv8323_fault_status = DRV8323RS_getFaults();    /* 读取DRV8323RS故障寄存器 */
        DRV8323RS_clearFaults();    /* 清除DRV8323RS故障 */
        drv8323_fault_status = DRV8323RS_getFaults();    /* 复查故障是否已清除 */
        if((drv8323_fault_status == 0) && (motor_get_fault() == 0))    /* 驱动器与电机侧故障均已清除 */
        {
            led_off(LED_FAULT);    /* 熄灭故障指示灯 */
            motor1.state = STOP;    /* 转入停机状态 */
            motor_timer_restart();    /* 重启电机定时器 */
        }
    }
}

/**
  * @brief 电机停止
  * @param 无
  * @retval 无
  */
void motor_stop(void)
{
    motor1.start = 0;    /* 清启动标志 */
    pmsm_mc_param.run_motor = 0;    /* FOC停止运行标志 */
    if(motor1.state == RUN)    /* 运行状态 */
    {
        motor_pwm_disable();    /* 封锁PWM输出 */
        motor1.state = STOP;    /* 转入停机状态 */
        motor1.speed_rpm = 0;    /* 转速显示清零 */
    }
}

/**
  * @brief 电机强制停机(封锁PWM输出并进入故障状态)
  * @param 无
  * @retval 无
  * @note
  */
void motor_forced_stop(void)
{
    motor_pwm_pin_disable();    /* PWM引脚切为GPIO,彻底封锁输出 */
    pmsm_mc_param.run_motor = 0;    /* FOC停止运行标志 */
    motor1.state = FAULT;    /* 转入故障状态 */
    motor1.start = 0;    /* 清启动标志 */
}


/**
  * @brief 电机任务10ms
  * @param 无
  * @retval 无
  */
void motor_app_task10ms(void)
{
    encoder_code_t encoder_code = ENCODER_NONE;    /* 编码器旋钮事件:无/增/减 */
    uint8_t key_code = KEY_NONE;    /* 按键事件码 */
    
    motor1.ntc_adc = adc_read_data(ADC_CH_NTC);    /* 读取NTC温度通道ADC滤波值 */
    motor1.vdc_adc = adc_read_data(ADC_CH_VDC);    /* 读取母线电压通道ADC滤波值 */
    motor1.idc_adc = adc_read_data(ADC_CHIDC_AVER);    /* 读取母线电流通道ADC平均值 */
    motor1.mosfet_temp = calculate_temperature_float(motor1.ntc_adc);    /* NTC阻值换算MOS管温度(℃) */
    motor1.vdc = motor1.vdc_adc * ADC_TO_VDC_COEF;    /* ADC值换算母线电压(V) */
    if(motor1.idc_adc > (ADC_FULL_BIT / 2))    /* 母线电流采样以ADC中点(2048)为零点 */
        motor1.idc = (motor1.idc_adc - 2048) * ADC_TO_CURRENT_COEF;    /* 中点以上:换算为正向母线电流(A) */
    else
        motor1.idc = 0;    /* 中点以下:母线电流按0处理 */
    if(pmsm_mc_param.run_motor == 1)    /* 电机运行中 */
    {
        /* 电角速度换算机械转速(rpm):×60/(2π×极对数) */
        motor1.speed_rpm = pmsm_mc_param.actual_speed * ((float)60 / ANGLE_2PI / MOTOR_NOPOLESPAIRS);
    }
    else
    {
        motor1.speed_rpm = 0;    /* 停机时转速显示清零 */
    }
    
    encoder_code = encoder_get();    /* 读取编码器旋钮转动事件 */
    key_scan();    /* 按键状态扫描(含消抖) */
    key_code = key_get();    /* 从按键FIFO取出一个按键事件 */
    if(encoder_code == ENCODER_INC)    /* 编码器旋钮增量动作 */
    {
		ui_event_send(KEY_EVENT_ENC0_INC);    /* 通知UI:编码器正转 */
    }
    else if(encoder_code == ENCODER_DEC)    /* 编码器旋钮减量动作 */
    {
		ui_event_send(KEY_EVENT_ENC0_DEC);    /* 通知UI:编码器反转 */
    }
    if(key_code == KEY_0_RELEASE)    /* KEY0短按释放 */
    {
        ui_event_send(KEY_EVENT_KEY0_REL);    /* 通知UI:KEY0释放 */
    }
    else if(key_code == KEY_0_LONG_PRESS)    /* KEY0长按 */
    {
		ui_event_send(KEY_EVENT_KEY0_LONG_PRE);    /* 通知UI:KEY0长按 */
    }
    motor1.motor_sensor = motor_sensor;    /* 同步传感器类型(可能被UI修改) */
    pmsm_mc_param.vel_input = (float)motor1.speed_input*RPM_TO_RADS*motor_pole;    /* 速度给定(rpm)换算为电角速度 */
    
    lv_tick_inc(10);    /* LVGL时基心跳+10ms */
    lv_task_handler();    /* LVGL任务轮询处理 */
    motor_can_transmit();    /* 发送电机状态CAN报文 */
}

/**
  * @brief 电机任务100ms
  * @param 无
  * @retval 无
  */
void motor_app_task100ms(void)
{
    ui_monitor_update();    /* 刷新LVGL监控页数据显示 */
}

/**
  * @brief 电机任务500ms
  * @param 无
  * @retval 无
  */
void motor_app_task500ms(void)
{

}

/**
  * @brief 电机任务1s
  * @param 无
  * @retval 无
  */
void motor_app_task1s(void)
{

}

/**
  * @brief 电机空闲任务
  * @param 无
  * @retval 无
  */
void motor_app_idle(void)
{
    adc_task();    /* 空闲时执行ADC后台滤波任务 */
}

/**
  * @brief 电机中断服务函数,在PWM中断中调用
  * @param 无
  * @retval 无
  */
void motor_app_isr(void)
{
    float temp1 = 0;    /* 调试帧临时变量1 */
    float temp2 = 0;    /* 调试帧临时变量2 */
    float temp3 = 0;    /* 调试帧临时变量3 */
    uint8_t uart_data[16] = {0};    /* 串口调试数据帧缓冲(16字节) */
    
    switch(motor1.state)    /* 电机主状态机 */
    {
        case INIT:    /* 初始化完成:转入ADC标定 */
            motor1.state = ADC_CAL;    /* 转入ADC标定状态 */
            break;
        case ADC_CAL:    /* ADC零点标定:采样求三相零点偏置 */
            if(motor1.adc_cal_cnt < ADC_CAL_COUNT)    /* 未满标定采样次数(1024次) */
            {
                motor1.adc_cal_cnt++;    /* 采样计数加1 */
                motor1.adc_ia = adc_inserted_data_read(ADC0, IU_INSERTED_CHANNEL);    /* 读取A相电流ADC注入组值 */
                motor1.adc_ib = adc_inserted_data_read(ADC0, IV_INSERTED_CHANNEL);    /* 读取B相电流ADC注入组值 */
                motor1.adc_ic = adc_inserted_data_read(ADC0, IW_INSERTED_CHANNEL);    /* 读取C相电流ADC注入组值 */
                
                ia_sum += motor1.adc_ia;    /* 累加A相采样值 */
                ib_sum += motor1.adc_ib;    /* 累加B相采样值 */
                ic_sum += motor1.adc_ic;    /* 累加C相采样值 */
            }
            else
            {
                motor1.ia_offset = ia_sum / motor1.adc_cal_cnt;    /* A相电流零点偏置(均值) */
                motor1.ib_offset = ib_sum / motor1.adc_cal_cnt;    /* B相电流零点偏置(均值) */
                motor1.ic_offset = ic_sum / motor1.adc_cal_cnt;    /* C相电流零点偏置(均值) */
                motor1.state = START_DELAY;    /* 转入启动延时状态 */
            }
            break;
        case START_DELAY:    /* 启动延时:上电稳定等待(约2秒) */
            if(motor1.start_delay_tick < START_DELAY_TICK)    /* 延时未到(START_DELAY_TICK个周期) */
            {
                motor1.start_delay_tick++;    /* 延时计数累加 */
            }
            else if(1U == motor1.start)    /* 延时结束且启动标志有效 */
            {
                motor1.state = RUN;    /* 转入运行状态 */
                motor_pwm_enable();    /* 使能三相PWM输出 */
            }
            else    /* 未请求启动 */
            {
                motor1.state = STOP;    /* 转入停机状态 */
            }
            break;
        case STOP:    /* 停机状态:等待启动命令 */
            break;
        case RUN:    /* 闭环运行状态 */
            {
                motor1.rotor_lock_tick++;    /* 堵转检测计数累加(霍尔中断清零) */
                if(motor1.rotor_lock_tick >= ROTOR_LOCK_CHECK_TICK)    /* 超过2秒未清零:转子堵转 */
                {
                    motor1.rotor_lock_fault = 1;    /* 置堵转故障标志 */
                }
                if(motor_get_fault())    /* 检测到故障 */
                {
                    motor_forced_stop();    /* 强制停机进入故障状态 */
                    break;
                }
                /* 读取ADC注入组数据寄存器 */
                motor1.adc_ia = adc_inserted_data_read(ADC0, IU_INSERTED_CHANNEL);    /* 读取A相电流ADC原始值 */
                motor1.adc_ib = adc_inserted_data_read(ADC0, IV_INSERTED_CHANNEL);    /* 读取B相电流ADC原始值 */
                motor1.adc_ic = adc_inserted_data_read(ADC0, IW_INSERTED_CHANNEL);    /* 读取C相电流ADC原始值 */
                
                switch(pmsm_foc_param.sector)    /* 按SVPWM扇区重构三相电流(实测两相+KCL算第三相) */
                {
                    case 1:    /* 扇区1/6:采样B、C两相 */
                    case 6:
                        /* B相ADC值减零点偏置后换算为实际电流(A) */
                        pmsm_foc_param.ib = ((float)motor1.adc_ib - motor1.ib_offset) * ADC_TO_CURRENT_COEF;
                        /* C相ADC值减零点偏置后换算为实际电流(A) */
                        pmsm_foc_param.ic = ((float)motor1.adc_ic - motor1.ic_offset) * ADC_TO_CURRENT_COEF;
                        /* A相电流由KCL重构:ia = -ib - ic */
                        pmsm_foc_param.ia = 0 - pmsm_foc_param.ib - pmsm_foc_param.ic;
                        break;
                    case 2:    /* 扇区2/3:采样A、C两相 */
                    case 3:
                        /* A相ADC值减零点偏置后换算为实际电流(A) */
                        pmsm_foc_param.ia = ((float)motor1.adc_ia - motor1.ia_offset) * ADC_TO_CURRENT_COEF;
                        /* C相ADC值减零点偏置后换算为实际电流(A) */
                        pmsm_foc_param.ic = ((float)motor1.adc_ic - motor1.ic_offset) * ADC_TO_CURRENT_COEF;
                        /* B相电流由KCL重构:ib = -ia - ic */
                        pmsm_foc_param.ib = 0 - pmsm_foc_param.ia - pmsm_foc_param.ic;
                        break;
                    case 4:    /* 扇区4/5:采样A、B两相 */
                    case 5:
                        /* A相ADC值减零点偏置后换算为实际电流(A) */
                        pmsm_foc_param.ia = ((float)motor1.adc_ia - motor1.ia_offset) * ADC_TO_CURRENT_COEF;
                        /* B相ADC值减零点偏置后换算为实际电流(A) */
                        pmsm_foc_param.ib = ((float)motor1.adc_ib - motor1.ib_offset) * ADC_TO_CURRENT_COEF;
                        /* C相电流由KCL重构:ic = -ia - ib */
                        pmsm_foc_param.ic = 0 - pmsm_foc_param.ia - pmsm_foc_param.ib;
                        break;
                    default:    /* 非法扇区:不做处理 */
                        break;
                }
                pmsm_mc_param.max_phase_voltage = motor1.vdc * ONE_BY_SQRT3;    /* 最大相电压=母线电压/√3(SVPWM限幅用) */
                
                /* 霍尔电角度按每周期增量积分(增量来自霍尔测速) */
                pmsm_mc_param.hall_theta = pmsm_mc_param.hall_theta + pmsm_mc_param.hall_theta_inc;
                if(pmsm_mc_param.hall_theta < 0.0f)    /* 角度归一化:小于0 */
                {
                    pmsm_mc_param.hall_theta += ANGLE_2PI;    /* 加2π回卷 */
                }
                else if(pmsm_mc_param.hall_theta > ANGLE_2PI)    /* 角度归一化:大于2π */
                {
                    pmsm_mc_param.hall_theta -= ANGLE_2PI;    /* 减2π回卷 */
                }
                
                pmsm_foc_run();    /* 执行FOC运算 */
                
                temp1 = (float)pmsm_foc_param.ia;    /* A相电流存入临时变量 */
                memcpy(&uart_data[0],&temp1,4);    /* float按4字节复制到帧偏移0 */
                temp2 = (float)pmsm_foc_param.ib;    /* B相电流存入临时变量 */
                memcpy(&uart_data[4],&temp2,4);    /* 复制到帧偏移4 */
                temp3 = (float)pmsm_foc_param.ic;    /* C相电流存入临时变量 */
                memcpy(&uart_data[8],&temp3,4);    /* 复制到帧偏移8 */
                uart_data[sizeof(uart_data)-2] = 0x80;    /* 帧尾第1字节0x80 */
                uart_data[sizeof(uart_data)-1] = 0x7f;    /* 帧尾第2字节0x7f */
                usart_send_data(uart_data,sizeof(uart_data));    /* 串口发送16字节调试帧(上位机绘图用) */
                
                /* 将FOC输出的三相占空比写入PWM定时器 */
                motor_pwm_set_duty(pmsm_foc_param.pwma,pmsm_foc_param.pwmb,pmsm_foc_param.pwmc);
            }
            break;
        case FAULT:    /* 故障状态:停机等待处理 */
            break;
        default:    /* 未知状态:不做处理 */
            break;
    }
}

/* 局部函数 -----------------------------------------------------------------------------------*/

/**
  * @brief 电机CAN报文发送任务
  * @param 无
  * @retval 无
  */
static void motor_can_transmit(void)
{
    static uint8_t status1_counter = 0;    /* 报文滚动计数器(发送字节7高4位) */
    uint8_t mosfet_temperature = 0;    /* MOS管温度编码值(偏移+40℃) */
    if(motor1.mosfet_temp < -40)    /* 温度低于-40℃按最小值编码 */
        mosfet_temperature = 0;
    else
        mosfet_temperature = motor1.mosfet_temp + 40;    /* 温度+40℃偏移映射到0~255 */
    
    transmit_message.tx_data[0] = mosfet_temperature;    /* 字节0:MOS管温度(+40℃偏移编码) */
    transmit_message.tx_data[1] = (uint8_t)(motor1.idc * 10);    /* 字节1:母线电流×10(0.1A分辨率) */
    transmit_message.tx_data[2] = (uint8_t)(motor1.vdc * 6);    /* 字节2:母线电压×6量化 */
    transmit_message.tx_data[3] = pmsm_foc_param.iq * 10;    /* 字节3:q轴电流×10(0.1A分辨率) */
    transmit_message.tx_data[4] = motor1.speed_rpm & 0xff;    /* 字节4:转速低字节 */
    transmit_message.tx_data[5] = motor1.speed_rpm >> 8;    /* 字节5:转速高字节 */
    transmit_message.tx_data[6] = motor1.motor_sensor & 0x0F;    /* 字节6:低4位=传感器类型(0-无感 1-霍尔) */
    transmit_message.tx_data[7] = motor1.state & 0x0F;    /* 字节7:低4位=电机状态 */
    transmit_message.tx_data[7] |= status1_counter << 4;    /* 字节7高4位=滚动计数 */
    
    status1_counter++;    /* 滚动计数递增 */
    if(status1_counter >= 0x0F)    /* 计满回卷 */
    {
        status1_counter = 0;    /* 计数清零 */
    }
    can_message_transmit(CAN0, &transmit_message);    /* 启动CAN报文发送 */
}

/**
  * @brief 查询电机是否故障
  * @param 无
  * @retval 1-有故障   0-无故障
  */
static uint8_t motor_get_fault(void)
{
    if(motor1.motor_sensor)    /* 霍尔有感模式才检测故障 */
    {
        if(motor1.hall_state_fault == 1)    /* 霍尔状态非法故障 */
        {
            return 1;    /* 报告有故障 */
        }
        if(motor1.rotor_lock_fault == 1)    /* 转子堵转故障 */
        {
            return 1;    /* 报告有故障 */
        }
    /* 无故障路径原代码未写显式返回(依赖编译器隐式返回) */
    }
}

/**
  * @brief 清除电机故障标志
  * @param 无
  * @retval 无
  */
static void motor_clear_fault(void)
{
    motor1.hall_state_fault = 0;    /* 清霍尔状态故障标志 */
    motor1.rotor_lock_fault = 0;    /* 清堵转故障标志 */
}
/************************************************文件结束************************************************/
/************************************************EOF************************************************/
