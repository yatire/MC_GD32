/*
*******************************************************************************************************
*
* 文件名称 : motor_app.h
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 电机控制应用主文件
*
*******************************************************************************************************
*/
#ifndef _MOTOR_APP_H_        /* 编译保护宏:防止头文件重复包含 */
#define _MOTOR_APP_H_        /* 编译保护宏定义 */

#ifdef __cplusplus
extern "C"{
#endif

/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "motor_hardware.h"    /* 电机硬件接口头文件(定时器/GPIO/ADC通道等硬件宏与接口) */
#include "motor_config.h"    /* 电机参数配置头文件(ADC换算系数/电流限值等) */

/* 宏定义 ------------------------------------------------------------------------------------------*/
#define START_DELAY_SEC     (float)2    /* 启动延时时间:2秒 */
/* 启动延时对应的PWM周期数(时间/单周期时长) */
#define START_DELAY_TICK    (uint32_t)((float)START_DELAY_SEC/(1/(float)MOTOR_PWM_FREQ_HZ))
    
#define ROTOR_LOCK_CHECK_SEC     (float)2    /* 转子堵转检测时间:2秒 */
/* 堵转检测对应的PWM周期数(时间/单周期时长) */
#define ROTOR_LOCK_CHECK_TICK    (uint32_t)((float)ROTOR_LOCK_CHECK_SEC/(1/(float)MOTOR_PWM_FREQ_HZ))

#define PHASE_SHIFT_ANGLE (float)       (45.0f/180.0f*ANGLE_2PI)    /* 相位偏移角度:45°换算为电弧度(0~2π) */

#define ADC_CAL_COUNT       1024    /* ADC零点标定采样次数:1024次取平均 */

typedef enum{        /* 电机主状态机状态枚举 */
    INIT = 0,        /* 初始化状态 */
    ADC_CAL,        /* ADC零点标定状态 */
    START_DELAY,        /* 启动延时状态 */
    STOP,        /* 停机状态 */
    RUN,        /* 运行状态 */
    FAULT,        /* 故障状态 */
}motor_state_t;

typedef struct{        /* 电机控制数据结构体 */
    uint16_t adc_ia;        /* A相电流ADC原始采样值 */
    uint16_t adc_ib;        /* B相电流ADC原始采样值 */
    uint16_t adc_ic;        /* C相电流ADC原始采样值 */
    uint16_t ia_offset;        /* A相电流零点偏置(标定所得) */
    uint16_t ib_offset;        /* B相电流零点偏置(标定所得) */
    uint16_t ic_offset;        /* C相电流零点偏置(标定所得) */
    uint32_t adc_cal_cnt;        /* ADC零点标定采样计数 */
    
    uint32_t start_delay_tick;        /* 启动延时计数(PWM周期数) */
    uint8_t start;        /* 启动请求标志:1启动 0停止 */
    
    uint16_t ntc_adc;        /* NTC温度通道ADC滤波值 */
    uint16_t vdc_adc;        /* 母线电压通道ADC滤波值 */
    uint16_t idc_adc;        /* 母线电流通道ADC平均值 */
    float mosfet_temp;        /* MOS管温度(℃,由NTC查表换算) */
    float vdc;        /* 母线电压(V) */
    float idc;        /* 母线电流(A) */
    
    uint16_t speed_rpm;        /* 电机转速(rpm) */
    uint16_t speed_input;        /* 速度给定输入(rpm) */
    
    uint8_t motor_sensor;        /* 位置传感器类型选择 */
    uint32_t rotor_lock_tick;        /* 转子堵转检测计数(PWM周期数) */
    uint8_t rotor_lock_fault;        /* 转子堵转故障标志 */
    uint8_t hall_state_fault;        /* 霍尔状态错误故障标志 */
    uint8_t hall_state;        /* 当前霍尔状态值 */
    
    motor_state_t state;        /* 当前状态机状态 */
}motor_control_t;

/* 变量定义 ----------------------------------------------------------------------------------------*/
extern motor_control_t motor1;    /* 电机1控制数据结构体实例 */

/* 函数定义 -----------------------------------------------------------------------------------------*/
void motor_app_init(void);    /* 电机应用初始化:结构体清零/状态机置INIT/置启动标志 */
void motor_app_isr(void);    /* 电机主中断服务函数,在PWM中断中调用(状态机调度) */
void motor_app_task10ms(void);    /* 10ms周期任务:采集NTC/母线电压/母线电流并换算 */
void motor_app_task100ms(void);    /* 100ms周期任务:刷新LVGL监控页数据显示 */
void motor_app_task500ms(void);    /* 500ms周期任务(本版本为空实现) */
void motor_app_task1s(void);    /* 1s周期任务(本版本为空实现) */
void motor_app_idle(void);    /* 空闲任务:执行ADC后台轮询滤波 */

void motor_get_data(motor_control_t *info);    /* 获取电机数据结构体副本 */
void motor_start(void);    /* 启动电机(停机/故障态下请求启动) */
void motor_stop(void);    /* 停止电机(正常停机流程) */
void motor_forced_stop(void);    /* 强制停止电机并置故障状态 */
void motor_set_speed(uint16_t speed);    /* 设置电机转速给定(rpm) */

#ifdef __cplusplus
extern "C"{
#endif

#endif /* _MOTOR_APP_H_ */

/***************************************** 文件结束 *********************************************/
