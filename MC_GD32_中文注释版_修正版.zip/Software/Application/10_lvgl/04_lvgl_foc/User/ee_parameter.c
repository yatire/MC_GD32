/*
*******************************************************************************************************
*
* 文件名称 : ee_parameter.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : EEPROM电机参数存取(创建日期: 2025-3-17)
*
*******************************************************************************************************
*/


/*******************************************************************************
* 头文件包含
*******************************************************************************/
#include <string.h> /* 字符串操作(memcpy/memset) */
#include "ee_parameter.h" /* EEPROM参数存取接口头文件 */
#include "userparms.h" /* 用户参数配置(电机参数默认值等) */

/*******************************************************************************
* 宏定义
*******************************************************************************/

/*******************************************************************************
* 宏
*******************************************************************************/


/*******************************************************************************
* 全局常量定义
*******************************************************************************/

/*******************************************************************************
* 局部常量定义
*******************************************************************************/

/*******************************************************************************
* 全局变量定义
*******************************************************************************/
uint16_t motor_r = (MOTOR_PHASE_RESISTANCE * 1000);     /* 单位:mR(毫欧) */
uint16_t motor_l = (MOTOR_PHASE_INDUCTANCE * 1000000);  /* 单位:uH(微亨) */
uint16_t motor_bemf = (MOTOR_BACK_EMF_Vpeak * 1000);    /* 单位:mV/KRPM(千转每分反电动势峰值) */
uint8_t motor_pole = MOTOR_NOPOLESPAIRS;                                /* 电机极对数 */
uint16_t motor_normal_spd = NOMINAL_SPEED_RPM;          /* 额定转速，单位:RPM */
uint8_t openloop_current = OPEN_LOOP_CURRENT * 10;      /* 开环电流给定，单位:0.1A */
uint8_t rotor_lock_time = LOCK_TIME_SEC * 10;           /* 转子锁定(预定位)时间，单位:0.1s */
uint16_t openloop_ramp_time = OPENLOOPTIMEINSEC * 10;   /* 开环斜坡时间，单位:0.1s */
uint16_t openloop_hold_time = OPENLOOP_HOLD_TIME_SEC *10;   /* 开环保持时间，单位:0.1s */
uint16_t open_loop_speed = OPEN_LOOP_END_SPEED_RPM;     /* 开环切换速度，单位:RPM */
uint8_t motor_sensor = 1;                               /* 位置传感器类型:0-无感 1-霍尔 */
/*******************************************************************************
* 局部变量定义
*******************************************************************************/
static uint8_t eeprom_data[EEPROM_PARAMETER_LEN] = {0}; /* EEPROM参数缓存区(EEPROM_PARAMETER_LEN字节) */

/*******************************************************************************
* 局部函数声明
*******************************************************************************/


/*******************************************************************************
*  全局函数实现
*******************************************************************************/
/* 从EEPROM加载电机参数(掩码有效时才恢复各参数) */
void eeprom_load_parameter(void)
{
    uint32_t mask = 0; /* 有效标志掩码暂存 */
    eeprom_read(EEPROM_PARAMETER_ADDR, eeprom_data, EEPROM_PARAMETER_LEN); /* 从EEPROM读取整个参数区到缓冲区 */
    memcpy(&mask,&eeprom_data[EEPROM_MASK_ADDR],EEPROM_MASK_LEN); /* 取出4字节有效标志掩码 */
    
    if(EEPROM_INIT_MASK == mask) /* 掩码匹配：EEPROM中已保存有效参数 */
    {
        memcpy(&motor_r,&eeprom_data[MOTOR_R_ADDR],MOTOR_R_LEN); /* 恢复相电阻 */
        memcpy(&motor_l,&eeprom_data[MOTOR_L_ADDR],MOTOR_L_LEN); /* 恢复相电感 */
        memcpy(&motor_bemf,&eeprom_data[MOTOR_BF_ADDR],MOTOR_BF_LEN); /* 恢复反电动势常数 */
        memcpy(&motor_pole,&eeprom_data[MOTOR_PL_ADDR],MOTOR_PL_LEN); /* 恢复极对数 */
        memcpy(&motor_normal_spd,&eeprom_data[MOTOR_NML_SPD_ADDR],MOTOR_NML_SPD_LEN); /* 恢复额定转速 */
        memcpy(&openloop_current,&eeprom_data[OL_AMP_ADDR],OL_AMP_LEN); /* 恢复开环电流给定 */
        memcpy(&rotor_lock_time,&eeprom_data[ROTOR_LOCK_TIME_ADDR],ROTOR_LOCK_TIME_LEN); /* 恢复转子锁定时间 */
        memcpy(&openloop_ramp_time,&eeprom_data[OL_RAMP_TIME_ADDR],OL_RAMP_TIME_LEN); /* 恢复开环斜坡时间 */
        memcpy(&openloop_hold_time,&eeprom_data[OL_HOLD_TIME_ADDR],OL_HOLD_TIME_LEN); /* 恢复开环保持时间 */
        memcpy(&open_loop_speed,&eeprom_data[OL_SPEED_ADDR],OL_SPEED_LEN); /* 恢复开环切换速度 */
        memcpy(&motor_sensor,&eeprom_data[MOTOR_SENSOR_ADDR],MOTOR_SENSOR_LEN); /* 恢复传感器类型选择 */
    }
}


/* 将当前电机参数保存到EEPROM */
void eeprom_save_parameter(void)
{
    uint32_t mask = EEPROM_INIT_MASK; /* 待写入的有效标志掩码 */
    memset(eeprom_data,0,sizeof(eeprom_data)); /* 清空数据缓冲区 */
    
    memcpy(&eeprom_data[MOTOR_R_ADDR],&motor_r,MOTOR_R_LEN); /* 相电阻写入缓冲区 */
    memcpy(&eeprom_data[MOTOR_L_ADDR],&motor_l,MOTOR_L_LEN); /* 相电感写入缓冲区 */
    memcpy(&eeprom_data[MOTOR_BF_ADDR],&motor_bemf,MOTOR_BF_LEN); /* 反电动势常数写入缓冲区 */
    memcpy(&eeprom_data[MOTOR_PL_ADDR],&motor_pole,MOTOR_PL_LEN); /* 极对数写入缓冲区 */
    memcpy(&eeprom_data[MOTOR_NML_SPD_ADDR],&motor_normal_spd,MOTOR_NML_SPD_LEN); /* 额定转速写入缓冲区 */
    memcpy(&eeprom_data[OL_AMP_ADDR],&openloop_current,OL_AMP_LEN); /* 开环电流给定写入缓冲区 */
    memcpy(&eeprom_data[ROTOR_LOCK_TIME_ADDR],&rotor_lock_time,ROTOR_LOCK_TIME_LEN); /* 转子锁定时间写入缓冲区 */
    memcpy(&eeprom_data[OL_RAMP_TIME_ADDR],&openloop_ramp_time,OL_RAMP_TIME_LEN); /* 开环斜坡时间写入缓冲区 */
    memcpy(&eeprom_data[OL_HOLD_TIME_ADDR],&openloop_hold_time,OL_HOLD_TIME_LEN); /* 开环保持时间写入缓冲区 */
    memcpy(&eeprom_data[OL_SPEED_ADDR],&open_loop_speed,OL_SPEED_LEN); /* 开环切换速度写入缓冲区 */
    memcpy(&eeprom_data[MOTOR_SENSOR_ADDR],&motor_sensor,MOTOR_SENSOR_LEN); /* 传感器类型写入缓冲区 */
    
    memcpy(&eeprom_data[EEPROM_MASK_ADDR],&mask,EEPROM_MASK_LEN); /* 写入有效标志掩码 */
    eeprom_write(EEPROM_PARAMETER_ADDR, eeprom_data, EEPROM_PARAMETER_LEN); /* 将缓冲区整体写入EEPROM */
}

/*******************************************************************************
*  局部函数实现
*******************************************************************************/


/***************************************** 文件结束 *********************************************/
