/*
*******************************************************************************************************
*
* File Name : ee_parameter.h
* Version   : V1.0
* Author    : mzy2364
* 说    明 : EEPROM参数配置头文件
* 
*******************************************************************************************************
*/
#ifndef _EE_PARAMETER_H_    /* 头文件保护宏 */
#define _EE_PARAMETER_H_    /* 定义头文件保护宏 */

#ifdef __cplusplus      /* 若使用C++编译器编译 */
extern "C"{             /* 以C语言方式编译链接，防止函数名被C++改名 */
#endif                  /* C++兼容声明结束 */

/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "eeprom.h"   /* EEPROM(24Cxx)底层读写驱动头文件 */

/* 宏定义 ------------------------------------------------------------------------------------------*/
#define EEPROM_INIT_MASK        0xAA551248  /* 参数区有效标志掩码(判断EEPROM是否已初始化) */

#define EEPROM_PARAMETER_ADDR   0       /* 参数区在EEPROM中的起始地址 */
#define EEPROM_PARAMETER_LEN    64      /* 参数区总长度(字节) */

#define MOTOR_R_ADDR            0       /* 相电阻存储地址 */
#define MOTOR_R_LEN             2       /* 相电阻数据长度(字节) */
#define MOTOR_L_ADDR            2       /* 相电感存储地址 */
#define MOTOR_L_LEN             2       /* 相电感数据长度(字节) */
#define MOTOR_BF_ADDR           4       /* 反电动势常数存储地址 */
#define MOTOR_BF_LEN            2       /* 反电动势常数数据长度(字节) */
#define MOTOR_PL_ADDR           6       /* 极对数存储地址 */
#define MOTOR_PL_LEN            1       /* 极对数数据长度(字节) */
#define MOTOR_NML_SPD_ADDR      7       /* 额定转速存储地址 */
#define MOTOR_NML_SPD_LEN       2       /* 额定转速数据长度(字节) */
#define OL_AMP_ADDR             9       /* 开环电流给定存储地址 */
#define OL_AMP_LEN              1       /* 开环电流给定数据长度(字节) */
#define ROTOR_LOCK_TIME_ADDR    10      /* 转子锁定时间存储地址 */
#define ROTOR_LOCK_TIME_LEN     1       /* 转子锁定时间数据长度(字节) */
#define OL_RAMP_TIME_ADDR       11      /* 开环斜坡时间存储地址 */
#define OL_RAMP_TIME_LEN        2       /* 开环斜坡时间数据长度(字节) */
#define OL_HOLD_TIME_ADDR       13      /* 开环保持时间存储地址 */
#define OL_HOLD_TIME_LEN        2       /* 开环保持时间数据长度(字节) */
#define OL_SPEED_ADDR           15      /* 开环切换速度存储地址 */
#define OL_SPEED_LEN            2       /* 开环切换速度数据长度(字节) */
#define MOTOR_SENSOR_ADDR       17      /* 位置传感器类型存储地址 */
#define MOTOR_SENSOR_LEN        1       /* 位置传感器类型数据长度(字节) */

#define EEPROM_MASK_ADDR        60      /* 有效标志掩码存储地址 */
#define EEPROM_MASK_LEN         4       /* 有效标志掩码长度(字节) */


/* 变量定义 ----------------------------------------------------------------------------------------*/
extern uint16_t motor_r;     /* 相电阻，单位:mR(毫欧) */
extern uint16_t motor_l;     /* 相电感，单位:uH(微亨) */
extern uint16_t motor_bemf;    /* 反电动势常数，单位:mV/KRPM(千转每分反电动势峰值) */
extern uint8_t motor_pole;       /* 电机极对数 */
extern uint16_t motor_normal_spd;    /* 额定转速，单位:RPM */
extern uint8_t openloop_current;      /* 开环电流给定，单位:0.1A */
extern uint8_t rotor_lock_time;           /* 转子锁定时间，单位:0.1s */
extern uint16_t openloop_ramp_time;   /* 开环斜坡时间，单位:0.1s */
extern uint16_t openloop_hold_time;   /* 开环保持时间，单位:0.1s */
extern uint16_t open_loop_speed;     /* 开环切换速度，单位:RPM */
extern uint8_t motor_sensor;        /* 位置传感器类型:0-无感 1-霍尔 */

/* 函数定义 -----------------------------------------------------------------------------------------*/
void eeprom_load_parameter(void);   /* 从EEPROM加载电机参数(掩码有效时才恢复) */
void eeprom_save_parameter(void);   /* 将当前电机参数保存到EEPROM */

#ifdef __cplusplus      /* 若使用C++编译器编译(原文件遗留的重复代码块，未成对闭合) */
extern "C"{             /* 以C语言方式编译链接 */
#endif                  /* C++兼容声明结束 */

#endif /* _EE_PARAMETER_H_ */   /* 头文件保护宏结束 */

/***************************************** 文件结束 *********************************************/
