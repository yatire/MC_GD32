/*
*******************************************************************************************************
*
* 文件名称 : main.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 主函数文件
*
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include <string.h>    /* 标准字符串处理头文件 */
#include "gd32f30x.h"    /* GD32F30x固件库主头文件(外设寄存器定义与库函数) */
#include "gd32f30x_libopt.h"    /* GD32F30x固件库外设配置头文件(库选项) */
#include "systick.h"    /* 滴答定时器头文件(系统时基) */
#include "led.h"    /* LED驱动头文件 */
#include "motor_hardware.h"    /* 电机硬件层头文件(PWM/ADC等硬件配置) */
#include "uart.h"    /* 串口驱动头文件 */
#include "i2c.h"    /* I2C驱动头文件 */
#include "eeprom.h"    /* EEPROM(24C02)读写驱动头文件 */
#include "encoder.h"    /* 编码器接口头文件 */
#include "delay.h"    /* 延时函数头文件 */
#include "adc_simple.h"    /* ADC简易采样头文件 */
#include "lcd.h"    /* LCD显示驱动头文件 */
#include "lcd_init.h"    /* LCD底层初始化头文件 */
#include "can.h"    /* CAN总线驱动头文件 */
#include "drv8323rs.h"    /* DRV8323RS栅极驱动器驱动头文件 */
#include "delay.h"    /* 延时函数头文件(重复包含) */
#include "eeprom.h"    /* EEPROM读写驱动头文件(重复包含) */
#include "foc.h"    /* FOC矢量控制算法头文件 */
#include "pmsm.h"    /* PMSM电机模型头文件(FOC参数结构体、电流换算系数) */
#include "userparms.h"    /* 用户参数配置头文件 */
#include "task.h"    /* 任务调度头文件 */
#include "motor_app.h"    /* 电机应用层头文件 */
/* 宏定义 ------------------------------------------------------------------------------------------*/

/* 变量定义 ----------------------------------------------------------------------------------------*/
uint32_t hall_timer_counter = 0;    /* TIMER2通道0捕获计数值：两次霍尔边沿之间的时间(用于霍尔测速) */

float hall_theta_tab[6] = {0,PI*2/3,PI/3,PI*4/3,PI*5/3,PI}; /* 霍尔状态1~6对应的转子电角度表(相邻区间相差PI/3，单位弧度) */
/* 函数定义 -----------------------------------------------------------------------------------------*/

/**
  * @brief 主函数
  * @param 无
  * @retval 无
  */
int main(void)
{
    SCB->VTOR = FLASH_BASE | 0x4000;    /* 重定位中断向量表到应用程序区(FLASH_BASE+0x4000，为Bootloader预留前16KB) */
    __enable_irq();    /* 使能全局中断 */
    
    systick_init();    /* 初始化滴答定时器(系统时基) */
    delay_tim_init();    /* 初始化延时定时器 */
    led_init();    /* 初始化LED */
    usart_init();    /* 初始化串口 */
    adc1_init();    /* 初始化ADC1 */
    i2c_init();    /* 初始化I2C */
    can_bus_init();    /* 初始化CAN总线 */
    encoder_init();    /* 初始化编码器接口 */
    LCD_Init();    /* 初始化LCD显示屏 */
    LCD_Fill(0,0,LCD_W,LCD_H,BLACK);    /* LCD整屏填充黑色(清屏) */
    DRV8323RS_init();    /* 初始化DRV8323RS栅极驱动器 */
    task_init();    /* 初始化任务调度模块 */
    
    motor_hardware_init();    /* 初始化电机硬件(定时器/PWM/ADC采样等) */
    pmsm_foc_param.pwm_period = MOTOR_PWM_PERIOD;    /* 设置FOC参数中的PWM周期计数值 */
    pmsm_foc_init();    /* 初始化FOC矢量控制模块 */
    
    while(1)    /* 主循环：周期性执行任务调度 */
    {
        task_scheduler();    /* 轮询执行各任务 */
    }
}

void TIMER0_BRK_IRQHandler(void)    /* TIMER0刹车(BRK)中断服务函数：发生刹车故障时强制关闭PWM输出 */
{
    timer_channel_output_mode_config(TIMER0,TIMER_CH_0,TIMER_OC_MODE_INACTIVE);    /* 将W相通道(CH0)置为匹配时无效电平模式(关闭W相输出) */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_1,TIMER_OC_MODE_INACTIVE);    /* 将V相通道(CH1)置为匹配时无效电平模式(关闭V相输出) */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_2,TIMER_OC_MODE_INACTIVE);    /* 将U相通道(CH2)置为匹配时无效电平模式(关闭U相输出) */
    /* 清除TIMER中断标志位 */
    timer_interrupt_flag_clear(TIMER0,TIMER_INT_FLAG_BRK);
    motor_forced_stop();    /* 强制停止电机输出 */
    led_on(LED_FAULT);    /* 点亮故障指示LED */
}

void ADC0_1_IRQHandler(void)    /* ADC0_1中断服务函数：ADC注入组转换完成中断 */
{
    /* 清除ADC中断标志 */
    adc_interrupt_flag_clear(ADC0, ADC_INT_FLAG_EOIC);
    motor_app_isr();    /* 调用电机应用层中断处理(执行FOC电流环等实时计算) */
}

/*!
    \brief      此函数处理CAN0 RX0接收中断
    \param[in]  无
    \param[out] 无
    \retval     无
*/
void USBD_LP_CAN0_RX0_IRQHandler(void)
{
    can_receive_message_struct receive_message;    /* CAN接收消息结构体 */
    /* 检查接收到的消息 */
    can_message_receive(CAN0, CAN_FIFO0, &receive_message);
}

/*!
    \brief      此函数处理TIMER2中断请求
    \param[in]  无
    \param[out] 无
    \retval     无
*/
void TIMER2_IRQHandler(void)
{
    /* 霍尔转速计算公式: hall_speed = 2PI / (6 * delta_t) */
    /* 其中: delta_t = hall_timer_counter / timer_clk(定时器计数频率) */
    if(SET == timer_interrupt_flag_get(TIMER2,TIMER_INT_FLAG_CH0))    /* 若是TIMER2通道0捕获中断(霍尔信号边沿到来) */
    {
        /* 清除通道0中断标志位 */
        timer_interrupt_flag_clear(TIMER2,TIMER_INT_FLAG_CH0);
        timer_interrupt_flag_clear(TIMER2,TIMER_INT_FLAG_UP);    /* 同时清除更新(溢出)中断标志 */

        /* 读取通道0捕获值：两次霍尔边沿间隔的计数值(+1修正) */
        hall_timer_counter = timer_channel_capture_value_register_read(TIMER2,TIMER_CH_0)+1;
        /* 计算每个PWM周期的电角度增量：单个霍尔区间电角度为PI/3，按区间时间与PWM频率换算 */
        pmsm_mc_param.hall_theta_inc = (PI/3)/((float)hall_timer_counter/HALL_TIMER_FREQ_HZ)/MOTOR_PWM_FREQ_HZ;
        motor1.hall_state = hall_get();    /* 读取当前霍尔状态(1~6) */
        if((motor1.hall_state > 0) && (motor1.hall_state <= 6))    /* 若霍尔状态有效(1~6之间) */
        {
            motor1.rotor_lock_tick = 0;    /* 清零转子堵转计数 */
            /* 查表得到该霍尔区间对应的电角度，并叠加相移提前角 */
            pmsm_mc_param.hall_theta = hall_theta_tab[motor1.hall_state - 1] + PHASE_SHIFT_ANGLE;
        }
        else
        {
            motor1.hall_state_fault = 1;    /* 置霍尔状态故障标志 */
        }
    }
    else if(SET == timer_interrupt_flag_get(TIMER2,TIMER_INT_FLAG_UP))    /* 若是更新(溢出)中断：霍尔长时间无跳变，转速极低或停转 */
    {
        timer_interrupt_flag_clear(TIMER2,TIMER_INT_FLAG_UP);    /* 清除更新中断标志 */

        pmsm_mc_param.hall_theta_inc = 0;    /* 电角度增量清零(停止角度递增) */
        motor1.hall_state = hall_get();    /* 读取当前霍尔状态(1~6) */
        if((motor1.hall_state > 0) && (motor1.hall_state <= 6))    /* 若霍尔状态有效(1~6之间) */
        {
            /* 查表得到该霍尔区间对应的电角度，并叠加相移提前角 */
            pmsm_mc_param.hall_theta = hall_theta_tab[motor1.hall_state - 1] + PHASE_SHIFT_ANGLE;
        }
        else
        {
            motor1.hall_state_fault = 1;    /* 置霍尔状态故障标志 */
        }
    }
}

/***************************************** 文件结束 *********************************************/
