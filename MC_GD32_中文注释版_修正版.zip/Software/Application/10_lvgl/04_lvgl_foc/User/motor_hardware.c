/*
*******************************************************************************************************
*
* 文件名称 : motor_hardware.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : 电机控制硬件配置文件
* 
*******************************************************************************************************
*/


/* 头文件包含 ------------------------------------------------------------------------------------*/
#include "motor_hardware.h"         /* 电机硬件层接口 */
#include "motor_config.h"           /* 电机参数与硬件参数配置 */
#include "systick.h"                /* SysTick毫秒延时接口 */

/* 宏定义 ------------------------------------------------------------------------------------------*/


/* 变量定义 ----------------------------------------------------------------------------------------*/

/* 函数定义 -----------------------------------------------------------------------------------------*/
static void pwm_gpio_init(void);         /* PWM输出引脚GPIO初始化 */
static void pwm_timer_config(void);      /* TIMER0互补PWM定时器配置 */
static void adc_gpio_init(void);         /* ADC采样引脚初始化 */
static void adc0_config(void);           /* ADC0注入组采样配置 */
static void hall_timer_config(void);     /* TIMER2霍尔接口定时器配置 */

/**
  * @brief GPIO与定时器初始化
  * @param 无
  * @retval 无
  */
void motor_hardware_init(void)
{
    interrupt_init();         /* 配置NVIC中断优先级 */
    pwm_gpio_init();          /* 初始化PWM三相输出引脚 */
    pwm_timer_config();       /* 配置TIMER0中央对齐互补PWM */
    motor_pwm_disable();      /* 先关闭三相PWM输出 */
    hall_init();              /* 初始化霍尔传感器接口 */
    adc0_init();              /* 初始化ADC0采样 */
}

/**
  * @brief 电机PWM定时器重启
  * @param 无
  * @retval 无
  */
void motor_timer_restart(void)
{
    pwm_gpio_init();          /* 重新初始化PWM三相输出引脚 */
    pwm_timer_config();       /* 重新配置TIMER0中央对齐互补PWM */
}

/**
  * @brief NVIC中断优先级配置
  * @param 无
  * @retval 无
  */
void interrupt_init(void)
{
    nvic_irq_enable(TIMER0_BRK_IRQn, 0, 0);       /* 使能TIMER0刹车中断:抢占优先级0,子优先级0 */
    nvic_irq_enable(ADC0_1_IRQn, 0, 2);           /* 使能ADC0/ADC1中断:抢占优先级0,子优先级2 */
    nvic_irq_enable(TIMER2_IRQn, 1, 1);           /* 使能TIMER2霍尔捕获中断:抢占优先级1,子优先级1 */
}

/**
  * @brief 更新三相PWM占空比
  * @param duty_u U相占空比
  * @param duty_v V相占空比
  * @param duty_w W相占空比
  * @retval 无
  */
void motor_pwm_set_duty(uint16_t duty_u,uint16_t duty_v,uint16_t duty_w)
{
    timer_channel_output_pulse_value_config(MOTOR_PWM_TIMER,PWM_U_CHANNEL,duty_u);   /* 设置U相通道比较值 */
    timer_channel_output_pulse_value_config(MOTOR_PWM_TIMER,PWM_V_CHANNEL,duty_v);   /* 设置V相通道比较值 */
    timer_channel_output_pulse_value_config(MOTOR_PWM_TIMER,PWM_W_CHANNEL,duty_w);   /* 设置W相通道比较值 */
}



/**
  * @brief ADC配置
  * @param 无
  * @retval 无
  */
void adc0_init(void)
{
    adc_gpio_init();        /* 初始化ADC采样引脚 */
    adc0_config();          /* 配置ADC0注入组采样 */
}

/**
  * @brief DAC比较保护配置(输出相电流过流阈值)
  * @param None
  * @retval None
  */
void comp_protect_init(void)
{
    /* 使能外设时钟 */
    rcu_periph_clock_enable(RCU_GPIOA);   /* 使能GPIOA时钟(DAC输出引脚) */
    rcu_periph_clock_enable(RCU_DAC);     /* 使能DAC外设时钟 */
    
    /* DAC使能后,对应GPIO引脚自动连接到DAC转换器输出 */
    gpio_init(GPIOA, GPIO_MODE_AIN, GPIO_OSPEED_50MHZ, GPIO_PIN_5);   /* PA5配置为模拟输入,作为DAC1输出引脚 */
    
    dac_deinit();   /* 复位DAC外设 */
    /* 配置DAC1通道(PA5输出) */
    dac_wave_mode_config(DAC1, DAC_WAVE_MODE_LFSR); /* 配置DAC1波形模式:LFSR伪随机噪声 */
    dac_lfsr_noise_config(DAC1, DAC_LFSR_BITS10_0);   /* LFSR噪声掩码位宽:位10~0 */
    
    /* 使能DAC1并写入数据 */
    dac_enable(DAC1);   /* 使能DAC1输出 */
    /* 以下为注释停用的重复写法,与下一行等效 */
    /* dac_data_set(DAC1, DAC_ALIGN_12B_R, PHASE_OVER_CURRENT_DAC_VAULE); */
    dac_data_set(DAC1, DAC_ALIGN_12B_R, PHASE_OVER_CURRENT_DAC_VAULE);  /* 设置DAC输出数据=相电流过流阈值(ADC码值) */
}

/**
  * @brief 霍尔传感器接口初始化
  * @param 无
  * @retval 无
  */
void hall_init(void)
{
    /* 使能GPIO时钟 */
    rcu_periph_clock_enable(HALLA_GPIO_CLK);   /* 使能霍尔A相输入引脚时钟 */
    rcu_periph_clock_enable(HALLB_GPIO_CLK);   /* 使能霍尔B相输入引脚时钟 */
    rcu_periph_clock_enable(HALLC_GPIO_CLK);   /* 使能霍尔C相输入引脚时钟 */
    rcu_periph_clock_enable(RCU_AF);           /* 使能复用功能时钟 */
    
    gpio_pin_remap_config(GPIO_TIMER2_FULL_REMAP,ENABLE);  /* TIMER2完全重映射,霍尔输入引脚按重映射表连接 */
    
    gpio_init(HALLA_GPIO_PORT,GPIO_MODE_IN_FLOATING,GPIO_OSPEED_50MHZ,HALLA_GPIO_PIN);  /* 霍尔A相输入引脚(浮空输入) */
    gpio_init(HALLB_GPIO_PORT,GPIO_MODE_IN_FLOATING,GPIO_OSPEED_50MHZ,HALLB_GPIO_PIN);  /* 霍尔B相输入引脚(浮空输入) */
    gpio_init(HALLC_GPIO_PORT,GPIO_MODE_IN_FLOATING,GPIO_OSPEED_50MHZ,HALLC_GPIO_PIN);  /* 霍尔C相输入引脚(浮空输入) */
    
    hall_timer_config();   /* 配置TIMER2霍尔接口模式 */
}

/**
  * @brief 获取霍尔传感器状态
  * @param 无
  * @retval 无
  */
uint8_t hall_get(void)
{
    uint8_t ret = 0;   /* 霍尔状态组合值 */
    
    ret |= gpio_input_bit_get(HALLA_GPIO_PORT,HALLA_GPIO_PIN);    /* 读霍尔A相电平至bit0 */
    ret |= gpio_input_bit_get(HALLB_GPIO_PORT,HALLB_GPIO_PIN) << 1;  /* 读霍尔B相电平左移1位至bit1 */
    ret |= gpio_input_bit_get(HALLC_GPIO_PORT,HALLC_GPIO_PIN) << 2;  /* 读霍尔C相电平左移2位至bit2 */
    
    return ret;     /* 返回霍尔状态码(1~6为有效状态) */
}

/**
  * @brief 将PWM引脚设置为复用推挽输出模式
  * @param 无
  * @retval 无
  */
void motor_pwm_pin_enable(void)
{
    gpio_init(PWM_UH_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_UH_GPIO_PIN);  /* U相上桥臂引脚复用推挽输出 */
    gpio_init(PWM_VH_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_VH_GPIO_PIN);  /* V相上桥臂引脚复用推挽输出 */
    gpio_init(PWM_WH_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_WH_GPIO_PIN);  /* W相上桥臂引脚复用推挽输出 */

    gpio_init(PWM_UL_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_UL_GPIO_PIN);  /* U相下桥臂引脚复用推挽输出 */
    gpio_init(PWM_VL_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_VL_GPIO_PIN);  /* V相下桥臂引脚复用推挽输出 */
    gpio_init(PWM_WL_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_WL_GPIO_PIN);  /* W相下桥臂引脚复用推挽输出 */
}

/**
  * @brief 将PWM引脚切换为普通GPIO输出模式
  * @param 无
  * @retval 无
  */
void motor_pwm_pin_disable(void)
{
    gpio_bit_write(PWM_UH_GPIO_PORT, PWM_UH_GPIO_PIN,RESET);  /* U相上桥臂引脚输出低电平 */
    gpio_bit_write(PWM_VH_GPIO_PORT, PWM_VH_GPIO_PIN,RESET);  /* V相上桥臂引脚输出低电平 */
    gpio_bit_write(PWM_WH_GPIO_PORT, PWM_WH_GPIO_PIN,RESET);  /* W相上桥臂引脚输出低电平 */

    gpio_bit_write(PWM_UL_GPIO_PORT, PWM_UL_GPIO_PIN,RESET);  /* U相下桥臂引脚输出低电平 */
    gpio_bit_write(PWM_VL_GPIO_PORT, PWM_VL_GPIO_PIN,RESET);  /* V相下桥臂引脚输出低电平 */
    gpio_bit_write(PWM_WL_GPIO_PORT, PWM_WL_GPIO_PIN,RESET);  /* W相下桥臂引脚输出低电平 */
    
    gpio_init(PWM_UH_GPIO_PORT,GPIO_MODE_OUT_PP,GPIO_OSPEED_50MHZ,PWM_UH_GPIO_PIN); /* U相上桥臂引脚改为推挽输出 */
    gpio_init(PWM_VH_GPIO_PORT,GPIO_MODE_OUT_PP,GPIO_OSPEED_50MHZ,PWM_VH_GPIO_PIN); /* V相上桥臂引脚改为推挽输出 */
    gpio_init(PWM_WH_GPIO_PORT,GPIO_MODE_OUT_PP,GPIO_OSPEED_50MHZ,PWM_WH_GPIO_PIN); /* W相上桥臂引脚改为推挽输出 */

    gpio_init(PWM_UL_GPIO_PORT,GPIO_MODE_OUT_PP,GPIO_OSPEED_50MHZ,PWM_UL_GPIO_PIN); /* U相下桥臂引脚改为推挽输出 */
    gpio_init(PWM_VL_GPIO_PORT,GPIO_MODE_OUT_PP,GPIO_OSPEED_50MHZ,PWM_VL_GPIO_PIN); /* V相下桥臂引脚改为推挽输出 */
    gpio_init(PWM_WL_GPIO_PORT,GPIO_MODE_OUT_PP,GPIO_OSPEED_50MHZ,PWM_WL_GPIO_PIN); /* W相下桥臂引脚改为推挽输出 */
}

/**
  * @brief 关闭三相PWM输出
  * @param 无
  * @retval 无
  */
void motor_pwm_disable(void)
{
    timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_U_CHANNEL,TIMER_CCX_DISABLE);   /* 关闭U相通道输出 */
    timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_V_CHANNEL,TIMER_CCX_DISABLE);   /* 关闭V相通道输出 */
    timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_W_CHANNEL,TIMER_CCX_DISABLE);   /* 关闭W相通道输出 */
    /* 关闭U相互补通道输出 */
    timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_U_CHANNEL,TIMER_CCXN_DISABLE);
    /* 关闭V相互补通道输出 */
    timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_V_CHANNEL,TIMER_CCXN_DISABLE);
    /* 关闭W相互补通道输出 */
    timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_W_CHANNEL,TIMER_CCXN_DISABLE);
}

/**
  * @brief 使能三相PWM输出
  * @param 无
  * @retval 无
  */
void motor_pwm_enable(void)
{
    timer_channel_output_mode_config(MOTOR_PWM_TIMER,PWM_U_CHANNEL,TIMER_OC_MODE_PWM0);   /* U相通道设为PWM0输出模式 */
    timer_channel_output_mode_config(MOTOR_PWM_TIMER,PWM_V_CHANNEL,TIMER_OC_MODE_PWM0);   /* V相通道设为PWM0输出模式 */
    timer_channel_output_mode_config(MOTOR_PWM_TIMER,PWM_W_CHANNEL,TIMER_OC_MODE_PWM0);   /* W相通道设为PWM0输出模式 */
    timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_U_CHANNEL,TIMER_CCX_ENABLE);    /* 使能U相通道输出 */
    timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_V_CHANNEL,TIMER_CCX_ENABLE);    /* 使能V相通道输出 */
    timer_channel_output_state_config(MOTOR_PWM_TIMER,PWM_W_CHANNEL,TIMER_CCX_ENABLE);    /* 使能W相通道输出 */
    /* 使能U相互补通道输出 */
    timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_U_CHANNEL,TIMER_CCXN_ENABLE);
    /* 使能V相互补通道输出 */
    timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_V_CHANNEL,TIMER_CCXN_ENABLE);
    /* 使能W相互补通道输出 */
    timer_channel_complementary_output_state_config(MOTOR_PWM_TIMER,PWM_W_CHANNEL,TIMER_CCXN_ENABLE);
}

/**
  * @brief 按矢量号以GPIO方式输出六步换相开关状态
  * @param 无
  * @retval 无
  */
void motor_set_voltage_vector(int16_t vector)
{
    /* 按c-b-a顺序以矢量号强制改写PWM引脚输出状态 */
    switch(vector)     /* 根据矢量号选择对应的开关状态组合 */
    {
        case 0:
            /* c-b-a :: 0-0-0 */
            gpio_bit_write(PWM_UH_GPIO_PORT, PWM_UH_GPIO_PIN,RESET);            /* U相上桥臂关断 */
            gpio_bit_write(PWM_VH_GPIO_PORT, PWM_VH_GPIO_PIN,RESET);            /* V相上桥臂关断 */
            gpio_bit_write(PWM_WH_GPIO_PORT, PWM_WH_GPIO_PIN,RESET);            /* W相上桥臂关断 */

            gpio_bit_write(PWM_UL_GPIO_PORT, PWM_UL_GPIO_PIN,RESET);            /* U相下桥臂关断 */
            gpio_bit_write(PWM_VL_GPIO_PORT, PWM_VL_GPIO_PIN,RESET);            /* V相下桥臂关断 */
            gpio_bit_write(PWM_WL_GPIO_PORT, PWM_WL_GPIO_PIN,RESET);            /* W相下桥臂关断 */
        break;  /* 跳出switch */
        
        case 1:
            /* c-b-a :: 0-0-1 */
            gpio_bit_write(PWM_UH_GPIO_PORT, PWM_UH_GPIO_PIN,RESET);            /* U相上桥臂关断 */
            gpio_bit_write(PWM_VH_GPIO_PORT, PWM_VH_GPIO_PIN,RESET);            /* V相上桥臂关断 */
            gpio_bit_write(PWM_WH_GPIO_PORT, PWM_WH_GPIO_PIN,SET);                /* W相上桥臂导通 */

            gpio_bit_write(PWM_UL_GPIO_PORT, PWM_UL_GPIO_PIN,SET);                /* U相下桥臂导通 */
            gpio_bit_write(PWM_VL_GPIO_PORT, PWM_VL_GPIO_PIN,SET);                /* V相下桥臂导通 */
            gpio_bit_write(PWM_WL_GPIO_PORT, PWM_WL_GPIO_PIN,RESET);            /* W相下桥臂关断 */
        break;  /* 跳出switch */
        
        case 2:
            /* c-b-a :: 0-1-1 */
            gpio_bit_write(PWM_UH_GPIO_PORT, PWM_UH_GPIO_PIN,RESET);            /* U相上桥臂关断 */
            gpio_bit_write(PWM_VH_GPIO_PORT, PWM_VH_GPIO_PIN,SET);                /* V相上桥臂导通 */
            gpio_bit_write(PWM_WH_GPIO_PORT, PWM_WH_GPIO_PIN,SET);                /* W相上桥臂导通 */

            gpio_bit_write(PWM_UL_GPIO_PORT, PWM_UL_GPIO_PIN,SET);                /* U相下桥臂导通 */
            gpio_bit_write(PWM_VL_GPIO_PORT, PWM_VL_GPIO_PIN,RESET);            /* V相下桥臂关断 */
            gpio_bit_write(PWM_WL_GPIO_PORT, PWM_WL_GPIO_PIN,RESET);            /* W相下桥臂关断 */
        break;  /* 跳出switch */
        
        case 3:
            /* c-b-a :: 0-1-0 */
            gpio_bit_write(PWM_UH_GPIO_PORT, PWM_UH_GPIO_PIN,RESET);            /* U相上桥臂关断 */
            gpio_bit_write(PWM_VH_GPIO_PORT, PWM_VH_GPIO_PIN,SET);                /* V相上桥臂导通 */
            gpio_bit_write(PWM_WH_GPIO_PORT, PWM_WH_GPIO_PIN,RESET);            /* W相上桥臂关断 */

            gpio_bit_write(PWM_UL_GPIO_PORT, PWM_UL_GPIO_PIN,SET);                /* U相下桥臂导通 */
            gpio_bit_write(PWM_VL_GPIO_PORT, PWM_VL_GPIO_PIN,RESET);            /* V相下桥臂关断 */
            gpio_bit_write(PWM_WL_GPIO_PORT, PWM_WL_GPIO_PIN,SET);                /* W相下桥臂导通 */
        break;  /* 跳出switch */
        
        case 4:
            /* c-b-a :: 1-1-0 */
            gpio_bit_write(PWM_UH_GPIO_PORT, PWM_UH_GPIO_PIN,SET);                /* U相上桥臂导通 */
            gpio_bit_write(PWM_VH_GPIO_PORT, PWM_VH_GPIO_PIN,SET);                /* V相上桥臂导通 */
            gpio_bit_write(PWM_WH_GPIO_PORT, PWM_WH_GPIO_PIN,RESET);            /* W相上桥臂关断 */

            gpio_bit_write(PWM_UL_GPIO_PORT, PWM_UL_GPIO_PIN,RESET);            /* U相下桥臂关断 */
            gpio_bit_write(PWM_VL_GPIO_PORT, PWM_VL_GPIO_PIN,RESET);            /* V相下桥臂关断 */
            gpio_bit_write(PWM_WL_GPIO_PORT, PWM_WL_GPIO_PIN,SET);                /* W相下桥臂导通 */
        break;  /* 跳出switch */
        
        case 5:
            /* c-b-a :: 1-0-0 */
            gpio_bit_write(PWM_UH_GPIO_PORT, PWM_UH_GPIO_PIN,SET);                /* U相上桥臂导通 */
            gpio_bit_write(PWM_VH_GPIO_PORT, PWM_VH_GPIO_PIN,RESET);            /* V相上桥臂关断 */
            gpio_bit_write(PWM_WH_GPIO_PORT, PWM_WH_GPIO_PIN,RESET);            /* W相上桥臂关断 */

            gpio_bit_write(PWM_UL_GPIO_PORT, PWM_UL_GPIO_PIN,RESET);            /* U相下桥臂关断 */
            gpio_bit_write(PWM_VL_GPIO_PORT, PWM_VL_GPIO_PIN,SET);                /* V相下桥臂导通 */
            gpio_bit_write(PWM_WL_GPIO_PORT, PWM_WL_GPIO_PIN,SET);                /* W相下桥臂导通 */
        break;  /* 跳出switch */
        
        case 6:
             /* c-b-a :: 1-0-1 */
            gpio_bit_write(PWM_UH_GPIO_PORT, PWM_UH_GPIO_PIN,SET);                /* U相上桥臂导通 */
            gpio_bit_write(PWM_VH_GPIO_PORT, PWM_VH_GPIO_PIN,RESET);            /* V相上桥臂关断 */
            gpio_bit_write(PWM_WH_GPIO_PORT, PWM_WH_GPIO_PIN,SET);                /* W相上桥臂导通 */

            gpio_bit_write(PWM_UL_GPIO_PORT, PWM_UL_GPIO_PIN,RESET);            /* U相下桥臂关断 */
            gpio_bit_write(PWM_VL_GPIO_PORT, PWM_VL_GPIO_PIN,SET);                /* V相下桥臂导通 */
            gpio_bit_write(PWM_WL_GPIO_PORT, PWM_WL_GPIO_PIN,RESET);            /* W相下桥臂关断 */
        break;  /* 跳出switch */
        
        case 7:
            /* c-b-a :: 1-1-1 */
            gpio_bit_write(PWM_UH_GPIO_PORT, PWM_UH_GPIO_PIN,SET);                /* U相上桥臂导通 */
            gpio_bit_write(PWM_VH_GPIO_PORT, PWM_VH_GPIO_PIN,SET);                /* V相上桥臂导通 */
            gpio_bit_write(PWM_WH_GPIO_PORT, PWM_WH_GPIO_PIN,SET);                /* W相上桥臂导通 */

            gpio_bit_write(PWM_UL_GPIO_PORT, PWM_UL_GPIO_PIN,RESET);            /* U相下桥臂关断 */
            gpio_bit_write(PWM_VL_GPIO_PORT, PWM_VL_GPIO_PIN,RESET);            /* V相下桥臂关断 */
            gpio_bit_write(PWM_WL_GPIO_PORT, PWM_WL_GPIO_PIN,RESET);            /* W相下桥臂关断 */
        break;  /* 跳出switch */

        default:     /* 无效矢量号 */
            vector = 0;   /* 非法矢量号归零 */
        break;  /* 跳出switch */
    }
}

/* 局部函数 -----------------------------------------------------------------------------------*/

/**
  * @brief PWM定时器输出引脚初始化
  * @param 无
  * @retval 无
  */
static void pwm_gpio_init(void)
{
    rcu_periph_clock_enable(RCU_GPIOA);  /* 使能GPIOA时钟(上桥臂引脚) */
    rcu_periph_clock_enable(RCU_GPIOB);  /* 使能GPIOB时钟(下桥臂与BKIN引脚) */
    rcu_periph_clock_enable(RCU_AF);     /* 使能复用功能时钟 */

    /*配置PA8 PA9 PA10(TIMER0 CH0 CH1 CH2)为复用推挽输出*/
    gpio_init(PWM_UH_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_UH_GPIO_PIN);  /* PA10:U相上桥臂输出 */
    gpio_init(PWM_VH_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_VH_GPIO_PIN);  /* PA9:V相上桥臂输出 */
    gpio_init(PWM_WH_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_WH_GPIO_PIN);  /* PA8:W相上桥臂输出 */

    /*配置PB13 PB14 PB15(TIMER0 CH0N CH1N CH2N)为复用推挽输出*/
    gpio_init(PWM_UL_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_UL_GPIO_PIN);  /* PB15:U相下桥臂互补输出 */
    gpio_init(PWM_VL_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_VL_GPIO_PIN);  /* PB14:V相下桥臂互补输出 */
    gpio_init(PWM_WL_GPIO_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,PWM_WL_GPIO_PIN);  /* PB13:W相下桥臂互补输出 */

    /*配置PB12(TIMER0 BKIN)为刹车输入引脚*/
    gpio_init(PWM_BKIN_GPIO_PORT,GPIO_MODE_IN_FLOATING,GPIO_OSPEED_50MHZ,PWM_BKIN_GPIO_PIN);  /* PB12刹车输入引脚 */
}

/**
  * @brief ADC采样引脚初始化
  * @param 无
  * @retval 无
  */
static void adc_gpio_init(void)
{
    /* 使能GPIO时钟 */
    rcu_periph_clock_enable(IU_ADC_CLK);       /* 使能U相电流采样引脚时钟 */
    rcu_periph_clock_enable(IV_ADC_CLK);       /* 使能V相电流采样引脚时钟 */
    rcu_periph_clock_enable(IW_ADC_CLK);       /* 使能W相电流采样引脚时钟 */
    rcu_periph_clock_enable(IDC_AVER_ADC_CLK); /* 使能母线电流采样引脚时钟 */
    
    gpio_init(IU_ADC_PORT, GPIO_MODE_AIN, GPIO_OSPEED_MAX, IU_ADC_PIN);  /* U相电流采样引脚,模拟输入 */
    gpio_init(IV_ADC_PORT, GPIO_MODE_AIN, GPIO_OSPEED_MAX, IV_ADC_PIN);  /* V相电流采样引脚,模拟输入 */
    gpio_init(IW_ADC_PORT, GPIO_MODE_AIN, GPIO_OSPEED_MAX, IW_ADC_PIN);  /* W相电流采样引脚,模拟输入 */
    gpio_init(IDC_AVER_ADC_PORT, GPIO_MODE_AIN, GPIO_OSPEED_MAX, IDC_AVER_ADC_PIN);  /* 母线电流采样引脚,模拟输入 */
}

/**
  * @brief PWM定时器初始化(中央对齐互补输出)
  * @param 无
  * @retval 无
  */
static void pwm_timer_config(void)
{
    /* 系统主频 systemcoreclock = 120MHz 
    *  PWM频率 = systemcoreclock / (prescaler+1) / period / 2
    *  死区时间 = 2us(deadtime=0xb8)
    */
    timer_oc_parameter_struct timer_ocintpara;      /* 通道输出参数结构体 */
    timer_parameter_struct timer_initpara;          /* 时基参数结构体 */
    timer_break_parameter_struct timer_breakpara;   /* 刹车与死区参数结构体 */

    rcu_periph_clock_enable(RCU_TIMER0); /* 使能TIMER0时钟 */

    timer_deinit(TIMER0);         /* 复位TIMER0 */

    /* TIMER0时基单元配置 */
    timer_initpara.prescaler         = 0;      /* 不分频,计数时钟120MHz */
    timer_initpara.alignedmode       = TIMER_COUNTER_CENTER_UP;  /* 中央对齐(向上计数)模式 */
    timer_initpara.counterdirection  = TIMER_COUNTER_UP;         /* 计数方向:向上 */
    timer_initpara.period            = MOTOR_PWM_PERIOD;   /* 自动重装载值,决定PWM频率(本配置为16kHz) */
    timer_initpara.clockdivision     = TIMER_CKDIV_DIV1;  /* 时钟分割:fDTS=fCK_TIMER */
    timer_initpara.repetitioncounter = 0;  /* 重复计数器0,每次溢出/下溢均产生更新事件 */
    timer_init(TIMER0,&timer_initpara);  /* 初始化TIMER0时基 */

     /* CH0/CH0N,CH1/CH1N与CH2/CH2N通道输出参数配置 */
    timer_ocintpara.outputstate  = TIMER_CCX_ENABLE;  /* 正相输出初始使能(CHx) */
    timer_ocintpara.outputnstate = TIMER_CCXN_ENABLE; /* 互补输出初始使能(CHxN) */
    timer_ocintpara.ocpolarity   = TIMER_OC_POLARITY_HIGH;  /* 正相输出高电平有效 */
    timer_ocintpara.ocnpolarity  = TIMER_OCN_POLARITY_HIGH; /* 互补输出高电平有效 */
    timer_ocintpara.ocidlestate  = TIMER_OC_IDLE_STATE_LOW;  /* 空闲状态:正相输出低电平 */
    timer_ocintpara.ocnidlestate = TIMER_OCN_IDLE_STATE_LOW; /* 空闲状态:互补输出低电平 */

    timer_channel_output_config(TIMER0,TIMER_CH_0,&timer_ocintpara);  /* 配置CH0通道输出参数 */
    timer_channel_output_config(TIMER0,TIMER_CH_1,&timer_ocintpara);  /* 配置CH1通道输出参数 */
    timer_channel_output_config(TIMER0,TIMER_CH_2,&timer_ocintpara);  /* 配置CH2通道输出参数 */
    timer_channel_output_config(TIMER0,TIMER_CH_3,&timer_ocintpara);  /* 配置CH3通道输出参数(用作ADC注入组触发) */

    timer_channel_output_pulse_value_config(TIMER0,TIMER_CH_0,1000);   /* CH0初始比较值 */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_0,TIMER_OC_MODE_PWM0);  /* CH0 PWM0输出模式 */
    timer_channel_output_shadow_config(TIMER0,TIMER_CH_0,TIMER_OC_SHADOW_ENABLE);  /* CH0比较值影子寄存器使能 */

    timer_channel_output_pulse_value_config(TIMER0,TIMER_CH_1,1000);   /* CH1初始比较值 */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_1,TIMER_OC_MODE_PWM0);  /* CH1 PWM0输出模式 */
    timer_channel_output_shadow_config(TIMER0,TIMER_CH_1,TIMER_OC_SHADOW_ENABLE);  /* CH1比较值影子寄存器使能 */

    timer_channel_output_pulse_value_config(TIMER0,TIMER_CH_2,1000);   /* CH2初始比较值 */
    timer_channel_output_mode_config(TIMER0,TIMER_CH_2,TIMER_OC_MODE_PWM0);  /* CH2 PWM0输出模式 */
    timer_channel_output_shadow_config(TIMER0,TIMER_CH_2,TIMER_OC_SHADOW_ENABLE);  /* CH2比较值影子寄存器使能 */
    
    /* CH3比较值=周期-1:计数器顶端附近(三相下管导通区)产生比较事件,触发ADC注入组采样 */
    timer_channel_output_pulse_value_config(TIMER0,TIMER_CH_3,timer_initpara.period - 1);
    timer_channel_output_mode_config(TIMER0,TIMER_CH_3,TIMER_OC_MODE_PWM0);  /* CH3 PWM0输出模式 */
    timer_channel_output_shadow_config(TIMER0,TIMER_CH_3,TIMER_OC_SHADOW_DISABLE); /* CH3比较值不使用影子寄存器 */


    /* 自动输出使能、刹车、死区与写保护配置*/
    timer_breakpara.runoffstate      = TIMER_ROS_STATE_ENABLE;  /* 运行模式关闭状态输出:使能 */
    timer_breakpara.ideloffstate     = TIMER_IOS_STATE_ENABLE ;   /* 空闲模式关闭状态输出:使能 */
    timer_breakpara.deadtime         = 0xb8;        /* 死区时间2us */
    timer_breakpara.breakpolarity    = TIMER_BREAK_POLARITY_LOW; /* 刹车输入BRK低电平有效 */
    timer_breakpara.outputautostate  = TIMER_OUTAUTO_ENABLE;  /* 自动输出使能:刹车撤销后MOE自动恢复 */
    timer_breakpara.protectmode      = TIMER_CCHP_PROT_OFF;    /* 无写保护 */
    timer_breakpara.breakstate       = TIMER_BREAK_ENABLE;     /* 使能刹车输入(BRK)功能 */
    timer_break_config(TIMER0,&timer_breakpara);  /* 写入刹车与死区配置 */
    
    /* 使能TIMER0主输出功能(MOE) */
    timer_primary_output_config(TIMER0,ENABLE);

    /* 使能TIMER0更新中断 */
    timer_interrupt_enable(TIMER0,TIMER_INT_UP);
    /* 使能TIMER0刹车中断 */
    timer_interrupt_enable(TIMER0,TIMER_INT_BRK);
    
    timer_interrupt_enable(TIMER0,TIMER_INT_CH3);   /* 使能CH3比较中断(ADC注入组触发的同源事件) */

    /* 启动TIMER0计数器 */
    timer_enable(TIMER0);
}

/**
  * @brief ADC0初始化
  * @param 无
  * @retval 无
  * @note ADC转换时间 = (12.5+采样时间) * 1/CLK_ADC
  *       CLK_ADC = APB时钟 / 4 = 30M
  *       采样时间 = 1.5周期
  *       ADC转换时间 = (12.5+1.5) * (1/30M) = 0.466us (单通道)
  */
static void adc0_config(void)
{
    /* 使能ADC0时钟 */
    rcu_periph_clock_enable(RCU_ADC0);
    /* 配置ADC时钟:APB2 4分频(30MHz) */
    rcu_adc_clock_config(RCU_CKADC_CKAPB2_DIV4);
    
    /* ADC工作模式配置(独立模式) */
    adc_mode_config(ADC_MODE_FREE); 
    /* ADC特殊功能配置 */
    adc_special_function_config(ADC0, ADC_SCAN_MODE, ENABLE);  /* 使能扫描模式 */
    adc_special_function_config(ADC0, ADC_CONTINUOUS_MODE, DISABLE);    /* 禁用连续转换模式 */
    /* ADC数据对齐配置(右对齐) */
    adc_data_alignment_config(ADC0, ADC_DATAALIGN_RIGHT);

    /* ADC注入组通道长度配置(共3个通道) */
    adc_channel_length_config(ADC0, ADC_INSERTED_CHANNEL, 3);
    /* ADC注入组通道配置(相电流三通道) */
    /* 注入组次序0挂接U相电流通道,采样时间1.5周期 */
    adc_inserted_channel_config(ADC0, IU_INSERTED_CHANNEL, IU_ADC_CHANNEL, ADC_SAMPLETIME_1POINT5);
    /* 注入组次序1挂接V相电流通道,采样时间1.5周期 */
    adc_inserted_channel_config(ADC0, IV_INSERTED_CHANNEL, IV_ADC_CHANNEL, ADC_SAMPLETIME_1POINT5);
    /* 注入组次序2挂接W相电流通道,采样时间1.5周期 */
    adc_inserted_channel_config(ADC0, IW_INSERTED_CHANNEL, IW_ADC_CHANNEL, ADC_SAMPLETIME_1POINT5);
    /* ADC注入组触发配置 */
    /* 注入组外部触发源:TIMER0 CH3比较事件(计数器顶端附近,下管导通采样点) */
    adc_external_trigger_source_config(ADC0, ADC_INSERTED_CHANNEL, ADC0_1_EXTTRIG_INSERTED_T0_CH3); 
    /* 使能ADC注入组外部触发 */
    adc_external_trigger_config(ADC0, ADC_INSERTED_CHANNEL, ENABLE);
    
    /* 清除ADC中断标志 */
    adc_interrupt_flag_clear(ADC0, ADC_INT_FLAG_EOC);  /* 清除EOC转换结束标志 */
    adc_interrupt_flag_clear(ADC0, ADC_INT_FLAG_EOIC);  /* 清除EOIC注入组转换结束标志 */
    /* 使能ADC注入组转换结束中断(EOIC) */
    adc_interrupt_enable(ADC0, ADC_INT_EOIC);

    /* 使能ADC接口 */
    adc_enable(ADC0);
    systick_delay(1);  /* 延时1ms等待ADC稳定 */
    /* 复位校准并启动ADC自校准 */
    adc_calibration_enable(ADC0);
}

/**
  * @brief TIMER2霍尔接口定时器初始化
  * @param 无
  * @retval 无
  */
static void hall_timer_config(void)
{
    /* TIMER2配置:输入捕获模式(霍尔接口) */
    timer_ic_parameter_struct timer_icinitpara;    /* 输入捕获参数结构体 */
    timer_parameter_struct timer_initpara;         /* 时基参数结构体 */

    rcu_periph_clock_enable(RCU_TIMER2);  /* 使能TIMER2时钟 */

    timer_deinit(TIMER2);           /* 复位TIMER2 */

    /* TIMER2时基单元配置 */
    timer_initpara.prescaler         = HALL_TIMER_PRESCALER;  /* 预分频119:计数时钟1MHz(120MHz/120) */
    timer_initpara.alignedmode       = TIMER_COUNTER_EDGE;  /* 边沿对齐计数模式 */
    timer_initpara.counterdirection  = TIMER_COUNTER_UP;  /* 向上计数 */
    timer_initpara.period            = 0xFFFF;  /* 计数周期65535(16位最大值) */
    timer_initpara.clockdivision     = TIMER_CKDIV_DIV1;  /* 时钟分割:fDTS=fCK_TIMER */
    timer_initpara.repetitioncounter = 0;  /* 重复计数器0 */
    timer_init(TIMER2,&timer_initpara);  /* 初始化TIMER2时基 */

    /* TIMER2配置 */
    /* TIMER2输入捕获配置 */
    timer_icinitpara.icpolarity  = TIMER_IC_POLARITY_RISING;  /* CH0上升沿捕获 */
    timer_icinitpara.icselection = TIMER_IC_SELECTION_ITS;  /* 捕获输入映射到ITS内部触发信号(由TRGS选择,此处为CH0边沿检测,霍尔接口模式下为三路霍尔异或) */
    timer_icinitpara.icprescaler = TIMER_IC_PSC_DIV1;  /* 捕获分频:不分频 */
    timer_icinitpara.icfilter    = 0x0;  /* 无输入滤波 */
    timer_input_capture_config(TIMER2,TIMER_CH_0,&timer_icinitpara);  /* 配置CH0输入捕获 */
    
    timer_icinitpara.icpolarity  = TIMER_IC_POLARITY_RISING;  /* CH1上升沿捕获 */
    timer_icinitpara.icselection = TIMER_IC_SELECTION_ITS;  /* 捕获输入映射到ITS内部触发信号(由TRGS选择,此处为CH0边沿检测,霍尔接口模式下为三路霍尔异或) */
    timer_icinitpara.icprescaler = TIMER_IC_PSC_DIV1;  /* 捕获分频:不分频 */
    timer_icinitpara.icfilter    = 0x0;  /* 无输入滤波 */
    timer_input_capture_config(TIMER2,TIMER_CH_1,&timer_icinitpara);  /* 配置CH1输入捕获 */
    
    timer_icinitpara.icpolarity  = TIMER_IC_POLARITY_RISING;  /* CH2上升沿捕获 */
    timer_icinitpara.icselection = TIMER_IC_SELECTION_ITS;  /* 捕获输入映射到ITS内部触发信号(由TRGS选择,此处为CH0边沿检测,霍尔接口模式下为三路霍尔异或) */
    timer_icinitpara.icprescaler = TIMER_IC_PSC_DIV1;  /* 捕获分频:不分频 */
    timer_icinitpara.icfilter    = 0x0;  /* 无输入滤波 */
    timer_input_capture_config(TIMER2,TIMER_CH_2,&timer_icinitpara);  /* 配置CH2输入捕获 */
    
    /* TIMER2从模式选择 */
    timer_input_trigger_source_select(TIMER2,TIMER_SMCFG_TRGSEL_CI0F_ED);   /* 触发源:CI0滤波边沿(霍尔异或信号) */
    timer_slave_mode_select(TIMER2,TIMER_SLAVE_MODE_RESTART); /* 复位模式:霍尔边沿到来即复位计数器 */
    
    /* 霍尔接口模式配置 */
    timer_hall_mode_config(TIMER2, TIMER_HALLINTERFACE_ENABLE); /* 使能霍尔接口(CH0/CH1/CH2异或接入CI0) */

    /* 使能自动重装载影子寄存器(预装载) */
    timer_auto_reload_shadow_enable(TIMER2);
    /* 清除中断标志 */
    timer_interrupt_flag_clear(TIMER2,TIMER_INT_FLAG_CH0);  /* 清除通道0捕获中断标志 */
    timer_interrupt_flag_clear(TIMER2,TIMER_INT_FLAG_UP);   /* 清除更新中断标志 */
    /* 使能中断 */
    timer_interrupt_enable(TIMER2,TIMER_INT_CH0);   /* 使能通道0捕获中断 */
    timer_interrupt_enable(TIMER2,TIMER_INT_UP);    /* 使能更新中断 */

    /* 启动TIMER2计数器 */
    timer_enable(TIMER2);
}

/***************************************** 文件结束 *********************************************/
