/*
*******************************************************************************************************
*
* 文件名称 : lv_port_disp_mcgd32.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 说    明 : LVGL显示驱动移植层(GD32平台,LCD写窗口+DMA搬运显存)
*
*******************************************************************************************************
*/

 /* 将此文件复制为 "lv_port_disp.c" 并将此值置 "1" 以启用本文件内容 */
#if 1 /* 置1启用本移植层文件,置0则禁用 */

/*********************
 *      头文件包含
 *********************/
#include "lv_port_disp_mcgd32.h"
#include "lv_conf.h"
#include "lcd.h"
/*********************
 *      宏定义
 *********************/

/**********************
 *      类型定义
 **********************/

/**********************
 *    静态函数声明
 **********************/
static void disp_init(void); /* 显示外设初始化函数声明 */

/* 显示刷新回调函数声明: 把缓冲区内容写到 LCD 指定区域 */
static void disp_flush(lv_disp_drv_t * disp_drv, const lv_area_t * area, lv_color_t * color_p);

/**********************
 *     静态变量定义
 **********************/
lv_disp_drv_t * my_disp_drv = NULL; /* 显示驱动指针(DMA传输完成中断中经此通知LVGL) */
/**********************
 *        宏
 **********************/

/**********************
 *      全局函数定义
 **********************/

/* LVGL 显示端口初始化: 初始化显示外设、创建绘制缓冲区并注册显示驱动 */
void lv_port_disp_init(void)
{
    /*-------------------------
     * 初始化你的显示屏
     * -----------------------*/
    disp_init(); /* 调用显示外设初始化 */

    /*-----------------------------
     * 创建绘制缓冲区
     *----------------------------*/

    /* LittlevGL 需要一块用于绘制图形对象的缓冲区, 缓冲区必须大于 1 行显示像素
     *
     * 有三种缓冲配置方案:
     * 1. 创建一块包含若干行的缓冲区:
     *      LittlevGL 把显示内容绘制到这里, 再由你写入显示屏
     *
     * 2. 创建两块包含若干行的缓冲区:
     *      LittlevGL 把显示内容绘制到一块缓冲区并写入你的显示屏.
     *      应使用 DMA 把缓冲区内容写到显示屏.
     *      这样在第一块缓冲区数据发送期间, LittlevGL 可以把屏幕的下一部分
     *      绘制到另一块缓冲区, 使渲染与刷新并行进行.
     *
     * 3. 创建两块整屏大小的缓冲区:
     *      与方案 2) 类似, 但缓冲区必须为整屏大小. LittlevGL 绘制完成后
     *      会把整帧数据交给显示器, 这样只需修改帧缓冲地址而无需拷贝像素.
     * */

    /* 示例 1) */
/*    static lv_disp_buf_t disp_buf_1; */
/*    static lv_color_t buf1_1[LV_HOR_RES_MAX * 10]; */                   /*缓冲区: 存 10 行数据*/
/*    lv_disp_buf_init(&disp_buf_1, buf1_1, NULL, LV_HOR_RES_MAX * 10); */   /*初始化显示缓冲区*/

    /* 示例 2) */
    static lv_disp_buf_t disp_buf_2; /* 显示缓冲区描述结构体 */
    static lv_color_t buf2_1[LV_HOR_RES_MAX * 10];                        /* 缓冲区1: 存 10 行数据 */
    static lv_color_t buf2_2[LV_HOR_RES_MAX * 10];                        /* 缓冲区2: 存 10 行数据(双缓冲) */
    lv_disp_buf_init(&disp_buf_2, buf2_1, buf2_2, LV_HOR_RES_MAX * 10);   /* 初始化显示缓冲区 */

    /* 示例 3) */
/*    static lv_disp_buf_t disp_buf_3; */
/*    static lv_color_t buf3_1[LV_HOR_RES_MAX * LV_VER_RES_MAX]; */         /*整屏大小缓冲区*/
/*    static lv_color_t buf3_2[LV_HOR_RES_MAX * LV_VER_RES_MAX]; */         /*另一块整屏大小缓冲区*/
/*    lv_disp_buf_init(&disp_buf_3, buf3_1, buf3_2, LV_HOR_RES_MAX * LV_VER_RES_MAX); */   /*初始化显示缓冲区*/


    /*-----------------------------------
     * 向 LittlevGL 注册显示屏
     *----------------------------------*/

    lv_disp_drv_t disp_drv;                         /* 显示驱动描述结构体 */
    lv_disp_drv_init(&disp_drv);                    /* 驱动结构体默认初始化 */

    /*设置访问你的显示屏所需的函数*/

    /*设置显示屏分辨率*/
    disp_drv.hor_res = LV_HOR_RES_MAX; /* 水平分辨率(像素) */
    disp_drv.ver_res = LV_VER_RES_MAX; /* 垂直分辨率(像素) */

    /*用于把缓冲区内容拷贝到显示屏*/
    disp_drv.flush_cb = disp_flush; /* 注册刷新回调函数 */

    /*绑定显示缓冲区*/
    disp_drv.buffer = &disp_buf_2; /* 绑定上面创建的显示缓冲区 */

    /*最后注册驱动*/
    lv_disp_drv_register(&disp_drv); /* 向 LVGL 注册显示驱动 */
}

/**********************
 *      静态函数定义
 **********************/

/* SPI2 + DMA 发送函数: 把 buf 中 size 个数据经 SPI2 发送到 LCD */
static void lcd_spi_dma_transmit(void* buf, uint32_t size)
{
	/* 设置SPI为16位模式 */
	spi_disable(SPI2); /* 先关闭 SPI 才能切换帧格式 */
	spi_i2s_data_frame_format_config(SPI2, SPI_FRAMESIZE_16BIT); /* 配置为 16 位数据帧 */
	spi_enable(SPI2); /* 重新使能 SPI */

    /* 开启DMA传输 */
	dma_channel_disable(DMA1, DMA_CH1); /* 关闭 DMA1 通道 1 以便配置 */
	dma_transfer_number_config(DMA1, DMA_CH1,size); /* 设置 DMA 传输数据量(像素数) */
	dma_memory_address_config(DMA1, DMA_CH1,(uint32_t)buf); /* 设置存储器地址(待发送数据首地址) */
	dma_channel_enable(DMA1, DMA_CH1); /* 使能 DMA1 通道 1, 开始搬运数据 */

}

/* 初始化显示屏及其所需外设 */
static void disp_init(void)
{
    /*在此添加你的初始化代码*/
}

/* 把内部缓冲区的内容刷新到显示屏的指定区域
 * 可以使用 DMA 或任何硬件加速在后台完成此操作, 但结束时必须调用
 * lv_disp_flush_ready() 通知 LVGL. */
static void disp_flush(lv_disp_drv_t * disp_drv, const lv_area_t * area, lv_color_t * color_p)
{
    /*最简单(但也最慢)的方式是逐个像素写到屏幕上*/

    int16_t w = (area->x2 - area->x1 + 1); /* 计算刷新区域宽度(像素) */
    int16_t h = (area->y2 - area->y1 + 1); /* 计算刷新区域高度(像素) */
    uint32_t size = w * h; /* 计算刷新区域总像素数 */

    my_disp_drv = disp_drv; /* 保存驱动指针, 供 DMA 传输完成中断中通知 LVGL 使用 */

    /* 设置SPI为8位模式 */
	spi_disable(SPI2); /* 先关闭 SPI 才能切换帧格式 */
	spi_i2s_data_frame_format_config(SPI2, SPI_FRAMESIZE_8BIT); /* 配置为 8 位数据帧 */
	spi_enable(SPI2); /* 重新使能 SPI */
    LCD_Address_Set(area->x1,area->y1,area->x2,area->y2);		/* 设置显存写入窗口地址 */

    LCD_CS_Clr();	/* 片选拉低, 选中 LCD */
    LCD_DC_Set();   /* DC 置高, 写数据 */

    lcd_spi_dma_transmit(color_p, size);	/* 启动 DMA 传输显存数据 */
}

/* DMA1 通道 1 传输完成中断服务函数 */
void DMA1_Channel1_IRQHandler(void)
{
    if(dma_interrupt_flag_get(DMA1,DMA_CH1,DMA_INT_FLAG_FTF) != RESET) /* 判断 DMA1 通道 1 传输完成(FTF)中断标志 */
    {
        dma_interrupt_flag_clear(DMA1,DMA_CH1,DMA_INT_FLAG_FTF); /* 清除传输完成中断标志 */
		LCD_CS_Set();	/* 片选拉高, 取消选中 */
        if(my_disp_drv) /* 若驱动指针有效, 通知 LVGL */
        {
            lv_disp_flush_ready(my_disp_drv);/* 告知 LVGL 刷新已完成 */
            my_disp_drv = NULL; /* 清空指针, 防止重复通知 */
        }
    }
}

#else /* 文件顶部开关为 0 时编译以下内容 */

/* 此哑元类型定义仅用于消除 -Wpedantic 警告 */
typedef int keep_pedantic_happy;
#endif /* 结束文件顶部开关条件编译 */
