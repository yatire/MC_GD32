/*
*******************************************************************************************************
*
* 文件名称 : mainwindow.h
* 版    本 : V1.0
* 作    者 : mzy2364
* 创建日期 : 2025-3-17
* 说    明 : LVGL 主窗口 UI 头文件(页面创建、切换与事件接口)
*
*******************************************************************************************************
*/

#ifndef _MAINDOW_H_     /* 头文件保护宏：防止重复包含 */
#define _MAINDOW_H_     /* 定义头文件保护宏 */

#ifdef __cplusplus      /* 若使用 C++ 编译器编译 */
extern "C"{             /* 以 C 语言方式编译链接，防止函数名被 C++ 改名 */
#endif                  /* C++ 兼容声明结束 */

#include "lvgl.h"       /* LVGL 图形库总头文件 */
#include "motor_app.h"  /* 电机应用层头文件 */
#include "pmsm.h"       /* PMSM(永磁同步电机)相关头文件 */

#define SCREEN_NUM      2   /* UI 屏幕界面(页面)总数 */

typedef enum{               /* UI 事件类型：按键与编码器事件 */
    KEY_EVENT_NONE = 0,         /* 无事件 */
    KEY_EVENT_KEY0_PRE,         /* KEY0 按下 */
    KEY_EVENT_KEY0_LONG_PRE,    /* KEY0 长按 */
    KEY_EVENT_KEY0_REL,         /* KEY0 释放 */

    KEY_EVENT_ENC0_INC,         /* 编码器0 增量(正转) */
    KEY_EVENT_ENC0_DEC,         /* 编码器0 减量(反转) */
}ui_event_t;


void lvgl_main_app(void);           /* LVGL 主应用：创建各屏幕界面并运行 UI 任务 */
void ui_event_send(ui_event_t e);   /* 发送 UI 事件(将按键/编码器事件通知 UI) */
void mainwindow_cutover_page(void); /* 主窗口页面切换 */
void ui_monitor_update(void);       /* 更新监控页数据显示 */
void ui_refresh(void);              /* UI 刷新 */

lv_obj_t *ui_monitor_create(lv_obj_t *parent);  /* 创建监控页面，返回页面对象 */
lv_obj_t *ui_set_create(lv_obj_t *parent);      /* 创建设置页面，返回页面对象 */
lv_obj_t *ui_program_create(lv_obj_t *parent);  /* 创建设置(编程)页面，返回页面对象 */

#ifdef __cplusplus      /* 若使用 C++ 编译器编译 */
}
#endif                  /* C++ 兼容声明结束 */

#endif /* _MAINDOW_H_ */    /* 头文件保护宏结束 */
