/*
*******************************************************************************************************
*
* 文件名称 : ui_monitor.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 创建日期 : 2025-3-17
* 说    明 : LVGL监视界面：数据显示/仪表刷新
*
*******************************************************************************************************
*/

/*******************************************************************************
* 头文件包含
*******************************************************************************/
#include "mainwindow.h"     /* 主窗口UI头文件(页面接口/UI事件类型定义) */
#include "ee_parameter.h"   /* EEPROM电机参数头文件(电机参数变量定义) */

/*******************************************************************************
* 宏定义
*******************************************************************************/

/*******************************************************************************
* 宏与类型定义
*******************************************************************************/


/*******************************************************************************
* 全局常量定义
*******************************************************************************/

/*******************************************************************************
* 局部常量定义
*******************************************************************************/

/*******************************************************************************
* 全局变量定义
*******************************************************************************/
LV_IMG_DECLARE(rotor)       /* 声明转子图片资源(本文件中暂未直接使用) */

/*******************************************************************************
* 局部变量定义
*******************************************************************************/
lv_obj_t *label_const_status;       /* "Status:"固定文字标签 */
lv_obj_t *label_const_speed;        /* "Speed:"固定文字标签 */
lv_obj_t *label_const_current;      /* "Current:"固定文字标签 */
lv_obj_t *label_const_voltage;      /* "Voltage:"固定文字标签 */
lv_obj_t *label_const_temp;         /* "Temp:"固定文字标签 */
lv_obj_t *lv_preload;               /* 预加载旋转动画控件指针(创建代码已注释停用) */
lv_obj_t *lv_led;                   /* LED指示灯控件(运行状态指示) */
lv_obj_t *lv_bar_ref_spd;           /* 参考速度进度条控件 */
lv_obj_t *lv_hall_state;            /* 霍尔状态显示标签 */

lv_obj_t *label_status;             /* 运行状态值标签(STOP/RUN/FAULT) */
lv_obj_t *label_speed;              /* 实际转速值标签 */
lv_obj_t *label_current;            /* q轴电流值标签 */
lv_obj_t *label_voltage;            /* 母线电压值标签 */
lv_obj_t *label_temp;               /* MOS管温度值标签 */
lv_obj_t *label_ref_spd;            /* 参考速度值标签(叠加在进度条上) */

static uint8_t led_toggle_tick = 0; /* LED闪烁分频计数器 */

/*******************************************************************************
* 局部函数声明
*******************************************************************************/
static void ui_monitor_event_cb(lv_obj_t* obj, lv_event_t event);   /* 监视页对象事件回调函数 */
static uint32_t my_pow(uint8_t m,uint8_t n);    /* 整数幂运算(求m的n次方) */
/* 标签显示整数数值(前导零抑制,可带单位文本) */
static void ui_label_show_int_num(lv_obj_t *label,int32_t num,uint8_t len,const char * unit_text,uint8_t unit_len);
/* 标签显示浮点数值(1位小数,可带单位文本) */
static void ui_label_show_float_num(lv_obj_t *label,float num,uint8_t len,const char * unit_text,uint8_t unit_len);
/*******************************************************************************
*  全局函数定义
*******************************************************************************/

/**
  * @brief 创建监视页面
  * @param parent - 父对象
  * @retval	当前页面对象
  * @note
  */
lv_obj_t *ui_monitor_create(lv_obj_t *parent)
{
    static lv_style_t style_label;          /* 数值标签样式 */
    static lv_style_t style_label_const;    /* 固定文字标签样式 */
    static lv_style_t style_bg;             /* 页面背景容器样式 */
    static lv_style_t style_preload;        /* 预加载动画样式 */
    static lv_style_t style_led;            /* LED指示灯样式 */
    static lv_style_t style_bar_bg;         /* 进度条背景样式 */
    static lv_style_t style_bar_inc;        /* 进度条指示器样式 */

    lv_style_copy(&style_label_const, &lv_style_plain);     /* 复制内置plain样式作为基底 */
    lv_style_copy(&style_bg, &lv_style_scr);                /* 复制屏幕样式作为基底 */
    style_label_const.text.font = &lv_font_roboto_22;       /* 固定文字字体:Roboto 22号 */
    style_label_const.text.color = LV_COLOR_WHITE;          /* 固定文字颜色:白色 */

    lv_style_copy(&style_label, &style_label_const);        /* 以固定文字样式为基底复制 */
    style_label.text.color = LV_COLOR_YELLOW;               /* 数值文字颜色:黄色 */

    style_bg.body.grad_color = LV_COLOR_GRAY;               /* 背景渐变结束色:灰色 */
    style_bg.body.main_color = LV_COLOR_GRAY;               /* 背景主色:灰色(纯色背景) */

    lv_style_copy(&style_preload, &lv_style_plain);         /* 复制内置plain样式作为基底 */
    style_preload.line.width = 10; /* 旋转部分线的宽度 */
    /* style_preload.line.color = lv_color_hex3(0x258); */ /* 旋转部分线的颜色 */
    /* style_preload.body.border.color = lv_color_hex3(0xBBB); */ /* 背景的颜色 */
    style_preload.line.color = LV_COLOR_YELLOW; /* 旋转部分线的颜色 */
    style_preload.body.border.color = LV_COLOR_BLUE; /* 背景的颜色 */
    style_preload.body.border.width = 10; /* 背景的圆圈的宽度 */
    style_preload.body.padding.left = 0; /* 左边部分填充为 0 */

    lv_style_copy(&style_led, &lv_style_pretty_color);      /* 复制内置pretty_color样式作为基底 */
    style_led.body.shadow.width = 5;                /* 阴影宽度5像素(发光效果) */
    style_led.body.radius = LV_RADIUS_CIRCLE;       /* 圆角半径设为正圆 */
    style_led.body.border.width = 3;                /* 边框宽度3像素 */
    style_led.body.border.opa = LV_OPA_30;          /* 边框不透明度30% */
    style_led.body.main_color = lv_color_hsv_to_rgb(210, 100, 100);     /* 主色:HSV(210,100,100)蓝色 */
    style_led.body.grad_color = lv_color_hsv_to_rgb(210, 100, 100);     /* 渐变结束色:与主色相同 */
    style_led.body.border.color = lv_color_hsv_to_rgb(210, 60, 60);     /* 边框色:HSV(210,60,60)深蓝 */
    style_led.body.shadow.color = lv_color_hsv_to_rgb(210, 100, 100);   /* 阴影色:蓝色光晕 */

    lv_style_copy(&style_bar_bg, &lv_style_plain);  /* 复制内置plain样式作为基底 */
    /* style_bar_bg.body.shadow.width = 0; */       /* 阴影宽度0 */
    /* style_bar_bg.body.border.width = 0; */       /* 边框宽度0 */
    /* style_bar_bg.body.padding.top = 0; */        /* 顶部内边距0 */
    /* style_bar_bg.body.padding.bottom = 0; */     /* 底部内边距0 */

    lv_style_copy(&style_bar_inc, &lv_style_plain_color);   /* 复制内置plain_color样式作为基底 */
    style_bar_inc.body.shadow.width = 0;    /* 指示器无阴影 */
    style_bar_inc.body.border.width = 0;    /* 指示器无边框 */
    style_bar_inc.body.padding.top = 0;     /* 指示器顶部内边距0 */
    style_bar_inc.body.padding.bottom = 0;  /* 指示器底部内边距0 */
    style_bar_inc.body.padding.left = 0;    /* 指示器左侧内边距0 */
    style_bar_inc.body.padding.right = 0;   /* 指示器右侧内边距0 */

    lv_obj_t *cont = lv_cont_create(parent,NULL);           /* 创建页面容器 */
    lv_cont_set_style(cont, LV_CONT_STYLE_MAIN, &style_bg); /* 容器应用背景样式 */
    lv_obj_set_size(cont,LV_HOR_RES_MAX,LV_VER_RES_MAX);    /* 容器尺寸:整个屏幕 */
    lv_obj_set_event_cb(cont, ui_monitor_event_cb);         /* 注册容器事件回调(按键/刷新处理) */

    label_const_status = lv_label_create(cont, NULL);       /* 创建"Status:"固定标签 */
    lv_obj_set_style(label_const_status, &style_label_const);   /* 应用固定文字样式 */
    lv_label_set_text(label_const_status, "Status:");       /* 设置标签文本 */
    lv_obj_align(label_const_status, NULL, LV_ALIGN_IN_TOP_LEFT, 0, 0);         /* 对齐:左上(0,0) */

    label_status = lv_label_create(cont, NULL);             /* 创建状态值标签 */
    lv_obj_set_style(label_status, &style_label);           /* 应用数值标签样式 */
    lv_label_set_text(label_status, "STOP");                /* 初始文本:STOP */
    lv_obj_align(label_status, NULL, LV_ALIGN_IN_TOP_LEFT, 100, 0);             /* 对齐:左上(100,0) */

    label_const_speed = lv_label_create(cont, NULL);        /* 创建"Speed:"固定标签 */
    lv_obj_set_style(label_const_speed, &style_label_const);    /* 应用固定文字样式 */
    lv_label_set_text(label_const_speed, "Speed:");         /* 设置标签文本 */
    lv_obj_align(label_const_speed, NULL, LV_ALIGN_IN_TOP_LEFT, 0, 23);         /* 对齐:左上(0,23) */

    label_speed = lv_label_create(cont, NULL);              /* 创建转速值标签 */
    lv_obj_set_style(label_speed, &style_label);            /* 应用数值标签样式 */
    lv_label_set_text(label_speed, "99999 RPM");            /* 初始占位文本 */
    lv_obj_align(label_speed, NULL, LV_ALIGN_IN_TOP_LEFT, 100, 23);             /* 对齐:左上(100,23) */

    label_const_current = lv_label_create(cont, NULL);      /* 创建"Current:"固定标签 */
    lv_obj_set_style(label_const_current, &style_label_const);  /* 应用固定文字样式 */
    lv_label_set_text(label_const_current, "Current:");     /* 设置标签文本 */
    lv_obj_align(label_const_current, NULL, LV_ALIGN_IN_TOP_LEFT, 0, 46);       /* 对齐:左上(0,46) */

    label_current = lv_label_create(cont, NULL);            /* 创建电流值标签 */
    lv_obj_set_style(label_current, &style_label);          /* 应用数值标签样式 */
    lv_label_set_text(label_current, "12.5 A");             /* 初始占位文本 */
    lv_obj_align(label_current, NULL, LV_ALIGN_IN_TOP_LEFT, 100, 46);           /* 对齐:左上(100,46) */

    label_const_voltage = lv_label_create(cont, NULL);      /* 创建"Voltage:"固定标签 */
    lv_obj_set_style(label_const_voltage, &style_label_const);  /* 应用固定文字样式 */
    lv_label_set_text(label_const_voltage, "Voltage:");     /* 设置标签文本 */
    lv_obj_align(label_const_voltage, NULL, LV_ALIGN_IN_TOP_LEFT, 0, 69);       /* 对齐:左上(0,69) */

    label_voltage = lv_label_create(cont, NULL);            /* 创建电压值标签 */
    lv_obj_set_style(label_voltage, &style_label);          /* 应用数值标签样式 */
    lv_label_set_text(label_voltage, "12.5 V");             /* 初始占位文本 */
    lv_obj_align(label_voltage, NULL, LV_ALIGN_IN_TOP_LEFT, 100, 69);           /* 对齐:左上(100,69) */

    label_const_temp = lv_label_create(cont, NULL);         /* 创建"Temp:"固定标签 */
    lv_obj_set_style(label_const_temp, &style_label_const);     /* 应用固定文字样式 */
    lv_label_set_text(label_const_temp, "Temp:");           /* 设置标签文本 */
    lv_obj_align(label_const_temp, NULL, LV_ALIGN_IN_TOP_LEFT, 0, 92);          /* 对齐:左上(0,92) */

    label_temp = lv_label_create(cont, NULL);               /* 创建温度值标签 */
    lv_obj_set_style(label_temp, &style_label);             /* 应用数值标签样式 */
    lv_label_set_text(label_temp, "105 degC");              /* 初始占位文本 */
    lv_obj_align(label_temp, NULL, LV_ALIGN_IN_TOP_LEFT, 100, 92);              /* 对齐:左上(100,92) */

    /* lv_preload = lv_preload_create(cont, NULL); */           /* 创建预加载动画(已注释停用) */
    /* lv_obj_set_style(lv_preload, &style_preload); */         /* 应用动画样式(已注释停用) */
    /* lv_obj_set_size(lv_preload, 50, 50); */                  /* 尺寸50x50(已注释停用) */
    /* lv_obj_align(lv_preload, NULL, LV_ALIGN_IN_TOP_RIGHT, -10, 50); */       /* 对齐右上(已注释停用) */

    lv_led = lv_led_create(cont, NULL);                     /* 创建LED指示灯控件 */
    lv_obj_set_style(lv_led, &style_led);                   /* 应用LED样式 */
    lv_obj_set_size(lv_led, 22, 22);                        /* LED尺寸22x22像素 */
    lv_obj_align(lv_led, NULL, LV_ALIGN_IN_TOP_RIGHT, -2, 2);   /* 对齐:右上(-2,2) */

    lv_hall_state = lv_label_create(cont, NULL);            /* 创建霍尔状态标签 */
    lv_obj_set_style(lv_hall_state, &style_label);          /* 应用数值标签样式 */
    lv_label_set_text(lv_hall_state,"0");                   /* 初始文本:'0' */
    lv_obj_align(lv_hall_state, NULL, LV_ALIGN_IN_TOP_RIGHT, -8, 24);   /* 对齐:右上(-8,24) */

    lv_bar_ref_spd = lv_bar_create(cont, NULL);             /* 创建参考速度进度条控件 */
    lv_bar_set_style(lv_bar_ref_spd,LV_BAR_STYLE_BG,&style_bar_bg);         /* 设置进度条背景样式 */
    lv_bar_set_style(lv_bar_ref_spd,LV_BAR_STYLE_INDIC,&style_bar_inc);     /* 设置进度条指示器样式 */
    lv_obj_set_size(lv_bar_ref_spd,LV_HOR_RES_MAX,16);      /* 进度条尺寸:全屏宽,高16像素 */
    lv_obj_align(lv_bar_ref_spd, NULL, LV_ALIGN_IN_BOTTOM_LEFT, 0, 0);      /* 对齐:左下(0,0) */
    lv_bar_set_range(lv_bar_ref_spd,0,100);                 /* 进度条量程0~100(百分比) */
    lv_bar_set_value(lv_bar_ref_spd,0,LV_ANIM_OFF);         /* 初始值0(无动画) */

    label_ref_spd = lv_label_create(lv_bar_ref_spd,NULL);   /* 在进度条上创建参考速度值标签 */
    lv_label_set_text(label_ref_spd,"0RPM");                /* 初始文本:0RPM */


    return cont;                        /* 返回创建完成的监视页容器对象 */
}

/**
  * @brief 监视页数据更新
  * @param void
  * @retval	无
  * @note
  */
void ui_monitor_update(void)
{
    char text_hall_state = '0';         /* 霍尔状态字符(状态值转ASCII后显示) */
    motor_control_t motor_info;         /* 电机状态数据结构体 */
    motor_get_data(&motor_info);        /* 获取最新电机状态数据 */

    if(motor_info.state == RUN)         /* 运行状态:显示实时数据 */
    {
        lv_label_set_text(label_status, "RUN");         /* 状态标签显示RUN */

        ui_label_show_int_num(label_speed,motor_info.speed_rpm,5," RPM",4);     /* 显示实际转速 */
        ui_label_show_float_num(label_current,pmsm_foc_param.iq,2," A",2);      /* 显示q轴电流值 */
    }
    else if(motor_info.state == FAULT)  /* 故障状态 */
    {
        lv_label_set_text(label_status, "FAULT");       /* 状态标签显示FAULT */
        lv_label_set_text(label_speed, " RPM");         /* 转速标签清空(仅保留单位) */
        lv_label_set_text(label_current, " A");         /* 电流标签清空(仅保留单位) */
    }
    else                                /* 其余状态按停止显示 */
    {
        lv_label_set_text(label_status, "STOP");        /* 状态标签显示STOP */
        lv_label_set_text(label_speed, " RPM");         /* 转速标签清空(仅保留单位) */
        lv_label_set_text(label_current, " A");         /* 电流标签清空(仅保留单位) */
    }
    text_hall_state = motor_info.hall_state + 0x30;     /* 霍尔状态值转ASCII字符('0'起) */
    lv_label_set_text(lv_hall_state,&text_hall_state);  /* 显示霍尔状态字符 */

    /* 更新参考速度进度条:给定转速占额定转速的百分比(0~100) */
    lv_bar_set_value(lv_bar_ref_spd,((motor_info.speed_input * 100) / motor_normal_spd),LV_ANIM_OFF);
    ui_label_show_int_num(label_ref_spd,motor_info.speed_input,5," RPM",4);     /* 显示参考转速 */

    led_toggle_tick++;                  /* LED闪烁分频计数递增(每次刷新+1) */
    if(led_toggle_tick >= 5)            /* 计满5次翻转一次,实现慢速闪烁 */
    {
        led_toggle_tick = 0;            /* 计数清零重新开始 */
        lv_led_toggle(lv_led);          /* LED状态翻转(亮灭切换) */
    }

    ui_label_show_float_num(label_voltage,motor_info.vdc,2," V",2);     /* 显示母线电压(1位小数+V单位) */
    ui_label_show_float_num(label_temp,motor_info.mosfet_temp,3," degC",5);     /* 显示MOS管温度 */
    /* ui_label_show_int_num(label_temp,(int32_t)motor_info.mosfet_temp,3," degC",5); */   /* 已停用写法 */
}


/*******************************************************************************
*  局部函数定义
*******************************************************************************/
/**
  * @brief 对象事件回调
  * @param void
  * @retval	无
  * @note
  */
static void ui_monitor_event_cb(lv_obj_t* obj, lv_event_t event)
{
    motor_control_t motor_info;         /* 电机状态数据结构体 */
    motor_get_data(&motor_info);        /* 获取最新电机状态数据 */

    if(event == LV_EVENT_KEY)           /* 按键事件(编码器/按键经ui_event_send转发) */
    {
        ui_event_t *e = (ui_event_t *)lv_event_get_data();  /* 取出事件数据(具体按键事件类型) */
        switch (*e)                     /* 按具体按键事件类型分支处理 */
        {
        case KEY_EVENT_ENC0_INC:        /* 编码器正转:给定转速提高 */
            if(motor_info.speed_input < motor_normal_spd)       /* 给定转速低于额定转速才允许增加 */
            {
                motor_set_speed(motor_info.speed_input + 100);  /* 给定转速提高100RPM */
            }
            break;                      /* 跳出分支 */
        case KEY_EVENT_ENC0_DEC:        /* 编码器反转:给定转速降低 */
            if(motor_info.speed_input > 0)      /* 给定转速大于0才允许减小 */
            {
                if(motor_info.speed_input > (open_loop_speed + 100))    /* 高于开环切换速度+100RPM */
                    motor_set_speed(motor_info.speed_input - 100);      /* 给定转速降低100RPM */
                else
                    motor_set_speed(open_loop_speed);   /* 钳位到开环切换速度(不进入开环区以下) */
            }
            break;                      /* 跳出分支 */
        case KEY_EVENT_KEY0_REL:        /* KEY0短按释放:启动/停止切换 */
            motor_get_data(&motor_info);        /* 重新获取电机状态(确保启停判断准确) */
            if(motor_info.state == RUN)         /* 正在运行 */
            {
                motor_stop();                   /* 停止电机 */
            }
            else if((motor_info.state == STOP) || (motor_info.state == FAULT))  /* 停止或故障状态 */
            {
                motor_start();                  /* 启动电机 */
            }
            break;                      /* 跳出分支 */
        case KEY_EVENT_KEY0_LONG_PRE:   /* KEY0长按:切换页面 */
            mainwindow_cutover_page();          /* 切换到下一个页面 */
            break;                      /* 跳出分支 */
        default:                        /* 其他事件不处理 */
            break;                      /* 跳出分支 */
        }
    }
    else if(event == LV_EVENT_REFRESH)  /* 刷新事件 */
    {
        ui_monitor_update();            /* 更新监视页全部数据显示 */
    }
}

/**
  * @brief 幂运算(求m的n次方)
  * @param m - 底数
           n - 指数
  * @retval	幂运算结果
  * @note
  */
uint32_t my_pow(uint8_t m,uint8_t n)
{
	/* 结果变量初始化为1 */
	uint32_t result=1;	 
	/* 连乘n次底数 */
	while(n--)result*=m;
	/* 返回幂运算结果 */
	return result;
}

/**
  * @brief 标签显示整数数值
  * @param label - 标签对象
           num - 待显示的数值
           len - 显示长度(整数位数)
           unit_text - 单位文本
           unit_len - 单位长度
  * @retval	无
  * @note
  */
static void ui_label_show_int_num(lv_obj_t *label,int32_t num,uint8_t len,const char * unit_text,uint8_t unit_len)
{
    uint8_t label_array[32] = {0};      /* 字符串构建缓冲区 */
    uint8_t text_index = 0;             /* 当前写入位置索引 */
    uint8_t header = 0;                 /* 有效数字开始标志(实现前导零抑制) */
    uint32_t u32_num = 0;               /* 数值绝对值(无符号逐位运算用) */
    uint8_t t,temp;                     /* 循环变量/当前位数字 */
    uint8_t i = 0;                      /* 循环变量(本函数未使用,保留) */

    if(num == 0)                        /* 数值为0直接显示字符'0' */
    {
        label_array[text_index++] = 0x30;       /* 写入字符'0' */
    }
    else                                /* 非0数值逐位提取 */
    {
        if(num > 0)                     /* 正数 */
        {
            u32_num = num;              /* 直接取值 */
        }
        else                            /* 负数 */
        {
            u32_num = -num;             /* 取绝对值 */
            label_array[text_index++] = '-';    /* 先写入负号 */
        }
        for(t=0;t<len;t++)              /* 从最高位到最低位逐位提取 */
        {
            temp = (u32_num/my_pow(10,len-t-1))%10;     /* 提取当前位数字(除以位权取余) */
            if((temp > 0) || (header != 0))     /* 遇到首个有效数字后才开始写入 */
            {
                header = 1;                     /* 置有效数字标志 */
                label_array[text_index++] = temp + 0x30;    /* 数字转ASCII字符写入 */
            }
        }
    }

    while(unit_len)                     /* 追加单位文本 */
    {
        label_array[text_index++] = *unit_text++;       /* 逐字符复制单位 */
        unit_len--;                     /* 剩余单位长度递减 */
    }
    lv_label_set_array_text(label, (const char*)label_array, text_index);       /* 设置标签显示的字符数组 */
}

/**
  * @brief 标签显示浮点数值(1位小数)
  * @param label - 标签对象
           num - 待显示的数值
           len - 显示长度(整数位数)
           unit_text - 单位文本
           unit_len - 单位长度
  * @retval	无
  * @note
  */
static void ui_label_show_float_num(lv_obj_t *label,float num,uint8_t len,const char * unit_text,uint8_t unit_len)
{
    uint8_t label_array[32] = {0};      /* 字符串构建缓冲区 */
    uint8_t text_index = 0;             /* 当前写入位置索引 */
    uint8_t header = 0;                 /* 有效数字开始标志(实现前导零抑制) */
    uint32_t u32_num = 0;               /* 整数部分(无符号逐位运算用) */
    uint8_t decimals = 0;               /* 小数位数字 */
    uint8_t t,temp;                     /* 循环变量/当前位数字 */
    uint8_t i = 0;                      /* 循环变量(本函数未使用,保留) */

    if((num >= -0.05f) && (num <= 0.05f))       /* 数值接近0直接显示字符'0' */
    {
        label_array[text_index++] = 0x30;       /* 写入字符'0' */
    }
    else                                /* 非0数值逐位提取整数部分 */
    {
        if(num > 0)                     /* 正数 */
        {
            u32_num = (uint32_t)num;    /* 截取整数部分 */
        }
        else                            /* 负数 */
        {
            u32_num = -(uint32_t)num;   /* 整数部分取负(绝对值) */
            label_array[text_index++] = '-';    /* 先写入负号 */
        }
        for(t=0;t<len;t++)              /* 从最高位到最低位逐位提取 */
        {
            temp = (u32_num/my_pow(10,len-t-1))%10;     /* 提取当前位数字(除以位权取余) */
            if((temp > 0) || (header != 0))     /* 遇到首个有效数字后才开始写入 */
            {
                header = 1;                     /* 置有效数字标志 */
                label_array[text_index++] = temp + 0x30;    /* 数字转ASCII字符写入 */
            }
        }
        if(header == 0)                 /* 整数部分为0(如0.5) */
        {
            label_array[text_index++] = 0x30;   /* 整数位补写'0' */
        }
    }
    decimals = (uint32_t)(num * 10.0f) % 10;    /* 计算小数位数字(放大10倍后取余) */
    label_array[text_index++] = '.';            /* 写入小数点 */
    label_array[text_index++] = decimals + 0x30;    /* 小数位数字转ASCII字符写入 */

    while(unit_len)                     /* 追加单位文本 */
    {
        label_array[text_index++] = *unit_text++;       /* 逐字符复制单位 */
        unit_len--;                     /* 剩余单位长度递减 */
    }
    lv_label_set_array_text(label, (const char*)label_array, text_index);       /* 设置标签显示的字符数组 */
}

/***************************************** 文件结束 *********************************************/
