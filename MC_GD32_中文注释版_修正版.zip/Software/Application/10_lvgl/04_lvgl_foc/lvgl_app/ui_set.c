/*
*******************************************************************************************************
*
* 文件名称 : ui_set.c
* 版    本 : V1.0
* 作    者 : mzy2364
* 创建日期 : 2025-3-17
* 说    明 : LVGL设置界面(电机参数编辑页)：控件创建/事件回调/参数设置
*
*******************************************************************************************************
*/

/*******************************************************************************
* 头文件包含
*******************************************************************************/
#include "mainwindow.h"     /* 主窗口UI头文件(页面接口/UI事件类型定义) */
#include <stdio.h>          /* 标准输入输出库(sprintf格式化参数值) */
#include "ee_parameter.h"   /* EEPROM电机参数头文件(参数变量与读写接口) */

/*******************************************************************************
* 宏定义
*******************************************************************************/
#define SET_ITEM_NUM    11      /* 设置页参数项总数(标签数组大小与之对应) */

/*******************************************************************************
* 宏与类型定义
*******************************************************************************/
typedef enum{                           /* 编码器旋钮工作状态枚举 */
	KNOB_SELECT = 0,		/* 编码器用于选择(上下移动列表选中项) */
	KNOB_SET,				/* 编码器用于设置(增减当前参数值) */
}knob_status_t;                         /* 编码器工作状态类型 */

/*******************************************************************************
* 全局常量定义
*******************************************************************************/

/*******************************************************************************
* 局部常量定义
*******************************************************************************/

/*******************************************************************************
* 全局变量定义
*******************************************************************************/
extern uint16_t motor_r;                /* 相电阻，单位:mR(毫欧) */
extern uint16_t motor_l;                /* 相电感，单位:uH(微亨) */
extern uint16_t motor_bemf;             /* 反电动势常数，单位:mV/KRPM */
extern uint8_t motor_pole;              /* 电机极对数 */
extern uint16_t motor_normal_spd;       /* 额定转速，单位:RPM */
extern uint8_t openloop_current;        /* 开环电流给定，单位:0.1A */
extern uint8_t rotor_lock_time;         /* 转子锁定时间，单位:0.1s */
extern uint16_t openloop_ramp_time;     /* 开环斜坡时间，单位:0.1s */
extern uint16_t openloop_hold_time;     /* 开环保持时间，单位:0.1s */
extern uint16_t open_loop_speed;        /* 开环切换速度，单位:RPM */
extern uint8_t motor_sensor;            /* 位置传感器类型:0-无感 1-霍尔 */

extern lv_font_t gbk_puhui16;           /* 16号汉字字体(参数值标签显示用) */

/*******************************************************************************
* 局部变量定义
*******************************************************************************/
static lv_obj_t *label_motor_r;             /* 相电阻参数值标签 */
static lv_obj_t *label_motor_l;             /* 相电感参数值标签 */
static lv_obj_t *label_motor_bemf;          /* 反电动势常数参数值标签 */
static lv_obj_t *label_motor_pole;          /* 极对数参数值标签 */
static lv_obj_t *label_motor_rate_spd;      /* 额定转速参数值标签 */
static lv_obj_t *label_openloop_current;    /* 开环电流给定参数值标签 */
static lv_obj_t *label_rotor_lock_time;     /* 转子锁定时间参数值标签 */
static lv_obj_t *label_openloop_ramp_time;  /* 开环斜坡时间参数值标签 */
static lv_obj_t *label_openloop_hold_time;  /* 开环保持时间参数值标签 */
static lv_obj_t *label_open_loop_speed;     /* 开环切换速度参数值标签 */
static lv_obj_t *label_motor_sensor;        /* 位置传感器类型参数值标签 */

static lv_obj_t *label_flash;               /* 数码闪烁光标块(编辑位指示小矩形) */

static knob_status_t knob_status = KNOB_SELECT;     /* 编码器当前工作状态(默认选择模式) */

uint16_t parameter_increment = 1;           /* 参数增减步进位权:1/10/100/1000 */

uint8_t number_flash = 0;                   /* 闪烁相位标志(0/1交替实现闪烁) */

uint8_t index_sel = 0;                      /* 当前选中参数项索引(0~SET_ITEM_NUM-1) */
/* = {label_motor_r,label_motor_l,label_motor_bemf,label_motor_pole,
 *     label_motor_rate_spd,spinbox_motor_rate_spd}; 旧数组初始化写法(已注释停用) */
lv_obj_t *label_tab[SET_ITEM_NUM];          /* 参数值标签指针数组(下标与设置项一一对应) */

/*******************************************************************************
* 局部函数声明
*******************************************************************************/
static void ui_set_event_cb(lv_obj_t* obj, lv_event_t event);   /* 设置页对象事件回调函数 */
static void my_task_cb(lv_task_t * task);                       /* 数码闪烁软定时器任务回调 */

/*******************************************************************************
* 全局函数定义
*******************************************************************************/

/**
  * @brief 创建设置页面
  * @param parent - 父对象
  * @retval	当前页面对象
  * @note
  */
lv_obj_t *ui_set_create(lv_obj_t *parent)
{
    static lv_style_t style_list;                   /* 列表按钮常规样式 */
    static lv_style_t style_list_btn_pre;           /* 列表按钮按下样式 */
    static lv_style_t style_list_btn_tgl_pre;       /* 列表按钮选中按下样式 */
    static lv_style_t style_list_btn_label;         /* 列表按钮内参数值标签样式 */
    static lv_style_t style_flash;                  /* 闪烁光标块样式 */
    lv_style_copy(&style_list, &lv_style_pretty);                   /* 复制内置pretty样式作为基底 */
    lv_style_copy(&style_list_btn_label, &lv_style_pretty);         /* 复制内置pretty样式作为基底 */
    lv_style_copy(&style_list_btn_pre, &lv_style_pretty_color);     /* 复制内置pretty_color样式作为基底 */
    lv_style_copy(&style_list_btn_tgl_pre, &lv_style_pretty_color); /* 复制内置pretty_color样式作为基底 */
    /* style_list.body.main_color = LV_COLOR_OLIVE; */		/* 设置底色(已注释停用) */
    style_list.body.opa = LV_OPA_TRANSP;                            /* 列表按钮背景全透明 */
    style_list.body.border.color = LV_COLOR_BLUE;                   /* 列表边框颜色为蓝色 */

    style_list.text.font = &lv_font_roboto_22;                      /* 列表文字字体:Roboto 22号 */
    style_list_btn_pre.text.font = &lv_font_roboto_22;              /* 按下态文字字体:Roboto 22号 */
    style_list_btn_tgl_pre.text.font = &lv_font_roboto_22;          /* 选中按下态文字字体:Roboto 22号 */
    style_list_btn_label.text.font = &gbk_puhui16;                  /* 参数值标签字体:16号汉字字体 */
    style_list_btn_label.text.color = LV_COLOR_BLACK;               /* 参数值标签文字颜色:黑色 */

    style_list_btn_pre.body.main_color = lv_color_hex(0x9fc8ef);    /* 按下态主色:浅蓝色 */
    style_list_btn_pre.body.grad_color = lv_color_hex(0x9fc8ef);    /* 按下态渐变结束色:浅蓝色 */
    style_list_btn_pre.text.color = LV_COLOR_BLACK;                 /* 按下态文字颜色:黑色 */

    style_list_btn_tgl_pre.body.main_color = lv_color_hex(0x4169E1);    /* 选中按下态主色:皇家蓝 */
    style_list_btn_tgl_pre.body.grad_color = lv_color_hex(0x4169E1);    /* 选中按下态渐变结束色:皇家蓝 */
    style_list_btn_tgl_pre.text.color = LV_COLOR_BLACK;                 /* 选中按下态文字颜色:黑色 */

    lv_obj_t* list = lv_list_create(parent, NULL);				/* 创建list控件 */
    lv_obj_set_size(list, LV_HOR_RES_MAX, LV_VER_RES_MAX);						/* 设置尺寸 */
    lv_obj_align(list, NULL, LV_ALIGN_IN_TOP_MID, 0, 0);	/* 设置位置 */
    lv_list_set_edge_flash(list, true);						/* 当滑动到顶部或者底部的时候,有个圆圈的效果 */
    lv_list_set_single_mode(list,true);                             /* 单选模式:同一时刻仅一个按钮可选中 */
    lv_obj_set_event_cb(list, ui_set_event_cb);                     /* 注册列表事件回调 */

    lv_list_set_style(list, LV_LIST_STYLE_SCRL, &lv_style_transp);  /* 滚动区样式:透明 */
    lv_list_set_style(list, LV_LIST_STYLE_BG, &lv_style_scr);       /* 列表背景样式:屏幕样式 */
    lv_list_set_style(list, LV_LIST_STYLE_BTN_PR, &style_list_btn_pre);         /* 按钮按下样式 */
    lv_list_set_style(list, LV_LIST_STYLE_BTN_REL, &style_list);                /* 按钮释放样式 */
    lv_list_set_style(list, LV_LIST_STYLE_BTN_INA, &style_list_btn_pre);        /* 按钮禁用样式 */

    lv_list_set_style(list, LV_LIST_STYLE_BTN_TGL_REL, &style_list);            /* 按钮选中释放样式 */
    lv_list_set_style(list, LV_LIST_STYLE_BTN_TGL_PR, &style_list_btn_tgl_pre); /* 按钮选中按下样式 */

    lv_obj_t* list_btn;                                             /* 列表按钮指针(逐项创建参数行) */

    list_btn = lv_list_add_btn(list, NULL, "RES(mR)");              /* 添加"相电阻"设置项 */
    lv_btn_set_layout(list_btn, LV_LAYOUT_OFF);			/* 重新设置一下btn的layout使得后面的对齐可用 */
    label_motor_r = lv_label_create(list_btn,NULL);                 /* 在按钮上创建参数值标签 */
    lv_label_set_style(label_motor_r,LV_LABEL_STYLE_MAIN,&style_list_btn_label);    /* 设置标签样式 */
    lv_label_set_text(label_motor_r,"Manual");                      /* 设置标签初始文本(刷新后被参数值覆盖) */
    lv_obj_align(label_motor_r, list_btn, LV_ALIGN_IN_RIGHT_MID, -12, 0);    /* 右对齐到按钮 */
    
    label_flash = lv_cont_create(list_btn,NULL);                    /* 在相电阻按钮内创建闪烁光标块容器 */
    lv_style_copy(&style_flash, lv_cont_get_style(label_flash,LV_CONT_STYLE_MAIN)); /* 复制容器样式 */
    style_flash.body.radius = 0;                    /* 圆角半径0(直角光标块) */
    style_flash.body.border.width = 0;              /* 无边框 */
    style_flash.body.opa = 255;                     /* 完全不透明 */
    style_flash.body.grad_color = lv_color_hex(0x4169E1);   /* 渐变结束色:皇家蓝 */
    style_flash.body.main_color = lv_color_hex(0x4169E1);   /* 主色:皇家蓝(纯色块) */
    style_flash.body.padding.top = 0;               /* 顶部内边距0 */
    style_flash.body.padding.bottom = 0;            /* 底部内边距0 */
    style_flash.body.padding.inner = 0;             /* 内部子对象间距0 */
    style_flash.body.padding.left = 0;              /* 左侧内边距0 */
    style_flash.body.padding.right = 0;             /* 右侧内边距0 */
    lv_cont_set_style(label_flash,LV_CONT_STYLE_MAIN,&style_flash); /* 应用光标块样式 */
    lv_obj_set_size(label_flash,11,lv_obj_get_height(label_motor_r));   /* 尺寸:宽11像素,高同参数值标签 */
    lv_obj_align(label_flash, label_motor_r, LV_ALIGN_IN_RIGHT_MID, 0, 0);  /* 对齐到参数值标签右端 */
    lv_obj_set_hidden(label_flash,true);            /* 初始隐藏(进入设置模式才显示) */


    list_btn = lv_list_add_btn(list, NULL, "IND(uH)");              /* 添加"相电感"设置项 */
    lv_btn_set_layout(list_btn, LV_LAYOUT_OFF);			/* 重新设置一下btn的layout使得后面的对齐可用 */
    label_motor_l = lv_label_create(list_btn,NULL);                 /* 在按钮上创建参数值标签 */
    lv_label_set_style(label_motor_l,LV_LABEL_STYLE_MAIN,&style_list_btn_label);    /* 设置标签样式 */
    lv_label_set_text(label_motor_l," ");                           /* 设置标签初始文本(空格占位) */
    lv_obj_align(label_motor_l, list_btn, LV_ALIGN_IN_RIGHT_MID, -12, 0);    /* 右对齐到按钮 */

    list_btn = lv_list_add_btn(list, NULL, "BEMF(mV)");             /* 添加"反电动势常数"设置项 */
    lv_btn_set_layout(list_btn, LV_LAYOUT_OFF);			/* 重新设置一下btn的layout使得后面的对齐可用 */
    label_motor_bemf = lv_label_create(list_btn,NULL);              /* 在按钮上创建参数值标签 */
    lv_label_set_style(label_motor_bemf,LV_LABEL_STYLE_MAIN,&style_list_btn_label); /* 设置标签样式 */
    lv_label_set_text(label_motor_bemf," ");                        /* 设置标签初始文本(空格占位) */
    lv_obj_align(label_motor_bemf, list_btn, LV_ALIGN_IN_RIGHT_MID, -12, 0);    /* 右对齐到按钮 */

    list_btn = lv_list_add_btn(list, NULL, "POLE");                 /* 添加"极对数"设置项 */
    lv_btn_set_layout(list_btn, LV_LAYOUT_OFF);			/* 重新设置一下btn的layout使得后面的对齐可用 */
    label_motor_pole = lv_label_create(list_btn,NULL);              /* 在按钮上创建参数值标签 */
    lv_label_set_style(label_motor_pole,LV_LABEL_STYLE_MAIN,&style_list_btn_label); /* 设置标签样式 */
    lv_label_set_text(label_motor_pole," ");                        /* 设置标签初始文本(空格占位) */
    lv_obj_align(label_motor_pole, list_btn, LV_ALIGN_IN_RIGHT_MID, -12, 0);    /* 右对齐到按钮 */

    list_btn = lv_list_add_btn(list, NULL, "RateRPM");              /* 添加"额定转速"设置项 */
    lv_btn_set_layout(list_btn, LV_LAYOUT_OFF);                     /* 关闭按钮默认布局(使自定义对齐生效) */
    label_motor_rate_spd = lv_label_create(list_btn,NULL);          /* 在按钮上创建参数值标签 */
    lv_label_set_style(label_motor_rate_spd,LV_LABEL_STYLE_MAIN,&style_list_btn_label); /* 设置标签样式 */
    lv_label_set_text(label_motor_rate_spd," ");                    /* 设置标签初始文本(空格占位) */
    lv_obj_align(label_motor_rate_spd, list_btn, LV_ALIGN_IN_RIGHT_MID, -12, 0);    /* 右对齐到按钮 */
    
    list_btn = lv_list_add_btn(list, NULL, "OLAMP");                /* 添加"开环电流给定"设置项 */
    lv_btn_set_layout(list_btn, LV_LAYOUT_OFF);                     /* 关闭按钮默认布局(使自定义对齐生效) */
    label_openloop_current = lv_label_create(list_btn,NULL);        /* 在按钮上创建参数值标签 */
    lv_label_set_style(label_openloop_current,LV_LABEL_STYLE_MAIN,&style_list_btn_label);   /* 设置标签样式 */
    lv_label_set_text(label_openloop_current," ");                  /* 设置标签初始文本(空格占位) */
    lv_obj_align(label_openloop_current, list_btn, LV_ALIGN_IN_RIGHT_MID, -12, 0);    /* 右对齐到按钮 */
    
    list_btn = lv_list_add_btn(list, NULL, "OL_LockT");             /* 添加"转子锁定时间"设置项 */
    lv_btn_set_layout(list_btn, LV_LAYOUT_OFF);                     /* 关闭按钮默认布局(使自定义对齐生效) */
    label_rotor_lock_time = lv_label_create(list_btn,NULL);         /* 在按钮上创建参数值标签 */
    lv_label_set_style(label_rotor_lock_time,LV_LABEL_STYLE_MAIN,&style_list_btn_label);    /* 设置标签样式 */
    lv_label_set_text(label_rotor_lock_time," ");                   /* 设置标签初始文本(空格占位) */
    lv_obj_align(label_rotor_lock_time, list_btn, LV_ALIGN_IN_RIGHT_MID, -12, 0);    /* 右对齐到按钮 */
    
    list_btn = lv_list_add_btn(list, NULL, "OL_RampT");             /* 添加"开环斜坡时间"设置项 */
    lv_btn_set_layout(list_btn, LV_LAYOUT_OFF);                     /* 关闭按钮默认布局(使自定义对齐生效) */
    label_openloop_ramp_time = lv_label_create(list_btn,NULL);      /* 在按钮上创建参数值标签 */
    lv_label_set_style(label_openloop_ramp_time,LV_LABEL_STYLE_MAIN,&style_list_btn_label); /* 设置标签样式 */
    lv_label_set_text(label_openloop_ramp_time," ");                /* 设置标签初始文本(空格占位) */
    lv_obj_align(label_openloop_ramp_time, list_btn, LV_ALIGN_IN_RIGHT_MID, -12, 0);    /* 右对齐到按钮 */
    
    list_btn = lv_list_add_btn(list, NULL, "OL_HoldT");             /* 添加"开环保持时间"设置项 */
    lv_btn_set_layout(list_btn, LV_LAYOUT_OFF);                     /* 关闭按钮默认布局(使自定义对齐生效) */
    label_openloop_hold_time = lv_label_create(list_btn,NULL);      /* 在按钮上创建参数值标签 */
    lv_label_set_style(label_openloop_hold_time,LV_LABEL_STYLE_MAIN,&style_list_btn_label); /* 设置标签样式 */
    lv_label_set_text(label_openloop_hold_time," ");                /* 设置标签初始文本(空格占位) */
    lv_obj_align(label_openloop_hold_time, list_btn, LV_ALIGN_IN_RIGHT_MID, -12, 0);    /* 右对齐到按钮 */
    
    list_btn = lv_list_add_btn(list, NULL, "OL_SPD");               /* 添加"开环切换速度"设置项 */
    lv_btn_set_layout(list_btn, LV_LAYOUT_OFF);                     /* 关闭按钮默认布局(使自定义对齐生效) */
    label_open_loop_speed = lv_label_create(list_btn,NULL);         /* 在按钮上创建参数值标签 */
    lv_label_set_style(label_open_loop_speed,LV_LABEL_STYLE_MAIN,&style_list_btn_label);    /* 设置标签样式 */
    lv_label_set_text(label_open_loop_speed," ");                   /* 设置标签初始文本(空格占位) */
    lv_obj_align(label_open_loop_speed, list_btn, LV_ALIGN_IN_RIGHT_MID, -12, 0);    /* 右对齐到按钮 */

    list_btn = lv_list_add_btn(list, NULL, "SENSOR");               /* 添加"位置传感器类型"设置项 */
    lv_btn_set_layout(list_btn, LV_LAYOUT_OFF);                     /* 关闭按钮默认布局(使自定义对齐生效) */
    label_motor_sensor = lv_label_create(list_btn,NULL);            /* 在按钮上创建参数值标签 */
    lv_label_set_style(label_motor_sensor,LV_LABEL_STYLE_MAIN,&style_list_btn_label);   /* 设置标签样式 */
    lv_label_set_text(label_motor_sensor," ");                      /* 设置标签初始文本(空格占位) */
    lv_obj_align(label_motor_sensor, list_btn, LV_ALIGN_IN_RIGHT_MID, -12, 0);    /* 右对齐到按钮 */

    lv_list_set_btn_selected(list, lv_list_get_next_btn(list, NULL));   /* 默认选中第一个列表项 */
    
    lv_task_t * task = lv_task_create(my_task_cb, 300, LV_TASK_PRIO_MID, NULL);    /* 数码闪烁定时任务 */

    label_tab[0] = label_motor_r;               /* 索引0:相电阻 */
    label_tab[1] = label_motor_l;               /* 索引1:相电感 */
    label_tab[2] = label_motor_bemf;            /* 索引2:反电动势常数 */
    label_tab[3] = label_motor_pole;            /* 索引3:极对数 */
    label_tab[4] = label_motor_rate_spd;        /* 索引4:额定转速 */
    label_tab[5] = label_openloop_current;      /* 索引5:开环电流给定 */
    label_tab[6] = label_rotor_lock_time;       /* 索引6:转子锁定时间 */
    label_tab[7] = label_openloop_ramp_time;    /* 索引7:开环斜坡时间 */
    label_tab[8] = label_openloop_hold_time;    /* 索引8:开环保持时间 */
    label_tab[9] = label_open_loop_speed;       /* 索引9:开环切换速度 */
    label_tab[10] = label_motor_sensor;         /* 索引10:位置传感器类型 */
    
    return list;                                /* 返回创建完成的设置页列表对象 */
}

/*******************************************************************************
* 局部函数定义
*******************************************************************************/

/* 按索引读取参数当前值(索引0~10与设置项顺序一一对应) */
static uint32_t parameter_get_value(uint8_t index)
{
    switch(index)                       /* 按参数项索引分支返回对应变量值 */
    {
        case 0:                         /* 项0:相电阻 */
            return motor_r;             /* 返回相电阻值 */
            break;                      /* 跳出分支 */
        case 1:                         /* 项1:相电感 */
            return motor_l;             /* 返回相电感值 */
            break;                      /* 跳出分支 */
        case 2:                         /* 项2:反电动势常数 */
            return motor_bemf;          /* 返回反电动势常数值 */
            break;                      /* 跳出分支 */
        case 3:                         /* 项3:极对数 */
            return motor_pole;          /* 返回极对数值 */
            break;                      /* 跳出分支 */
        case 4:                         /* 项4:额定转速 */
            return motor_normal_spd;    /* 返回额定转速值 */
            break;                      /* 跳出分支 */
        case 5:                         /* 项5:开环电流给定 */
            return openloop_current;    /* 返回开环电流给定值 */
            break;                      /* 跳出分支 */
        case 6:                         /* 项6:转子锁定时间 */
            return rotor_lock_time;     /* 返回转子锁定时间值 */
            break;                      /* 跳出分支 */
        case 7:                         /* 项7:开环斜坡时间 */
            return openloop_ramp_time;  /* 返回开环斜坡时间值 */
            break;                      /* 跳出分支 */
        case 8:                         /* 项8:开环保持时间 */
            return openloop_hold_time;  /* 返回开环保持时间值 */
            break;                      /* 跳出分支 */
        case 9:                         /* 项9:开环切换速度 */
            return open_loop_speed;     /* 返回开环切换速度值 */
            break;                      /* 跳出分支 */
        case 10:                        /* 项10:位置传感器类型 */
            return motor_sensor;        /* 返回位置传感器类型值 */
            break;                      /* 跳出分支 */
        default:                        /* 无效索引 */
            return 0;                   /* 返回0 */
            break;                      /* 跳出分支 */
    }
}

/* 按索引写入参数新值(索引含义与parameter_get_value一致) */
static void parameter_set_value(uint8_t index,uint32_t value)
{
    switch(index)                       /* 按参数项索引分支写入对应变量 */
    {
        case 0:                         /* 项0:相电阻 */
            motor_r = value;            /* 更新相电阻 */
            break;                      /* 跳出分支 */
        case 1:                         /* 项1:相电感 */
            motor_l = value;            /* 更新相电感 */
            break;                      /* 跳出分支 */
        case 2:                         /* 项2:反电动势常数 */
            motor_bemf = value;         /* 更新反电动势常数 */
            break;                      /* 跳出分支 */
        case 3:                         /* 项3:极对数 */
            motor_pole = value;         /* 更新极对数 */
            break;                      /* 跳出分支 */
        case 4:                         /* 项4:额定转速 */
            motor_normal_spd = value;   /* 更新额定转速 */
            break;                      /* 跳出分支 */
        case 5:                         /* 项5:开环电流给定 */
            openloop_current = value;   /* 更新开环电流给定 */
            break;                      /* 跳出分支 */
        case 6:                         /* 项6:转子锁定时间 */
            rotor_lock_time = value;    /* 更新转子锁定时间 */
            break;                      /* 跳出分支 */
        case 7:                         /* 项7:开环斜坡时间 */
            openloop_ramp_time = value; /* 更新开环斜坡时间 */
            break;                      /* 跳出分支 */
        case 8:                         /* 项8:开环保持时间 */
            openloop_hold_time = value; /* 更新开环保持时间 */
            break;                      /* 跳出分支 */
        case 9:                         /* 项9:开环切换速度 */
            open_loop_speed = value;    /* 更新开环切换速度 */
            break;                      /* 跳出分支 */
        case 10:                        /* 项10:位置传感器类型 */
            motor_sensor = value;       /* 更新位置传感器类型 */
            if(motor_sensor > 1)        /* 越界保护:类型仅允许0/1 */
                motor_sensor = 1;       /* 大于1强制钳位为1(霍尔) */
            break;                      /* 跳出分支 */
        default:                        /* 无效索引 */
            break;                      /* 直接跳出(不修改任何参数) */
    }
}

/**
  * @brief 数码闪烁定时任务(300ms周期调用,编辑位光标闪烁)
  * @param void
  * @retval	无
  * @note
  */
static void my_task_cb(lv_task_t * task)
{
    char value_buf[16] = {0};           /* 字符缓冲区(本任务中未使用,保留) */
    int16_t y_pos = 0;                  /* 光标块水平偏移量(随位权逐位左移) */
    uint8_t len = 0;                    /* 长度变量(本任务中未使用,保留) */

    if(knob_status == KNOB_SET)         /* 设置模式才显示闪烁光标 */
    {
        if(parameter_increment == 1)    /* 位权为1:光标指示个位 */
        {
            y_pos = 0;                  /* 偏移0(最右侧数字) */
        }
        else if(parameter_increment == 10)      /* 位权为10:光标指示十位 */
        {
            y_pos = -11;                /* 左移11像素(约一个数字宽度) */
        }
        else if(parameter_increment == 100)     /* 位权为100:光标指示百位 */
        {
            y_pos = -22;                /* 左移22像素(两个数字宽度) */
        }
        else if(parameter_increment == 1000)    /* 位权为1000:光标指示千位 */
        {
            y_pos = -33;                /* 左移33像素(三个数字宽度) */
        }

        if(number_flash)                /* 闪烁相位1:光标显示 */
        {
            lv_obj_set_hidden(label_flash,number_flash);    /* 显示光标块(number_flash=1不隐藏) */
            /* 光标块对齐到当前选中项参数值右端,并按位权水平偏移到对应数字位 */
            lv_obj_align(label_flash, label_tab[index_sel], LV_ALIGN_IN_RIGHT_MID, y_pos, 0);
            lv_obj_realign(label_flash);            /* 重新按对齐规则摆放光标块 */
        }
        else                            /* 闪烁相位0:光标隐藏 */
        {
            lv_obj_set_hidden(label_flash,number_flash);    /* 隐藏光标块(number_flash=0) */
            /* 光标块对齐到当前选中项参数值右端,并按位权水平偏移到对应数字位 */
            lv_obj_align(label_flash, label_tab[index_sel], LV_ALIGN_IN_RIGHT_MID, y_pos, 0);
            lv_obj_realign(label_flash);            /* 重新按对齐规则摆放光标块 */
        }
    }
    else                                /* 选择模式:不显示光标 */
    {
        lv_obj_set_hidden(label_flash,true);    /* 隐藏光标块 */
    }
    number_flash = 1 - number_flash;    /* 翻转闪烁相位,实现300ms亮灭交替 */
}

/**
  * @brief 设置页对象事件回调
  * @param void
  * @retval	无
  * @note
  */
static void ui_set_event_cb(lv_obj_t* obj, lv_event_t event)
{
    lv_obj_t *sel_btn = NULL;           /* 当前选中的按钮指针 */
    lv_obj_t *next_btn = NULL;          /* 下一个按钮指针 */
    lv_obj_t *prev_btn = NULL;          /* 上一个按钮指针 */
    uint8_t i = 0;                      /* 循环计数索引 */

    char value_buf[16] = {0};           /* 参数值格式化缓冲区 */

    if(event == LV_EVENT_KEY)           /* 按键事件(编码器/按键经ui_event_send转发) */
    {
        ui_event_t *e = (ui_event_t *)lv_event_get_data();  /* 取出事件数据(具体按键事件类型) */
        sel_btn = lv_list_get_btn_selected(obj);            /* 获取列表当前选中的按钮 */
        index_sel = lv_list_get_btn_index(obj,sel_btn);     /* 记录选中项索引(0~10) */
        switch (*e)                     /* 按具体按键事件类型分支处理 */
        {
        case KEY_EVENT_ENC0_INC:        /* 编码器正转(增量) */
            if(knob_status == KNOB_SELECT)      /* 选择模式:移动选中项 */
            {
                next_btn = lv_list_get_next_btn(obj,sel_btn);   /* 获取下一个按钮 */
                if(next_btn)                    /* 存在下一项 */
                    lv_list_set_btn_selected(obj, next_btn);    /* 选中下一项(光标下移) */
            }
            else                        /* 设置模式:修改参数值 */
            {
                /* 当前参数值增加一个步进(位权) */
                parameter_set_value(index_sel,parameter_get_value(index_sel) + parameter_increment);
                lv_event_send(obj, LV_EVENT_REFRESH, NULL);     /* 发送刷新事件,更新全部参数标签 */
            }
            break;                      /* 跳出分支 */
        case KEY_EVENT_ENC0_DEC:        /* 编码器反转(减量) */
			if(knob_status == KNOB_SELECT)      /* 选择模式:移动选中项 */
			{
				prev_btn = lv_list_get_prev_btn(obj,sel_btn);   /* 获取上一个按钮 */
				if(prev_btn)                    /* 存在上一项 */
					lv_list_set_btn_selected(obj, prev_btn);    /* 选中上一项(光标上移) */
			}
			else                        /* 设置模式:修改参数值 */
            {
                /* 当前参数值减少一个步进(位权) */
                parameter_set_value(index_sel,parameter_get_value(index_sel) - parameter_increment);
                lv_event_send(obj, LV_EVENT_REFRESH, NULL);     /* 发送刷新事件,更新全部参数标签 */
            }
            break;                      /* 跳出分支 */
        case KEY_EVENT_KEY0_REL:        /* KEY0短按释放 */
            if(knob_status == KNOB_SELECT)      /* 选择模式:进入设置模式 */
            {
                knob_status = KNOB_SET;         /* 切换到设置模式 */
                lv_btn_set_state(sel_btn,LV_BTN_STATE_TGL_PR);  /* 按钮置为选中按下态(高亮提示进入编辑) */

                lv_obj_set_parent(label_flash,label_tab[index_sel]);    /* 光标块挂载到当前选中项下 */
                parameter_increment = 1;        /* 步进位权复位为1(从个位开始编辑) */
            }
            else                        /* 设置模式:切换步进位权 */
            {
                if(parameter_increment < 1000)      /* 位权未达到最大 */
                {
                    parameter_increment = parameter_increment * 10;     /* 位权×10:1→10→100→1000 */
                }
                else                        /* 已达最大位权1000 */
                {
                    parameter_increment = 1;    /* 回到最小位权1 */
                }
            }
            break;                      /* 跳出分支 */
        case KEY_EVENT_KEY0_LONG_PRE:   /* KEY0长按 */
            if(knob_status == KNOB_SELECT)      /* 选择模式:保存参数并切换页面 */
            {
                eeprom_save_parameter();        /* 将全部电机参数保存到EEPROM */
                mainwindow_cutover_page();      /* 切换回主窗口(监控页) */
            }
            else                        /* 设置模式:确认修改并退出编辑 */
            {
                /* 确认 保存 */
                lv_obj_set_hidden(label_flash,true);    /* 隐藏闪烁光标块 */
                knob_status = KNOB_SELECT;              /* 返回选择模式 */
                lv_btn_set_state(sel_btn,LV_BTN_STATE_PR);      /* 按钮恢复按下态外观 */
            }
            break;                      /* 跳出分支 */
        default:                        /* 其他事件不处理 */
            break;                      /* 跳出分支 */
        }
    }
    else if(event == LV_EVENT_FOCUSED)  /* 页面获得焦点事件(切入设置页) */
    {
        motor_stop();                   /* 进入设置页先停止电机(安全保护) */
        lv_list_set_btn_selected(obj, lv_list_get_next_btn(obj, NULL));     /* 选中第一个列表项 */
    }
    else if(event == LV_EVENT_REFRESH)  /* 刷新事件(参数增减后触发) */
    {
        for(i=0;i<SET_ITEM_NUM;i++)     /* 遍历全部11个参数项 */
        {
            memset(value_buf,0,sizeof(value_buf));      /* 清空格式化缓冲区 */
            sprintf(value_buf,"%05d",parameter_get_value(i));   /* 按5位十进制补零格式化参数值 */
            lv_label_set_text(label_tab[i], value_buf); /* 更新第i项参数值标签文本 */
            lv_obj_realign(label_tab[i]);               /* 标签按原对齐规则重新摆放 */
        }

    }
}

/***************************************** 文件结束 *********************************************/
